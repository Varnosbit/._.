const { randomString, getTime, convertTime } = global.utils;
const { createCanvas, loadImage } = require('canvas');
const https = require('https');
// Word lists for different lengths (you can expand these)
const wordLists = {
  "2": [
    "DO",
    "GO",
    "NO",
    "SO",
    "TO",
    "UP",
    "WE",
    "HE",
    "IT",
    "IS",
    "AS",
    "AT",
    "BE",
    "BY",
    "IF",
    "IN",
    "OF",
    "ON",
    "OR"
  ],
  "3": [
    "THE",
    "AND",
    "FOR",
    "ARE",
    "BUT",
    "NOT",
    "YOU",
    "ALL",
    "CAN",
    "HER",
    "WAS",
    "ONE",
    "OUR",
    "OUT",
    "DAY",
    "GET",
    "HAS",
    "HIM",
    "HOW",
    "ITS",
    "LET",
    "NEW",
    "NOW",
    "OLD",
    "SEE",
    "TWO",
    "WHO",
    "BOY",
    "DID",
    "END",
    "FEW",
    "GOT",
    "HIS",
    "HOT",
    "LOW",
    "MAN",
    "MAY",
    "OFF",
    "OWN",
    "PUT",
    "RUN",
    "SAD",
    "SAY",
    "SHE",
    "TOO",
    "TRY",
    "USE",
    "WAY",
    "WIN"
  ],
  "4": [
    "WORD",
    "TIME",
    "WORK",
    "LIFE",
    "YEAR",
    "GOOD",
    "BACK",
    "LONG",
    "MAKE",
    "COME",
    "HAND",
    "HIGH",
    "PART",
    "TAKE",
    "TURN",
    "TELL",
    "KNOW",
    "FIND",
    "GIVE",
    "HELP",
    "LOVE",
    "PLAY",
    "MOVE",
    "LIVE",
    "FEEL",
    "FACE",
    "EYES",
    "HEAD",
    "HOME",
    "DOOR",
    "ROOM",
    "FIRE",
    "BOOK",
    "TREE",
    "FOOD",
    "GAME",
    "BLUE",
    "SHIP",
    "MOON",
    "STAR",
    "HOPE",
    "NICE",
    "COOL",
    "BEST",
    "FAST",
    "SLOW",
    "EASY",
    "HARD",
    "REAL",
    "OPEN"
  ],
  "5": [
    "ABOUT",
    "OTHER",
    "WHICH",
    "THEIR",
    "WOULD",
    "THERE",
    "COULD",
    "FIRST",
    "AFTER",
    "THESE",
    "THINK",
    "WHERE",
    "BEING",
    "EVERY",
    "GREAT",
    "MIGHT",
    "SHALL",
    "STILL",
    "THOSE",
    "UNDER",
    "WHILE",
    "SOUND",
    "AGAIN",
    "WATER",
    "NEVER",
    "FOUND",
    "SMALL",
    "HOUSE",
    "WORLD",
    "BELOW",
    "ASKED",
    "GOING",
    "LARGE",
    "UNTIL",
    "ALONG",
    "SHALL",
    "MUSIC",
    "LIGHT",
    "BEGAN",
    "YOUNG",
    "PLACE",
    "RIGHT",
    "NIGHT",
    "OFTEN",
    "STORY",
    "MONEY",
    "HAPPY",
    "PARTY",
    "LEARN",
    "GUESS"
  ],
  "6": [
    "BEFORE",
    "SHOULD",
    "DURING",
    "FOLLOW",
    "AROUND",
    "GROUND",
    "MOTHER",
    "FATHER",
    "LITTLE",
    "ANSWER",
    "SCHOOL",
    "CHANGE",
    "FRIEND",
    "FAMILY",
    "LETTER",
    "ALWAYS",
    "ALMOST",
    "ENOUGH",
    "THOUGH",
    "ACROSS",
    "BETTER",
    "SYSTEM",
    "PERSON",
    "TWENTY",
    "TWELVE",
    "WONDER",
    "LOOKED",
    "TURNED",
    "WALKED",
    "NEEDED",
    "WANTED",
    "PLAYED",
    "WORKED",
    "CALLED",
    "HELPED",
    "AROUND",
    "MINUTE",
    "BECOME",
    "HAVING"
  ],
  "7": [
    "BETWEEN",
    "BECAUSE",
    "WITHOUT",
    "ANOTHER",
    "AGAINST",
    "NOTHING",
    "SOMEONE",
    "MORNING",
    "GETTING",
    "LOOKING",
    "RUNNING",
    "WORKING",
    "PLAYING",
    "WALKING",
    "TALKING",
    "FEELING",
    "SITTING",
    "READING",
    "WRITING",
    "SINGING",
    "DANCING",
    "JUMPING",
    "SMILING",
    "COOKING",
    "HELPING",
    "SHARING",
    "AMAZING",
    "AWESOME",
    "PERFECT",
    "SPECIAL",
    "MAGICAL",
    "MYSTERY",
    "JOURNEY",
    "THOUGHT",
    "PROBLEM",
    "MACHINE"
  ],
  "8": [
    "TOGETHER",
    "QUESTION",
    "EVERYONE",
    "ANYTHING",
    "YOURSELF",
    "ALTHOUGH",
    "REMEMBER",
    "COMPLETE",
    "CONTINUE",
    "BUILDING",
    "THINKING",
    "POSSIBLE",
    "BUSINESS",
    "PROBABLY",
    "CHILDREN",
    "SUDDENLY",
    "HAPPENED",
    "TERRIBLE",
    "HORRIBLE",
    "FAVORITE",
    "SURPRISE",
    "BIRTHDAY",
    "COMPUTER",
    "INTERNET",
    "KEYBOARD",
    "MOUNTAIN",
    "ELEPHANT",
    "DINOSAUR",
    "TREASURE",
    "PRINCESS",
    "SANDWICH",
    "HOSPITAL",
    "NOTEBOOK",
    "BATHROOM",
    "TEACHING"
  ],
  "9": [
    "DIFFERENT",
    "FOLLOWING",
    "COMMUNITY",
    "AVAILABLE",
    "EDUCATION",
    "POLITICAL",
    "YESTERDAY",
    "SOMETIMES",
    "SOMETHING",
    "IMPORTANT",
    "CAREFULLY",
    "BEAUTIFUL",
    "WONDERFUL",
    "EXCELLENT",
    "FANTASTIC",
    "ADVENTURE",
    "CELEBRATE",
    "CHOCOLATE",
    "DANGEROUS",
    "EMERGENCY",
    "FURNITURE",
    "GUARANTEE",
    "HAMBURGER",
    "KNOWLEDGE",
    "LIBRARIAN",
    "NIGHTMARE",
    "ORCHESTRA",
    "PINEAPPLE",
    "QUESTIONS",
    "RECOGNIZE",
    "SITUATION",
    "TELEPHONE"
  ],
  "10": [
    "EVERYTHING",
    "GOVERNMENT",
    "MANAGEMENT",
    "TECHNOLOGY",
    "INSTRUMENT",
    "INDIVIDUAL",
    "PARTICULAR",
    "ESPECIALLY",
    "THEMSELVES",
    "UNDERSTAND",
    "BACKGROUND",
    "BASKETBALL",
    "COMMERCIAL",
    "DEMOCRATIC",
    "ELECTRONIC",
    "GENERATION",
    "HELICOPTER",
    "IMPOSSIBLE",
    "JOURNALISM",
    "LABORATORY",
    "NAVIGATION",
    "OPERATIONS",
    "RESTAURANT",
    "STRAWBERRY",
    "TELEVISION",
    "UNIVERSITY",
    "VEGETARIAN"
  ]
};

const difficulties = [
	{ length: 2, maxAttempts: 4, rewardPoints: 1 },
	{ length: 3, maxAttempts: 5, rewardPoints: 2 },
	{ length: 4, maxAttempts: 6, rewardPoints: 3 },
	{ length: 5, maxAttempts: 6, rewardPoints: 4 },
	{ length: 6, maxAttempts: 7, rewardPoints: 5 },
	{ length: 7, maxAttempts: 8, rewardPoints: 6 },
	{ length: 8, maxAttempts: 9, rewardPoints: 7 },
	{ length: 9, maxAttempts: 10, rewardPoints: 8 },
	{ length: 10, maxAttempts: 11, rewardPoints: 9 }
];

module.exports = {
	config: {
		name: "wordle",
		aliases: ["word"],
		version: "1.0",
		author: "Claude",
		countDown: 260,
		role: 0,
		description: {
			en: "Wordle word guessing game with multiple difficulty levels"
		},
		category: "game",
		guide: {
			en: "  {pn} [2-10] [single | multi]: create a new wordle game, with:"
				+ "\n    2-10 is the word length (default is 5)"
				+ "\n    single | multi is the game mode (default is single)"
				+ "\n   Examples:"
				+ "\n    {pn} - Creates a 5-letter word game"
				+ "\n    {pn} 6 multi - Creates a 6-letter multiplayer game"
				+ "\n"
				+ "\n   How to play: Reply to the bot's message with your word guess"
				+ "\n   🟩 Green = Correct letter in correct position"
				+ "\n   🟨 Yellow = Correct letter in wrong position"
				+ "\n   ⬜ Gray = Letter not in the word"
				+ "\n"
				+ "\n   {pn} rank <page>: View the leaderboard"
				+ "\n   {pn} stats [user]: View detailed player statistics"
				+ "\n   {pn} reset: Reset rankings (admin only)"
		}
	},

	langs: {
		en: {
			leaderboard: "🏆 | WORDLE CHAMPIONS:\n%1",
			pageInfo: "Page %1/%2",
			noScore: "🎯 | No one has played yet! Be the first champion!",
			noPermissionReset: "❌ | You don't have permission to reset rankings.",
			notFoundUser: "🔍 | User ID %1 not found in rankings.",
			playerStats: "📊 | PLAYER STATISTICS:\n👤 Name: %1\n🏆 Score: %2 points\n🎮 Games Played: %3\n✅ Wins: %4 (%5%)\n❌ Losses: %6 (%7%)\n⏱️ Avg Game Time: %8\n🎯 Best Streak: %9\n📈 Word Length Stats:\n%10",
			wordLengthStat: "  • %1-letter words: %2 wins / %3 attempts",
			resetSuccess: "✅ | Rankings reset successfully! Time for a fresh start!",
			invalidLength: "❌ | Word length must be between 2 and 10 letters!",
			invalidMode: "❌ | Game mode must be 'single' or 'multi'!",
			gameCreated: "🎯 | WORDLE GAME CREATED!\n🎮 Mode: %1\n📝 Word Length: %2 letters\n🎲 Attempts: %3\n💰 Reward: %4 points\n\n🤔 I'm thinking of a %2-letter word...",
			replyToPlay: "💬 | Reply to this message with your %1-letter word guess!",
			invalidGuess: "❌ | Please enter exactly %1 letters!",
			notAWord: "🤨 | '%1' doesn't look like a real word to me! Try again!",
			alreadyGuessed: "🙄 | You already guessed '%1'! Try something new!",
			gameWin: "🎉 | FANTASTIC! You got it!\n🎯 Word: %1\n📊 Attempts: %2/%3\n💰 Points earned: %4\n⏱️ Time: %5\n\n🎊 You're a word wizard! ✨",
			gameLose: "😅 | Game Over! Better luck next time!\n💡 The word was: %1\n📊 Your attempts: %2/%3\n⏱️ Time: %4\n\n🎯 Don't give up, champion! Practice makes perfect! 💪",
			guessResult: "🎯 | Attempt %1/%2\n⏱️ Time elapsed: %3\n\n💭 Keep going! You've got this! 🚀"
		}
	},

	onStart: async function ({ message, event, getLang, commandName, args, globalData, usersData, role }) {
		if (args[0] === "rank") {
			/*const rankings = await globalData.get("wordleRankings", "data", []);
			if (!rankings.length) {
				return message.reply(getLang("noScore"));
			}

			const page = parseInt(args[1]) || 1;
			const maxPerPage = 20;
			const startIndex = (page - 1) * maxPerPage;
			const endIndex = page * maxPerPage;

			const rankedPlayers = await Promise.all(
				rankings.slice(startIndex, endIndex).map(async (player, index) => {
					const userName = await usersData.getName(player.id);
					const totalGames = player.wins.length + player.losses.length;
					const winRate = totalGames > 0 ? ((player.wins.length / totalGames) * 100).toFixed(1) : 0;
					const globalRank = startIndex + index + 1;
					const medal = globalRank <= 3 ? ["🥇", "🥈", "🥉"][globalRank - 1] : `${globalRank}.`;
					
					return `${medal} ${userName}\n   💰 ${player.points} pts | 🏆 ${player.wins.length}W ${player.losses.length}L | 📊 ${winRate}%`;
				})
			);

			const totalPages = Math.ceil(rankings.length / maxPerPage);
			const leaderboardText = rankedPlayers.join("\n\n");
			
			return message.reply(
				getLang("leaderboard", leaderboardText) + 
				"\n\n" + 
				getLang("pageInfo", page, totalPages)
			);*/
			return await LB(message, usersData, globalData, args, event);
		}

		if (args[0] === "stats") {
			const rankings = await globalData.get("wordleRankings", "data", []);
			let targetID = event.senderID;
			
			if (Object.keys(event.mentions).length) {
				targetID = Object.keys(event.mentions)[0];
			} else if (event.messageReply) {
				targetID = event.messageReply.senderID;
			} else if (!isNaN(args[1])) {
				targetID = args[1];
			}

			const playerData = rankings.find(p => p.id == targetID);
			if (!playerData) {
				return message.reply(getLang("notFoundUser", targetID));
			}

			const userName = await usersData.getName(targetID);
			const totalGames = playerData.wins.length + playerData.losses.length;
			const winRate = totalGames > 0 ? ((playerData.wins.length / totalGames) * 100).toFixed(1) : 0;
			const lossRate = totalGames > 0 ? ((playerData.losses.length / totalGames) * 100).toFixed(1) : 0;
			
			const totalTime = [...playerData.wins, ...playerData.losses].reduce((sum, game) => sum + game.timeSpent, 0);
			const avgTime = totalGames > 0 ? convertTime(Math.floor(totalTime / totalGames)) : "0s";
			
			const bestStreak = playerData.bestStreak || 0;

			// Word length statistics
			const lengthStats = {};
			difficulties.forEach(diff => {
				const wins = playerData.wins.filter(w => w.wordLength === diff.length).length;
				const losses = playerData.losses.filter(l => l.wordLength === diff.length).length;
				const total = wins + losses;
				if (total > 0) {
					lengthStats[diff.length] = { wins, total };
				}
			});

			const lengthStatsText = Object.keys(lengthStats).length > 0 
				? Object.entries(lengthStats)
					.map(([length, stats]) => getLang("wordLengthStat", length, stats.wins, stats.total))
					.join("\n")
				: "  • No games completed yet";

			return message.reply(
				getLang("playerStats", 
					userName, 
					playerData.points, 
					totalGames, 
					playerData.wins.length, 
					winRate,
					playerData.losses.length, 
					lossRate,
					avgTime, 
					bestStreak,
					lengthStatsText
				)
			);
		}

		if (args[0] === "reset") {
			if (role < 2) {
				return message.reply(getLang("noPermissionReset"));
			}
			await globalData.set("wordleRankings", [], "data");
			return message.reply(getLang("resetSuccess"));
		}

		// Create new game
		const wordLength = parseInt(args[0]) || 5;
		const difficulty = difficulties.find(d => d.length === wordLength);
		
		if (!difficulty) {
			return message.reply(getLang("invalidLength"));
		}

		const mode = (args[1] || args[0] === "multi" || args[1] === "multi") ? 
			(args.includes("multi") ? "multi" : "single") : "single";
		
		if (mode !== "single" && mode !== "multi") {
			return message.reply(getLang("invalidMode"));
		}

		// Get random word
		const wordList = wordLists[wordLength];
		const targetWord = wordList[Math.floor(Math.random() * wordList.length)];

		const gameData = {
			targetWord: targetWord.toUpperCase(),
			wordLength,
			maxAttempts: difficulty.maxAttempts,
			rewardPoints: difficulty.rewardPoints,
			mode,
			attempts: [],
			guesses: [],
			timeStart: getTime("x"),
			isFinished: false,
			author: event.senderID
		};

		const gameImage = createWordleImage(gameData);
		
		const modeText = mode === "single" ? "Single Player 👤" : "Multiplayer 👥";
		const introText = getLang("gameCreated", modeText, wordLength, difficulty.maxAttempts, difficulty.rewardPoints);
		
		message.reply(introText + "\n\n" + getLang("replyToPlay", wordLength), (err, info) => {
			if (!err) {
				message.reply({
					attachment: gameImage
				}, (err2, info2) => {
					if (!err2) {
						global.GoatBot.onReply.set(info2.messageID, {
							commandName,
							messageID: info2.messageID,
							author: event.senderID,
							gameData
						});
					}
				});
			}
		});
	},

	onReply: async ({ message, Reply, event, getLang, globalData, usersData }) => {
		const { gameData } = Reply;
		
		// Check if player can play
		if (gameData.mode === "single" && event.senderID !== Reply.author) {
			return;
		}

		if (gameData.isFinished) {
			return;
		}

		const guess = event.body.trim().toUpperCase();
		
		// Validate guess length
		if (guess.length !== gameData.wordLength) {
			return message.reply(getLang("invalidGuess", gameData.wordLength));
		}

		// Check if only letters
		if (!/^[A-Z]+$/.test(guess)) {
			return message.reply(getLang("notAWord", guess));
		}

		// Check if already guessed
		if (gameData.guesses.includes(guess)) {
			return message.reply(getLang("alreadyGuessed", guess));
		}

		// Process guess
		gameData.guesses.push(guess);
		const result = processGuess(guess, gameData.targetWord);
		gameData.attempts.push({ guess, result });

		const isWin = guess === gameData.targetWord;
		const isGameOver = isWin || gameData.attempts.length >= gameData.maxAttempts;
		const timeSpent = getTime("x") - gameData.timeStart;

		if (isGameOver) {
			gameData.isFinished = true;
			await updatePlayerStats(event.senderID, gameData, isWin, timeSpent, globalData);
		}

		// Create updated image
		const gameImage = createWordleImage(gameData);
		
		// Delete old messages
		global.GoatBot.onReply.delete(Reply.messageID);
		//message.unsend(Reply.messageID);

		let f = { attachment: gameImage };
		if (isWin) {
			f.body = getLang("gameWin", 
				gameData.targetWord, 
				gameData.attempts.length, 
				gameData.maxAttempts, 
				gameData.rewardPoints,
				convertTime(timeSpent)
			);
		} else if (gameData.attempts.length >= gameData.maxAttempts) {
			f.body = getLang("gameLose", 
				gameData.targetWord, 
				gameData.attempts.length, 
				gameData.maxAttempts,
				convertTime(timeSpent)
			);
		} else {
			/*responseText = getLang("guessResult", 
				gameData.attempts.length, 
				gameData.maxAttempts,
				convertTime(timeSpent)
			);*/
		}

		message.reply(f, (err, info) => {
			if (!err && !isGameOver) {
				global.GoatBot.onReply.set(info.messageID, {
					commandName: "wordle",
					messageID: info.messageID,
					author: Reply.author,
					gameData
				});
			}
		});
	}
};

function processGuess(guess, target) {
	const result = [];
	const targetLetters = target.split('');
	const guessLetters = guess.split('');
	const used = new Array(target.length).fill(false);

	// First pass: mark correct positions (green)
	for (let i = 0; i < guessLetters.length; i++) {
		if (guessLetters[i] === targetLetters[i]) {
			result[i] = 'correct';
			used[i] = true;
		}
	}

	// Second pass: mark wrong positions (yellow) and incorrect (gray)
	for (let i = 0; i < guessLetters.length; i++) {
		if (result[i] === 'correct') continue;
		
		const letterIndex = targetLetters.findIndex((letter, index) => 
			letter === guessLetters[i] && !used[index]
		);
		
		if (letterIndex !== -1) {
			result[i] = 'present';
			used[letterIndex] = true;
		} else {
			result[i] = 'absent';
		}
	}

	return result;
}

async function updatePlayerStats(playerID, gameData, isWin, timeSpent, globalData) {
	const rankings = await globalData.get("wordleRankings", "data", []);
	let playerIndex = rankings.findIndex(p => p.id === playerID);
	
	const gameResult = {
		wordLength: gameData.wordLength,
		attempts: gameData.attempts.length,
		timeSpent,
		date: getTime(),
		word: gameData.targetWord
	};

	if (playerIndex === -1) {
		// New player
		const newPlayer = {
			id: playerID,
			points: isWin ? gameData.rewardPoints : 0,
			wins: isWin ? [gameResult] : [],
			losses: isWin ? [] : [gameResult],
			currentStreak: isWin ? 1 : 0,
			bestStreak: isWin ? 1 : 0
		};
		rankings.push(newPlayer);
	} else {
		// Existing player
		const player = rankings[playerIndex];
		
		if (isWin) {
			player.wins.push(gameResult);
			player.points += gameData.rewardPoints;
			player.currentStreak = (player.currentStreak || 0) + 1;
			player.bestStreak = Math.max(player.bestStreak || 0, player.currentStreak);
		} else {
			player.losses.push(gameResult);
			player.currentStreak = 0;
		}
		
		rankings[playerIndex] = player;
	}

	// Sort by points (descending)
	rankings.sort((a, b) => b.points - a.points);
	
	await globalData.set("wordleRankings", rankings, "data");
}

function createWordleImage(gameData) {
	const cellSize = 80;
	const cellMargin = 8;
	const padding = 40;
	const headerHeight = 120;
	
	const canvasWidth = gameData.wordLength * (cellSize + cellMargin) - cellMargin + (padding * 2);
	const canvasHeight = gameData.maxAttempts * (cellSize + cellMargin) - cellMargin + (padding * 2) + headerHeight;
	
	const canvas = createCanvas(canvasWidth, canvasHeight);
	const ctx = canvas.getContext('2d');
	
	// Background
	ctx.fillStyle = '#1a1a1a';
	ctx.fillRect(0, 0, canvasWidth, canvasHeight);
	
	// Header
	ctx.fillStyle = '#ffffff';
	ctx.font = 'bold 32px Arial';
	ctx.textAlign = 'center';
	ctx.fillText('WORDLE', canvasWidth / 2, 40);
	
	ctx.font = '18px Arial';
	ctx.fillStyle = '#888888';
	const modeText = gameData.mode === 'single' ? 'Single Player' : 'Multiplayer';
	ctx.fillText(`${gameData.wordLength} Letters • ${modeText}`, canvasWidth / 2, 70);
	ctx.fillText(`${gameData.attempts.length}/${gameData.maxAttempts} Attempts`, canvasWidth / 2, 95);
	
	// Game grid
	for (let row = 0; row < gameData.maxAttempts; row++) {
		for (let col = 0; col < gameData.wordLength; col++) {
			const x = padding + col * (cellSize + cellMargin);
			const y = headerHeight + padding + row * (cellSize + cellMargin);
			
			// Cell background
			if (row < gameData.attempts.length) {
				const attempt = gameData.attempts[row];
				const result = attempt.result[col];
				
				switch (result) {
					case 'correct':
						ctx.fillStyle = '#538d4e'; // Green
						break;
					case 'present':
						ctx.fillStyle = '#b59f3b'; // Yellow
						break;
					case 'absent':
						ctx.fillStyle = '#3a3a3c'; // Dark gray
						break;
				}
			} else {
				ctx.fillStyle = '#121213'; // Empty cell
			}
			
			// Draw cell
			drawRoundedRect(ctx, x, y, cellSize, cellSize, 4);
			
			// Border
			ctx.strokeStyle = row < gameData.attempts.length ? '#565758' : '#3a3a3c';
			ctx.lineWidth = 2;
			ctx.stroke();
			
			// Letter
			if (row < gameData.attempts.length) {
				ctx.fillStyle = '#ffffff';
				ctx.font = 'bold 36px Arial';
				ctx.textAlign = 'center';
				ctx.textBaseline = 'middle';
				ctx.fillText(
					gameData.attempts[row].guess[col], 
					x + cellSize / 2, 
					y + cellSize / 2
				);
			}
		}
	}
	
	// Game status
	if (gameData.isFinished) {
		const isWin = gameData.attempts.some(attempt => attempt.guess === gameData.targetWord);
		
		// Semi-transparent overlay
		ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
		ctx.fillRect(0, 0, canvasWidth, canvasHeight);
		
		// Result text
		ctx.fillStyle = isWin ? '#538d4e' : '#f85149';
		ctx.font = 'bold 48px Arial';
		ctx.textAlign = 'center';
		ctx.fillText(isWin ? '🎉 YOU WIN! 🎉' : '💀 GAME OVER 💀', canvasWidth / 2, canvasHeight / 2 - 40);
		
		ctx.fillStyle = '#ffffff';
		ctx.font = 'bold 24px Arial';
		ctx.fillText(`The word was: ${gameData.targetWord}`, canvasWidth / 2, canvasHeight / 2 + 20);
	}
	const x = canvas.createPNGStream();
	x.path = `wordle_${randomString(5)}.png`;
	return x;
}

function drawRoundedRect(ctx, x, y, width, height, radius) {
	ctx.beginPath();
	ctx.moveTo(x + radius, y);
	ctx.lineTo(x + width - radius, y);
	ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
	ctx.lineTo(x + width, y + height - radius);
	ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
	ctx.lineTo(x + radius, y + height);
	ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
	ctx.lineTo(x, y + radius);
	ctx.quadraticCurveTo(x, y, x + radius, y);
	ctx.closePath();
	ctx.fill();
}

function downloadImage(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (response) => {
      if (response.statusCode !== 200) return reject(new Error(`Failed to download image: ${response.statusCode}`));
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('end', () => resolve(Buffer.concat(chunks)));
      response.on('error', reject);
    }).on('error', reject);
  });
}

function convertTimeB(seconds) {
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  if (minutes < 60) return `${minutes}m ${remainingSeconds}s`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return `${hours}h ${remainingMinutes}m ${remainingSeconds}s`;
}

function truncateName(name, maxLength = 14) {
  return name.length <= maxLength ? name : name.slice(0, maxLength - 1);
}

function drawRoundedRectLB(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function drawRoundedFlag(ctx, flagImg, x, y, width, height, radius = 8) {
  ctx.save();
  
  ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
  ctx.shadowBlur = 8;
  ctx.shadowOffsetX = 2;
  ctx.shadowOffsetY = 2;
  
  drawRoundedRectLB(ctx, x, y, width, height, radius);
  ctx.clip();
  
  ctx.drawImage(flagImg, x, y, width, height);
  
  ctx.restore();
  
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
  ctx.lineWidth = 2;
  drawRoundedRectLB(ctx, x, y, width, height, radius);
  ctx.stroke();
  ctx.restore();
}

async function drawLeaderboardHeader(ctx, x, y, width, height, iconSize, currentPage, totalPages) {
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + width, y);
  ctx.lineTo(x + width, y + height);
  ctx.lineTo(x, y + height);
  ctx.closePath();
  ctx.fillStyle = "rgba(0, 0, 0, 0.4)";
  ctx.fill();

  const icon = await loadImage(await downloadImage("https://i.imgur.com/ROrnXeH.png"));
  const iconX = x + 20;
  const iconY = y + (height - iconSize) / 2;
  ctx.drawImage(icon, iconX, iconY, iconSize, iconSize);

  ctx.font = `bold ${Math.floor(height * 0.25)}px sans-serif`;
  ctx.fillStyle = "#fff";
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  const titleX = iconX + iconSize + 20;
  const titleY = y + height / 2.5;
  ctx.fillText("Wordle global leaderboard", titleX, titleY);
  ctx.font = `bold ${Math.floor(height * 0.18)}px sans-serif`;
  ctx.globalAlpha = 0.8;
  ctx.fillText(`Page ${currentPage} of ${totalPages} - Top players worldwide`, titleX, titleY + 50);
  ctx.globalAlpha = 1;
}

function drawRightTrapezoid(ctx, x, y, size, num, numColor, fillType) {
  const scale = size / 20;
  const points = [
    { x: x, y: y },
    { x: x + 14 * scale, y: y },
    { x: x + 9 * scale, y: y + 20 * scale },
    { x: x, y: y + 20 * scale }
  ];

  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  ctx.lineTo(points[1].x, points[1].y);
  ctx.lineTo(points[2].x, points[2].y);
  ctx.lineTo(points[3].x, points[3].y);
  ctx.closePath();

  const gradient = ctx.createLinearGradient(x, y, x, y + 20 * scale);
  if (fillType === 'green') {
    gradient.addColorStop(0, '#6aaa64');
    gradient.addColorStop(1, '#538d4e');
  } else if (fillType === 'yellow') {
    gradient.addColorStop(0, '#c9b458');
    gradient.addColorStop(1, '#b59f3b');
  } else if (fillType === 'grey') {
    gradient.addColorStop(0, '#787c7e');
    gradient.addColorStop(1, '#3a3a3c');
  } else {
    gradient.addColorStop(0, '#909FB3');
    gradient.addColorStop(1, '#B7ADAD');
  }

  ctx.fillStyle = gradient;
  ctx.fill();

  const centerX = x + (11.5 * scale) / 2;
  const centerY = y + 10 * scale;

  ctx.fillStyle = numColor;
  ctx.font = `bold ${Math.max(12, size / 3)}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(num.toString(), centerX, centerY);
}

async function bg(ctx, canvas) {
  const bgImg = await loadImage(await downloadImage("https://i.imgur.com/e5kSXH1.jpeg"));
  const imgW = bgImg.width;
  const imgH = bgImg.height;
  const canW = canvas.width;
  const canH = canvas.height;
  const canAspect = canW / canH;
  const imgAspect = imgW / imgH;

  let drawW, drawH, offsetX, offsetY;
  if (imgAspect > canAspect) {
    drawH = canH;
    drawW = imgW * (canH / imgH);
    offsetX = -(drawW - canW) / 2;
    offsetY = 0;
  } else {
    drawW = canW;
    drawH = imgH * (canW / imgW);
    offsetX = 0;
    offsetY = -(drawH - canH) / 2;
  }

  ctx.drawImage(bgImg, offsetX, offsetY, drawW, drawH);
}

async function LB(message, usersData, globalData, args, event) {
const width = 1080;
const height = 2280;
const canvas = createCanvas(width, height);
const ctx = canvas.getContext('2d');

const startX = 40;
const startY = 235;
const size = 190;
const spacing = 7;

await bg(ctx, canvas);

const rankings = await globalData.get("wordleRankings", "data", []);
let targetID = event.senderID;

if (Object.keys(event.mentions).length) {
  targetID = Object.keys(event.mentions)[0];
} else if (event.messageReply) {
  targetID = event.messageReply.senderID;
} else if (!isNaN(args[1])) {
  targetID = args[1];
}

const playersPerPage = 10;
const totalPages = Math.ceil(rankings.length / playersPerPage);

let currentPage = 1;
const playerIndex = rankings.findIndex(player => player.id == targetID);
if (playerIndex !== -1) {
  currentPage = Math.ceil((playerIndex + 1) / playersPerPage);
}

const startIndex = (currentPage - 1) * playersPerPage;
const endIndex = Math.min(startIndex + playersPerPage, rankings.length);
const pageRankings = rankings.slice(startIndex, endIndex);

await drawLeaderboardHeader(ctx, startX, 40, width - 2 * startX, 170, 100, currentPage, totalPages);

const rankedPlayers = await Promise.all(pageRankings.map(async (player, i) => {
  const nameRaw = await usersData.get(player.id, "data.status.name") || await usersData.getName(player.id);
  const name = truncateName(nameRaw);
  const flagUrl = await usersData.get(player.id, "data.status.flag");
  const flagImg = flagUrl ? await loadImage(await downloadImage(flagUrl)) : null;
  const wins = player.wins.length;
  const losses = player.losses.length;
  const points = player.points;
  const total = wins + losses;
  const rate = total > 0 ? ((wins / total) * 100).toFixed(1) : "0";
  
  const totalTime = [...player.wins, ...player.losses].reduce((sum, game) => sum + game.timeSpent, 0);
  const avgTime = total > 0 ? convertTimeB(Math.floor(totalTime / total)) : "0s";
  const bestStreak = player.bestStreak || 0;
  
  return { name, points, wins, losses, rate, flagImg, actualRank: startIndex + i + 1, isCurrentUser: player.id == targetID, avgTime, bestStreak };
}));

for (let i = 0; i < rankedPlayers.length; i++) {
  const player = rankedPlayers[i];
  const posY = startY + i * (size + spacing);

  const bgGradient = ctx.createLinearGradient(startX, posY, startX, posY + size);
  if (player.isCurrentUser) {
    bgGradient.addColorStop(0, 'rgba(255, 215, 0, 0.2)');
    bgGradient.addColorStop(1, 'rgba(255, 215, 0, 0.1)');
  } else {
    bgGradient.addColorStop(0, 'rgba(0, 0, 0, 0.35)');
    bgGradient.addColorStop(1, 'rgba(0, 0, 0, 0.25)');
  }
  ctx.fillStyle = bgGradient;
  ctx.fillRect(startX, posY, width - 2 * startX, size);

  let fillType = 'default';
  if (player.actualRank === 1) fillType = 'green';
  else if (player.actualRank === 2) fillType = 'yellow';
  else if (player.actualRank === 3) fillType = 'grey';

  drawRightTrapezoid(ctx, startX, posY, size, player.actualRank, '#ffffff', fillType);

  const textX = startX + size + 25;
  const nameY = posY + 50;
  const statY = posY + 110;
  const availableWidth = width - textX - 40;

  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.font = 'bold 42px Arial';
  ctx.fillStyle = player.isCurrentUser ? '#FFD700' : '#ffffff';
  
  ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
  ctx.shadowBlur = 4;
  ctx.shadowOffsetX = 2;
  ctx.shadowOffsetY = 2;
  
  ctx.fillText(player.name, textX, nameY);
  
  const nameWidth = ctx.measureText(player.name).width;
  
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;

  if (player.flagImg) {
    const flagHeight = 30;
    const flagAspectRatio = player.flagImg.width / player.flagImg.height;
    const flagWidth = flagHeight * flagAspectRatio;
    const flagX = textX + nameWidth + 20;
    const flagY = nameY + 10;
    
    drawRoundedFlag(ctx, player.flagImg, flagX, flagY, flagWidth, flagHeight, 6);
  }

  ctx.font = 'bold 24px Arial';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowBlur = 2;
  ctx.shadowOffsetX = 1;
  ctx.shadowOffsetY = 1;
  
  const stats = [
    { text: `${player.points}pt`, color: '#FFD700' },
    { text: `${player.wins}W ${player.losses}L`, color: '#87CEEB' },
    { text: `${player.rate}%`, color: '#98FB98' },
    { text: `${player.avgTime}`, color: '#FFA500' },
    { text: `${player.bestStreak}*`, color: '#FF69B4' }
  ];
  
  let currentX = textX;
  const statSpacing = availableWidth / stats.length;
  
  stats.forEach((stat, index) => {
    ctx.fillStyle = stat.color;
    const statWidth = ctx.measureText(stat.text).width;
    const maxStatWidth = statSpacing;//☠️
    
    if (statWidth > maxStatWidth) {
      const scaleFactor = maxStatWidth / statWidth;
      ctx.save();
      ctx.scale(scaleFactor, 1);
      ctx.fillText(stat.text, currentX / scaleFactor, statY);
      ctx.restore();
    } else {
      ctx.fillText(stat.text, currentX, statY);
    }
    
    currentX += statSpacing;
  });
  
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
}

const stream = canvas.createPNGStream();
stream.path = 'img.png';
return message.send({ attachment: stream });
}
