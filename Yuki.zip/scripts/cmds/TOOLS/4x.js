//2.3
const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
exports.config = {
    name: "upscale",
    aliases: ["جودة", "4k", "4x"],
    by: "Allou",
    role: 0,
    desc: {
      en: "Upscale an image.",
      ar: "تحسين دقة الصورة."
    },
    guide: "{pn} reply to image or imgUrl"
};

exports.onStart = async function({ message, event, args }) {
    try {
        const imageUrl = event.messageReply?.attachments?.[0]?.url || args.join(" ").trim();
        if (!imageUrl) return message.send("ارسل صورة او رابط صورة.");
        await message.reaction("⏳", event.messageID);
        const { data } = await axios.get(imageUrl, { responseType: "arraybuffer" });
        const imageData = Buffer.from(data);
        const upscaled = await upscaleImage(imageData);

        const outputP = "./upscaled.png";
        fs.writeFileSync(outputP, upscaled);
        await message.reaction("✅", event.messageID);
        return message.send(
            { attachment: fs.createReadStream(outputP) }, 
            () => fs.unlinkSync(outputP)
        );

    } catch (err) {
        return message.send("حدث خطأ أثناء معالجة الصورة.");
    }
};

async function upscaleImage(imageData, scale = 4) {
    const taskId = '35mgpvmkm2r8ytqchyj0y1rxgpp74f78hAccdrc2019n4rc8d2zxs7nbh69z3pb6g97bc0007rwlbcj3hfn11gzmf83h1gjnfdj0cd738ykfAgr6r479pz09n30fzpg0tc33vkvq6zhj11fbk5mjsrqAq90kn0hxmyAmys3yf0dcz5flrqxq';
    
    const { data: html } = await axios.get("https://www.iloveimg.com/upscale-image");
    const token = html.match(/"toolText":"Upscale","token":"([^"]+)"/)[1];
    const authorization = `Bearer ${token}`;
    const uploadData = new FormData();
    const fileName = `image_${Date.now()}.jpg`;
    
    uploadData.append('name', fileName);
    uploadData.append('chunk', '0');
    uploadData.append('chunks', '1');
    uploadData.append('task', taskId);
    uploadData.append('preview', '1');
    uploadData.append('pdfinfo', '0');
    uploadData.append('pdfforms', '0');
    uploadData.append('pdfresetforms', '0');
    uploadData.append('v', 'web.0');
    uploadData.append('file', imageData, { filename: fileName });

    const uploadConfig = {
      method: 'POST',
      url: 'https://api12g.iloveimg.com/v1/upload',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'sec-ch-ua-platform': '"Android"',
        'authorization': authorization,
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?1',
        'Origin': 'https://www.iloveimg.com',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://www.iloveimg.com/',
        'Accept-Language': 'en,fr;q=0.9,ar;q=0.8',
        ...uploadData.getHeaders()
      },
      data: uploadData
    };

    const uploadResponse = await axios.request(uploadConfig);
    const serverFilename = uploadResponse.data.server_filename;
    
    const upscaleData = new FormData();
    upscaleData.append('task', taskId);
    upscaleData.append('server_filename', serverFilename);
    upscaleData.append('scale', scale.toString());

    const upscaleConfig = {
      method: 'POST',
      url: 'https://api12g.iloveimg.com/v1/upscale',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'sec-ch-ua-platform': '"Android"',
        'Authorization': authorization,
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?1',
        'Origin': 'https://www.iloveimg.com',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://www.iloveimg.com/',
        'Accept-Language': 'en,fr;q=0.9,ar;q=0.8',
        ...upscaleData.getHeaders()
      },
      data: upscaleData,
      responseType: 'arraybuffer'
    };
    
    try {
      const upscaleResponse = await axios.request(upscaleConfig);
      const imageBuffer = Buffer.from(upscaleResponse.data);
      return imageBuffer;
    } catch (error) {
      throw error;
    }
}
