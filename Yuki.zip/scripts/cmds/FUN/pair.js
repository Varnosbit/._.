const Canvas = require("canvas");
const jimp = require("jimp");

this.config = {
	name: "pairing",
	aliases: ["زوجني"],
	version: "1.0.0",
	author: "Ntkhang in Goat V1 moded for Goat V2 By Allou Mohamed.",
	countDown: 5,
	role: 0,
	description: {
	    en: "Pair '-'.",
	    ar: "يزوجك 🗿"
	},
	category: "image",
	guide: "{pn}"
};

module.exports = {
	config: this.config,
	onStart: async function ({ api, args, threadsData, message, event, usersData }) {
            //    🤧    return message.reply("شوف يا اسود يا فلاح يا زنجي يا خطيئة الارض انتا كيف عايش في الدنيا دي بي لونك دا و بتتعامل طبيعي مع الناس لونك دا خطيئة فادحة على المجتمع امثالك زمان كانو فلاحين بحصدو قطن و ما بقدرو يفتحو خشمهم كانت ايام جميلة ماف عب زيك بقدر يقل ادبو او يفتح خشمو بي كلام زي دا انتا يا زنجي زمان كانو ببيعوك بالرخيص موية ما لاقي عشان تشرب و جاي تتكلم مع اسيادك انا كنتا زمان ببيعك و بفتح فيك عروض في السوق اشتري سوط و احصل على زنجي مجانا لونك دا كان زمان محظور في الدول و ياريت لي هسي محظور عشان تاني م نشوف امثالك يخ ربنا يرجع ايام زمان يا رب و صدقني ماف زول حيحبك بي لونك القذر دا يا مقرف يا منحط يا عب ما مفترض يكون عندك حقوق زاتو يا وسخ البشرية لك مني كل الكراهية يا زنجي يا اسود يا عبد");
		async function circleImage(buffer) {
			const imageBuffer = await jimp.read(buffer);
			imageBuffer.circle();
			return await imageBuffer.getBufferAsync("image/png");
		}

		const { threadID, senderID, messageID } = event;
		const threadData = await threadsData.get(threadID);
		const { members } = threadData;
		const sender = members.find(x => x.userID == senderID);
		const senderGender = sender.gender;
		const senderName = sender.name;
        const otherGender = members.filter(x => x.gender != senderGender && x.inGroup == true); //عشان ما يزوجنا اشخاص طلعو من الجروب 🐦
        const randomPersona = otherGender[Math.floor(Math.random() * otherGender.length)];
        const random = randomPersona.userID;
        const pairName = randomPersona.name;
        
		const frame = await Canvas.loadImage("https://i.pinimg.com/736x/15/fa/9d/15fa9d71cdd07486bb6f728dae2fb264.jpg");
		const avatarAuthor = await Canvas.loadImage(await circleImage(await usersData.getAvatarUrl(senderID)));
		const avatarRandom = await Canvas.loadImage(await circleImage(await usersData.getAvatarUrl(random)));

		const canvas = Canvas.createCanvas(frame.width, frame.height);
		const ctx = canvas.getContext("2d");

		const infoFrame = [
			{
				gender: "MALE",
				x: 355,
				y: 120,
				size: 80
			},
			{
				gender: "FEMALE",
				x: 250,
				y: 155,
				size: 75
			}
		];
		const drawAuthor = infoFrame.find(item => item.gender == senderGender);
		const drawRandom = infoFrame.find(item => item.gender != senderGender);

		ctx.drawImage(frame, 0, 0, frame.width, frame.height);
		ctx.drawImage(avatarAuthor, drawAuthor.x, drawAuthor.y, drawAuthor.size, drawAuthor.size);
		ctx.drawImage(avatarRandom, drawRandom.x, drawRandom.y, drawRandom.size, drawRandom.size);

        const stream = canvas.createPNGStream();
        stream.path = 'pair.png';
        const msg = `🐦 يا أعضاء الجروب: ${senderName} رسميا صار زوج\n${pairName}.\n\n🐦عقبال الذرية الصالحة يا كرنجيين ._.🤍.`;
        message.send({
          body: msg,
          attachment: stream,
          mentions: [{tag: senderName, id: senderID},{tag: pairName, id:random}]
        });
	}
};
