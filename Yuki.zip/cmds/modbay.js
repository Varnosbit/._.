const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

const baseUrl = 'https://modbay.org/mods';
const totalPages = 359;
const cacheDir = './cache';
const cacheFile = path.join(cacheDir, 'modbay_addons.json');
const updateInterval = 2 * 24 * 60 * 60 * 1000; // 2 days in milliseconds

module.exports = {
    config: {
        name: "modbay",
        aliases: ["مودات"],
        version: "0.0.2",
        category: "search",
        author: "allou Mohamed",
        description: {
            ar: "الحصول على مودات ماين كرافت من موقع modby",
            en: "get modbay Minecraft addons"
        },
        category: "Minecraft",
        guide: {
           syntax: "/modbay [addon]",
           params: "addon: The name or keyword of the addon to search for",
           usage: "/modbay lucky block"
       }
    },
    onStart: async ({ message, args }) => {
        const searchTerm = args.join(" ");
        
        if (!searchTerm.trim()) {
            await message.reply("🐦 Please provide a search term! Example: /modbay lucky block");
            return;
        }
        
        const mods = await searchMods(searchTerm);
        
        if (mods.length > 0) {
            let body = `🐦 Found ${mods.length} addon${mods.length > 1 ? 's' : ''} matching "${searchTerm}":\n\n`;
            let imageStream = [];
            for (let i = 0; i < mods.length && i < 6; i++) {
                const mod = mods[i];
                const { name, description, image, url } = mod;
                body += `${i + 1}. ${name}\n${description}\n- Link: ${url}\n\n`;
                if (image) {
                    try {
                        imageStream.push(await utils.getStreamFromURL("https://modbay.org" + image));
                    } catch (error) {
                        console.error(`Error loading image for ${name}: ${error.message}`);
                    }
                }
            }
            
            if (mods.length > 6) {
                body += `🐦 And ${mods.length - 6} more results...`;
            }
            
            await message.reply({ body: body, attachment: imageStream });
        } else {
            await message.reply(`🐦 Sorry, couldn't find any mods related to "${searchTerm}". Try different keywords!`);
        }

        // Create cache directory if it doesn't exist
        function ensureCacheDir() {
            if (!fs.existsSync(cacheDir)) {
                fs.mkdirSync(cacheDir, { recursive: true });
            }
        }

        // Load cached data from JSON file
        function loadCachedData() {
            try {
                if (fs.existsSync(cacheFile)) {
                    const data = fs.readFileSync(cacheFile, 'utf8');
                    return JSON.parse(data);
                }
            } catch (error) {
                console.error(`Error loading cached data: ${error.message}`);
            }
            return null;
        }

        // Save data to JSON file
        function saveCachedData(data) {
            try {
                ensureCacheDir();
                const cacheData = {
                    lastUpdated: new Date().toISOString(),
                    totalAddons: data.length,
                    addons: data
                };
                fs.writeFileSync(cacheFile, JSON.stringify(cacheData, null, 2));
                console.log(`Cached ${data.length} addons to ${cacheFile}`);
            } catch (error) {
                console.error(`Error saving cached data: ${error.message}`);
            }
        }

        // Check if cache needs update
        function needsUpdate(cachedData) {
            if (!cachedData || !cachedData.lastUpdated) {
                return true;
            }
            
            const lastUpdated = new Date(cachedData.lastUpdated);
            const now = new Date();
            const timeDiff = now.getTime() - lastUpdated.getTime();
            
            return timeDiff > updateInterval;
        }

        async function fetchModsDataFromPage(url) {
            try {
                const { data } = await axios.get(url);
                const $ = cheerio.load(data);

                const mods = [];

                $('.post-card').each((index, element) => {
                    const mod = {};
                    mod.url = $(element).find('.post-card__link-img').attr('href');
                    mod.image = $(element).find('.post-card__link-img img').data('srcset')?.split(' ')[0] || '';
                    mod.name = $(element).find('.post-card__title a').text().trim();
                    mod.description = $(element).find('.post-card__descr').text().trim();
                    mods.push(mod);
                });

                return mods;
            } catch (error) {
                console.error(`Error fetching the data from ${url}: ${error.message}`);
                return [];
            }
        }

        async function fetchAllModsData() {
            const allMods = [];
            
            for (let i = 1; i <= totalPages; i++) {
                const pageUrl = `${baseUrl}/page/${i}/`;
                const mods = await fetchModsDataFromPage(pageUrl);
                allMods.push(...mods);
            }
            
            // Save to cache
            saveCachedData(allMods);
            
            return allMods;
        }

        async function searchMods(searchTerm) {
            ensureCacheDir();
            
            // Load cached data
            let cachedData = loadCachedData();
            
            // Check if we need to update (only based on time)
            const needsRefresh = needsUpdate(cachedData);
            
            if (!cachedData || !cachedData.addons || needsRefresh) {
                // Fetch fresh data and save to cache
                if (needsRefresh && cachedData) {
                    await message.reply("🐦 Cache is a bit old, updating addon database...");
                } else {
                    await message.reply("🐦 Setting up addon database for the first time...");
                }
                
                const freshData = await fetchAllModsData();
                
                // Reload cached data after saving
                cachedData = loadCachedData();
                
                await message.reply(`🐦 Database updated! Found ${cachedData.totalAddons} total addons.`);
            }

            // Search directly in the cached data
            const allMods = cachedData.addons;
            
            const filteredMods = allMods.filter(mod => 
                mod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                mod.description.toLowerCase().includes(searchTerm.toLowerCase())
            );

            return filteredMods;
        }
    }
};
