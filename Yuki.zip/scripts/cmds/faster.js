const axios = require("axios");
const cheerio = require('cheerio');
function getRandomEmoji() {
    const emojiArray = [
        "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😭", "🥳", "🤩", "😍", "🥰", "😘", "😚", "😙", 
        "😗", "😉", "🙃", "😋", "🙂", "🤤", "🥲", "😏", "😊", "😌", "☺️", "😑", "😛", "😬", "😝", "🥺", 
        "😜", "😔", "🤪", "🥴", "😱", "😐", "🤗", "😶", "🥱", "🤐", "🤭", "🤔", "🤫", "😞", "🤨", "🤬", 
        "🧐", "😡", "😒", "😠", "🙄", "😤", "☹️", "😢", "🙁", "😥", "😕", "😟", "😰", "😨", "😓", "😧", 
        "😩", "😫", "😦", "😮", "😵", "🥶", "😯", "😲", "🥵", "🤢", "😳", "🤮", "🤯", "😴", "😖", "😪", 
        "😣", "👹", "🤓", "☠️", "🤑", "💀", "🤠", "👻", "😇", "👿", "🤥", "😈", "😷", "🤡", "🤕", "🥸", 
        "🤒", "😎", "🤧", "💥", "😼", "🌛", "👺", "💨", "😽", "🌜", "🎃", "💦", "🙀", "🙈", "💩", "💤", 
        "😿", "🙉", "🤖", "🕳️", "😾", "🙊", "👽", "🔥", "💫", "😺", "👾", "💯", "⭐", "😸", "🌚", "🌝", 
        "🌞", "😻", "😹", "🌟", "✨", "❤️", "🎉", "💘", "🧡", "🤍", "💛", "🖤", "💚", "🤎", "💙", "🖤", 
        "💜", "♥️", "💝", "💟", "💖", "💌", "💗", "💕", "💓", "💞", "🧠", "❣️", "👣", "💔", "🗣️", "💋", 
        "👤", "🫂", "👥", "🫀", "👄", "🫁", "👁️", "🩸", "👀", "🦠", "🦴", "🦷", "🦾", "🦿", "👅", "🤝", 
        "☘️", "🌳", "🌴", "🌵", "☃️", "⛄", "❄️", "🏔️", "🌅", "🌄", "🌏", "🌎", "🌍", "🌔", "🌓", "🌒", 
        "🌑", "🌘", "🌗", "🌖", "🌕", "🌌", "🐯", "🐹", "🐴", "🦖", "🦎", "🐕‍🦺", "🐩", "🦌", "🐘", 
        "🐁", "🐄", "🦙", "🐸", "🐍", "🐫", "🐪", "🦧", "🦍", "🐒", "🐅", "🐆", "🦒", "🦛", "🐔", "🐣", 
        "🐓", "🦤", "🦈", "🦢", "🦭", "🦆", "🐧", "🦩", "🦚", "🐋", "🦞", "🐳", "🐡", "🕸️", "🦪", "🐝", 
        "🦟", "🦋", "🦗", "🐛", "🍓", "🍌", "🍎", "🍊", "🍉", "🍐", "🫒", "🍈", "🍇", "🍋", "🌶️", "🥬", 
        "🧅", "🌽", "🥑", "🫓", "🍠", "🥜", "🧄", "🥔", "🥐", "🥓", "🥯", "🍳", "🥯", "🥞", "🍕", "🍖", 
        "🥪", "🍖", "🌭", "🥣", "🍤", "🥗", "🦞", "🍲", "🍜", "🥡", "🍡", "🍱", "🍘", "🍢", "🥟", "🎂", 
        "🥠", "🍰", "🍧", "🍦", "🧁", "🧈", "🍬", "🍪", "🧋", "🥛", "🧊", "🍵", "🛑", "🚇", "🚨", "🧭", 
        "🚨", "🚦", "🚙", "🛴", "🚲", "🛴", "🛻", "🚒", "🚚", "🚛", "🚂", "🚕", "🚝", "🛺", "🚔", "🚋", 
        "🚊", "🚎", "⛵", "🚆", "🛳️", "🚤", "🚁", "🚀", "🚠", "🛫", "🛸", "🎢", "🗿", "🎡", "🎪", "💈", 
        "🛕", "⛲", "🕍", "🕋", "🏟️", "🏠", "🏫", "🏤", "🏨", "⛺", "🏕️", "🛖", "🌆", "🏡", "🌉", "💺", 
        "🌁", "🗾", "🌁", "🎊", "🧨", "🎈", "🎁", "🪔", "🎋", "🪅", "🎎", "🎃", "🎖️", "🥇", "🥉", "📢", 
        "🥅", "⚾", "🏐", "🥎", "🏀", "🏏", "🏑", "🏸", "🥌", "🛷", "🦠", "🐾"
    ];

    const randomIndex = Math.floor(Math.random() * emojiArray.length);
    return emojiArray[randomIndex];
}

module.exports = {
  config: {
    name: "fastest",
    aliases: ["الأسرع", "الاسرع"],
    version: "1.3",
    author: "allou mohamed",
    countDown: 5,
    role: 0,
    shortDescription: {
      ar: "اسرع من يرسل إيموجي",
      en: "the fast one who send the emoji"
    },
    category: "game",
    guide: {
      ar: "   {pn}",
      en: "   {pn}"
    }
  },

  langs: {
    ar: {
      Emoji: "أول من يرسل هذا الإيموجي يفوز",
      manyRequest: "⚠️ لسيرفر معطل"
    },
    en: {      
      Emoji: "The first who send this emoji wins.",
      manyRequest: "⚠️ Server disabled"
    }
  },

  onStart: async function ({ args, message, event, getLang }) {
    const emoji = getRandomEmoji();
    let image = await fetchFacebookEmojiImage(emoji);
    if (!image) return message.send("آسف خلصو الإيموجيات");
    message.stream(getLang("Emoji"), image);
    const reg = new RegExp(emoji);
    global.onListen.add(event.senderID, async ({ event }) => reg.test(event.body), async ({ message, usersData, event }) => {
	        const currentBal = await usersData.getMoney(event.senderID);
	        const neBal = currentBal + 10;
	        const txt = `😁 @${event.senderID}:\n✅ جوابك صحيح: ${emoji}\n💸 ربحت 10 دنانير تافهة و رصيدك زاد شوي صار ${neBal} دينار.`;
	        message.reply(txt);
	        await usersData.addMoney(event.senderID, 10);
	    });
  }
};

async function fetchFacebookEmojiImage(emoji) {
  try {
    if (!emoji || typeof emoji !== 'string') {
      throw new Error('Invalid emoji input.');
    }

    const encodedEmoji = encodeURIComponent(emoji);
    const emojiUrl = `https://www.emojiall.com/en/image/${encodedEmoji}`;

    const { data } = await axios.get(emojiUrl);
    const $ = cheerio.load(data);
    let facebookImageSrc = null;

    $('figure').each((_, figure) => {
      const platformText = $(figure).find('p a').last().text().trim();
      if (platformText.toLowerCase() === 'facebook') {
        facebookImageSrc = $(figure).find('img').attr('data-src') || $(figure).find('img').attr('src');
      }
    });

    if (!facebookImageSrc || facebookImageSrc.includes('loading-new.svg')) {
      throw new Error('Facebook emoji image not found.');
    }

    const baseUrl = 'https://www.emojiall.com';
    return new URL(facebookImageSrc, baseUrl).href;
  } catch (error) {
    console.error('Error fetching emoji image:', error.message);
    throw error;
     return null;
  }
}
