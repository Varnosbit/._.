exports.config = {
  name: "إختار",
  category: "ميمز"
};

exports.onStart = async ({ message, commandName }) => {
  try {
    const sent = await message.reply("إختار أزرق أو أحمر.");
    YukiBot.onReply.set(sent.messageID, { commandName });
  } catch (e) {}
};

exports.onReply = async ({ message, args }) => {
  const choice = args[0]?.toLowerCase();
  if (choice === "أحمر" || choice === "احمر") {
    return message.stream("https://i.postimg.cc/p9CQn6jY/received-985326073359391.jpg");
  }

  if (choice === "أزرق" || choice === "ازرق") {
    return message.stream("https://i.postimg.cc/SQtMK6cQ/Messenger-creation-642017935326194.jpg");
  }
};

const threadMessageCounts = new Map();
exports.onChat = async ({ message, event, commandName }) => {
  const threadID = event.threadID;
  const currentCount = threadMessageCounts.get(threadID) || 0;

  if (currentCount + 1 >= 40) {
    try {
      const sent = await message.reply("ردو على هذه الرسالة بإختيار أزرق أو أحمر.");
      YukiBot.onReply.set(sent.messageID, { commandName });
    } catch (e) {
      console.error("Error in onChat:", e);
    }
    threadMessageCounts.set(threadID, 0);
  } else {
    threadMessageCounts.set(threadID, currentCount + 1);
  }
};