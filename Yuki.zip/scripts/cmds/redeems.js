const codeFormat = "xxx-xxxx-xx-x-xxxxx";

module.exports = {
    config: {
        name: "redeem",
        aliases: ["ريديم", "كود"],
        version: "1.5.9",
        author: "allou mohamed",
        role: 0,
        countDown: 0,
        description: {
            en: "use redeem codes to get money",
            ar: "كودات الفلوس"
        },
        category: "economy",
        guid: "{pn} code"
    },
    onStart: async ({
        message, event, args, role, usersData, globalData
    }) => {
        const redeems = await globalData.get("redeems", "data", {});

        if ((args[0] === "c" || args[0] == "إنشاء") && role >= 3) {
            const code = generateRedeemCode(codeFormat);
            const redeemFor = event?.messageReply?.senderID ? event.messageReply.senderID: "all";

            redeems[code] = {
                for_: redeemFor,
                amount: parseInt(args[1], 10)
            };

            await globalData.set("redeems", redeems, "data");

            let ownerMessage = `تم إنشاء كود:\n ${code}\n (يمكن إستخدامه من طرف: ${redeemFor == "all" ? "الكل" : redeemFor})`;

            if (redeemFor !== "all") {
                ownerMessage += `\nمن أجل @${redeemFor} فقط`;
            }

            await message.reply(ownerMessage+"\n\nأكتب /كود جنبها الكود للحصول على المال.");
            return;
        }

        const code = args.join(" ").trim();
        const codeFor = redeems[code] ? redeems[code].for_: null;
        if (!redeems[code]) return message.reply("يا الكود غير صالح يا إستعمله شخص قبلك.");
        if (codeFor != "all" && event.senderID != codeFor) {
            return message.reply("هذا الكود ليس لك.");
        }

        const {
            amount
        } = redeems[code];
        await usersData.addMoney(event.senderID, amount);
        message.reply(`مبروك 🎉 الكود فيه ${amount} عملة.`);
        // Remove the used one
        delete redeems[code];
        const _redeems = Object.fromEntries(Object.entries(redeems).filter(([key, value]) => value != null));
        await globalData.set("redeems", _redeems, "data");
    }
};

function generateRedeemCode(format) {
    return format.replace(/[x]/g, () => Math.floor(Math.random() * 10));
}
