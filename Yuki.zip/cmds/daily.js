module.exports = {
	config: {
		name: "daily",
		version: "3.0.4",
		author: "Allou Mohamed",
		countDown: 5,
		role: 0,
		description: "Get Your Daily Reward.",
		category: "Economy",
		guide: {
			syntax: "/daily reward",
			params: "reward: exp - cash",
			usage: "/daily exp: get your daily exp.\n/daily cash: get your daily money."
		}
	},

	onStart: async function ({ message, event, usersData, args, prefix }) {
		const senderID = event.senderID;
		const name = await usersData.getName(senderID);
		const task = await usersData.get(senderID, "data.task");
		const lastClaim = await usersData.get(senderID, "data.lastDaily") || 0;
		const now = Date.now();

		const remaining = 86400000 - (now - lastClaim);
		if (remaining > 0) {
			const hours = Math.floor(remaining / 3600000);
			const minutes = Math.floor((remaining % 3600000) / 60000);
			const seconds = Math.floor((remaining % 60000) / 1000);
			return message.reply(`%bd${name}%, you're already claiming the daily reward. Please wait for %bd${hours} hours, ${minutes} minutes, ${seconds} seconds%.`);
		}

		// If user hasn't selected a reward
		if (!args[0] || (args[0] !== "exp" && args[0] !== "cash")) {
			if (task)
				return message.reply(`%bd${name}%, you have an unfinished task.\n\nUse %bd${prefix}cancel% to cancel your previous task.`);

			await usersData.set(senderID, "DAILY", "data.task");
			await message.send(`# %bdDaily Reward%\n\n- %bdExp%: 50 EXP\n- %bdCash%: 500 Cn\n\nSend message of your choice to choose the daily reward.`);

			// Clear task after 2.5 minutes
			setTimeout(async () => {
				const currentTask = await usersData.get(senderID, "data.task");
				if (currentTask === "DAILY")
					await usersData.set(senderID, null, "data.task");
			}, 150000);

			return;
		}

		// Set last claim time
		await usersData.set(senderID, now, "data.lastDaily");

		if (task === "DAILY") await usersData.set(senderID, null, "data.task");

		if (args[0] === "exp") {
			const currentExp = await usersData.get(senderID, "exp") || 0;
			await usersData.set(senderID, currentExp + 50, "exp");
			return message.reply(`%bd${name}%, you're successfully claiming %bd50 EXP% daily reward!`);
		}

		if (args[0] === "cash") {
			await usersData.addMoney(senderID, 500);
			return message.reply(`%bd${name}%, you're successfully claiming %bd500 Cn% daily reward!`);
		}
	},

	onChat: async function ({ message, event, usersData, args, prefix }) {
		const senderID = event.senderID;
		const task = await usersData.get(senderID, "data.task");
		if (task === "DAILY") {
			const content = event.body.trim().toLowerCase();
			if (content === "exp"/* || content === `${prefix}daily exp`*/)
				return this.onStart({ message, event, usersData, args: ["exp"], prefix });
			if (content === "cash"/* || content === `${prefix}daily cash`*/)
				return this.onStart({ message, event, usersData, args: ["cash"], prefix });
		}
	}
};
