const fetch = require('node-fetch');
const cheerio = require('cheerio');
const axios = require("axios");
const bingUrl = 'https://www.bing.com';
class BingApi {
    constructor(cookie) {
        this.cookie = cookie;
        this.headers = {
            'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
            Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Alt-Used': 'www.bing.com',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-User': '?1',
            Cookie: `${cookie};`,
            'X-Forwarded-For': `20.${this.getRandomNum()}.${this.getRandomNum()}.${this.getRandomNum()}`,
        };
    }

    async createImages(prompt, isSlowMode) {
        try {
            const payload = `q=${encodeURIComponent(prompt)}`;
            let credits = await this.getCredits();
            if (!credits) {
                credits = 0;
            }
            let response = await this.sendRequest(credits > 0 ? isSlowMode: true, payload);

            if (response.status === 200) {
                const responseHtml = await response.text();
                const $ = cheerio.load(responseHtml);
                const errorAmount = $('.gil_err_img.rms_img').length;
                if (!isSlowMode && credits > 0 && $('#gilen_son').hasClass('show_n')) {
                    throw 'Dalle-3 is currently unavailable due to high demand';
                } else if ($('#gilen_son').hasClass('show_n') || (errorAmount === 2 && credits > 0 && isSlowMode)) {
                    throw 'Slow mode is currently unavailable due to high demand';
                } else if (errorAmount === 2) {
                    throw 'Invalid cookie';
                } else if (errorAmount === 4) {
                    throw 'Prompt has been blocked';
                } else {
                    throw 'Unknown error';
                }
            }

            const eventId = response.headers.get('x-eventid');
            return await this.retrieveImages(eventId);
        } catch (error) {
            console.log(`error is ${error}`);
        }
    }

    async getCredits() {
        const response = await fetch(`${bingUrl}/create`, {
            headers: this.headers,
            method: 'GET',
            mode: 'cors',
        });
        const html = await response.text();
        const $ = cheerio.load(html);
        return $('#token_bal').text();
    }

    getRandomNum() {
        return Math.floor(Math.random() * 254) + 1;
    }

    async sendRequest(isSlowMode, payload) {
        try {
            const response = await fetch(`${bingUrl}/images/create?${payload}&rt=${isSlowMode ? '3': '4'}`,
                {
                    headers: this.headers,
                    method: 'POST',
                    mode: 'cors',
                    redirect: 'manual',
                }
            );
            return response;
        } catch (error) {
            console.log('Error in sendRequest:', error);
        }
    }

    async retrieveImages(eventId) {
        try {
            while (true) {
                const images = await fetch(`${bingUrl}/images/create/async/results/1-${eventId}`, {
                    headers: this.headers,
                    method: 'GET',
                    mode: 'cors',
                });

                const html = await images.text();

                if (html.includes(`"errorMessage":"Pending"`)) {
                    throw 'Error occurred';
                }

                let results = [];

                if (html === '') {
                    await new Promise((resolve) => setTimeout(resolve, 5000));
                    continue;
                }

                const $ = cheerio.load(html);
                for (let i = 0; i < $('.mimg').length; i++) {
                    const badLink = $('.mimg')[i].attribs.src;
                    const goodLink = badLink.slice(0, badLink.indexOf('?')); // Delete the parameters
                    results.push(goodLink);
                }
                return results;
            }
        } catch (error) {
            console.log(`Error in retrieveImages: ${error}`);
        }
    }
}

const apikeybing = '_C_Auth=; ipv6=hit=1736281114093&t=4; MUID=31542A27BFEC60E50AA93E9CBE9B61A3; SRCHD=AF=NOFORM; SRCHUID=V=2&GUID=1F20F9C0DEF64511BE609E9D30AA9581&dmnchg=1; MUIDB=31542A27BFEC60E50AA93E9CBE9B61A3; MUIDB=31542A27BFEC60E50AA93E9CBE9B61A3; _clck=ni3o1y%7C2%7Cfsd%7C0%7C1833; ANON=A=9391650C7C72C8FC44EC0A61FFFFFFFF&E=1eb1&W=1; NAP=V=1.9&E=1e57&C=ew3l4W_1UQBRGWDZOj3YXjsUeV7ApyzyyBS2BxNZa7ENTNEGZ6Sccg&W=1; PPLState=1; KievRPSSecAuth=FABqBBRaTOJILtFsMkpLVWSG6AN6C/svRwNmAAAEgAAACNadyXD1H1DsKAT7sohwSJaZQfxzFaa0sqJcrfu2JOGKIEybv+HR8LxQf8/m6tImGe+SXcg1baJjixFktr12eRoChMWvZeY1kI3eLIJ4NtCLKfLezwCsid+CTUqcgWfR2zrCtkfRk0DXjAmagdJYQXeMqUC1iSUUzaQSgiSPwpgdLhBAHGICkQa8+2LjezHX0/Kgn2Gk/D2TfyFhTglR3X7+C2LB9T6zJT4t7AjQZ3NcbzpCSIXobUIvXpRj2ueN8W8DWC5xO6MhXyP1BZMvyKiibeOAqy3iIwdT6FGbfn4w5iHOmEPewMnQ/7ijBqlTFjei9BmnkiN2sJ8fE1xbsmcE49j5urJDAZTNGK+rm9in9pEkWUMt31Zs5znI78a2RaAjFDO+yU8W4Uw7WyWqrmw8piVXoV9PXYBT8udTuDI+fwq/Jpbh+nw5sNxv//uJ4MuOBHZVmFPXGrrHnDcZhi+Ds9JQcR+PzOOZDHISq13eOerLlsipWuaNM597Gb1LqvARiVDkANFFlfCOct6ENfYpJVZecKJhm1KLYKg6Q2Udux01m0gieqeUNcXG8nP+dxTwbGGTfomspWrk318cuZAj7AN8eBPqr2l7/A2Kn9b/29dAV6LvgQ7F8S+biYiBdvJi3Tcc8KP8feQPE1LceIxa32OyDxLYWNGZublmW5HpUeJCpJrGlOZcgoiyc4b3Qv3yEH8mEsAx6DfRCwyLXXrRe4RjUAr57W41ty5aZaBXngaM5UdbZH3Xb4E4VQiEMI9tF2m0n2HZOCt4ERYZMUi++D+a7zNxhSxXfAOFJXNd6xRrrvsb75XjGr/LL5HX+Mtw6L6FAdzujqmVJ4/Oly/YxBAAu2dkUG+hjOrxH2ATx5ueIkiv4z7lRhcq04FS/hJlBNkfn1tTQDeryH6pMhzpdZI18mz4ozF3EM52gLHXdYCF03x84R8awf0RMxmujrWPX+rurY7p2AxHqO9OPOMy5GE0dQJ668nxjv2LlhBTf9Nmb79K8RskSp8eFqNFyKad8nZYjgPckXeWrf3UigG/h9UKrTFWRMCCs0/XF8JUnUvPOoWhHbCZ7mOXoI6JPBUt4mpDXiiVBjQkYwzgDnXlkUGdW0VXQByJsUaEuoZ4/4z67NnPAjAW1Tg/HGPF/5OLBP/1BaRc8rvKl1C3jHhdCxt9Qov8aptX8Wync9PEX9Skv5TxXmmvGOUDyBtwrHfo4eGiMXcjMgSvVj6z96ic99q+ETGwXvWFXZATSI9sZc91axeock7gfIWa/amUcGA1OEeupoNgo16R8/1bBSp4adLt0BsRpXlPE2YIrJ61N+nLPNOjrWEytMBSJFc0uLbdan16aJ+dE2UpTb+YmkrDg7Dnx78jZCbzwrUm2Fex1CK8JduBgICToSz2O7VtobtD78KoT+tW7pw4TrVkFxMHdRQAZE63Ew/dgh0D/WLq/ui49J+1FJs=; _U=12dEN5uDI7u37Ibvc4gljcCpKuqopZjqQVa5cEUDgAEH8uurJ7t9LbdnmYZGeGPQDLnKaPwfz3cEHhmaFMEzg6NMkKckBj3TELi1Z32ywQSeCcDMRZjq7csWFnOKW9CMl66obpBhjRKfj1Nvz2esnNnWZEl_iDTdgJr6LeJrInHay5W-qeGQXajyJ1kGYlxMij_aPDeQEq3DfP9qZRdhPtQ; WLID=IcIbdFL0q23oNyIxgMVm4xh068YXwjb467UEADmY1JBhejB90lugRPAGR/NJkZAclA7KPCeiA4sAEW+R9FuIgpxzSvrD7bJq/TXiAvMq6R8=; SRCHHPGUSR=SRCHLANG=en&DM=1&CW=980&CH=1938&SCW=980&SCH=1938&BRW=MW&BRH=MT&DPR=2.0&UTC=60&HV=1736276661&PV=11.0.0&WTS=63871873378&PRVCW=360&PRVCH=712; SRCHUSR=DOB=20250107&POEX=W&T=1736276667000&TPC=1736276669000; WLS=C=775a21680a1ee344&N=; _EDGE_S=SID=3F345B50E9746C0C08C34E3DE8716DA6; _Rwho=u=d&ts=2025-01-07; _SS=SID=3F345B50E9746C0C08C34E3DE8716DA6&R=0&RB=0&GB=0&RG=0&RP=0; _clsk=14qeoo0%7C1736277875522%7C7%7C0%7Cn.clarity.ms%2Fcollect; _RwBf=mta=0&rc=0&rb=0&gb=0&rg=0&pc=0&mtu=0&rbb=0.0&g=0&cid=&clo=0&v=6&l=2025-01-07T08:00:00.0000000Z&lft=0001-01-01T00:00:00.0000000&aof=0&ard=0001-01-01T00:00:00.0000000&rwdbt=-62135539200&rwflt=-62135539200&rwaul2=0&o=0&p=MSAAUTOENROLL&c=MR000T&t=5907&s=2023-12-22T19:08:49.5986374+00:00&ts=2025-01-07T20:01:35.4364879+00:00&rwred=0&wls=2&wlb=0&wle=0&ccp=2&cpt=0&lka=0&lkt=0&aad=0&TH=&e=Qp5h5NaejzsmPEAVqUN7VUcP2zDptwmggh2yap20GIVhM6q9yOQHuEUj6r3SKJIB7Brckmn4mMpGrIa7NdDWQQ&A=';
const x = new BingApi(apikeybing);
module.exports = {
    config: {
        name: "dalle",
        aliases: ["دالي"],
        version: "1.0",
        author: "Allou Mohamed",
        countDown: 5,
        role: 2,
        description: {
            en: "gen dalle images",
            ar: "دالي بينغ"
        },
        category: "general",
        guide: {
            en: "   {pn} prompt.",
            ar: "   {pn} طلب."
        }
    },
    onStart: async function({
        args, message, event
    }) {
        if (args.length < 1) return;
        const isKeyboardMode = args.join(" ").split("--kb")[1].trim() == "y";
        if (isKeyboardMode) {
            async function getberr() {

                const datam = new URLSearchParams({
                    client_id: 'ce80f643-ae76-472f-b4d1-755080f1f0e5',
                    scope: 'https://ai.swiftkey.com/v2/SwiftKeyAI.Connect',
                    redirect_uri: 'com.touchtype.swiftkey://swiftkey.com/auth/microsoft/account',
                    refresh_token: 'M.C542_BL2.0.U.-CjCUw8tdurlmKxdg1D!aYnVsmAK9S!ngB8DCjJySeEb5xhmI4UZWueCtBRU33RDw0fsDe1*ZfczYNWI3C0s0fQTvzopM8tFDUW!rVt1k5dEGtt9DDAnLUqkdls9mTs1l1FCBHRn*yZB32cJsItabr5lB*K*BXakIjfndUwPS6krvpLW2FQ9eXkMv4Ad7uLJ6ihd1icrBbC5ip0XtvVmEKjatbWp3t5dWnXwMFDJc9wgKxB7RpqS3Rq9HP29uzON5oNVrpLwyM0QTo1S0b*bVIoJOSlJ7RteN4HzfWpqII7T9LTlZLHQeH359!fUin5vJKltdp2qqqkODHS4Kj4k*7iZXY7IlN9bED*WJ3HsckkuE6bE5i3CTfvK!q6EDOeMcTwxjS3n!Py36C6wqKwNsBBVcweFtiEt8TalWEvMvFBroPLqCnIDI*uXlg04Tn1eKyQ$$',
                    grant_type: 'refresh_token'
                });
                const headersk = {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 8.1.0; VOX Alpha Build/O11019)',
                    'Host': 'login.live.com',
                    'Connection': 'Keep-Alive',
                    'Accept-Encoding': 'gzip',
                    'Content-Length': datam.toString().length
                };
                let tok = await axios.post('https://login.live.com/oauth20_token.srf', datam, {
                    headers: headersk
                });
                let berr = tok.data.access_token;
                return berr;
            }
            async function GenTask(prompt, berr) {

                const url = "https://www.bing.com/api/swiftkey/v1/image-creator/create";
                const headers = {
                    "Host": "www.bing.com",
                    "authorization": 'Bearer '+berr,
                    "x-swiftkey-source": "swiftkey-android",
                    "content-type": "application/json; charset=utf-8",
                    "accept-encoding": "gzip",
                    "user-agent": "okhttp/4.12.0"
                };
                const data = {
                    type: "com.microsoft.bingimagecreatornative.data.network.models.BingImageCreatorCreateRequest",
                    Query: prompt,
                    Locale: "EN"
                };

                let res = await axios.post(url, data, {
                    headers
                });
                let idd = res.data.createdImagesRetrieveId;
                return idd;
            };
            async function GetTask(idd, prompt, berr) {

                const config = {
                    method: 'post',
                    url: 'https://www.bing.com/api/swiftkey/v1/image-creator/retrieve',
                    headers: {
                        'Host': 'www.bing.com',
                        'authorization': 'Bearer '+berr,
                        'x-swiftkey-source': 'swiftkey-android',
                        'content-type': 'application/json; charset=utf-8',
                        'accept-encoding': 'gzip',
                        'user-agent': 'okhttp/4.12.0'
                    },
                    data: {
                        type: "com.microsoft.bingimagecreatornative.data.network.models.BingImageCreatorRetrieveRequest",
                        RetrieveId: idd,
                        Query: prompt,
                        RemoveBackground: false,
                        Width: null
                    }
                };

                let mod = await axios(config);
                let yy = mod.data.images;
                return yy;
            };
            async function CreateImg(prompt) {
                let brr = await getberr();

                let gt = await GenTask(prompt, brr);
                let yy = await GetTask(gt, prompt, brr);
                while (!yy[0]) {
                    yy = await GetTask(gt, prompt, brr);
                }
                let format = yy.map(x => x.thumbnailUrl)
                return format;
            }
            const a3 = await CreateImg(args.join(" "));
            try {
                message.reaction("✅", event.messageID);
                message.stream("keyboard scrap ♪", a3);
            } catch(e) {
                message.reaction("❌", event.messageID);
            }
        } else {
            const z = await x.createImages(args.join(" "));
            try {
                message.reaction("✅", event.messageID);
                message.stream("Web scrap ♪", z);
            } catch(e) {
                message.reaction("❌", event.messageID);
            }
        }
    }
};