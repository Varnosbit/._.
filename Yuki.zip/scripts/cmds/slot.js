module.exports = {
  config: {
    name: "slot",
    version: "1.0",
    author: "Allou Mohamed",
    description: "Slot Your Money.",
    category: "Games",
    guide: {
      params: "amount",
      usage: "Required",
      syntax: "slot [amount] | slot 10000"
    }
  },
  langs: {
    ar: {
      invalid_amount: "على الأقل 100 𝗗𝗮",
      not_enough_money: "رصيدك غير كافي 🌝",
      spin_message: "جاري الدوران ...",
      win_message: "#𝗪𝗶𝗻: %1 𝗗𝗮",
      lose_message: "#𝗟𝗼𝘀𝗲: %1 𝗗𝗮",
      jackpot_message: "#𝕁𝔸ℂ𝕂ℙ𝕆𝕋: %1 𝗗𝗮",
    },
    en: {
      invalid_amount: "على الأقل 100 𝗗𝗮",
      not_enough_money: "رصيدك غير كافي 🌝",
      spin_message: "جاري الدوران ...",
      win_message: "#𝗪𝗶𝗻: %1 𝗗𝗮",
      lose_message: "#𝗟𝗼𝘀𝗲: %1 𝗗𝗮",
      jackpot_message: "#𝕁𝔸ℂ𝕂ℙ𝕆𝕋: %1 𝗗𝗮",
    }
  },
  onStart: async function ({ args, message, event, envCommands, usersData, commandName, getLang }) {
    const { senderID } = event;
    const userData = await usersData.get(senderID);
    const amount = parseInt(args[0]);

    if (isNaN(amount) || amount < 100000) {
      return message.reply(getLang("invalid_amount"));
    }

    if (amount > userData.money) {
      return message.reply(getLang("not_enough_money"));
    }

    const slots = ["🍒", "🍇", "🍊", "🍉", "🍋", "🍎", "🍓", "🍑", "🥝"];
    const slot1 = slots[Math.floor(Math.random() * slots.length)];
    const slot2 = slots[Math.floor(Math.random() * slots.length)];
    const slot3 = slots[Math.floor(Math.random() * slots.length)];

    const winnings = calculateWinnings(slot1, slot2, slot3, amount);

    await usersData.set(senderID, {
      money: userData.money + winnings,
      data: userData.data,
    });

    const messageText = getSpinResultMessage(slot1, slot2, slot3, winnings, getLang);

    return message.reply("#𝗦𝗹𝗼𝘁:\n\n"+messageText);
  },
};

function calculateWinnings(slot1, slot2, slot3, betAmount) {
  if (slot1 === "🍒" && slot2 === "🍒" && slot3 === "🍒") {
    return betAmount * 10;
  } else if (slot1 === "🍇" && slot2 === "🍇" && slot3 === "🍇") {
    return betAmount * 5;
  } else if (slot1 === slot2 && slot2 === slot3) {
    return betAmount * 3;
  } else if (slot1 === slot2 || slot1 === slot3 || slot2 === slot3) {
    return betAmount * 2;
  } else {
    return -betAmount;
  }
}

function getSpinResultMessage(slot1, slot2, slot3, winnings, getLang) {
  if (winnings > 0) {
    if (slot1 === "🍒" && slot2 === "🍒" && slot3 === "🍒") {
      return getLang("jackpot_message", winnings);
    } else {
      return getLang("win_message", winnings) + `\n═══ ${slot1} ║ ${slot2} ║ ${slot3} ═══`;
    }
  } else {
    return getLang("lose_message", -winnings) + `\n══ ${slot1} ║ ${slot2} ║ ${slot3} ═══`;
  }
}
