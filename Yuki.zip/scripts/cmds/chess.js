const { createCanvas, loadImage } = require('canvas');

const THEMES = {
  wooden: {
    lightSquare: '#F0D9B5',
    darkSquare: '#B58863',
    borderColor: '#8B4513',
    textColor: '#654321',
    backgroundColor: '#D2B48C',
    borderWidth: 30
  },
  paper: {
    lightSquare: '#FFFEF7',
    darkSquare: '#D2D2D2',
    borderColor: '#A0A0A0',
    textColor: '#333333',
    backgroundColor: '#F5F5F5',
    borderWidth: 25
  },
  modern: {
    lightSquare: '#EEEED2',
    darkSquare: '#769656',
    borderColor: '#2E2E2E',
    textColor: '#FFFFFF',
    backgroundColor: '#1E1E1E',
    borderWidth: 35
  },
  blue: {
    lightSquare: '#E6F3FF',
    darkSquare: '#4A90E2',
    borderColor: '#1E3A8A',
    textColor: '#FFFFFF',
    backgroundColor: '#2563EB',
    borderWidth: 30
  },
  classic: {
    lightSquare: '#FFFFFF',
    darkSquare: '#000000',
    borderColor: '#666666',
    textColor: '#333333',
    backgroundColor: '#CCCCCC',
    borderWidth: 25
  }
};

// Default chess starting position in FEN notation
const DEFAULT_POSITION = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR';

const PIECE_MAPPING = {
  'r': 'black.rook.png',
  'n': 'black.knight.png',
  'b': 'black.bishop.png',
  'q': 'black.queen.png',
  'k': 'black.king.png',
  'p': 'black.pawn.png',
  'R': 'white.rook.png',
  'N': 'white.knight.png',
  'B': 'white.bishop.png',
  'Q': 'white.queen.png',
  'K': 'white.king.png',
  'P': 'white.pawn.png'
};

function parseFEN(fen) {
  const board = [];
  const rows = fen.split('/');
  
  for (let row of rows) {
    const boardRow = [];
    for (let char of row) {
      if (char >= '1' && char <= '8') {
        const emptySquares = parseInt(char);
        for (let i = 0; i < emptySquares; i++) {
          boardRow.push(null);
        }
      } else {
        boardRow.push(char);
      }
    }
    board.push(boardRow);
  }
  
  return board;
}

async function drawChessBoard(options = {}) {
  const {
    theme = 'wooden',
    position = DEFAULT_POSITION,
    size = 640,
    coordinates = true,
    flipped = false,
    outputPath = 'chessboard.png'
  } = options;

  const themeConfig = THEMES[theme] || THEMES.wooden;
  const borderWidth = themeConfig.borderWidth;
  const canvasSize = size + (borderWidth * 2);
  const squareSize = size / 8;
  const canvas = createCanvas(canvasSize, canvasSize);
  const ctx = canvas.getContext('2d');
  const board = parseFEN(position);
  ctx.fillStyle = themeConfig.backgroundColor;
  ctx.fillRect(0, 0, canvasSize, canvasSize);
  ctx.fillStyle = themeConfig.borderColor;
  ctx.fillRect(0, 0, canvasSize, canvasSize);
  ctx.fillStyle = themeConfig.lightSquare;
  ctx.fillRect(borderWidth, borderWidth, size, size);
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const x = borderWidth + col * squareSize;
      const y = borderWidth + row * squareSize;
      const isLightSquare = (row + col) % 2 === 0;
      ctx.fillStyle = isLightSquare ? themeConfig.lightSquare : themeConfig.darkSquare;
      ctx.fillRect(x, y, squareSize, squareSize);
    }
  }
  if (coordinates) {
    ctx.font = `bold ${Math.floor(borderWidth * 0.5)}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = themeConfig.textColor;
    const files = flipped ? ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'] : ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
    for (let i = 0; i < 8; i++) {
      const x = borderWidth + i * squareSize + squareSize / 2;
      ctx.fillText(files[i], x, borderWidth / 2);
      ctx.fillText(files[i], x, canvasSize - borderWidth / 2);
    }
    const ranks = flipped ? ['1', '2', '3', '4', '5', '6', '7', '8'] : ['8', '7', '6', '5', '4', '3', '2', '1'];
    ctx.textAlign = 'center';
    for (let i = 0; i < 8; i++) {
      const y = borderWidth + i * squareSize + squareSize / 2;
      ctx.fillText(ranks[i], borderWidth / 2, y);
      ctx.fillText(ranks[i], canvasSize - borderWidth / 2, y);
    }
  }
  const baseUrl = "https://raw.githubusercontent.com/nchankov/chess/28659bf626131f819cf26691f097b18dca72faa3/figures/";
  
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece) {
        try {
          const pieceImageName = PIECE_MAPPING[piece];
          const pieceUrl = baseUrl + pieceImageName;
          const pieceImage = await loadImage(pieceUrl);
          const displayRow = flipped ? 7 - row : row;
          const displayCol = flipped ? 7 - col : col;
          const x = borderWidth + displayCol * squareSize;
          const y = borderWidth + displayRow * squareSize;
          const padding = squareSize * 0.1;
          ctx.drawImage(
            pieceImage, 
            x + padding, 
            y + padding, 
            squareSize - padding * 2, 
            squareSize - padding * 2
          );
        } catch (error) {
          console.warn(`Failed to load piece image for ${piece}:`, error.message);
        }
      }
    }
  }
 
    const buffer = canvas.createPNGStream();
    buffer.path = `chess_${Date.now()}.png`;
    return buffer;
}

async function createCustomBoard(fen, theme = 'wooden', outputPath = 'custom_board.png') {
  try {
    await drawChessBoard({
      position: fen,
      theme: theme,
      outputPath: outputPath,
      size: 800,
      coordinates: true
    });
  } catch (error) {
    console.error('Error creating chess board:', error);
  }
}

async function generateThemeExamples() {
  const themes = Object.keys(THEMES);
  
  for (const theme of themes) {
    const outputPath = `chessboard_${theme}.png`;
    console.log(`Generating ${theme} theme...`);
    
    try {
      await drawChessBoard({
        theme: theme,
        outputPath: outputPath,
        size: 640,
        coordinates: true
      });
    } catch (error) {
      console.error(`Error generating ${theme} theme:`, error);
    }
  }
  
  console.log('All theme examples generated!');
}

async function examples() {
  await drawChessBoard({
    theme: 'wooden',
    outputPath: 'wooden_board.png'
  });
 
  await drawChessBoard({
    theme: 'modern',
    size: 800,
    outputPath: 'modern_board.png'
  });
  
  const scholarsMate = 'rnbqk1nr/pppp1ppp/8/2b1p3/2B1P3/8/PPPP1PPP/RNBQK1NR';
  await drawChessBoard({
    theme: 'blue',
    position: scholarsMate,
    outputPath: 'scholars_mate.png'
  });
  
  await drawChessBoard({
    theme: 'paper',
    flipped: true,
    outputPath: 'flipped_board.png'
  });
  
  await drawChessBoard({
    theme: 'classic',
    coordinates: false,
    outputPath: 'no_coords_board.png'
  });
}
 
const { Chess } = require('chess.js');

module.exports = {
	config: {
		name: "chess",
		aliases: ["شطرنج", "ch"],
		version: "2.0",
		author: "X7 team",
		countDown: 5,
		role: 0,
		description: {
			ar: "لعبة الشطرنج - العب ضد لاعب آخر",
			en: "Chess game - play against another player"
		},
		category: "game",
		guide: {
			ar: "{pn} @mention [theme] - للعب ضد لاعب\n{pn} themes - لعرض الثيمات المتاحة\n{pn} leaderboard - عرض المتصدرين",
			en: "{pn} @mention [theme] - to play against another player\n{pn} themes - show available themes\n{pn} leaderboard - show leaderboard"
		},
		envConfig: {
			winReward: 1500,
			drawReward: 500,
			participationReward: 100
		}
	},

	onStart: async function ({ message, event, args, usersData, commandName }) {
		try {
			const senderID = event.senderID;
			
			// Show available themes
			if (args[0] === 'themes') {
				const themesMsg = `🎨 الثيمات المتاحة:\n\n` +
					`1. wooden - خشبي كلاسيكي 🪵\n` +
					`2. paper - ورقي نظيف 📄\n` +
					`3. modern - حديث أنيق ✨\n` +
					`4. blue - أزرق مميز 🔵\n` +
					`5. classic - أبيض وأسود ⚫\n` +
					`6. green - أخضر طبيعي 🟢\n\n` +
					`💡 استخدم: chess @mention wooden`;
				return message.reply(themesMsg);
			}

			// Show leaderboard
			if (args[0] === 'leaderboard' || args[0] === 'lb') {
				return await showLeaderboard(message, usersData);
			}

			// Show player stats
			if (args[0] === 'stats' || args[0] === 'profile') {
				const targetID = Object.keys(event.mentions)[0] || senderID;
				return await showPlayerStats(message, targetID, usersData);
			}
			
			// Check if player is already in a game
			if (isPlayerInGame(senderID)) {
				const currentGame = getPlayerGame(senderID);
				const gameInfo = global.chessGames.get(currentGame);
				const opponent = gameInfo.player1 === senderID ? gameInfo.player2 : gameInfo.player1;
				const opponentName = await getUserName(opponent, usersData);
				
				return message.reply(`❌ أنت مشغول في لعبة ضد ${opponentName}\n\n💡 يمكنك استخدام: resign للاستسلام`);
			}

			// Player vs Player Mode
			const mentions = Object.keys(event.mentions);
			if (mentions.length === 0) {
				return message.reply(`❌ تحتاج لذكر لاعب آخر للعب\n\n💡 مثال: chess @username\n🎨 للثيمات: chess themes\n📊 للإحصائيات: chess stats`);
			}

			const opponentID = mentions[0];
			const theme = validateTheme(args[0]) ? args[0] : 'wooden';
			
			if (opponentID === senderID) {
				return message.reply("❌ لا يمكنك اللعب ضد نفسك!");
			}

			if (isPlayerInGame(opponentID)) {
				const opponentName = await getUserName(opponentID, usersData);
				return message.reply(`❌ ${opponentName} مشغول في لعبة أخرى`);
			}

			const chess = new Chess();
			const gameID = `${Math.min(senderID, opponentID)}_${Math.max(senderID, opponentID)}_${Date.now()}`;
			
			const gameData = {
				chess: chess,
				gameID: gameID,
				player1: senderID,
				player2: opponentID,
				whitePlayer: senderID,
				blackPlayer: opponentID,
				currentTurn: senderID,
				theme: theme,
				gameActive: true,
				gameStartTime: Date.now(),
				lastMoveTime: Date.now(),
				moveHistory: [],
				gameStats: {
					totalMoves: 0,
					captures: 0,
					checks: 0,
					castles: 0
				},
				drawOffers: new Set(),
				spectators: new Set()
			};

			global.chessGames = global.chessGames || new Map();
			global.chessGames.set(gameID, gameData);

			const player1Name = await getUserName(senderID, usersData);
			const player2Name = await getUserName(opponentID, usersData);

			const canvas = await drawChessBoard({
				theme: theme,
				position: chess.fen().split(' ')[0],
				size: 800,
				coordinates: true,
				lastMove: null,
				outputPath: 'chess_game.png'
			});

			const gameMessage = `🏁 بدأت لعبة الشطرنج!\n\n` +
				`⚪ اللاعب الأبيض: ${player1Name}\n` +
				`⚫ اللاعب الأسود: ${player2Name}\n\n` +
				`🎨 الثيم: ${theme}\n` +
				`🆔 رقم اللعبة: ${gameID.split('_')[2]}\n\n` +
				`💡 دور ${player1Name} (الأبيض)\n\n` +
				`📝 أمثلة على الحركات:\n` +
				`• e2e4 أو e4 (بيدق)\n` +
				`• Nf3 (حصان)\n` +
				`• O-O (تبييت قصير)\n` +
				`• O-O-O (تبييت طويل)\n\n` +
				`🎮 الأوامر المتاحة:\n` +
				`• resign - استسلام\n` +
				`• draw - عرض تعادل\n` +
				`• moves - تاريخ الحركات\n` +
				`• position - معلومات الموضع\n` +
				`• time - الوقت المنقضي`;

			message.reply({
				body: gameMessage,
				attachment: canvas
			}, (err, info) => {
				if (!err) {
					global.GoatBot.onReply.set(info.messageID, {
						commandName,
						messageID: info.messageID,
						gameID: gameID,
						type: 'chess'
					});
				}
			});

		} catch (error) {
			console.error("Chess onStart error:", error);
			message.reply("❌ حدث خطأ في بدء اللعبة. حاول مرة أخرى.");
		}
	},

	onReply: async function ({ message, Reply, event, usersData, envCommands, commandName }) {
		try {
			const { gameID } = Reply;
			const senderID = event.senderID;
			const input = event.body.trim();

			global.chessGames = global.chessGames || new Map();
			const gameData = global.chessGames.get(gameID);

			if (!gameData || !gameData.gameActive) {
				return message.reply("❌ اللعبة غير موجودة أو انتهت");
			}

			gameData.lastMoveTime = Date.now();

			const lowerInput = input.toLowerCase();
			
			if (lowerInput === 'resign') {
				return await handleResign(message, gameData, senderID, usersData, envCommands);
			}

			if (lowerInput === 'draw') {
				return await handleDrawOffer(message, gameData, senderID, usersData);
			}

			if (lowerInput === 'moves' || lowerInput === 'history') {
				return showMoveHistory(message, gameData);
			}

			if (lowerInput === 'position' || lowerInput === 'fen') {
				return showPosition(message, gameData);
			}

			if (lowerInput === 'time') {
				return showGameTime(message, gameData);
			}

			if (lowerInput === 'help') {
				return showHelp(message);
			}

			if (!isPlayerTurn(gameData, senderID)) {
				const currentPlayerName = await getUserName(gameData.currentTurn, usersData);
				return message.reply(`⚠️ ليس دورك! دور ${currentPlayerName} الآن`);
			}

			if (gameData.player1 !== senderID && gameData.player2 !== senderID) {
				gameData.spectators.add(senderID);
				return message.reply("👀 تمت إضافتك كمتفرج على هذه اللعبة");
			}

			const moveResult = makeMove(gameData, input);
			
			if (!moveResult.success) {
				return message.reply(`❌ ${moveResult.error}\n\n💡 أمثلة على الحركات الصحيحة:\n` +
					`• e2e4 أو e4 (بيدق من e2 إلى e4)\n` +
					`• Nf3 (حصان إلى f3)\n` +
					`• Qh5 (ملكة إلى h5)\n` +
					`• O-O (تبييت قصير)\n` +
					`• O-O-O (تبييت طويل)\n\n` +
					`ℹ️ اكتب 'help' للمساعدة`);
			}

			updateGameStats(gameData, moveResult);

			gameData.currentTurn = gameData.currentTurn === gameData.player1 ? gameData.player2 : gameData.player1;
			gameData.moveHistory.push({
				move: moveResult.san,
				fen: gameData.chess.fen(),
				time: Date.now(),
				player: senderID
			});

			gameData.drawOffers.clear();

			const gameEndResult = checkGameEnd(gameData);
			
			if (gameEndResult.isGameOver) {
				gameData.gameActive = false;
				global.GoatBot.onReply.delete(Reply.messageID);
				
				const canvas = await drawChessBoard({
					theme: gameData.theme,
					position: gameData.chess.fen().split(' ')[0],
					size: 800,
					coordinates: true,
					lastMove: moveResult.move,
					outputPath: 'chess_game.png'
				});

				await handleGameEnd(message, gameData, gameEndResult, usersData, envCommands);
				
				// Cleanup
				global.chessGames.delete(gameID);
				return;
			}

			const nextPlayerName = await getUserName(gameData.currentTurn, usersData);
			const currentPlayerColor = gameData.currentTurn === gameData.whitePlayer ? '⚪' : '⚫';
			const isCheck = gameData.chess.inCheck();
			
			const canvas = await drawChessBoard({
				theme: gameData.theme,
				position: gameData.chess.fen().split(' ')[0],
				size: 800,
				coordinates: true,
				flipped: gameData.currentTurn === gameData.blackPlayer,
				lastMove: moveResult.move,
				outputPath: 'chess_game.png'
			});

			let statusMessage = `✅ تم تنفيذ الحركة: ${moveResult.san}\n\n`;
			
			if (moveResult.captured) {
				statusMessage += `🎯 تم أسر قطعة!\n`;
			}
			
			if (isCheck) {
				statusMessage += `⚠️ كش! ${nextPlayerName} في خطر\n`;
			}

			statusMessage += `${currentPlayerColor} دور ${nextPlayerName}\n` +
				`📊 الحركة ${gameData.chess.moveNumber()}\n`;

			if (gameData.spectators.size > 0) {
				statusMessage += `👥 متفرجين: ${gameData.spectators.size}\n`;
			}

			statusMessage += `\n💡 اكتب حركتك التالية`;

			message.reply({
				body: statusMessage,
				attachment: canvas
			}, (err, info) => {
				if (!err) {
					global.GoatBot.onReply.set(info.messageID, {
						commandName,
						messageID: info.messageID,
						gameID: gameID,
						type: 'chess'
					});
				}
			});

		} catch (error) {
			console.error("Chess onReply error:", error);
			message.reply("❌ حدث خطأ في معالجة الحركة. حاول مرة أخرى.");
		}
	}
};

function validateTheme(theme) {
	const validThemes = ['wooden', 'paper', 'modern', 'blue', 'classic', 'green'];
	return validThemes.includes(theme);
}

function isPlayerInGame(playerID) {
	global.chessGames = global.chessGames || new Map();
	
	for (const [gameID, gameData] of global.chessGames.entries()) {
		if (gameData.gameActive && (gameData.player1 === playerID || gameData.player2 === playerID)) {
			return true;
		}
	}
	return false;
}

function getPlayerGame(playerID) {
	global.chessGames = global.chessGames || new Map();
	
	for (const [gameID, gameData] of global.chessGames.entries()) {
		if (gameData.gameActive && (gameData.player1 === playerID || gameData.player2 === playerID)) {
			return gameID;
		}
	}
	return null;
}

async function getUserName(userID, usersData) {
	try {
		const userData = await usersData.get(userID);
		return userData.name || "مجهول";
	} catch {
		return "مجهول";
	}
}

function isPlayerTurn(gameData, senderID) {
	return gameData.currentTurn === senderID;
}

function makeMove(gameData, moveInput) {
	try {
		// Clean the input
		let cleanInput = moveInput.trim().replace(/[+#!?]/g, '');
		
		// Try to make the move
		const move = gameData.chess.move(cleanInput);
		
		if (move === null) {
			// Try alternative formats
			const alternatives = generateMoveAlternatives(cleanInput);
			for (const alt of alternatives) {
				const altMove = gameData.chess.move(alt);
				if (altMove !== null) {
					return {
						success: true,
						move: altMove,
						san: altMove.san,
						captured: altMove.captured !== undefined
					};
				}
			}
			
			return {
				success: false,
				error: "حركة غير قانونية أو غير صحيحة"
			};
		}
		
		return {
			success: true,
			move: move,
			san: move.san,
			captured: move.captured !== undefined
		};
		
	} catch (error) {
		return {
			success: false,
			error: "خطأ في تحليل الحركة"
		};
	}
}

function generateMoveAlternatives(input) {
	const alternatives = [];
	
	// If input is like "e2e4", also try "e4"
	if (input.match(/^[a-h][1-8][a-h][1-8]$/)) {
		const to = input.slice(2);
		alternatives.push(to);
	}
	
	// If input is like "e4", also try "e2e4"
	if (input.match(/^[a-h][1-8]$/)) {
		// This is more complex as we'd need to determine the from square
		// The chess.js library should handle this, but we can add common patterns
		if (input[1] === '4' && input[0] >= 'a' && input[0] <= 'h') {
			alternatives.push(input[0] + '2' + input);
		}
		if (input[1] === '5' && input[0] >= 'a' && input[0] <= 'h') {
			alternatives.push(input[0] + '7' + input);
		}
	}
	
	return alternatives;
}

function updateGameStats(gameData, moveResult) {
	gameData.gameStats.totalMoves++;
	
	if (moveResult.captured) {
		gameData.gameStats.captures++;
	}
	
	if (gameData.chess.inCheck()) {
		gameData.gameStats.checks++;
	}
	
	if (moveResult.san.includes('O-O')) {
		gameData.gameStats.castles++;
	}
}

function checkGameEnd(gameData) {
	const chess = gameData.chess;
	
	if (chess.isCheckmate()) {
		const winner = chess.turn() === 'w' ? gameData.blackPlayer : gameData.whitePlayer;
		const loser = chess.turn() === 'w' ? gameData.whitePlayer : gameData.blackPlayer;
		return {
			isGameOver: true,
			result: 'checkmate',
			winner: winner,
			loser: loser,
			reason: 'كش مات'
		};
	}
	
	if (chess.isStalemate()) {
		return {
			isGameOver: true,
			result: 'stalemate',
			reason: 'استحالة الحركة (تعادل)'
		};
	}
	
	if (chess.isThreefoldRepetition()) {
		return {
			isGameOver: true,
			result: 'repetition',
			reason: 'تكرار الموضع ثلاث مرات (تعادل)'
		};
	}
	
	if (chess.isInsufficientMaterial()) {
		return {
			isGameOver: true,
			result: 'insufficient_material',
			reason: 'قطع غير كافية للفوز (تعادل)'
		};
	}
	
	if (chess.isDraw()) {
		return {
			isGameOver: true,
			result: 'draw',
			reason: 'تعادل'
		};
	}
	
	return { isGameOver: false };
}

async function handleGameEnd(message, gameData, gameEndResult, usersData, envCommands) {
	const player1Name = await getUserName(gameData.player1, usersData);
	const player2Name = await getUserName(gameData.player2, usersData);
	const gameDuration = Math.floor((Date.now() - gameData.gameStartTime) / 1000 / 60);
	
	let resultMessage = "🏁 انتهت اللعبة!\n\n";
	
	const winReward = envCommands.chess?.winReward || 1500;
	const drawReward = envCommands.chess?.drawReward || 500;
	const participationReward = envCommands.chess?.participationReward || 100;
	
	if (gameEndResult.result === 'checkmate') {
		const winnerName = await getUserName(gameEndResult.winner, usersData);
		const loserName = await getUserName(gameEndResult.loser, usersData);
		
		resultMessage += `🏆 الفائز: ${winnerName}\n`;
		resultMessage += `💔 الخاسر: ${loserName}\n`;
		resultMessage += `🎯 السبب: ${gameEndResult.reason}\n\n`;
		
		// Award money
		await usersData.addMoney(gameEndResult.winner, winReward);
		await usersData.addMoney(gameEndResult.loser, participationReward);
		
		resultMessage += `💰 ${winnerName} حصل على ${winReward}$\n`;
		resultMessage += `🎁 ${loserName} حصل على ${participationReward}$ (مشاركة)\n`;
		
		// Update stats
		await updatePlayerStats(gameEndResult.winner, 'win', usersData);
		await updatePlayerStats(gameEndResult.loser, 'loss', usersData);
		
	} else {
		// Draw scenarios
		resultMessage += `🤝 تعادل!\n`;
		resultMessage += `🎯 السبب: ${gameEndResult.reason}\n\n`;
		
		// Award draw money
		await usersData.addMoney(gameData.player1, drawReward);
		await usersData.addMoney(gameData.player2, drawReward);
		
		resultMessage += `💰 كل لاعب حصل على ${drawReward}$\n`;
		
		// Update stats
		await updatePlayerStats(gameData.player1, 'draw', usersData);
		await updatePlayerStats(gameData.player2, 'draw', usersData);
	}
	
	// Game statistics
	resultMessage += `\n📊 إحصائيات اللعبة:\n`;
	resultMessage += `⏱️ المدة: ${gameDuration} دقيقة\n`;
	resultMessage += `📝 الحركات: ${gameData.gameStats.totalMoves}\n`;
	resultMessage += `🎯 الأسر: ${gameData.gameStats.captures}\n`;
	resultMessage += `⚠️ الكش: ${gameData.gameStats.checks}\n`;
	resultMessage += `🏰 التبييت: ${gameData.gameStats.castles}\n`;
	
	if (gameData.spectators.size > 0) {
		resultMessage += `👥 المتفرجين: ${gameData.spectators.size}\n`;
	}
	
	// Final board
	const canvas = await drawChessBoard({
		theme: gameData.theme,
		position: gameData.chess.fen().split(' ')[0],
		size: 800,
		coordinates: true,
		outputPath: 'chess_game.png'
	});
	
	message.reply({
		body: resultMessage,
		attachment: canvas.createPNGStream()
	});
}

async function handleResign(message, gameData, senderID, usersData, envCommands) {
	gameData.gameActive = false;
	
	const resignerName = await getUserName(senderID, usersData);
	const opponent = senderID === gameData.player1 ? gameData.player2 : gameData.player1;
	const winnerName = await getUserName(opponent, usersData);
	
	const winReward = envCommands.chess?.winReward || 1500;
	const participationReward = envCommands.chess?.participationReward || 100;
	
	// Award money
	await usersData.addMoney(opponent, winReward);
	await usersData.addMoney(senderID, participationReward);
	
	// Update stats
	await updatePlayerStats(opponent, 'win', usersData);
	await updatePlayerStats(senderID, 'loss', usersData);
	
	const gameDuration = Math.floor((Date.now() - gameData.gameStartTime) / 1000 / 60);
	
	const resignMessage = `🏳️ استسلام!\n\n` +
		`💔 ${resignerName} استسلم\n` +
		`🏆 ${winnerName} يفوز!\n\n` +
		`💰 ${winnerName} حصل على ${winReward}$\n` +
		`🎁 ${resignerName} حصل على ${participationReward}$ (مشاركة)\n\n` +
		`⏱️ مدة اللعبة: ${gameDuration} دقيقة\n` +
		`📊 الحركات: ${gameData.gameStats.totalMoves}`;
	
	message.reply(resignMessage);
	
	// Cleanup
	global.chessGames.delete(gameData.gameID);
	global.GoatBot.onReply.forEach((value, key) => {
		if (value.gameID === gameData.gameID) {
			global.GoatBot.onReply.delete(key);
		}
	});
}

async function handleDrawOffer(message, gameData, senderID, usersData) {
	const senderName = await getUserName(senderID, usersData);
	const opponent = senderID === gameData.player1 ? gameData.player2 : gameData.player1;
	const opponentName = await getUserName(opponent, usersData);
	
	if (gameData.drawOffers.has(opponent)) {
		// Opponent already offered draw, accept it
		gameData.gameActive = false;
		
		const drawReward = 500; // You can get this from envCommands
		await usersData.addMoney(gameData.player1, drawReward);
		await usersData.addMoney(gameData.player2, drawReward);
		
		// Update stats
		await updatePlayerStats(gameData.player1, 'draw', usersData);
		await updatePlayerStats(gameData.player2, 'draw', usersData);
		
		const gameDuration = Math.floor((Date.now() - gameData.gameStartTime) / 1000 / 60);
		
		message.reply(`🤝 تم قبول التعادل!\n\n` +
			`💰 كل لاعب حصل على ${drawReward}$\n` +
			`⏱️ مدة اللعبة: ${gameDuration} دقيقة\n` +
			`📊 الحركات: ${gameData.gameStats.totalMoves}`);
		
		// Cleanup
		global.chessGames.delete(gameData.gameID);
		return;
	}
	
	// Add draw offer
	gameData.drawOffers.add(senderID);
	
	message.reply(`🤝 ${senderName} عرض التعادل على ${opponentName}\n\n` +
		`💬 على ${opponentName} كتابة 'draw' للموافقة\n` +
		`ℹ️ العرض سيُلغى بعد الحركة التالية`);
}

function showMoveHistory(message, gameData) {
	if (gameData.moveHistory.length === 0) {
		return message.reply("📝 لم يتم تنفيذ أي حركات بعد");
	}
	
	let historyText = "📝 تاريخ الحركات:\n\n";
	let moveNumber = 1;
	
	for (let i = 0; i < gameData.moveHistory.length; i += 2) {
		const whiteMove = gameData.moveHistory[i];
		const blackMove = gameData.moveHistory[i + 1];
		
		historyText += `${moveNumber}. ${whiteMove ? whiteMove.move : ''} ${blackMove ? blackMove.move : ''}\n`;
		moveNumber++;
	}
	
	if (gameData.moveHistory.length > 10) {
		// Show only last 10 moves
		const recentMoves = gameData.moveHistory.slice(-10);
		historyText = "📝 آخر 10 حركات:\n\n";
		// ... format recent moves
	}
	
	message.reply(historyText);
}

function showPosition(message, gameData) {
	const chess = gameData.chess;
	const fen = chess.fen();
	const turn = chess.turn() === 'w' ? 'الأبيض' : 'الأسود';
	
	const positionInfo = `🔍 معلومات الموضع:\n\n` +
		`📋 FEN: ${fen}\n` +
		`🔄 الدور: ${turn}\n` +
		`📊 رقم الحركة: ${chess.moveNumber()}\n` +
		`⚠️ كش: ${chess.inCheck() ? 'نعم' : 'لا'}\n` +
		`🏰 التبييت متاح: ${getcastlingRights(chess)}\n` +
		`⏱️ الوقت المنقضي: ${Math.floor((Date.now() - gameData.gameStartTime) / 1000 / 60)} دقيقة`;
	
	message.reply(positionInfo);
}

// Missing helper functions for the chess game

function getCastlingRights(chess) {
	const fen = chess.fen().split(' ');
	const castling = fen[2];
	
	if (castling === '-') {
		return 'غير متاح';
	}
	
	const rights = [];
	if (castling.includes('K')) rights.push('أبيض قصير');
	if (castling.includes('Q')) rights.push('أبيض طويل');
	if (castling.includes('k')) rights.push('أسود قصير');
	if (castling.includes('q')) rights.push('أسود طويل');
	
	return rights.join(', ') || 'غير متاح';
}

function showHelp(message) {
	const helpText = `🆘 مساعدة لعبة الشطرنج:\n\n` +
		`📝 كيفية كتابة الحركات:\n` +
		`• e4, d4, c4 - حركة البيدق\n` +
		`• Nf3, Nc3 - حركة الحصان\n` +
		`• Bb5, Bc4 - حركة الفيل\n` +
		`• Re1, Rd1 - حركة الرخ\n` +
		`• Qh5, Qd2 - حركة الملكة\n` +
		`• Kg1, Ke2 - حركة الملك\n` +
		`• O-O - تبييت قصير\n` +
		`• O-O-O - تبييت طويل\n` +
		`• e2e4 - من المربع إلى المربع\n\n` +
		`🎮 الأوامر المتاحة:\n` +
		`• resign - الاستسلام\n` +
		`• draw - عرض/قبول التعادل\n` +
		`• moves - تاريخ الحركات\n` +
		`• position - معلومات الموضع\n` +
		`• time - الوقت المنقضي\n` +
		`• help - هذه المساعدة\n\n` +
		`💡 نصائح:\n` +
		`• يمكن كتابة الحركات بالانجليزية\n` +
		`• استخدم الإحداثيات مثل e2e4 إذا كانت الحركة غير واضحة\n` +
		`• الحروف الكبيرة للقطع: K=ملك, Q=ملكة, R=رخ, B=فيل, N=حصان`;
	
	return message.reply(helpText);
}

async function showLeaderboard(message, usersData) {
	try {
		// Get all users and their chess stats
		const allUsers = await usersData.getAll();
		const chessPlayers = [];
		
		for (const [userID, userData] of allUsers) {
			const chessStats = userData.chessStats;
			if (chessStats && (chessStats.wins > 0 || chessStats.losses > 0 || chessStats.draws > 0)) {
				const totalGames = chessStats.wins + chessStats.losses + chessStats.draws;
				const winRate = totalGames > 0 ? Math.round((chessStats.wins / totalGames) * 100) : 0;
				const points = (chessStats.wins * 3) + (chessStats.draws * 1);
				
				chessPlayers.push({
					userID,
					name: userData.name || 'مجهول',
					wins: chessStats.wins || 0,
					losses: chessStats.losses || 0,
					draws: chessStats.draws || 0,
					totalGames,
					winRate,
					points
				});
			}
		}
		
		// Sort by points, then by win rate
		chessPlayers.sort((a, b) => {
			if (b.points !== a.points) return b.points - a.points;
			return b.winRate - a.winRate;
		});
		
		if (chessPlayers.length === 0) {
			return message.reply("📊 لا توجد إحصائيات للشطرنج حتى الآن!");
		}
		
		let leaderboardText = "🏆 متصدري الشطرنج:\n\n";
		
		chessPlayers.slice(0, 10).forEach((player, index) => {
			const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}.`;
			leaderboardText += `${medal} ${player.name}\n`;
			leaderboardText += `   📊 ${player.wins}W-${player.losses}L-${player.draws}D | ${player.winRate}% | ${player.points}pts\n\n`;
		});
		
		message.reply(leaderboardText);
		
	} catch (error) {
		console.error("Leaderboard error:", error);
		message.reply("❌ خطأ في عرض المتصدرين");
	}
}

async function showPlayerStats(message, playerID, usersData) {
	try {
		const userData = await usersData.get(playerID);
		const playerName = userData.name || 'مجهول';
		const chessStats = userData.chessStats || {
			wins: 0,
			losses: 0,
			draws: 0,
			totalGames: 0,
			bestStreak: 0,
			currentStreak: 0
		};
		
		const totalGames = chessStats.wins + chessStats.losses + chessStats.draws;
		const winRate = totalGames > 0 ? Math.round((chessStats.wins / totalGames) * 100) : 0;
		const points = (chessStats.wins * 3) + (chessStats.draws * 1);
		
		let statsText = `📊 إحصائيات ${playerName}:\n\n`;
		statsText += `🏆 الانتصارات: ${chessStats.wins}\n`;
		statsText += `💔 الهزائم: ${chessStats.losses}\n`;
		statsText += `🤝 التعادل: ${chessStats.draws}\n`;
		statsText += `📈 إجمالي الألعاب: ${totalGames}\n`;
		statsText += `📊 معدل الفوز: ${winRate}%\n`;
		statsText += `⭐ النقاط: ${points}\n`;
		statsText += `🔥 أفضل سلسلة: ${chessStats.bestStreak || 0}\n`;
		statsText += `⚡ السلسلة الحالية: ${chessStats.currentStreak || 0}\n`;
		
		if (totalGames === 0) {
			statsText += `\n💡 لم يلعب أي مباراة بعد!`;
		}
		
		message.reply(statsText);
		
	} catch (error) {
		console.error("Player stats error:", error);
		message.reply("❌ خطأ في عرض الإحصائيات");
	}
}

async function updatePlayerStats(playerID, result, usersData) {
	try {
		const userData = await usersData.get(playerID);
		
		if (!userData.chessStats) {
			userData.chessStats = {
				wins: 0,
				losses: 0,
				draws: 0,
				bestStreak: 0,
				currentStreak: 0
			};
		}
		
		const stats = userData.chessStats;
		
		if (result === 'win') {
			stats.wins++;
			stats.currentStreak++;
			if (stats.currentStreak > stats.bestStreak) {
				stats.bestStreak = stats.currentStreak;
			}
		} else if (result === 'loss') {
			stats.losses++;
			stats.currentStreak = 0;
		} else if (result === 'draw') {
			stats.draws++;
			// Draws don't break the streak but don't increase it either
		}
		
		await usersData.set(playerID, userData);
		
	} catch (error) {
		console.error("Update stats error:", error);
	}
}

// Complete the showGameTime function that was cut off
function showGameTime(message, gameData) {
	const totalTime = Math.floor((Date.now() - gameData.gameStartTime) / 1000);
	const minutes = Math.floor(totalTime / 60);
	const seconds = totalTime % 60;
	
	const avgTimePerMove = gameData.gameStats.totalMoves > 0 ? 
		Math.floor(totalTime / gameData.gameStats.totalMoves) : 0;
	
	const timeInfo = `⏱️ وقت اللعبة:\n\n` +
		`🕐 الوقت الكلي: ${minutes}:${seconds.toString().padStart(2, '0')}\n` +
		`📊 الحركات: ${gameData.gameStats.totalMoves}\n` +
		`⚡ متوسط الوقت للحركة: ${avgTimePerMove} ثانية\n` +
		`🎯 الأسر: ${gameData.gameStats.captures}\n` +
		`⚠️ مرات الكش: ${gameData.gameStats.checks}`;
	
	message.reply(timeInfo);
}

// Auto cleanup function for abandoned games (optional)
function cleanupAbandonedGames() {
	if (!global.chessGames) return;
	
	const now = Date.now();
	const timeoutDuration = 30 * 60 * 1000; // 30 minutes
	
	for (const [gameID, gameData] of global.chessGames.entries()) {
		if (gameData.gameActive && (now - gameData.lastMoveTime) > timeoutDuration) {
			gameData.gameActive = false;
			global.chessGames.delete(gameID);
			
			// Also cleanup reply handlers
			global.GoatBot.onReply.forEach((value, key) => {
				if (value.gameID === gameID) {
					global.GoatBot.onReply.delete(key);
				}
			});
		}
	}
}

setInterval(cleanupAbandonedGames, 10 * 60 * 1000);