class EventListener {
    constructor() {
        this.listeners = new Map();
    }

    add(key, conditionFunc, resultFunc) {
        if (!key || !conditionFunc || !resultFunc) {
            throw new Error("missed important parameters");
        }

        if (typeof conditionFunc !== 'function' || typeof resultFunc !== 'function') {
            throw new Error("conditionFunc and resultFunc must be functions");
        }

        if (conditionFunc.constructor.name !== 'AsyncFunction') {
            conditionFunc = async (...args) => conditionFunc(...args);
        }

        if (resultFunc.constructor.name !== 'AsyncFunction') {
            resultFunc = async (...args) => resultFunc(...args);
        }

        this.listeners.set(key, { conditionFunc, resultFunc });
    }

    async triggerAll(params) {
        for (let [key, listener] of this.listeners) {
            const { conditionFunc, resultFunc } = listener;

            try {
                if (await conditionFunc(params)) {
                    await resultFunc(params);
                    this.listeners.delete(key);
                }
            } catch (error) {
                console.error(`Error in EventListener for key ${key}:`, error);
                this.listeners.delete(key);
            }
        }
    }
}

global.onListen = new EventListener();

const createFuncMessage = global.utils.message;
const handlerCheckDB = require("./handlerCheckData.js");

module.exports = (api, threadModel, userModel, dashBoardModel, globalModel, usersData, threadsData, dashBoardData, globalData, mqtt) => {
    const handlerEvents = require(process.env.NODE_ENV == 'development' ? "./handlerEvents.dev.js" : "./handlerEvents.js")(api, threadModel, userModel, dashBoardModel, globalModel, usersData, threadsData, dashBoardData, globalData, mqtt);

    return async function (event) {
        if (
            global.YukiBot.config.antiInbox == true &&
            (event.senderID == event.threadID || event.userID == event.senderID || event.isGroup == false) &&
            (event.senderID || event.userID || event.isGroup == false)
        )
            return;

        const message = createFuncMessage(api, event, mqtt);//may soon '&'

        await handlerCheckDB(usersData, threadsData, event);
        const handlerChat = await handlerEvents(event, message);
        if (!handlerChat)
            return;

        const {
            onAnyEvent, onFirstChat, onStart, onChat,
            onReply, onEvent, handlerEvent, onReaction,
            typ, presence, read_receipt
        } = handlerChat;

        const Params = {
            api,
            threadModel,
            userModel,
            dashBoardModel,
            globalModel,
            usersData,
            threadsData,
            dashBoardData,
            globalData,
            event,
            message,
            mqtt
        };

        global.onListen.triggerAll(Params);
        onAnyEvent();
        switch (event.type) {
            case "message":
            case "message_reply":
            case "message_unsend":
                onFirstChat();
                onChat();
                onStart();
                onReply();
                break;
            case "event":
                handlerEvent();
                onEvent();
                break;
            case "message_reaction":
                onReaction();
                break;
            case "typ":
                typ();
                break;
            case "presence":
                presence();
                break;
            case "read_receipt":
                read_receipt();
                break;
            default:
                break;
        }
    };
};
