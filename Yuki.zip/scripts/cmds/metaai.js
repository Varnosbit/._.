const axios = require("axios")
const qs = require("qs")
const fs = require("fs")
const { randomUUID } = require("crypto")

async function meta_ai_prompt(message, external_conversation_id) {
  const ok = await updateCookies(
    "datr=p5xIZ0uIlx7zFlyuwDTOuyuG; ps_l=1; ps_n=1; abra_sess=FtKjvbD9u%2F4BFlgYDlZUdUFiYWRKT1ZXdFZBFrzmyvsMAA%3D%3D;v wd=1024x1366;",
  )
  const authPayload = {
    fb_dtsg: ok.dtsg,
    lsd: ok.lsd,
  }
  const url = `https://www.meta.ai/api/graphql/?fb_dtsg=${ok.dtsg}&lsd=${ok.lsd}`
  const externalConversationId = !external_conversation_id ? randomUUID() : external_conversation_id

  const payload = {
    ...authPayload,
    fb_api_caller_class: "RelayModern",
    fb_api_req_friendly_name: "useAbraSendMessageMutation",
    __user: 0,
    __a: 1,
    __req: "1j",
    __hs: "20109.HYP:abra_pkg.2.1.0.0.0",
    dpr: 2,
    __ccg: "GOOD",
    variables: JSON.stringify({
      message: { sensitive_string_value: message },
      externalConversationId: externalConversationId,
      offlineThreadingId: generateOfflineThreadingId(),
      suggestedPromptIndex: null,
      flashPreviewInput: null,
      promptPrefix: null,
      entrypoint: "ABRA__CHAT__TEXT",
      icebreaker_type: "TEXT_V2",
      attachments: [],
      attachmentsV2: [],
      activeMediaSets: null,
      activeCardVersions: [],
      activeArtifactVersion: null,
      userUploadEditModeInput: null,
      reelComposeInput: null,
      qplJoinId: "f66b4cd9e2f22e8c7",
      gkAbraArtifactsEnabled: false,
      model_preference_override: null,
      __relay_internal__pv__AbraDebugDevOnlyrelayprovider: false,
      __relay_internal__pv__WebPixelRatiorelayprovider: 2,
      __relay_internal__pv__AbraPinningConversationsrelayprovider: false,
      __relay_internal__pv__AbraArtifactsEnabledrelayprovider: false,
      __relay_internal__pv__AbraSearchInlineReferencesEnabledrelayprovider: true,
      __relay_internal__pv__AbraArtifactVersionCreationMessagerelayprovider: false,
      __relay_internal__pv__AbraSearchReferencesHovercardEnabledrelayprovider: true,
      __relay_internal__pv__AbraCardNavigationCountrelayprovider: true,
      __relay_internal__pv__AbraDebugDevOnlyrelayprovider: false,
      __relay_internal__pv__AbraHasNuxTourrelayprovider: true,
      __relay_internal__pv__AbraQPSidebarNuxTriggerNamerelayprovider:
        "meta_dot_ai_abra_web_message_actions_sidebar_nux_tour",
      __relay_internal__pv__AbraSurfaceNuxIDrelayprovider: "12177",
      __relay_internal__pv__AbraFileUploadsrelayprovider: false,
      __relay_internal__pv__AbraQPFileUploadTransparencyDisclaimerTriggerNamerelayprovider:
        "meta_dot_ai_abra_web_file_upload_transparency_disclaimer",
      __relay_internal__pv__AbraUpsellsKillswitchrelayprovider: true,
      __relay_internal__pv__AbraIcebreakerImagineFetchCountrelayprovider: 20,
      __relay_internal__pv__AbraImagineYourselfIcebreakersrelayprovider: false,
      __relay_internal__pv__AbraEmuReelsIcebreakersrelayprovider: false,
      __relay_internal__pv__AbraQueryFromQPInfrarelayprovider: false,
      __relay_internal__pv__AbraArtifactsEditorDiffingrelayprovider: false,
      __relay_internal__pv__AbraArtifactEditorDebugModerelayprovider: false,
      __relay_internal__pv__AbraArtifactsRenamingEnabledrelayprovider: false,
      __relay_internal__pv__AbraArtifactSharingrelayprovider: false,
      __relay_internal__pv__AbraArtifactEditorSaveEnabledrelayprovider: false,
      __relay_internal__pv__AbraArtifactEditorDownloadHTMLEnabledrelayprovider: false,
    }),
    server_timestamps: "true",
    doc_id: "7783822248314888",
  }

  const headers = {
    "x-fb-lsd": authPayload.lsd,
    "x-asbd-id": "129477",
    "content-type": "application/x-www-form-urlencoded",
    origin: "https://www.meta.ai",
    referer: "https://www.meta.ai/",
  }

  headers["cookie"] = ok.cookies

  try {
    const response = await axios.post(url, qs.stringify(payload), {
      headers,
      responseType: "text",
    })

    const rawResponse = response.data
    const lastStreamedResponse = extractLastResponse(rawResponse)
    if (!lastStreamedResponse) {
      throw new Error("No valid response received from Meta AI")
    }
    
    return extractData(lastStreamedResponse)
  } catch (error) {
    console.error("Error in meta_ai_prompt:", error)
    throw error
  }
}

function extractLastResponse(response) {
  let lastStreamedResponse = null
  const lines = response.split("\n")
  for (const line of lines) {
    if (!line.trim()) continue
    try {
      const jsonLine = JSON.parse(line)
      const botResponseMessage = jsonLine?.data?.node?.bot_response_message || {}

      if (botResponseMessage?.streaming_state === "OVERALL_DONE") {
        lastStreamedResponse = jsonLine
      }
    } catch (err) {
      continue
    }
  }
  return lastStreamedResponse
}

function extractData(jsonLine) {
  const botResponseMessage = jsonLine?.data?.node?.bot_response_message || {}
  const conversationResponseMessage = jsonLine?.data?.node?.conversation || {}
  
  let images = []
  let videos = []
  let mediaIds = [] // Store individual media IDs for animation
  
  if (botResponseMessage.imagine_card) {
    const extractedData = extractMedia(botResponseMessage)
    images = extractedData.images
    mediaIds = extractedData.mediaIds
  }
  
  return {
    text: botResponseMessage.snippet || "",
    reels: botResponseMessage?.reels || null,
    search_results: botResponseMessage.search_results || [],
    images,
    videos,
    media_set_id: botResponseMessage?.imagine_card?.session?.media_sets?.[0]?.media_set_id || null,
    media_ids: mediaIds, // Individual media IDs for animation
    external_conversation_id: conversationResponseMessage.external_conversation_id,
  }
}

function extractMedia(jsonLine) {
  const images = []
  const mediaIds = []
  const imagineCard = jsonLine?.imagine_card || {}
  const session = imagineCard?.session || {}
  const mediaSets = session?.media_sets || []

  for (const mediaSet of mediaSets) {
    const imagineMedia = mediaSet?.imagine_media || []
    for (const media of imagineMedia) {
      images.push({
        url: media.uri,
        type: media.media_type,
        prompt: media.prompt,
      })
      // Store individual media ID for animation
      if (media.image_id || media.id) {
        mediaIds.push(media.image_id || media.id)
      }
    }
  }
  return { images, mediaIds }
}

async function animate(media_id, external_conversation_id) {
  try {
    const ok = await updateCookies(
      "datr=p5xIZ0uIlx7zFlyuwDTOuyuG; ps_l=1; ps_n=1; abra_sess=FtKjvbD9u%2F4BFlgYDlZUdUFiYWRKT1ZXdFZBFrzmyvsMAA%3D%3D;v",
    )
    const authPayload = {
      fb_dtsg: ok.dtsg,
      lsd: ok.lsd,
    }
    const url = "https://www.meta.ai/api/graphql/"

    const payload = {
      ...authPayload,
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "useAbraImagineAnimateMutation",
      variables: JSON.stringify({
        input: {
          client_mutation_id: "2",
          actor_id: "512054858655166",
          external_conversation_id: external_conversation_id,
          image_id: media_id, // Use individual media ID, not media_set_id
          media_set_id: null,
          media_type: "IMAGE",
        },
      }),
      server_timestamps: "true",
      doc_id: "7938413782872932",
    }

    const headers = {
      "x-fb-lsd": authPayload.lsd,
      "x-asbd-id": "129477",
      "content-type": "application/x-www-form-urlencoded",
      "x-fb-friendly-name": "useAbraImagineAnimateMutation",
      origin: "https://www.meta.ai",
      referer: `https://www.meta.ai/c/${external_conversation_id}`,
    }

    headers["cookie"] = ok.cookies

    const response = await axios.post(url, qs.stringify(payload), {
      headers,
    })

    const lastStreamedResponse = response.data
    const botResponseMessage = lastStreamedResponse?.data || {}
    return extractAnimatedMedia(botResponseMessage)
  } catch (error) {
    console.error("Error in animate:", error)
    throw error
  }
}

function extractAnimatedMedia(jsonLine) {
  const medias = []
  const mediaSets = jsonLine?.media_set || {}
  const imagineMedia = mediaSets?.imagine_media || []
  for (const media of imagineMedia) {
    medias.push({
      url: media.uri,
      type: media.media_type,
      prompt: media.prompt,
    })
  }
  return medias
}

function generateOfflineThreadingId() {
  const MAX_INT = BigInt("0xFFFFFFFFFFFFFFFF")
  const MASK_22_BITS = BigInt("0x3FFFFF")

  function getCurrentTimestamp() {
    return BigInt(Date.now())
  }

  function getRandom64BitInt() {
    return BigInt(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER))
  }

  function combineAndMask(timestamp, randomValue) {
    const shiftedTimestamp = timestamp << BigInt(22)
    const maskedRandom = randomValue & MASK_22_BITS
    return (shiftedTimestamp | randomValue) & MAX_INT
  }

  const timestamp = getCurrentTimestamp()
  const randomValue = getRandom64BitInt()
  const threadingId = combineAndMask(timestamp, randomValue)

  return threadingId.toString()
}

async function updateCookies(cookies) {
  const response = await axios.get("https://www.meta.ai/", {
    headers: {
      cookie: cookies,
      origin: "https://www.meta.ai",
      referer: "https://www.meta.ai/",
      "x-asbd-id": "129477",
      "User-Agent": "okhttp/4.3.1",
    },
  })

  const text = response.data
  const lsd = extractValue(text, null, '"LSD",[],{"token":"', '"}')
  const dtsg = extractValue(text, null, '"DTSGInitialData",[],{"token":"', '"}')
  
  if (!lsd || !dtsg) {
    throw new Error("Failed to extract authentication tokens")
  }
  
  return {
    lsd,
    dtsg,
    cookies,
  }
}

function extractValue(text, key = null, startStr = null, endStr = '",') {
  if (!startStr) {
    startStr = `${key}":{"value":"`
  }
  const start = text.indexOf(startStr)
  if (start >= 0) {
    const adjustedStart = start + startStr.length
    const end = text.indexOf(endStr, adjustedStart)
    if (end >= 0) {
      return text.substring(adjustedStart, end)
    }
  }
  return null
}

// Bot Command Implementation
const Stor = new Map();
const { getStreamFromUrl } = global.utils;

exports.config = {
  name: "metaai",
  version: "@beta-1.3",
  role: 0,
  description: "Meta AI 🔍 - Chat, generate images, and create animations",
  countDown: 30,
  category: "Ais",
  guide: "{pn} <prompt> - Ask Meta AI\n{pn} clear - Clear conversation\nReply 'animate <number>' to animate a specific image",
  aliases: ["meta"],
  author: "Allou Mohamed"
};

exports.onStart = async function({ event, message, args }) {
  const { senderID } = event;
  const { reply } = message;
  
  try {
    if (args[0] && args[0].toLowerCase() === "clear") {
      Stor.delete(senderID);
      return reply("✅ Conversation cleared! Starting fresh with Meta AI.");
    }
    
    const prompt = args.join(" ");
    
    if (!prompt) {
      return reply("❌ Please provide a prompt for Meta AI.\n\nExample: metaai What is artificial intelligence?\nOr use 'metaai clear' to start a new conversation.");
    }
    
    let conversationId = Stor.get(senderID);
    if (!conversationId) {
      conversationId = null;
    }
    
    reply("🤖 Meta AI is thinking...");
    
    const result = await meta_ai_prompt(prompt, conversationId);
    
    if (result.external_conversation_id) {
      Stor.set(senderID, result.external_conversation_id);
    }
    
    let responseData = {
      body: ""
    };
    
    // Handle text response
    if (result.text) {
      responseData.body = `🤖 Meta AI:\n\n${result.text}`;
    }
    
    // Handle images
    if (result.images && result.images.length > 0) {
      responseData.attachment = [];
      for (const image of result.images) {
        try {
          const stream = await getStreamFromUrl(image.url);
          responseData.attachment.push(stream);
        } catch (err) {
          console.error("Error downloading image:", err);
        }
      }
      
      if (result.images.length > 0) {
        responseData.body += `\n\n🖼️ Generated ${result.images.length} image(s)`;
        if (result.media_ids && result.media_ids.length > 0) {
          responseData.body += "\n💡 Reply 'animate 1' (or 2, 3, 4) to animate specific images!";
        }
      }
    }
    
    // Handle search results
    if (result.search_results && Array.isArray(result.search_results) && result.search_results.length > 0) {
      responseData.body += "\n\n🔍 Web Search Results:";
      result.search_results.slice(0, 3).forEach((item, index) => {
        if (item && item.title) {
          responseData.body += `\n${index + 1}. ${item.title}`;
          if (item.snippet) {
            responseData.body += `\n   ${item.snippet.substring(0, 80)}...`;
          }
          if (item.url) {
            responseData.body += `\n   🔗 ${item.url}`;
          }
        }
      });
    }
    
    // Handle reels
    if (result.reels && typeof result.reels === 'object' && result.reels !== null) {
      if (result.reels.media_url) {
        try {
          if (!responseData.attachment) responseData.attachment = [];
          const stream = await getStreamFromUrl(result.reels.media_url);
          responseData.attachment.push(stream);
          responseData.body += "\n\n🎬 Reel content included";
        } catch (err) {
          console.error("Error downloading reel:", err);
          responseData.body += "\n\n🎬 Reel content available (download failed)";
        }
      } else {
        responseData.body += "\n\n🎬 Reel content generated";
      }
    }
    
    if (!responseData.body) {
      responseData.body = "❌ No response received from Meta AI.";
    }
    
    responseData.body += "\n\n💬 Reply to continue the conversation or use 'clear' to start fresh.";
    
    reply(responseData, (error, info) => {
      if (error) {
        console.error("Reply error:", error);
        return;
      }
      
      global.YukiBot.onReply.set(info.messageID, {
        commandName: "metaai",
        senderID: senderID,
        conversationId: result.external_conversation_id,
        mediaSetId: result.media_set_id,
        mediaIds: result.media_ids || []
      });
    });
    
  } catch (error) {
    console.error("Meta AI Error:", error);
    reply(`❌ Error: ${error.message || "Failed to get response from Meta AI"}`);
  }
};

exports.onReply = async function({ event, message, Reply }) {
  const { commandName, senderID, conversationId, mediaSetId, mediaIds } = Reply;
  const { reply } = message;
  
  if (commandName !== "metaai") return;
  
  const userInput = event.body.trim();
  const inputArgs = userInput.split(" ");
  
  try {
    // Handle clear command
    if (inputArgs[0] && inputArgs[0].toLowerCase() === "clear") {
      Stor.delete(senderID);
      return reply("✅ Conversation cleared! Starting fresh with Meta AI.");
    }
    
    // Handle animation command
    if (inputArgs[0] && inputArgs[0].toLowerCase() === "animate") {
      if (!mediaIds || mediaIds.length === 0) {
        return reply("❌ No images available to animate. Please generate images first.");
      }
      
      let imageIndex = 0; // Default to first image
      if (inputArgs[1]) {
        const requestedIndex = parseInt(inputArgs[1]) - 1;
        if (requestedIndex >= 0 && requestedIndex < mediaIds.length) {
          imageIndex = requestedIndex;
        } else {
          return reply(`❌ Invalid image number. Please choose between 1 and ${mediaIds.length}.`);
        }
      }
      
      const selectedMediaId = mediaIds[imageIndex];
      
      reply(`🎬 Creating animation for image ${imageIndex + 1}...`);
      
      try {
        const videos = await animate(selectedMediaId, conversationId);
        
        if (videos && videos.length > 0) {
          const responseData = {
            body: `🎬 Animation created successfully for image ${imageIndex + 1}!`,
            attachment: []
          };
          
          for (const video of videos) {
            try {
              const stream = await getStreamFromUrl(video.url);
              responseData.attachment.push(stream);
            } catch (err) {
              console.error("Error downloading animated video:", err);
            }
          }
          
          reply(responseData, (error, info) => {
            if (error) return;
            
            global.YukiBot.onReply.set(info.messageID, {
              commandName: "metaai",
              senderID: senderID,
              conversationId: conversationId,
              mediaSetId: mediaSetId,
              mediaIds: mediaIds
            });
          });
        } else {
          reply("❌ Failed to create animation. The service might be unavailable.");
        }
      } catch (animateError) {
        console.error("Animation error:", animateError);
        reply("❌ Failed to create animation. Please try again later.");
      }
      return;
    }
    
    // Handle regular conversation
    reply("🤖 Meta AI is thinking...");
    
    const result = await meta_ai_prompt(userInput, conversationId);
    
    if (result.external_conversation_id) {
      Stor.set(senderID, result.external_conversation_id);
    }
    
    let responseData = {
      body: ""
    };
    
    // Handle text response
    if (result.text) {
      responseData.body = `🤖 Meta AI:\n\n${result.text}`;
    }
    
    // Handle images
    if (result.images && result.images.length > 0) {
      responseData.attachment = [];
      for (const image of result.images) {
        try {
          const stream = await getStreamFromUrl(image.url);
          responseData.attachment.push(stream);
        } catch (err) {
          console.error("Error downloading image:", err);
        }
      }
      
      if (result.images.length > 0) {
        responseData.body += `\n\n🖼️ Generated ${result.images.length} image(s)`;
        if (result.media_ids && result.media_ids.length > 0) {
          responseData.body += "\n💡 Reply 'animate 1' (or 2, 3, 4) to animate specific images!";
        }
      }
    }
    
    // Handle search results
    if (result.search_results && Array.isArray(result.search_results) && result.search_results.length > 0) {
      responseData.body += "\n\n🔍 Web Search Results:";
      result.search_results.slice(0, 3).forEach((item, index) => {
        if (item && item.title) {
          responseData.body += `\n${index + 1}. ${item.title}`;
          if (item.snippet) {
            responseData.body += `\n   ${item.snippet.substring(0, 80)}...`;
          }
          if (item.url) {
            responseData.body += `\n   🔗 ${item.url}`;
          }
        }
      });
    }
    
    // Handle reels
    if (result.reels && typeof result.reels === 'object' && result.reels !== null) {
      if (result.reels.media_url) {
        try {
          if (!responseData.attachment) responseData.attachment = [];
          const stream = await getStreamFromUrl(result.reels.media_url);
          responseData.attachment.push(stream);
          responseData.body += "\n\n🎬 Reel content included";
        } catch (err) {
          console.error("Error downloading reel:", err);
          responseData.body += "\n\n🎬 Reel content available (download failed)";
        }
      } else {
        responseData.body += "\n\n🎬 Reel content generated";
      }
    }
    
    if (!responseData.body) {
      responseData.body = "❌ No response received from Meta AI.";
    }
    
    responseData.body += "\n\n💬 Reply to continue the conversation or use 'clear' to start fresh.";
    
    reply(responseData, (error, info) => {
      if (error) {
        console.error("Reply error:", error);
        return;
      }
      
      global.YukiBot.onReply.set(info.messageID, {
        commandName: "metaai",
        senderID: senderID,
        conversationId: result.external_conversation_id,
        mediaSetId: result.media_set_id,
        mediaIds: result.media_ids || []
      });
    });
    
  } catch (error) {
    console.error("Meta AI Reply Error:", error);
    reply(`❌ Error: ${error.message || "Failed to get response from Meta AI"}`);
  }
};
