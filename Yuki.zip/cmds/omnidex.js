const { createCanvas, loadImage } = require("canvas");
const axios = require("axios");

const base = "https://raw.githubusercontent.com/Aslam-Naseer/memory-card/17e507e37f1ebe0359f56d01f62419f989c12179/src/images/Aliens/";
const PER_PAGE = 4;
const WIDTH = 900;
const HEIGHT = 700;

function drawRoundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
  ctx.fill();
}

function drawGradientBackground(ctx, x, y, w, h, r) {
  const gradient = ctx.createLinearGradient(x, y, x + w, y + h);
  gradient.addColorStop(0, "#2a2d3e");
  gradient.addColorStop(0.5, "#1e2130");
  gradient.addColorStop(1, "#181b26");
  ctx.fillStyle = gradient;
  drawRoundedRect(ctx, x, y, w, h, r);
}

function drawCardShadow(ctx, x, y, w, h, r) {
  ctx.shadowColor = "rgba(0, 0, 0, 0.3)";
  ctx.shadowBlur = 15;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 8;
  ctx.fillStyle = "rgba(0, 0, 0, 0.1)";
  drawRoundedRect(ctx, x, y, w, h, r);
  ctx.shadowColor = "transparent";
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
}

function drawGradientText(ctx, text, x, y, fontSize = 28, colors = ["#00d2ff", "#3a47d5"]) {
  ctx.font = `bold ${fontSize}px 'Segoe UI', Arial, sans-serif`;
  const gradient = ctx.createLinearGradient(x, y - fontSize, x + 400, y);
  gradient.addColorStop(0, colors[0]);
  gradient.addColorStop(1, colors[1]);
  ctx.fillStyle = gradient;
  ctx.fillText(text, x, y);
}

function drawGlowEffect(ctx, x, y, w, h, r, color = "#00d2ff") {
  ctx.save();
  ctx.globalAlpha = 0.3;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

function drawCountBadge(ctx, count, x, y) {
  const badgeW = 50;
  const badgeH = 30;
  const badgeX = x - badgeW / 2;
  const badgeY = y - badgeH / 2;

  // Badge background with gradient
  const gradient = ctx.createLinearGradient(badgeX, badgeY, badgeX + badgeW, badgeY + badgeH);
  gradient.addColorStop(0, "#ff6b6b");
  gradient.addColorStop(1, "#ee5a52");
  ctx.fillStyle = gradient;
  drawRoundedRect(ctx, badgeX, badgeY, badgeW, badgeH, 15);

  // Badge border
  ctx.strokeStyle = "#fff";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(badgeX + 15, badgeY);
  ctx.arcTo(badgeX + badgeW, badgeY, badgeX + badgeW, badgeY + badgeH, 15);
  ctx.arcTo(badgeX + badgeW, badgeY + badgeH, badgeX, badgeY + badgeH, 15);
  ctx.arcTo(badgeX, badgeY + badgeH, badgeX, badgeY, 15);
  ctx.arcTo(badgeX, badgeY, badgeX + badgeW, badgeY, 15);
  ctx.closePath();
  ctx.stroke();

  // Badge text
  ctx.fillStyle = "#fff";
  ctx.font = "bold 16px 'Segoe UI', Arial, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(count.toString(), x, y + 5);
  ctx.textAlign = "left";
}

exports.config = {
  name: "omnidex",
  aliases: [],
  version: "2.0",
  author: "Allou Mohamed",
  role: 0,
  category: "game",
  description: "Show your collected aliens.",
  guide: {
    syntax: "> omnidex [page]",
    params: "page: optional page number (starts at 1)",
    usage: "Example: > omnidex\n> omnidex 2"
  }
};

exports.onStart = async function ({ message, usersData, args, event }) {
  const senderID = event.senderID;
  const page = parseInt(args[0]) || 1;

  const list = await usersData.get(senderID, "data.omnitrex", []);
  if (!list.length) return message.reply("You don't have any aliens yet.");

  const count = {};
  list.forEach(name => count[name] = (count[name] || 0) + 1);
  const entries = Object.entries(count).sort(([a], [b]) => a.localeCompare(b));
  const totalPages = Math.ceil(entries.length / PER_PAGE);

  if (page < 1 || page > totalPages) return message.reply(`Invalid page. Choose between 1 and ${totalPages}.`);

  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext("2d");

  // Enhanced background with gradient
  const bgGradient = ctx.createRadialGradient(WIDTH/2, HEIGHT/2, 0, WIDTH/2, HEIGHT/2, WIDTH/2);
  bgGradient.addColorStop(0, "#1a1d29");
  bgGradient.addColorStop(1, "#0f111a");
  ctx.fillStyle = bgGradient;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  // Add subtle pattern overlay
  ctx.fillStyle = "rgba(255, 255, 255, 0.02)";
  for (let i = 0; i < WIDTH; i += 40) {
    for (let j = 0; j < HEIGHT; j += 40) {
      ctx.fillRect(i, j, 1, 1);
    }
  }

  // Enhanced header with better styling
  drawGradientText(ctx, "◊ OMNIDEX", 50, 60, 42, ["#00d2ff", "#3a47d5"]);

  // Page indicator with better styling
  ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
  ctx.font = "20px 'Segoe UI', Arial, sans-serif";
  ctx.fillText(`Page ${page} of ${totalPages}`, 50, 90);

  // Total aliens counter
  ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
  ctx.font = "16px 'Segoe UI', Arial, sans-serif";
  ctx.fillText(`Total: ${entries.length} species collected`, 50, 110);

  const slice = entries.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const positions = [
    [70, 140], [470, 140],
    [70, 400], [470, 400]
  ];

  for (let i = 0; i < slice.length; i++) {
    const [name, count] = slice[i];
    const [x, y] = positions[i];
    const cardW = 350;
    const cardH = 230;

    // Card shadow
    drawCardShadow(ctx, x, y, cardW, cardH, 15);

    // Card background with gradient
    drawGradientBackground(ctx, x, y, cardW, cardH, 15);

    // Card glow effect
    drawGlowEffect(ctx, x, y, cardW, cardH, 15);

    // Image container with better styling
    const imgX = x + 20;
    const imgY = y + 20;
    const imgSize = 140;

    // Image background
    ctx.fillStyle = "rgba(255, 255, 255, 0.05)";
    drawRoundedRect(ctx, imgX, imgY, imgSize, imgSize, 10);

    // Image border
    ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(imgX + 10, imgY);
    ctx.arcTo(imgX + imgSize, imgY, imgX + imgSize, imgY + imgSize, 10);
    ctx.arcTo(imgX + imgSize, imgY + imgSize, imgX, imgY + imgSize, 10);
    ctx.arcTo(imgX, imgY + imgSize, imgX, imgY, 10);
    ctx.arcTo(imgX, imgY, imgX + imgSize, imgY, 10);
    ctx.closePath();
    ctx.stroke();

    // Alien image
    try {
      const imgData = (await axios.get(base + name + ".png", { responseType: "arraybuffer" })).data;
      const img = await loadImage(imgData);

      // Add subtle glow behind image
      ctx.save();
      ctx.globalAlpha = 0.3;
      ctx.shadowColor = "#00d2ff";
      ctx.shadowBlur = 20;
      ctx.drawImage(img, imgX + 10, imgY + 10, imgSize - 20, imgSize - 20);
      ctx.restore();

      // Draw actual image
      ctx.drawImage(img, imgX + 10, imgY + 10, imgSize - 20, imgSize - 20);
    } catch {
      // Fallback placeholder with better styling
      const placeholderGradient = ctx.createLinearGradient(imgX + 10, imgY + 10, imgX + imgSize - 10, imgY + imgSize - 10);
      placeholderGradient.addColorStop(0, "#444");
      placeholderGradient.addColorStop(1, "#222");
      ctx.fillStyle = placeholderGradient;
      ctx.fillRect(imgX + 10, imgY + 10, imgSize - 20, imgSize - 20);

      // Placeholder icon
      ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
      ctx.font = "48px 'Segoe UI', Arial, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("◊", imgX + imgSize/2, imgY + imgSize/2 + 15);
      ctx.textAlign = "left";
    }

    // Alien name with better typography
    const nameX = imgX + imgSize + 20;
    const nameY = imgY + 40;

    // Name background
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
    drawRoundedRect(ctx, nameX - 10, nameY - 30, 150, 40, 8);

    // Name text
    drawGradientText(ctx, name, nameX, nameY, 22, ["#ffffff", "#cccccc"]);

    // Description or rarity indicator
    ctx.fillStyle = "rgba(255, 255, 255, 0.5)";
    ctx.font = "14px 'Segoe UI', Arial, sans-serif";
    ctx.fillText("Alien Species", nameX, nameY + 25);

    // Count badge (top right of card)
    if (count > 1) {
      drawCountBadge(ctx, count, x + cardW - 30, y + 25);
    }

    // Status indicator (bottom right)
    ctx.fillStyle = count > 1 ? "#4CAF50" : "#FFC107";
    ctx.beginPath();
    ctx.arc(x + cardW - 20, y + cardH - 20, 8, 0, Math.PI * 2);
    ctx.fill();

    // Status text
    ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
    ctx.font = "12px 'Segoe UI', Arial, sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(count > 1 ? "Multiple" : "Single", x + cardW - 35, y + cardH - 15);
    ctx.textAlign = "left";
  }

  // Footer with statistics
  ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
  ctx.font = "14px 'Segoe UI', Arial, sans-serif";
  ctx.fillText(`Collection Progress: ${entries.length} species discovered`, 50, HEIGHT - 20);

  const s = canvas.createPNGStream();
  s.path = Date.now() + "_dex.png";
  return message.reply({ attachment: s });
};