//1.0.0
exports.getPinUrl = async i => {
  if (!i || typeof i !== "string" || !/^https?:/.test(i)) return null;
  if (/\.(jpe?g|png)$/i.test(i)) return i;
  
  return require("axios")
    .get(i)
    .then(r => {
      const patterns = [
        /<link[^>]+id="pin-image-preload"[^>]+href="(https?:\/\/[^"]+\.(?:jpe?g|png))"/i,
        /<link[^>]+href="(https?:\/\/[^"]+\.(?:jpe?g|png))"[^>]+id="pin-image-preload"/i,
        /<meta[^>]+property="og:image"[^>]+content="(https?:\/\/[^"]+\.(?:jpe?g|png))"/i,
        /<meta[^>]+content="(https?:\/\/[^"]+\.(?:jpe?g|png))"[^>]+property="og:image"/i,
        /<meta[^>]+name="twitter:image:src"[^>]+content="(https?:\/\/[^"]+\.(?:jpe?g|png))"/i,
        /<meta[^>]+content="(https?:\/\/[^"]+\.(?:jpe?g|png))"[^>]+name="twitter:image:src"/i,
        /<meta[^>]+name="twitter:image"[^>]+content="(https?:\/\/[^"]+\.(?:jpe?g|png))"/i,
        /<meta[^>]+content="(https?:\/\/[^"]+\.(?:jpe?g|png))"[^>]+name="twitter:image"/i,
        /"imageSpec_736x":\{"url":"(https?:\/\/[^"]+\.(?:jpe?g|png))"/i,
        /https?:\/\/i\.pinimg\.com\/(?:736x|originals|564x)\/[a-f0-9]{2}\/[a-f0-9]{2}\/[a-f0-9]{2}\/[a-f0-9]+\.(?:jpe?g|png)/i
      ];
      
      for (const pattern of patterns) {
        const match = r.data.match(pattern);
        if (match && match[1]) {
          return match[1].replace(/&amp;/g, '&');
        }
      }
      
      return null;
    })
    .catch(() => null);
};

exports.imgToUrl =async i=>{
 return await require("./helpers").top4top(i);
};
