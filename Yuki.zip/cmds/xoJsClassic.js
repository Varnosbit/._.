module.exports = {
	config: {
		name: "tictactoe",
		aliases: ["ttt", "xo"],
		version: "1.0",
		author: "X7 team",
		countDown: 3,
		role: 0,
		description: {
			ar: "لعبة إكس أو مع لوحة مرسومة - العب ضد لاعب آخر أو ضد الذكاء الاصطناعي",
			en: "Tic Tac Toe game with visual board - play against another player or AI"
		},
		category: "game",
		guide: {
			ar: "{pn} @mention - للعب ضد لاعب\n{pn} ai [easy/medium/hard] - للعب ضد الذكاء الاصطناعي\n{pn} solo [easy/medium/hard] - للعب لوحدك ضد الذكاء الاصطناعي",
			en: "{pn} @mention - to play against another player\n{pn} ai [easy/medium/hard] - to play against AI\n{pn} solo [easy/medium/hard] - to play solo against AI"
		},
		envConfig: {
			winReward: 500,
			drawReward: 200
		}
	},

	langs: {
		en: {
			gameStarted: "Game started %1 go first",
			gameStartedAI: "Game started %1 go first",
			gameEnd: "Game end %1 win",
			gameEndAI: "Game end AI win",
			gameEndPlayerWin: "Game end %1 win",
			gameDraw: "Game end Draw",
			invalidMove: "❌ حركة غير صحيحة! اختر خانة فارغة من 1 إلى 9",
			notYourTurn: "⚠️ ليس دورك الآن",
			notInGame: "⚠️ أنت لست في هذه اللعبة",
			needOpponent: "❌ تحتاج لذكر لاعب آخر أو استخدم 'ai' للعب ضد الذكاء الاصطناعي",
			opponentBusy: "❌ اللاعب المذكور مشغول في لعبة أخرى",
			alreadyInGame: "❌ أنت مشغول في لعبة أخرى بالفعل",
			invalidDifficulty: "❌ صعوبة غير صحيحة! استخدم: easy, medium, hard"
		}
	},

	onStart: async function ({ message, event, getLang, args, usersData, commandName }) {
		try {
			const senderID = event.senderID;
			
			// Check if player is already in a game
			if (isPlayerInGame(senderID)) {
				return message.reply(getLang("alreadyInGame"));
			}

			// AI Game Mode
			if (args[0] === 'ai' || args[0] === 'solo') {
				const difficulty = args[1] || 'medium';
				if (!['easy', 'medium', 'hard'].includes(difficulty)) {
					return message.reply(getLang("invalidDifficulty"));
				}

				const gameData = {
					type: 'ai',
					player1: senderID,
					player2: 'ai',
					board: Array(9).fill(null),
					currentPlayer: senderID,
					difficulty: difficulty,
					gameActive: true
				};

				// Store game data
				global.tictactoeGames = global.tictactoeGames || new Map();
				global.tictactoeGames.set(senderID, gameData);

				const player1Name = await getUserName(senderID, usersData);

				// Send game start message
				message.reply(getLang("gameStartedAI", player1Name), (err, info) => {
					if (!err) {
						global.GoatBot.onReply.set(info.messageID, {
							commandName,
							messageID: info.messageID,
							gameID: senderID,
							type: 'ai'
						});
					}
				});

				// Send initial board
				setTimeout(() => {
					const boardDisplay = drawBoard(gameData.board);
					message.reply(boardDisplay, (err, info) => {
						if (!err) {
							global.GoatBot.onReply.set(info.messageID, {
								commandName,
								messageID: info.messageID,
								gameID: senderID,
								type: 'ai'
							});
						}
					});
				}, 500);
				return;
			}

			// Player vs Player Mode
			const mentions = Object.keys(event.mentions);
			if (mentions.length === 0) {
				return message.reply(getLang("needOpponent"));
			}

			const opponentID = mentions[0];
			if (opponentID === senderID) {
				return message.reply(getLang("needOpponent"));
			}

			if (isPlayerInGame(opponentID)) {
				return message.reply(getLang("opponentBusy"));
			}

			const gameData = {
				type: 'pvp',
				player1: senderID,
				player2: opponentID,
				board: Array(9).fill(null),
				currentPlayer: senderID,
				gameActive: true
			};

			const gameID = `${senderID}_${opponentID}`;
			global.tictactoeGames = global.tictactoeGames || new Map();
			global.tictactoeGames.set(gameID, gameData);

			const player1Name = await getUserName(senderID, usersData);

			// Send game start message
			message.reply(getLang("gameStarted", player1Name), (err, info) => {
				if (!err) {
					global.GoatBot.onReply.set(info.messageID, {
						commandName,
						messageID: info.messageID,
						gameID: gameID,
						type: 'pvp'
					});
				}
			});

			// Send initial board
			setTimeout(() => {
				const boardDisplay = drawBoard(gameData.board);
				message.reply(boardDisplay, (err, info) => {
					if (!err) {
						global.GoatBot.onReply.set(info.messageID, {
							commandName,
							messageID: info.messageID,
							gameID: gameID,
							type: 'pvp'
						});
					}
				});
			}, 500);

		} catch (error) {
			console.error("TicTacToe onStart error:", error);
			message.reply("❌ حدث خطأ في بدء اللعبة");
		}
	},

	onReply: async function ({ message, Reply, event, getLang, usersData, envCommands, commandName }) {
		try {
			const { gameID, type } = Reply;
			const senderID = event.senderID;
			const move = parseInt(event.body.trim());

			global.tictactoeGames = global.tictactoeGames || new Map();
			const gameData = global.tictactoeGames.get(gameID);

			if (!gameData || !gameData.gameActive) {
				return message.reply("❌ اللعبة غير موجودة أو انتهت");
			}

			// Validate move
			if (isNaN(move) || move < 1 || move > 9) {
				return message.reply(getLang("invalidMove"));
			}

			const boardIndex = move - 1;
			if (gameData.board[boardIndex] !== null) {
				return message.reply(getLang("invalidMove"));
			}

			// Check if it's player's turn
			if (type === 'pvp') {
				if (senderID !== gameData.currentPlayer) {
					return message.reply(getLang("notYourTurn"));
				}
				if (senderID !== gameData.player1 && senderID !== gameData.player2) {
					return message.reply(getLang("notInGame"));
				}
			} else if (type === 'ai') {
				if (senderID !== gameData.player1) {
					return message.reply(getLang("notInGame"));
				}
			}

			// Make player move
			gameData.board[boardIndex] = senderID === gameData.player1 ? 'X' : 'O';

			// Check for win or draw
			const result = checkGameEnd(gameData.board);
			
			if (result.gameOver) {
				gameData.gameActive = false;
				global.GoatBot.onReply.delete(Reply.messageID);
				
				const boardDisplay = drawBoard(gameData.board, result.winningLine);

				if (result.winner) {
					if (type === 'pvp') {
						const winnerID = result.winner === 'X' ? gameData.player1 : gameData.player2;
						const winnerName = await getUserName(winnerID, usersData);
						const reward = envCommands.tictactoe?.winReward || 500;
						
						await usersData.addMoney(winnerID, reward);
						
						message.reply(getLang("gameEnd", winnerName));
						setTimeout(() => {
							message.reply(boardDisplay);
						}, 500);
					} else {
						if (result.winner === 'X') {
							const reward = envCommands.tictactoe?.winReward || 500;
							const playerName = await getUserName(gameData.player1, usersData);
							await usersData.addMoney(gameData.player1, reward);
							message.reply(getLang("gameEndPlayerWin", playerName));
							setTimeout(() => {
								message.reply(boardDisplay);
							}, 500);
						} else {
							message.reply(getLang("gameEndAI"));
							setTimeout(() => {
								message.reply(boardDisplay);
							}, 500);
						}
					}
				} else {
					// Draw
					const drawReward = envCommands.tictactoe?.drawReward || 200;
					if (type === 'pvp') {
						await usersData.addMoney(gameData.player1, drawReward);
						await usersData.addMoney(gameData.player2, drawReward);
					} else {
						await usersData.addMoney(gameData.player1, drawReward);
					}
					
					message.reply(getLang("gameDraw"));
					setTimeout(() => {
						message.reply(boardDisplay);
					}, 500);
				}
				
				global.tictactoeGames.delete(gameID);
				return;
			}

			// AI Turn
			if (type === 'ai') {
				setTimeout(async () => {
					const aiMove = getAIMove(gameData.board, gameData.difficulty);
					gameData.board[aiMove] = 'O';

					const aiResult = checkGameEnd(gameData.board);
					
					if (aiResult.gameOver) {
						gameData.gameActive = false;
						global.GoatBot.onReply.delete(Reply.messageID);
						
						const boardDisplay = drawBoard(gameData.board, aiResult.winningLine);

						if (aiResult.winner) {
							if (aiResult.winner === 'X') {
								const reward = envCommands.tictactoe?.winReward || 500;
								const playerName = await getUserName(gameData.player1, usersData);
								await usersData.addMoney(gameData.player1, reward);
								message.reply(getLang("gameEndPlayerWin", playerName));
								setTimeout(() => {
									message.reply(boardDisplay);
								}, 500);
							} else {
								message.reply(getLang("gameEndAI"));
								setTimeout(() => {
									message.reply(boardDisplay);
								}, 500);
							}
						} else {
							const drawReward = envCommands.tictactoe?.drawReward || 200;
							await usersData.addMoney(gameData.player1, drawReward);
							message.reply(getLang("gameDraw"));
							setTimeout(() => {
								message.reply(boardDisplay);
							}, 500);
						}
						
						global.tictactoeGames.delete(gameID);
						return;
					}

					// Continue game - send board only
					const boardDisplay = drawBoard(gameData.board);
					message.reply(boardDisplay, (err, info) => {
						if (!err) {
							global.GoatBot.onReply.set(info.messageID, {
								commandName,
								messageID: info.messageID,
								gameID: gameID,
								type: 'ai'
							});
						}
					});
				}, 1500);
				
			} else {
				// PvP - Switch turns and send board only
				gameData.currentPlayer = gameData.currentPlayer === gameData.player1 ? gameData.player2 : gameData.player1;
				
				const boardDisplay = drawBoard(gameData.board);
				message.reply(boardDisplay, (err, info) => {
					if (!err) {
						global.GoatBot.onReply.set(info.messageID, {
							commandName,
							messageID: info.messageID,
							gameID: gameID,
							type: 'pvp'
						});
					}
				});
			}

		} catch (error) {
			console.error("TicTacToe onReply error:", error);
			message.reply("❌ حدث خطأ في معالجة الحركة");
		}
	}
};

// Helper Functions
function drawBoard(board, winningLine = null) {
	let boardStr = "";
	
	for (let i = 0; i < 9; i += 3) {
		let row = "";
		for (let j = 0; j < 3; j++) {
			const index = i + j;
			let cell;
			
			if (winningLine && winningLine.includes(index)) {
				cell = "🟩"; // Green square for winning line
			} else if (board[index] === 'X') {
				cell = "❌";
			} else if (board[index] === 'O') {
				cell = "⭕";
			} else {
				cell = "🔲";
			}
			
			row += cell;
		}
		boardStr += row;
		if (i < 6) boardStr += "\n";
	}
	
	return boardStr;
}

function checkGameEnd(board) {
	const winPatterns = [
		[0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
		[0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns  
		[0, 4, 8], [2, 4, 6] // Diagonals
	];

	for (const pattern of winPatterns) {
		const [a, b, c] = pattern;
		if (board[a] && board[a] === board[b] && board[a] === board[c]) {
			return { gameOver: true, winner: board[a], winningLine: pattern };
		}
	}

	if (board.every(cell => cell !== null)) {
		return { gameOver: true, winner: null };
	}

	return { gameOver: false };
}

function getAIMove(board, difficulty) {
	const availableMoves = board.map((cell, index) => cell === null ? index : null).filter(val => val !== null);
	
	if (difficulty === 'easy') {
		// Random move 80% of the time
		if (Math.random() < 0.8) {
			return availableMoves[Math.floor(Math.random() * availableMoves.length)];
		}
	}

	if (difficulty === 'easy' || difficulty === 'medium') {
		// Check for winning move
		for (const move of availableMoves) {
			const testBoard = [...board];
			testBoard[move] = 'O';
			if (checkGameEnd(testBoard).winner === 'O') {
				return move;
			}
		}

		// Check for blocking move
		for (const move of availableMoves) {
			const testBoard = [...board];
			testBoard[move] = 'X';
			if (checkGameEnd(testBoard).winner === 'X') {
				return move;
			}
		}

		if (difficulty === 'medium') {
			// Medium: 50% random after checking win/block
			if (Math.random() < 0.5) {
				return availableMoves[Math.floor(Math.random() * availableMoves.length)];
			}
		}
	}

	// Hard difficulty: Use minimax
	return minimax(board, 0, true).index;
}

function minimax(board, depth, isMaximizing) {
	const result = checkGameEnd(board);
	
	if (result.gameOver) {
		if (result.winner === 'O') return { score: 10 - depth };
		if (result.winner === 'X') return { score: depth - 10 };
		return { score: 0 };
	}

	const availableMoves = board.map((cell, index) => cell === null ? index : null).filter(val => val !== null);

	if (isMaximizing) {
		let bestScore = -Infinity;
		let bestMove = availableMoves[0];

		for (const move of availableMoves) {
			const newBoard = [...board];
			newBoard[move] = 'O';
			const score = minimax(newBoard, depth + 1, false).score;
			
			if (score > bestScore) {
				bestScore = score;
				bestMove = move;
			}
		}

		return { score: bestScore, index: bestMove };
	} else {
		let bestScore = Infinity;
		let bestMove = availableMoves[0];

		for (const move of availableMoves) {
			const newBoard = [...board];
			newBoard[move] = 'X';
			const score = minimax(newBoard, depth + 1, true).score;
			
			if (score < bestScore) {
				bestScore = score;
				bestMove = move;
			}
		}

		return { score: bestScore, index: bestMove };
	}
}

function isPlayerInGame(playerID) {
	global.tictactoeGames = global.tictactoeGames || new Map();
	
	for (const [gameID, gameData] of global.tictactoeGames.entries()) {
		if (gameData.gameActive && (gameData.player1 === playerID || gameData.player2 === playerID)) {
			return true;
		}
	}
	return false;
}

async function getUserName(userID, usersData) {
	try {
		const userData = await usersData.get(userID);
		return userData.name || "مجهول";
	} catch {
		return "مجهول";
	}
}