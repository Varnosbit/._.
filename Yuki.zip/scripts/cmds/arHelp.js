const { commands } = global.YukiBot;

const config = {
    name: "help",
    aliases: ["أوامر", "اوامر", "مساعدة", "الاوامر", "الأوامر"],
    description: {
        en: "Arabic help list",
        ar: "قائمة أوامر عربية."
    },
    role: 0,
    guide: {
        en: "{pn}",
        ar: "{pn} | رقم الصفحة | الكل"
    },
    category: "info",
    ar: true
};

const onStart = async ({ message, args }) => {
    let pageIndex = parseInt(args[0]) || 1;
    const isAllCommandsRequested = args[0] === "الكل";

    if (isNaN(pageIndex) && !isAllCommandsRequested) {
        return message.reply("⚠️ الصفحة المطلوبة غير موجودة.");
    }

    const helpInfo = isAllCommandsRequested 
        ? getAllCommandsInfo(commands) 
        : getPageCommandsInfo(commands, pageIndex);

    if (!helpInfo || !helpInfo.list) {
        return message.reply("⚠️ لا توجد أوامر.");
    }

    message.reply(helpInfo.list);
};

module.exports = { config, onStart };

function getAllCommandsInfo(commands) {
    const groupedCommands = {};

    commands.forEach(cmd => {
        const { category = "أخرى", ar } = cmd.config;

        if (!ar) return;

        if (!groupedCommands[category]) {
            groupedCommands[category] = [];
        }
        groupedCommands[category].push(cmd.config);
    });

    let returnList = Object.entries(groupedCommands)
        .map(([category, cmds]) => {
            const commandsList = cmds
                .map(({ aliases, name, description }) => {
                    const cmdName = aliases ? aliases[0] : name;
                    const cmdDescription = getDescription({ description });
                    return `✎ ${cmdName}: ${cmdDescription}`;
                })
                .join("\n");

            return `-ˋˏ✄┈┈ ${category} ┈┈┈ˋˏ-\n${commandsList}`;
        })
        .join("\n\n");

    return {
        list: returnList.trim(),
        total: Object.keys(groupedCommands).length
    };
}

function getPageCommandsInfo(commands, pageIndex) {
    const maxPerPage = 30;
    const allCommands = Array.from(commands.values())
        .map(cmd => cmd.config)
        .filter(({ ar }) => ar);

    const totalPages = Math.ceil(allCommands.length / maxPerPage);
    const startIndex = (pageIndex - 1) * maxPerPage;

    if (pageIndex > totalPages || pageIndex < 1) {
        return null;
    }

    const cmds = allCommands.slice(startIndex, startIndex + maxPerPage);
    const returnList = cmds
        .map(({ aliases, name, description }) => {
            const cmdName = aliases ? aliases[0] : name;
            const cmdDescription = getDescription({ description });
            return `✎ ${cmdName}: ${cmdDescription}`;
        })
        .join("\n");

    return {
        list: `${returnList.trim()}\n\tالصفحة: ${pageIndex}/${totalPages}`,
        total: cmds.length,
        totalPages
    };
}

function getDescription(config) {
    const fields = ['description', 'shortDescription', 'longDescription'];

    for (const field of fields) {
        const value = config[field];
        if (!value) continue;

        if (typeof value === 'object') {
            return value.ar || value.en || '';
        } else if (typeof value === 'string') {
            return value;
        }
    }

    return "لا يوجد وصف.";
}
