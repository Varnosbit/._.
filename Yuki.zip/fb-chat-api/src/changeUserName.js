"use strict";

const log = require("npmlog");

function formatRequestData(newUsername, ctx) {
  return {
    av: ctx.userID,
    fb_api_caller_class: "RelayModern",
    fb_api_req_friendly_name: "FXAccountsCenterIdentityUsernameEditDialogRouteResolverQuery",
    doc_id: "6827728020598527",
    variables: JSON.stringify({
      identity_id: ctx.userID,
      new_username: newUsername
    }),
    fb_dtsg: ctx.fb_dtsg
  };
}

module.exports = function (defaultFuncs, api, ctx) {
  return function changeUsername(newUsername, callback) {
    let resolveFunc = function () {};
    let rejectFunc = function () {};
    const returnPromise = new Promise(function (resolve, reject) {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err, data) {
        if (err) {
          return rejectFunc(err);
        }
        resolveFunc(data);
      };
    }

    const form = formatRequestData(newUsername, ctx);

    defaultFuncs
      .post("https://accountscenter.facebook.com/api/graphql/", ctx.jar, form)
      .then(function (resData) {
        if (resData.errors) {
          throw resData;
        }
        return callback(null, resData);
      })
      .catch(function (err) {
        log.error("changeUsername", err);
        return callback(err);
      });

    return returnPromise;
  };
};