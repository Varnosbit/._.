const Config = require('./Config');
const Utils = require('./Utils');
const Variables = require('./Variables');
const Database = require('./Database');

async function startNightPhase(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  game.phase = "night";
  game.day++;
  game.nightActions = {};
  
  for (const p of Object.values(game.players)) {
    if (p.alive) {
      p.protected = false;
      p.blackmailed = false;
      p.roleblocked = false;
      p.framed = false;
      delete p.alerted;
      delete p.bodyguarded;
      delete p.trapped;
      delete p.crusaded;
    }
  }
  
  await mqtt.sendMessage(
    `${Utils.formatPhaseMessage("night", game.day)}

____________________________

${Utils.formatGameStatus(game)}

____________________________

⏱️ المرحلة الليلية: ${Config.gameSettings.nightDurationMs / 1000} ثانية
🤫 صمت تام في المجموعة!
✨ استخدموا قدراتكم بحكمة في الشات الخاص الذي ضفتكم فيه ._.`,
    game.main
  );
  
  for (const p of Variables.alive(game)) {
    await sendNightActionPrompt(mqtt, game, p, usersData);
  }
  
  nightPhaseTimer(mqtt, gameID, usersData);
}

async function sendNightActionPrompt(mqtt, game, player, usersData) {
  const roleData = Config.ROLES[player.role];
  
  if (!roleData.night && !roleData.canKill) return;
  if (player.roleblocked) return;
  
  const canAct = roleData.canKill || roleData.ability;
  if (!canAct) return;
  
  let msg = `${Utils.formatPhaseMessage("night", game.day)}\n\n${roleData.emoji} | ${roleData.name}: ${roleData.desc}\n____________________________\n`;
  
  if (player.role === "retributionist") {
    const deadPlayers = Object.values(game.players).filter(pl => !pl.alive);
    if (deadPlayers.length === 0 || !Utils.hasRoleAbilityUses(player, "revive")) {
      await Utils.sendToPlayerOrRoom(mqtt, player, `❌ لا توجد موتى لإحيائهم! 😔`);
      return;
    }
    msg += `💀➡️ اختر رقم الميت لإحيائه:\n____________________________\n\n`;
    for (let i = 0; i < deadPlayers.length; i++) {
      const deadName = await usersData.getName(deadPlayers[i].userID);
      msg += `${i + 1}. ${deadName} ☠️\n`;
    }
    msg += `\n____________________________\n✨ سيعود للحياة ليلة واحدة!\n⚡ متبقي: ${player.abilities.revive} مرة`;
  } else if (player.role === "amnesiac") {
    const deadPlayers = Object.values(game.players).filter(pl => !pl.alive);
    if (deadPlayers.length === 0 || !Utils.hasRoleAbilityUses(player, "remember")) {
      await Utils.sendToPlayerOrRoom(mqtt, player, `❌ لا توجد موتى لتذكر دورهم! 😔`);
      return;
    }
    msg += `❓ اختر رقم الميت لتذكر دوره:\n____________________________\n\n`;
    for (let i = 0; i < deadPlayers.length; i++) {
      const deadName = await usersData.getName(deadPlayers[i].userID);
      msg += `${i + 1}. ${deadName} ☠️\n`;
    }
    msg += `\n____________________________\n✨ ستصبح مثله تماماً!\n⚡ متبقي: ${player.abilities.remember} مرة`;
  } else if (player.role === "psychic") {
    await handlePsychicVision(mqtt, game, player, usersData);
    return;
  } else if (player.role === "medium") {
    await handleMediumSeance(mqtt, game, player, usersData);
    return;
  } else if (player.role === "spy") {
    return;
  } else if (player.role === "veteran") {
    msg += `⚔️ رد بـ: نعم للتحصن\n💀 ستقتل كل من يزورك!\n`;
    if (player.abilities.alert) {
      msg += `⚡ متبقي: ${player.abilities.alert} مرة`;
    }
  } else if (player.role === "survivor") {
    msg += `🦺 رد بـ: نعم لاستخدام الدرع\n🛡️ ستحمي نفسك من القتل!\n`;
    if (player.abilities.vest) {
      msg += `⚡ متبقي: ${player.abilities.vest} مرة`;
    }
  } else if (player.role === "transporter" || player.role === "witch") {
    const playersList = await Utils.listPlayers(game, usersData, false);
    msg += `رد برقم اللاعبين:\n${playersList}\n____________________________\n`;
    if (player.role === "transporter") {
      msg += `🚗 اختر رقمين للتبديل\n📝 مثال: 1 2\n🔄 ستبدل مكانهما وكل من يزورهما!`;
    } else {
      msg += `🧙 اختر رقمين للسيطرة\n📝 مثال: 1 2\n🎯 الأول: من ستسيطرين عليه\n🎯 الثاني: هدفه الجديد`;
    }
  } else if (player.role === "arsonist") {
    const playersList = await Utils.listPlayers(game, usersData, false);
    msg += `رد برقم اللاعب:\n${playersList}\n____________________________\n`;
    msg += `🔥 اختر رقماً لإشعاله\n💥 أو اكتب: حرق - لحرق الجميع!`;
  } else if (player.role === "werewolf" && game.day % 2 === 0) {
    await Utils.sendToPlayerOrRoom(mqtt, player, `🐺 ليلة هادئة! لا يمكنك المهاجمة الليلة 🌕`);
    return;
  } else {
    const needsPlayerList = ["mafia", "godfather", "consigliere", "framer", "janitor", 
      "blackmailer", "cop", "sheriff", "doctor", "bodyguard", "vigilante", "lookout", 
      "tracker", "escort", "crusader", "trapper", "serial_killer", "werewolf", "vampire", "vampire_hunter"];
    
    if (needsPlayerList.includes(player.role)) {
      const playersList = await Utils.listPlayers(game, usersData, false);
      msg += `رد برقم اللاعب:\n${playersList}\n____________________________\n`;
    }
    
    const actionDescriptions = {
      "mafia": `🔪 اختر رقم اللاعب الذي تريد قتله\n💀 اختر بحكمة!`,
      "godfather": `🔪 اختر رقم اللاعب الذي تريد قتله\n💀 اختر بحكمة!`,
      "consigliere": `🎯 اختر رقماً للكشف الدقيق عن دوره`,
      "framer": `🖼️ اختر رقماً لتزويره وجعله يظهر كمافيا`,
      "janitor": `🧹 اختر رقماً لإخفاء دوره بعد موته${player.abilities.clean ? `\n⚡ متبقي: ${player.abilities.clean} مرة` : ''}`,
      "blackmailer": `🤫 اختر رقماً لابتزازه ومنعه من التصويت`,
      "cop": `👮 اختر رقماً للتحقيق منه`,
      "sheriff": `⭐ اختر رقماً لفحصه وقتله إن كان مافيا`,
      "doctor": `💊 اختر رقماً لحمايته من القتل`,
      "bodyguard": `🛡️ اختر رقماً لحراسته والموت بدلاً منه`,
      "vigilante": `🔫 اختر رقماً لقتله${player.abilities.vigi_kill ? `\n⚡ متبقي: ${player.abilities.vigi_kill} مرة` : ''}`,
      "lookout": `👁️ اختر رقماً لمراقبة منزله`,
      "tracker": `🔎 اختر رقماً لتعقبه ومعرفة من زار`,
      "escort": `💃 اختر رقماً لإشغاله ومنعه من التصرف`,
      "crusader": `⚔️🛡️ اختر رقماً لحراسته وقتل من يهاجمه`,
      "trapper": `🪤 اختر رقماً لنصب فخ على منزله`,
      "serial_killer": `🔪💀 اختر رقماً لقتله بدم بارد`,
      "werewolf": `🐺 اختر رقماً لمهاجمته وقتل كل زواره`,
      "vampire": `🧛 اختر رقماً لتحويله لمصاص دماء`,
      "vampire_hunter": `🧄 اختر رقماً لفحصه وقتله إن كان مصاص دماء`
    };
    
    msg += actionDescriptions[player.role] || "";
  }
  
  msg += `\n____________________________\n⚠️ إقرأ جيداً! اختر بحكمة 🧠`;
  
  try {
    let messageID;
    const playerName = await usersData.getName(player.userID);
    
    if (Config.InboxMode) {
      const result = await mqtt.sendMessage(msg, player.userID);
      messageID = result.messageID;
    } else {
      if (player.groupID) {
        try {
          const result = await mqtt.sendMessage(msg, player.groupID);
          messageID = result.messageID;
        } catch (groupError) {
          console.error(`[MAFIA42] Failed to send to group ${player.groupID}, falling back to inbox:`, groupError);
          await mqtt.sendMessage(`⚠️ خطأ في إرسال رسالة ليلية للاعب ${playerName}`, game.main);
          const result = await mqtt.sendMessage(msg, player.userID);
          messageID = result.messageID;
        }
      } else {
        console.error(`[MAFIA42] Player ${player.userID} has no groupID, sending to inbox`);
        await mqtt.sendMessage(`⚠️ اللاعب ${playerName} ليس لديه غرفة خاصة، تم الإرسال للإنبوكس`, game.main);
        const result = await mqtt.sendMessage(msg, player.userID);
        messageID = result.messageID;
      }
    }
    
    if (messageID) {
      global.YamiBot.onReply.set(messageID, {
        commandName: game.commandName,
        gameID: game.id,
        playerID: player.userID,
        type: "night"
      });
    } else {
      console.error(`[MAFIA42] No messageID returned for player ${player.userID}`);
      await mqtt.sendMessage(`❌ خطأ: لم يتم تسجيل استماع الرد للاعب ${playerName}`, game.main);
    }
  } catch (error) {
    console.error(`[MAFIA42] Critical error sending night message to ${player.userID}:`, error);
    const playerName = await usersData.getName(player.userID);
    await mqtt.sendMessage(`❌ خطأ حرج: فشل إرسال رسالة ليلية للاعب ${playerName}`, game.main);
  }
}

async function handlePsychicVision(mqtt, game, player, usersData) {
  const alivePlayers = Variables.alive(game);
  if (alivePlayers.length < 3) {
    await Utils.sendToPlayerOrRoom(mqtt, player, `❌ لا يوجد لاعبون كافيون للرؤيا! 😔`);
    return;
  }
  
  const shuffled = Utils.secureShuffle(alivePlayers.filter(pl => pl.userID !== player.userID));
  const evilRoles = ["mafia", "godfather", "consigliere", "framer", "janitor", "blackmailer", 
    "serial_killer", "werewolf", "arsonist", "witch"];
  const evilPlayer = shuffled.find(pl => evilRoles.includes(pl.role));
  
  if (!evilPlayer) {
    await Utils.sendToPlayerOrRoom(mqtt, player, `❌ لا يوجد أشرار في الرؤيا! 😔`);
    return;
  }
  
  const goodPlayer = shuffled.find(pl => pl.userID !== evilPlayer.userID && !evilRoles.includes(pl.role));
  if (!goodPlayer) {
    await Utils.sendToPlayerOrRoom(mqtt, player, `❌ لا يوجد أخيار في الرؤيا! 😂 لووول متت`);
    return;
  }
  
  const pair = Utils.secureRandom(0, 1) === 0 ? [evilPlayer, goodPlayer] : [goodPlayer, evilPlayer];
  const name1 = await usersData.getName(pair[0].userID);
  const name2 = await usersData.getName(pair[1].userID);
  
  await Utils.sendToPlayerOrRoom(mqtt, player, 
    `🔮 رؤياك الليلة 🔮\n____________________________\n\n👤 ${name1}\n👤 ${name2}\n\n____________________________\n⚠️ أحدهما شرير بالتأكيد!\n✨ استخدم هذه المعلومة بحكمة`
  );
}

async function handleMediumSeance(mqtt, game, player, usersData) {
  const deadPlayers = Object.values(game.players).filter(pl => !pl.alive);
  if (deadPlayers.length === 0) {
    await Utils.sendToPlayerOrRoom(mqtt, player, `❌ لا توجد أرواح للحديث معها! 😔`);
    return;
  }
  
  const randomDead = Utils.getRandomElement(deadPlayers);
  const deadName = await usersData.getName(randomDead.userID);
  const roleData = Config.ROLES[randomDead.role];
  
  await Utils.sendToPlayerOrRoom(mqtt, player, 
    `👻 تواصلت مع روح ${deadName}!\n____________________________\n\n🎭 دوره: ${roleData.emoji} ${roleData.name}\n\n____________________________\n💬 الأموات يخبرون الحقيقة!`
  );
}

function nightPhaseTimer(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  const timer1 = setTimeout(async () => {
    if (game.phase === "night") {
      await mqtt.sendMessage(`⏰ تبقى ${Config.gameSettings.nightReminderMs / 1000} ثواني على نهاية الليل! 🌙`, game.main);
    }
  }, Config.gameSettings.nightDurationMs - Config.gameSettings.nightReminderMs);
  
  const timer2 = setTimeout(() => {
    if (game.phase === "night") {
      resolveNightActions(mqtt, gameID, usersData);
    }
  }, Config.gameSettings.nightDurationMs);
  
  Variables.addTimer(gameID, timer1);
  Variables.addTimer(gameID, timer2);
}

async function handleNightAction(Reply, event, mqtt, usersData) {
  const game = Variables.getGame(Reply.gameID);
  if (!game || game.phase !== "night") return;
  
  const player = game.players[Reply.playerID];
  if (!player || !player.alive) return;
  
  if (player.roleblocked) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "💤 تم إشغالك! لا يمكنك التصرف الليلة 😴");
  }
  
  const input = event.body.trim();
  const parsed = Utils.parseActionInput(input);
  
  if (parsed.type === "confirm") {
    return handleConfirmAction(game, player, mqtt);
  }
  
  if (parsed.type === "ignite" && player.role === "arsonist") {
    game.nightActions[player.userID] = { type: "ignite" };
    return Utils.sendToPlayerOrRoom(mqtt, player, `🔥 سيحترق كل من أشعلتهم! 💥\n____________________________\n😈 نار الانتقام قادمة!`);
  }
  
  if (parsed.type === "two_targets") {
    return handleTwoTargetAction(game, player, parsed.target1, parsed.target2, mqtt, usersData);
  }
  
  if (parsed.type === "single_target") {
    return handleSingleTargetAction(game, player, parsed.target, mqtt, usersData);
  }
  
  return Utils.sendToPlayerOrRoom(mqtt, player, "❌ إدخال غير صحيح! اتبع التعليمات 🔢");
}

async function handleConfirmAction(game, player, mqtt) {
  const yesActions = ["veteran", "survivor"];
  if (!yesActions.includes(player.role)) return;
  
  if (player.role === "veteran") {
    if (!Utils.hasRoleAbilityUses(player, "alert")) {
      return Utils.sendToPlayerOrRoom(mqtt, player, "❌ لا توجد استخدامات متبقية! 😔");
    }
    game.nightActions[player.userID] = { type: "alert" };
    Utils.decrementAbilityUse(player, "alert");
    player.alerted = true;
    return Utils.sendToPlayerOrRoom(mqtt, player, `⚔️ متحصن! ستقتل كل من يزورك الليلة! 💀\n____________________________\n⚡ متبقي: ${player.abilities.alert} مرة`);
  } else if (player.role === "survivor") {
    if (!Utils.hasRoleAbilityUses(player, "vest")) {
      return Utils.sendToPlayerOrRoom(mqtt, player, "❌ لا توجد دروع متبقية! 😔");
    }
    game.nightActions[player.userID] = { type: "vest" };
    Utils.decrementAbilityUse(player, "vest");
    player.protected = true;
    return Utils.sendToPlayerOrRoom(mqtt, player, `🦺 استخدمت الدرع! أنت محمي الليلة! 🛡️\n____________________________\n⚡ متبقي: ${player.abilities.vest} مرة`);
  }
}

async function handleTwoTargetAction(game, player, target1Index, target2Index, mqtt, usersData) {
  const target1 = Variables.getPlayerByIndex(game, target1Index);
  const target2 = Variables.getPlayerByIndex(game, target2Index);
  
  if (!target1 || !target2) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ أرقام خاطئة! تحقق من القائمة 📋");
  }
  
  if (player.role === "transporter") {
    game.nightActions[player.userID] = { 
      type: "transport", 
      target1: target1.userID, 
      target2: target2.userID 
    };
    const name1 = await usersData.getName(target1.userID);
    const name2 = await usersData.getName(target2.userID);
    return Utils.sendToPlayerOrRoom(mqtt, player, `🚗 سيتم تبديل ${name1} و ${name2}!\n____________________________\n🔄 كل من يزور أحدهما سيزور الآخر!`);
  } else if (player.role === "witch") {
    game.nightActions[player.userID] = { 
      type: "control", 
      target: target1.userID, 
      newTarget: target2.userID 
    };
    const name1 = await usersData.getName(target1.userID);
    const name2 = await usersData.getName(target2.userID);
    return Utils.sendToPlayerOrRoom(mqtt, player, `🧙 ستسيطرين على ${name1}!\n____________________________\n🎯 هدفه الجديد: ${name2}\n✨ السحر يعمل!`);
  }
}

async function handleSingleTargetAction(game, player, targetIndex, mqtt, usersData) {
  let target;
  
  if (player.role === "retributionist" || player.role === "amnesiac") {
    const dead = Object.values(game.players).filter(p => !p.alive);
    if (targetIndex < 1 || targetIndex > dead.length) {
      return Utils.sendToPlayerOrRoom(mqtt, player, "❌ رقم خاطئ! اختر من الموتى 💀");
    }
    target = dead[targetIndex - 1];
    
    const ability = player.role === "retributionist" ? "revive" : "remember";
    if (!Utils.hasRoleAbilityUses(player, ability)) {
      return Utils.sendToPlayerOrRoom(mqtt, player, "❌ لا توجد استخدامات متبقية! 😔");
    }
    
    game.nightActions[player.userID] = { type: ability, target: target.userID };
    Utils.decrementAbilityUse(player, ability);
    
    const targetName = await usersData.getName(target.userID);
    const msg = player.role === "retributionist" 
      ? `✅ تم التأكيد!\n____________________________\n💀➡️ سيتم إحياء ${targetName}!\n____________________________\n⏳ انتظر النتائج...`
      : `✅ تم التأكيد!\n____________________________\n❓ ستتذكر دور ${targetName}!\n____________________________\n⏳ انتظر النتائج...`;
    
    return Utils.sendToPlayerOrRoom(mqtt, player, msg);
  } else {
    target = Variables.getPlayerByIndex(game, targetIndex);
    if (!target) {
      return Utils.sendToPlayerOrRoom(mqtt, player, "❌ رقم خاطئ! تحقق من القائمة 📋");
    }
  }
  
  if (!Variables.canUseSkillOn(game, player.userID, target.userID, player.role)) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "⚠️ لقد استخدمت هذه القدرة على هذا اللاعب! اختر هدفاً آخر 🔄");
  }
  
  const simpleActions = {
    "mafia": "kill", "godfather": "kill", "consigliere": "precise_check",
    "framer": "frame", "janitor": "clean", "blackmailer": "blackmail",
    "cop": "investigate", "sheriff": "sheriff_check", "doctor": "heal",
    "bodyguard": "bodyguard", "vigilante": "vigi_kill", "lookout": "lookout",
    "tracker": "track", "escort": "roleblock", "crusader": "crusade",
    "trapper": "trap", "arsonist": "douse", "serial_killer": "sk_kill",
    "werewolf": "maul", "vampire": "convert_vamp", "vampire_hunter": "vh_check"
  };
  
  const actionType = simpleActions[player.role];
  if (!actionType) return;
  
  if ((player.role === "vigilante" && !Utils.hasRoleAbilityUses(player, "vigi_kill")) ||
      (player.role === "janitor" && !Utils.hasRoleAbilityUses(player, "clean"))) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ لا توجد استخدامات متبقية! 😔");
  }
  
  game.nightActions[player.userID] = { type: actionType, target: target.userID };
  Variables.trackSkillUsage(game, player.userID, target.userID, player.role);
  
  if (player.role === "vigilante") Utils.decrementAbilityUse(player, "vigi_kill");
  if (player.role === "janitor") Utils.decrementAbilityUse(player, "clean");
  
  const targetName = await usersData.getName(target.userID);
  const confirmations = {
    "kill": `🔪 سيتم قتل ${targetName} الليلة!`,
    "precise_check": `🎯 سيتم الكشف الدقيق عن ${targetName}!`,
    "frame": `🖼️ سيتم تزوير ${targetName}!`,
    "clean": `🧹 سيتم تنظيف دور ${targetName}!`,
    "blackmail": `😂 سيتم ابتزاز ${targetName}!`,
    "investigate": `👮 سيتم التحقيق من ${targetName}!`,
    "sheriff_check": `⭐ سيتم فحص ${targetName}!`,
    "heal": `💊 سيتم حماية ${targetName}!`,
    "bodyguard": `🛡️ ستحرس ${targetName}!`,
    "vigi_kill": `🔫 سيتم قتل ${targetName}!`,
    "lookout": `👁️ ستراقب ${targetName}!`,
    "track": `🔎 ستتعقب ${targetName}!`,
    "roleblock": `💃 سيتم إشغال ${targetName}!`,
    "crusade": `⚔️🛡️ ستحرس ${targetName}!`,
    "trap": `🪤 سيتم نصب فخ على ${targetName}!`,
    "douse": `🔥 سيتم إشعال ${targetName}!`,
    "sk_kill": `🔪💀 سيتم قتل ${targetName}!`,
    "maul": `🐺 سيتم مهاجمة ${targetName}!`,
    "convert_vamp": `🧛 سيتم تحويل ${targetName}!`,
    "vh_check": `🧄 سيتم فحص ${targetName}!`
  };
  
  return Utils.sendToPlayerOrRoom(mqtt, player, `✅ تم التأكيد!\n____________________________\n${confirmations[actionType] || `تم: ${targetName}`}\n____________________________\n⏳ انتظر النتائج...`);
}

async function resolveNightActions(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  const NightResolution = require('./NightResolution');
  await NightResolution.resolveActions(mqtt, game, usersData);
}

module.exports = {
  startNightPhase,
  nightPhaseTimer,
  handleNightAction
};
