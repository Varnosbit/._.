

module.exports = {
    config: {
        name: "setname",
        aliases: ["سيتنيم",
            "name"],
        role: 0,
        description: {
            en: "Change your display name (max 14 characters, English letters only)",
            ar: "تغيير اسم العرض (بحد أقصى 14 حرفًا، أحرف إنجليزية فقط)"
        },
        category: "Status",
        countDown: 10
    },
    onStart: async function({
        message, event, usersData, args
    }) {
        const id = event.senderID;
        const name = args.join(' ').trim();

        if (name.length > 14) {
            message.reply("Name cannot exceed 14 characters. Please try again.");
            return;
        }

        const namePattern = /^[A-Za-z\s]+$/;
        if (!namePattern.test(name)) {
            message.reply("Name can only contain English letters. Please try again.");
            return;
        }

        await helpers.setP(usersData, id, name, "name");
        message.reply(`Your name has been successfully changed to: ${name}`);
    }
};