const axios = require("axios");
const FormData = require("form-data");
const fetch = require("node-fetch");

module.exports = {
    config: {
        name: "p",
        version: "1.6",
        author: "allou mohamed",
        countDown: 5,
        role: 2,
        description: {
            ar: "prompt",
            en: "prompt"
        },
        category: "owner",
        guide: {
            ar: "{pn} reply",
            en: "{pn} reply"
        }
    },

    onStart: async function({ message, event, args }) {
        try {
            if (typeof helpers === "undefined") {
                return message.reply("⚠️ helpers is not available in this context.");
            }

            const imageUrl = event?.messageReply?.attachments?.[0]?.url;

            if (args.length) {
                const r = await helpers.enhancePrompt(args.join(" "));
                return message.reply(r?.prompt || "⚠️ No prompt returned.");
            }

            if (imageUrl) {
                const r = await helpers.Prompt1(imageUrl);
                return message.reply(r?.prompt || "⚠️ No prompt returned.");
            }

            return message.reply("⚠️ Please provide text or reply to an image.");
        } catch (err) {
            return message.reply("❌ Error: " + err.message);
        }
    }
};
