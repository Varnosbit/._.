/*
const fetch = require('node-fetch');

class ChippChatClient {
  constructor(appNameId, cookies = "") {
    this.appNameId = appNameId;
    this.cookies = cookies;
    this.sessionId = null;
    this.baseUrl = `https://${appNameId}.chipp.ai`;
    this.conversationHistory = [];
  }

  async startNewSession() {
    try {
      const response = await fetch(`${this.baseUrl}/w/chat/`, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,* /*;q=0.8',
          'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"Windows"',
          'Cookie': this.cookies
        },
        redirect: 'manual'
      });

      // Extract session ID from redirect location or response body
      const location = response.headers.get('location');
      if (location) {
        const match = location.match(/session\/([a-f0-9-]+)/);
        if (match) {
          this.sessionId = match[1];
          console.log(`New session created: ${this.sessionId}`);
          return this.sessionId;
        }
      }

      // If no redirect, parse HTML for session ID
      const html = await response.text();
      const match = html.match(/session\/([a-f0-9-]+)/);
      if (match) {
        this.sessionId = match[1];
        console.log(`New session created: ${this.sessionId}`);
        return this.sessionId;
      }

      throw new Error('Could not extract session ID');
    } catch (error) {
      console.error('Error starting session:', error);
      throw error;
    }
  }

  generateMessageId() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 16; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  parseSSEStream(text) {
    const lines = text.split('\n');
    const events = [];
    let currentEvent = null;

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        const data = line.substring(6);
        
        if (data === '[DONE]') {
          break;
        }

        try {
          const parsed = JSON.parse(data);
          events.push(parsed);
        } catch (e) {
          // Skip invalid JSON
        }
      }
    }

    return events;
  }

  async sendMessage(text) {
    if (!this.sessionId) {
      throw new Error('No active session. Call startNewSession() first.');
    }

    const messageId = this.generateMessageId();
    
    // Add user message to history
    const userMessage = {
      id: messageId,
      role: "user",
      parts: [{ type: "text", text: text }]
    };
    
    this.conversationHistory.push(userMessage);

    const payload = {
      chatSessionId: this.sessionId,
      id: messageId,
      messages: this.conversationHistory,
      trigger: "submit-message"
    };

    try {
      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream',
          'x-app-name-id': this.appNameId,
          'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"Windows"',
          'origin': this.baseUrl,
          'sec-fetch-site': 'same-origin',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': `${this.baseUrl}/w/chat/${this.appNameId}/session/${this.sessionId}`,
          'Cookie': this.cookies
        },
        body: JSON.stringify(payload)
      });

      const rawText = await response.text();
      const events = this.parseSSEStream(rawText);

      // Extract response text and images
      let responseText = '';
      const images = [];
      let assistantMessageId = null;
      let metadata = {};

      for (const event of events) {
        switch (event.type) {
          case 'start':
            assistantMessageId = event.messageId;
            break;
          
          case 'text-delta':
            responseText += event.delta || '';
            break;

          case 'tool-output-available':
            // Extract image URLs from markdown
            if (event.output) {
              const imgMatch = event.output.match(/!\[.*?\]\((https?:\/\/[^\)]+)\)/);
              if (imgMatch) {
                images.push(imgMatch[1]);
              }
            }
            break;

          case 'message-metadata':
            if (event.messageMetadata) {
              metadata = { ...metadata, ...event.messageMetadata };
            }
            break;
        }
      }

      // Add assistant message to history
      const assistantMessage = {
        id: assistantMessageId || this.generateMessageId(),
        role: "assistant",
        parts: [
          {
            type: "text",
            text: responseText,
            state: "done"
          }
        ],
        metadata: metadata
      };

      this.conversationHistory.push(assistantMessage);

      return {
        response: responseText,
        imgs: images,
        messageId: assistantMessageId,
        metadata: metadata
      };

    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  clearHistory() {
    this.conversationHistory = [];
  }

  getHistory() {
    return this.conversationHistory;
  }
}
*/
const fetch = require('node-fetch');

class ChippChatClient {
  constructor(appNameId, cookies = "") {
    this.appNameId = appNameId;
    this.cookieJar = this.parseCookies(cookies);
    this.sessionId = null;
    this.baseUrl = `https://${appNameId}.chipp.ai`;
    this.conversationHistory = [];
  }

  parseCookies(cookieString) {
    const cookies = {};
    if (!cookieString) return cookies;
    
    cookieString.split(';').forEach(cookie => {
      const [name, ...rest] = cookie.trim().split('=');
      if (name) {
        cookies[name] = rest.join('=');
      }
    });
    return cookies;
  }

  getCookieString() {
    return Object.entries(this.cookieJar)
      .map(([name, value]) => `${name}=${value}`)
      .join('; ');
  }

  updateCookies(setCookieHeaders) {
    if (!setCookieHeaders) return;
    
    const headers = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
    
    headers.forEach(header => {
      const [cookiePart] = header.split(';');
      const [name, value] = cookiePart.split('=');
      
      if (name && value) {
        this.cookieJar[name.trim()] = value.trim();
      }
    });
  }

  async startNewSession() {
    try {
      const cookieString = this.getCookieString();
      const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-site': 'none',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document'
      };

      if (cookieString) {
        headers['Cookie'] = cookieString;
      }

      const response = await fetch(`${this.baseUrl}/w/chat/`, {
        method: 'GET',
        headers: headers,
        redirect: 'manual'
      });

      // Update cookies from response
      const setCookie = response.headers.get('set-cookie');
      if (setCookie) {
        this.updateCookies(setCookie);
      }

      // Extract session ID from redirect location or response body
      const location = response.headers.get('location');
      if (location) {
        const match = location.match(/session\/([a-f0-9-]+)/);
        if (match) {
          this.sessionId = match[1];
          console.log(`New session created: ${this.sessionId}`);
          return this.sessionId;
        }
      }

      // If no redirect, parse HTML for session ID
      const html = await response.text();
      const match = html.match(/session\/([a-f0-9-]+)/);
      if (match) {
        this.sessionId = match[1];
        console.log(`New session created: ${this.sessionId}`);
        return this.sessionId;
      }

      throw new Error('Could not extract session ID');
    } catch (error) {
      console.error('Error starting session:', error);
      throw error;
    }
  }

  generateMessageId() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 16; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  parseSSEStream(text) {
    const lines = text.split('\n');
    const events = [];
    let currentEvent = null;

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        const data = line.substring(6);
        
        if (data === '[DONE]') {
          break;
        }

        try {
          const parsed = JSON.parse(data);
          events.push(parsed);
        } catch (e) {
          // Skip invalid JSON
        }
      }
    }

    return events;
  }

  async sendMessage(text) {
    if (!this.sessionId) {
      throw new Error('No active session. Call startNewSession() first.');
    }

    const messageId = this.generateMessageId();
    
    // Add user message to history
    const userMessage = {
      id: messageId,
      role: "user",
      parts: [{ type: "text", text: text }]
    };
    
    this.conversationHistory.push(userMessage);

    const payload = {
      chatSessionId: this.sessionId,
      id: messageId,
      messages: this.conversationHistory,
      trigger: "submit-message"
    };

    try {
      const cookieString = this.getCookieString();
      const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream',
        'x-app-name-id': this.appNameId,
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'origin': this.baseUrl,
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'referer': `${this.baseUrl}/w/chat/${this.appNameId}/session/${this.sessionId}`
      };

      if (cookieString) {
        headers['Cookie'] = cookieString;
      }

      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(payload)
      });

      // Update cookies from response
      const setCookie = response.headers.get('set-cookie');
      if (setCookie) {
        this.updateCookies(setCookie);
      }

      const rawText = await response.text();
      const events = this.parseSSEStream(rawText);

      // Extract response text and images
      let responseText = '';
      const images = [];
      let assistantMessageId = null;
      let metadata = {};

      for (const event of events) {
        switch (event.type) {
          case 'start':
            assistantMessageId = event.messageId;
            break;
          
          case 'text-delta':
            responseText += event.delta || '';
            break;

          case 'tool-output-available':
            // Extract image URLs from markdown
            if (event.output) {
              const imgMatch = event.output.match(/!\[.*?\]\((https?:\/\/[^\)]+)\)/);
              if (imgMatch) {
                images.push(imgMatch[1]);
              }
            }
            break;

          case 'message-metadata':
            if (event.messageMetadata) {
              metadata = { ...metadata, ...event.messageMetadata };
            }
            break;
        }
      }

      // Add assistant message to history
      const assistantMessage = {
        id: assistantMessageId || this.generateMessageId(),
        role: "assistant",
        parts: [
          {
            type: "text",
            text: responseText,
            state: "done"
          }
        ],
        metadata: metadata
      };

      this.conversationHistory.push(assistantMessage);
      if (this.conversationHistory.length > 10) this.conversationHistory.shift();
      return {
        response: responseText,
        imgs: images,
        messageId: assistantMessageId,
        metadata: metadata
      };

    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  clearHistory() {
    this.conversationHistory = [];
  }

  getHistory() {
    return this.conversationHistory;
  }
}
// Example usage (for testing):
/*
(async () => {
  const client = new ChippChatClient("yami-10032249");
  
  await client.startNewSession();
  
  const result = await client.sendMessage("مرحبا");
  console.log("Response:", result.response);
  console.log("Images:", result.imgs);
  
  const result2 = await client.sendMessage("draw a cat");
  console.log("Response:", result2.response);
  console.log("Images:", result2.imgs);
})();
*/
const APP_NAME_ID = "yuki-10032249";
const COOKIES = "";

const sessions = {};

module.exports = {
  config: {
    name: "gpt",
    aliases: ["يامي"],
    version: "1.1.0",
    author: "Allou",
    countDown: 0,
    role: 0,
    desc: {
      en: "yami is based on gpt",
      ar: "يامي شات جي بي تي متطور"
    },
  },

  onStart: async function ({ message, event, args, commandName }) {
    const senderID = event.senderID;
    const text = args.join(" ");
    if (!text) {
      return message.reply("اكتب ما تريد قوله ليامي.");
    }
    if (!sessions[senderID]) {
      const client = new ChippChatClient(APP_NAME_ID, COOKIES);
      await client.startNewSession();
      sessions[senderID] = client;
    }
    const client = sessions[senderID];
    try {
      const result = await client.sendMessage(text);
      const reply = result.response || "لا يوجد رد.";
      const imgs = result.imgs;
      let h;
      if (reply && !imgs.length) {
        h = await message.send(reply);
      } else {
        h = await message.stream(reply, imgs);
      }
      YamiBot.onReply.set(h.messageID, { commandName });
    } catch (e) {
      message.send("حدث خطأ أثناء الاتصال بيامي.");
    }
  },

  onReply: async function ({ message, event, args, commandName }) {
    const senderID = event.senderID;
    const text = args.join(" ");
    if (!sessions[senderID]) {
      const client = new ChippChatClient(APP_NAME_ID, COOKIES);
      await client.startNewSession();
      sessions[senderID] = client;
    }
    const client = sessions[senderID];
    try {
      const result = await client.sendMessage(text);
      const reply = result.response || "لا يوجد رد.";
      const imgs = result.imgs;
      let h;
      if (reply && !imgs.length) {
        h = await message.send(reply);
      } else {
        h = await message.stream(reply, imgs);
      }
      YamiBot.onReply.set(h.messageID, { commandName });
    } catch (e) {
      message.send("حدث خطأ أثناء الاتصال بيامي.");
    }
  }
};
