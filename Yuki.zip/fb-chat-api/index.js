"use strict";

const utils = require("./utils");
const log = require("npmlog");
const cron = require("node-cron");
const fs = require("fs").promises;
const path = require("path");

// Constants
const DEFAULT_LOG_RECORD_SIZE = 100;
const DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36";
const FACEBOOK_BASE_URL = "https://www.facebook.com";
const DTSG_REFRESH_CRON = "0 0 * * *"; // Daily at midnight
const TIMEZONE = "Africa/Algiers";

// Initialize log settings
log.maxRecordSize = DEFAULT_LOG_RECORD_SIZE;

/**
 * Configuration options for the API
 */
const DEFAULT_OPTIONS = {
    selfListen: false,
    selfListenEvent: false,
    listenEvents: false,
    listenTyping: false,
    updatePresence: false,
    forceLogin: false,
    autoMarkDelivery: true,
    autoMarkRead: false,
    autoReconnect: true,
    logRecordSize: DEFAULT_LOG_RECORD_SIZE,
    online: true,
    emitReady: false,
    userAgent: DEFAULT_USER_AGENT
};

/**
 * Validates and sets global options
 * @param {Object} globalOptions - Global options object to modify
 * @param {Object} options - Options to set
 */
function setOptions(globalOptions, options) {
    const optionHandlers = {
        online: (value) => Boolean(value),
        logLevel: (value) => {
            log.level = value;
            return value;
        },
        logRecordSize: (value) => {
            log.maxRecordSize = value;
            return value;
        },
        selfListen: (value) => Boolean(value),
        selfListenEvent: (value) => value,
        listenEvents: (value) => Boolean(value),
        pageID: (value) => value.toString(),
        updatePresence: (value) => Boolean(value),
        forceLogin: (value) => Boolean(value),
        userAgent: (value) => value,
        autoMarkDelivery: (value) => Boolean(value),
        autoMarkRead: (value) => Boolean(value),
        listenTyping: (value) => Boolean(value),
        proxy: (value) => {
            if (typeof value !== "string") {
                delete globalOptions.proxy;
                utils.setProxy();
                return undefined;
            }
            utils.setProxy(value);
            return value;
        },
        autoReconnect: (value) => Boolean(value),
        emitReady: (value) => Boolean(value)
    };

    Object.entries(options).forEach(([key, value]) => {
        const handler = optionHandlers[key];
        if (handler) {
            const processedValue = handler(value);
            if (processedValue !== undefined) {
                globalOptions[key] = processedValue;
            }
        } else {
            log.warn("setOptions", `Unrecognized option: ${key}`);
        }
    });
}

/**
 * Extracts tokens from HTML response
 * @param {string} html - HTML content
 * @returns {Object} Extracted tokens
 */
function extractTokens(html) {
    const tokens = {};
    
    try {
        // Extract fb_dtsg token
        const dtsgMatch = html.match(/DTSGInitialData.*?token":"(.*?)"/);
        if (dtsgMatch) {
            tokens.fb_dtsg = dtsgMatch[1];
        }
        
        // Extract jazoest token
        const jazoestMatch = html.match(/jazoest=([^"&,]+)/);
        if (jazoestMatch) {
            tokens.jazoest = jazoestMatch[1];
        }
        
        // Extract MQTT endpoint and region
        const endpointMatch = html.match(/"endpoint":"([^"]+)"/);
        if (endpointMatch) {
            tokens.mqttEndpoint = endpointMatch[1].replace(/\\\//g, '/');
            try {
                const url = new URL(tokens.mqttEndpoint);
                tokens.region = url.searchParams.get('region')?.toUpperCase() || "PRN";
            } catch (e) {
                log.warn('extractTokens', 'Failed to parse MQTT endpoint URL');
            }
        }
        
    } catch (error) {
        log.error('extractTokens', `Error extracting tokens: ${error.message}`);
    }
    
    return tokens;
}

/**
 * Updates DTSG tokens from response
 * @param {Object} res - HTTP response
 * @param {Array} appstate - Application state (unused, kept for compatibility)
 * @param {string} userId - User ID for logging
 * @returns {Object} Updated tokens and response
 */
async function updateDTSG(res, appstate, userId) {
    try {
        if (!res?.body) {
            throw new Error("Invalid response: Response body is missing.");
        }
        
        const fb_dtsg = utils.getFrom(res.body, '["DTSGInitData",[],{"token":"', '","');
        const jazoest = utils.getFrom(res.body, 'jazoest=', '",');
        
        return { res, fb_dtsg, jazoest };
    } catch (error) {
        log.error('updateDTSG', `Error updating DTSG for user ${userId || 'unknown'}: ${error.message}`);
        return { res };
    }
}

/**
 * Validates user cookies and extracts user information
 * @param {Object} jar - Cookie jar
 * @returns {Object} User information
 */
function validateAndExtractUserInfo(jar) {
    const cookies = jar.getCookies(FACEBOOK_BASE_URL);
    
    const maybeCookie = cookies.filter(val => 
        val.cookieString().split("=")[0] === "c_user"
    );
    
    if (maybeCookie.length === 0) {
        throw { 
            error: "Error retrieving userID. This can be caused by getting blocked by Facebook for logging in from an unknown location. Try logging in with a browser to verify." 
        };
    }
    
    const objCookie = cookies.reduce((obj, val) => {
        const [key, value] = val.cookieString().split("=");
        obj[key] = value;
        return obj;
    }, {});
    
    const userID = maybeCookie[0].cookieString().split("=")[1].toString();
    const i_userID = objCookie.i_user || null;
    
    return { userID, i_userID };
}

/**
 * Loads API functions from directory
 * @param {string} dirPath - Directory path
 * @param {Object} defaultFuncs - Default functions
 * @param {Object} api - API object
 * @param {Object} ctx - Context object
 * @returns {Object} Loaded functions
 */
async function loadAPIFunctions(dirPath, defaultFuncs, api, ctx) {
    const functions = {};
    
    try {
        const files = await fs.readdir(dirPath);
        const jsFiles = files.filter(file => file.endsWith('.js'));
        
        for (const file of jsFiles) {
            const funcName = file.replace('.js', '');
            const funcPath = path.join(dirPath, file);
            
            try {
                functions[funcName] = require(funcPath)(defaultFuncs, api, ctx);
            } catch (error) {
                log.error('loadAPIFunctions', `Failed to load function ${funcName}: ${error.message}`);
            }
        }
    } catch (error) {
        log.error('loadAPIFunctions', `Failed to read directory ${dirPath}: ${error.message}`);
    }
    
    return functions;
}

/**
 * Sets up DTSG token refresh cron job
 * @param {Object} ctx - Context object
 * @param {Object} globalOptions - Global options
 */
function setupTokenRefresh(ctx, globalOptions) {
    const refreshJob = cron.schedule(DTSG_REFRESH_CRON, async () => {
        try {
            log.info("tokenRefresh", `Starting token refresh for user ${ctx.userID}`);
            
            const res = await utils.get(FACEBOOK_BASE_URL + '/', ctx.jar, null, globalOptions, { noRef: true });
            const dtsgResult = await updateDTSG(res, null, ctx.userID);
            
            if (dtsgResult.fb_dtsg && dtsgResult.jazoest) {
                ctx.fb_dtsg = dtsgResult.fb_dtsg;
                ctx.jazoest = dtsgResult.jazoest;
                log.info("tokenRefresh", `Tokens refreshed successfully for user ${ctx.userID}`);
            } else {
                log.error("tokenRefresh", `Failed to extract new tokens for user ${ctx.userID}`);
            }
        } catch (error) {
            log.error("tokenRefresh", `Error during token refresh for user ${ctx.userID}: ${error.message}`);
        }
    }, {
        timezone: TIMEZONE,
        scheduled: false // Don't start immediately
    });
    
    // Start the cron job
    refreshJob.start();
    
    return refreshJob;
}

/**
 * Builds the main API object
 * @param {Object} globalOptions - Global options
 * @param {string} html - HTML content
 * @param {Object} jar - Cookie jar
 * @returns {Array} Context, default functions, API, and MQTT objects
 */
async function buildAPI(globalOptions, html, jar) {
    // Validate user info
    const { userID, i_userID } = validateAndExtractUserInfo(jar);
    
    // Check for checkpoint
    if (html.indexOf("/checkpoint/block/?next") > -1) {
        log.warn("login", "Checkpoint detected. Please log in with a browser to verify.");
    }
    if (html.indexOf("601051028565049") > -1) {
        return log.error("login", "Checkpoint FbScrap Warn.");
    }
    
    log.info("login", `Logged in as ${userID}`);
    
    // Generate client ID
    const clientID = (Math.random() * 2147483648 | 0).toString(16);
    
    // Extract tokens
    const tokens = extractTokens(html);
    
    // Create context
    const ctx = {
        userID,
        i_userID,
        jar,
        clientID,
        globalOptions,
        loggedIn: true,
        access_token: 'NONE',
        clientMutationId: 0,
        mqttClient: undefined,
        lastSeqId: tokens.irisSeqID,
        syncToken: undefined,
        mqttEndpoint: tokens.mqttEndpoint,
        wsReqNumber: 0,
        wsTaskNumber: 0,
        reqCallbacks: {},
        region: tokens.region,
        firstListen: true,
        fb_dtsg: tokens.fb_dtsg,
        jazoest: tokens.jazoest,
        refreshJob: null // Will store the cron job
    };
    
    // Log server region
    if (tokens.region) {
        log.info('login', `Server region: ${tokens.region}`);
    }
    
    // Create API object
    const api = {
        setOptions: setOptions.bind(null, globalOptions),
        getAppState: function getAppState() {
            const appState = utils.getAppState(jar);
            // Remove duplicates based on key
            return appState.filter((item, index, self) => 
                self.findIndex(t => t.key === item.key) === index
            );
        }
    };
    
    // Create MQTT object
    const mqtt = {};
    
    // Setup token refresh
    ctx.refreshJob = setupTokenRefresh(ctx, globalOptions);
    
    // Create default functions
    const defaultFuncs = utils.makeDefaults(html, i_userID || userID, ctx);
    
    // Load API functions
    try {
        const srcPath = path.join(__dirname, 'src');
        const mqttPath = path.join(__dirname, 'src', 'mqttFuncs');
        
        // Load main API functions
        const apiFunctions = await loadAPIFunctions(srcPath, defaultFuncs, api, ctx);
        Object.assign(api, apiFunctions);
        
        // Load MQTT functions
        const mqttFunctions = await loadAPIFunctions(mqttPath, defaultFuncs, api, ctx);
        Object.assign(mqtt, mqttFunctions);
        
        // Set listen method
        api.listen = api.listenMqtt;
        
    } catch (error) {
        log.error('buildAPI', `Error loading API functions: ${error.message}`);
        // Fallback to synchronous loading for compatibility
        try {
            const fs = require('fs');
            
            fs.readdirSync(__dirname + '/src/')
                .filter(v => v.endsWith('.js'))
                .forEach(v => {
                    const funcName = v.replace('.js', '');
                    api[funcName] = require('./src/' + v)(defaultFuncs, api, ctx);
                });
            
            fs.readdirSync(__dirname + '/src/mqttFuncs/')
                .filter(v => v.endsWith('.js'))
                .forEach(v => {
                    const funcName = v.replace('.js', '');
                    mqtt[funcName] = require('./src/mqttFuncs/' + v)(defaultFuncs, api, ctx);
                });
                
            api.listen = api.listenMqtt;
        } catch (fallbackError) {
            log.error('buildAPI', `Fallback loading also failed: ${fallbackError.message}`);
            throw fallbackError;
        }
    }
    
    return [ctx, defaultFuncs, api, mqtt];
}

/**
 * Normalizes app state to consistent format
 * @param {Array|string} appState - Application state
 * @returns {Array} Normalized app state
 */
function normalizeAppState(appState) {
    if (utils.getType(appState) === 'Array' && appState.some(c => c.name)) {
        return appState.map(c => {
            c.key = c.name;
            delete c.name;
            return c;
        });
    }
    
    if (utils.getType(appState) === 'String') {
        const arrayAppState = [];
        appState.split(';').forEach(c => {
            const [key, value] = c.split('=');
            arrayAppState.push({
                key: (key || "").trim(),
                value: (value || "").trim(),
                domain: "facebook.com",
                path: "/",
                expires: new Date().getTime() + 1000 * 60 * 60 * 24 * 365
            });
        });
        return arrayAppState;
    }
    
    return appState;
}

/**
 * Main login helper function
 * @param {Array} appState - Application state
 * @param {string} email - Email (deprecated)
 * @param {string} password - Password (deprecated)
 * @param {Object} globalOptions - Global options
 * @param {Function} callback - Callback function
 * @param {Function} prCallback - Promise callback
 */
async function loginHelper(appState, email, password, globalOptions, callback, prCallback) {
    const jar = utils.getJar();
    let mainPromise = null;
    
    try {
        if (appState) {
            const normalizedAppState = normalizeAppState(appState);
            
            // Set cookies from app state
            normalizedAppState.forEach(c => {
                const cookieString = `${c.key}=${c.value}; expires=${c.expires}; domain=${c.domain}; path=${c.path};`;
                jar.setCookie(cookieString, `http://${c.domain}`);
            });
            
            mainPromise = utils
                .get(FACEBOOK_BASE_URL + '/', jar, null, globalOptions, { noRef: true })
                .then(utils.saveCookies(jar));
        } else if (email) {
            throw { 
                error: "Currently, the login method by email and password is no longer supported, please use the login method by appState" 
            };
        } else {
            throw { error: "No appState given." };
        }
        
        let ctx = null;
        let defaultFuncs = null;
        let api = null;
        let mqtt = null;
        
        mainPromise = mainPromise
            .then(res => {
                // Handle redirects
                const redirectRegex = /<meta http-equiv="refresh" content="0;url=([^"]+)[^>]+>/;
                const redirect = redirectRegex.exec(res.body);
                if (redirect?.[1]) {
                    return utils
                        .get(redirect[1], jar, null, globalOptions)
                        .then(utils.saveCookies(jar));
                }
                return res;
            })
            .then(res => updateDTSG(res, appState))
            .then(async dtsgResult => {
                const html = dtsgResult.res.body;
                const buildResult = await buildAPI(globalOptions, html, jar);
                
                [ctx, defaultFuncs, api, mqtt] = buildResult;
                
                // Update context with fresh tokens
                if (dtsgResult.fb_dtsg && dtsgResult.jazoest) {
                    ctx.fb_dtsg = dtsgResult.fb_dtsg;
                    ctx.jazoest = dtsgResult.jazoest;
                }
                
                return dtsgResult.res;
            });
        
        // Handle page ID if specified
        if (globalOptions.pageID) {
            mainPromise = mainPromise
                .then(() => {
                    const pageUrl = `${FACEBOOK_BASE_URL}/${globalOptions.pageID}/messages/?section=messages&subsection=inbox`;
                    return utils.get(pageUrl, jar, null, globalOptions);
                })
                .then(resData => {
                    let url = utils.getFrom(resData.body, 'window.location.replace("https:\\/\\/www.facebook.com\\', '");')
                        .split('\\').join('');
                    url = url.substring(0, url.length - 1);
                    
                    return utils.get(FACEBOOK_BASE_URL + url, jar, null, globalOptions);
                });
        }
        
        // Complete login
        await mainPromise;
        log.info("login", 'Done logging in.');
        callback(null, { api, mqtt });
        
    } catch (error) {
        log.error("login", error.error || error.message || error);
        callback(error);
    }
}

/**
 * Main login function
 * @param {Object} loginData - Login data containing appState
 * @param {Object} options - Configuration options
 * @param {Function} callback - Callback function
 * @returns {Promise} Promise that resolves with API and MQTT objects
 */
function login(loginData, options, callback) {
    // Handle optional parameters
    if (utils.getType(options) === 'Function' || utils.getType(options) === 'AsyncFunction') {
        callback = options;
        options = {};
    }
    
    // Create global options with defaults
    const globalOptions = { ...DEFAULT_OPTIONS };
    setOptions(globalOptions, options || {});
    
    let returnPromise = null;
    
    // Handle promise-based usage
    if (utils.getType(callback) !== "Function" && utils.getType(callback) !== "AsyncFunction") {
        returnPromise = new Promise((resolve, reject) => {
            const promiseCallback = (error, result) => {
                if (error) {
                    return reject(error);
                }
                return resolve(result);
            };
            
            loginHelper(
                loginData.appState, 
                loginData.email, 
                loginData.password, 
                globalOptions, 
                promiseCallback, 
                promiseCallback
            );
        });
    } else {
        // Handle callback-based usage
        loginHelper(
            loginData.appState, 
            loginData.email, 
            loginData.password, 
            globalOptions, 
            callback, 
            callback
        );
    }
    
    return returnPromise;
}

module.exports = login;
