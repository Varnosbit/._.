
module.exports = {
	config: {
		name: "scrambled-word",
		aliases: ["ترتيب"],
		version: "3.3",
		author: "Allou Mohamed",
		countDown: 5,
		role: 0,
		description: {
			ar: "لعبة ترتيب الكلمات",
			en: "Arabic hard quizzes"
		},
		category: "owner",
		guide: {
			ar: "{pn}",
			en: "{pn}"
		}
	},
	
	sessions: {},
	
	onStart: async function ({ message, event, usersData }) {
		const threadID = event.threadID;
		
		if (this.sessions[threadID] && this.sessions[threadID].active) {
			const session = this.sessions[threadID];
			return message.reply(`⚠️ يوجد جلسة لعب نشطة بالفعل!\n\n✏️ الكلمة الحالية:\n${session.currentQuestion}`);
		}
		
		this.sessions[threadID] = {
			scores: {},
			currentAnswer: null,
			currentQuestion: null,
			startTime: Date.now(),
			active: true,
			processing: false
		};
		
		message.reply("🎮 بدأت جلسة جديدة من لعبة ترتيب الكلمات!\n⏰ المدة: 10 دقائق\n💰 كل إجابة صحيحة = 5 دنانير\n\nاستعدوا...");
		
		setTimeout(() => {
			this.sendNewQuestion(threadID, message);
		}, 2000);
		
		setTimeout(() => {
			this.endGameSession(threadID, message, usersData);
		}, 10 * 60 * 1000);
	},
	
	onChat: async function ({ message, event, usersData }) {
		const threadID = event.threadID;
		const senderID = event.senderID;
		
		if (!this.sessions[threadID] || !this.sessions[threadID].active) {
			return;
		}
		
		const session = this.sessions[threadID];
		
		if (session.processing) {
			return;
		}
		
		const userAnswer = event.body.trim();
		const correctAnswer = session.currentAnswer;
		
		if (userAnswer === correctAnswer) {
			session.processing = true;
			
			if (!session.scores[senderID]) {
				session.scores[senderID] = 0;
			}
			session.scores[senderID]++;
			
			await usersData.addMoney(senderID, 5);
			const newBalance = await usersData.getMoney(senderID);
			const userName = await usersData.getName(senderID);
			
			const questionData = this.generateScrambledWord();
			session.currentAnswer = questionData.answer;
			session.currentQuestion = questionData.Quiz;
			
			message.send({
				body: `🎉 أحسنت! إجابة صحيحة يا ${userName}\n✅ الكلمة: ${correctAnswer}\n💰 +5 دنانير | رصيدك: ${newBalance}\n\n⏬ الكلمة التالية:\n✏️ رتب هذه الكلمة:\n${questionData.Quiz}`,
				mentions: [{
					tag: userName,
					id: senderID
				}]
			});
			
			session.processing = false;
		}
	},
	
	sendNewQuestion: function(threadID, message) {
		if (!this.sessions[threadID] || !this.sessions[threadID].active) {
			return;
		}
		
		const session = this.sessions[threadID];
		const questionData = this.generateScrambledWord();
		session.currentAnswer = questionData.answer;
		session.currentQuestion = questionData.Quiz;
		
		message.reply(`✏️ رتب هذه الكلمة:\n\n${questionData.Quiz}`);
	},
	
	endGameSession: async function(threadID, message, usersData) {
		if (!this.sessions[threadID]) {
			return;
		}
		
		const session = this.sessions[threadID];
		session.active = false;
		
		const scores = session.scores;
		
		if (Object.keys(scores).length === 0) {
			message.reply("⏰ انتهت الجلسة!\n😔 لم يشارك أحد في اللعبة.");
			delete this.sessions[threadID];
			return;
		}
		
		const sortedPlayers = Object.entries(scores).sort((a, b) => b[1] - a[1]);
		let leaderboard = "🏆 انتهت الجلسة! لوحة المتصدرين:\n\n";
		const medals = ["🥇", "🥈", "🥉"];
		const mentions = [];
		
		for (let i = 0; i < Math.min(sortedPlayers.length, 10); i++) {
			const [userID, score] = sortedPlayers[i];
			const medal = i < 3 ? medals[i] : `${i + 1}.`;
			const userName = await usersData.getName(userID);
			leaderboard += `${medal} ${userName}: ${score} إجابة صحيحة\n`;
			mentions.push({
				tag: userName,
				id: userID
			});
		}
		
		leaderboard += "\n💰 تم إضافة الجوائز لحساباتكم!";
		
		message.send({
			body: leaderboard,
			mentions: mentions
		});
		
		delete this.sessions[threadID];
	},
	
	generateScrambledWord: function() {
		const words = [
			"سماء", "أرض", "شمس", "قمر", "نجوم", "بحر", "نهر", "جبل", "وادي", "غابة",
			"زهرة", "شجرة", "نخلة", "وردة", "عشب", "صحراء", "طريق", "مدينة", "قرية", "شارع",
			"بيت", "باب", "نافذة", "مطبخ", "غرفة", "سقف", "حائط", "أرضية", "سرير", "كرسي",
			"طاولة", "كتاب", "دفتر", "قلم", "ورقة", "حبر", "مكتب", "خريطة", "قميص", "بنطال",
			"حذاء", "قبعة", "معطف", "جورب", "نظارة", "ساعة", "حقيبة", "هاتف", "حاسوب", "لوحة",
			"سيارة", "دراجة", "طائرة", "قطار", "سفينة", "قارب", "حصان", "بقرة", "خروف", "ماعز",
			"فيل", "أسد", "نمر", "قطة", "كلب", "طائر", "سمكة", "حوت", "ثعبان", "عقرب",
			"نملة", "فراشة", "نحلة", "ذبابة", "بعوضة", "دب", "غزال", "ثعلب", "ذئب", "جرذ",
			"فأر", "سنجاب", "قرد", "غوريلا", "شمبانزي", "ضفدع", "سلحفاة", "تمساح", "أرنب", "دلفين",
			"قرش", "حمار", "بغل", "نسر", "صقر", "بومة", "بجعة", "نعامة", "بطريق", "نورس",
			"حمامة", "عصفور", "ببغاء", "غراب", "بط", "أوز", "حبارى", "دجاجة", "ديك", "طاووس",
			"بلبل", "يمامة", "جرادة", "ضبع", "غيث", "ربيع", "شتاء", "خريف", "صيف", "ياسمين",
			"نرجس", "خزامى", "زعفران", "فل", "قرنفل", "ريحان", "بخور", "مر", "زعتر", "برتقال",
			"ليمون", "تفاح", "موز", "عنب", "رمان", "خوخ", "مشمش", "إجاص", "كرز", "تين",
			"بطيخ", "شمام", "فراولة", "توت", "عليق", "تمر", "زيتون", "عصير", "ماء", "شاي",
			"قهوة", "لبن", "عسل", "خبز", "أرز", "دقيق", "ملح", "سكر", "فلفل", "زبدة",
			"جبن", "لحم", "دجاج", "بيض", "عدس", "حمص", "فول", "فاصوليا", "بازلاء", "بطاطا",
			"بصل", "ثوم", "كرفس", "جزر", "فجل", "خيار", "خس", "ملفوف", "قرنبيط", "باذنجان",
			"كوسا", "بندورة", "بقدونس", "لوز", "فستق", "بندق", "كاجو", "جوز", "كستناء", "كعك",
			"بسكويت", "شوكولاتة", "حلوى", "خثارة", "كريمة", "جمل", "زرافة"
		];
		
		const originalWord = words[Math.floor(Math.random() * words.length)];
		let scrambledWordArray = originalWord.split('');
		
		for (let i = scrambledWordArray.length - 1; i > 0; i--) {
			const j = Math.floor(Math.random() * (i + 1));
			[scrambledWordArray[i], scrambledWordArray[j]] = [scrambledWordArray[j], scrambledWordArray[i]];
		}
		
		const scrambledWord = scrambledWordArray.join(' ');
		
		return {
			Quiz: scrambledWord,
			answer: originalWord
		};
	}
};