const {
    getStreamFromUrl
} = utils;
const {
    createCanvas,
    loadImage
} = require('canvas');
const axios = require("axios");
const collection = [
    "Airi",
    "Ako",
    "Aru",
    "Azusa",
    "Chinatsu",
    "Hanae",
    "Haruka",
    "Haruna",
    "Hibiki",
    "Hina",
    "Hinata",
    "Hiyori",
    "Hoshino",
    "Iori",
    "Junko",
    "Juri",
    "Kaho",
    "Kasumi",
    "Kikyou",
    "Koyami",
    "Makoto",
    "Mashiro",
    "Meru",
    "Michiru",
    "Mika",
    "Mina",
    "Miyu",
    "Momiji",
    "Mutsuki",
    "Noa",
    "Pina",
    "Rumi",
    "Sakurako",
    "Saya",
    "Sena",
    "Serika",
    "Shigure",
    "Shimiko",
    "Shiroko",
    "Toki",
    "Tsubaki",
    "Yuuka",
    "Yuzu",
    //[2]
    "Serina",
    "Kirino",
    "Wakamo",
    "Nonomi",
    "Umika",
    "Miyako",
    "Fuuka",
    "Aris",
    "Izumi",
    "Hanako",
    "Natsu",
    "Chise",
    "Midori",
    "Karin",
    "Nagisa",
    "Ayane",
    "Himari",
    "Shizuko",
    "Kayoko",
    "Kazusa",
    "Reisa",
    "Kotori",
    "Hasumi",
    "Momoi",
    "Saori",
    "Mari",
    "Hifumi"
];

const baseGit = "https://raw.githubusercontent.com/Varnosbit/Ba/refs/heads/main/show/";
const baseApi = "https://api.ennead.cc/buruaka/character/";

const show = (name, id) => {
    if (name) name = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
    if (id && id >= 1 && id <= collection.length) return `${baseGit}${collection[id - 1]}.jpg`;
    return name && collection.includes(name) ? `${baseGit}${name}.jpg`: false;
};

const info = (name, id) => {
    if (name) name = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
    if (id && id >= 1 && id <= collection.length) return `${baseApi}${collection[id - 1]}`;
    return name && collection.includes(name) ? `${baseApi}${name}`: false;
};

exports.config = {
    name: 'blueArchiveGacha',
    aliases: ["ba"],
    description: {
        en: 'Blue Archive Gacha Game - Pull, Show, Sell Features',
        ar: 'لعبة ڨاتشا اذا مش عارف المعنى فراسك مربع و لا انصحك تجربها حتى.',
    },
    author: 'Allou Mohamed',
    version: '1.0.0',
    role: 0,
    guide: {
        en: 'Buy, sell, trade, and show your collection to other users.',
        ar: 'اشتري و بع و اعرض تجميعتك.',
    },
    countDown: 10
};

exports.onStart = async function({
    event, args, usersData, role, api, globalData, message: x
}) {
    const sender = event.senderID;
    const thread = event.threadID;

    let globalCollection = await globalData.get("ba", "data.globalCollection", []);
    let senderCollection = await usersData.get(sender, "data.ba", []);

    const availablePulls = collection.filter(name =>
        !senderCollection.some(obj => obj.name === name) && !globalCollection.includes(name)
    );

    const action = args[0];

    switch (action) {
        case 'show':
            let nameOrId = args[1];
            let name_,
            id;
            if (nameOrId) {
                isNaN(parseInt(nameOrId)) ? name_ = nameOrId: id = parseInt(nameOrId);
            }
            if (name_ && !senderCollection.some(obj => obj.name === name_) && role < 3) {
                return x.send({
                    body: "You don't have this character."
                });
            }

            if (id && id >= 1 && id <= collection.length && !senderCollection.some(obj => obj.name === collection[id - 1]) && role < 3) {
                return x.send({
                    body: "You don't have this character."
                });
            }

            const imageUrl = show(name_, id);
            return imageUrl ? await x.stream(imageUrl) : x.send({
                body: "We don't have this."
            });

            case 'pull':
                if (availablePulls.length === 0) {
                    return x.send({
                        body: "All characters have been obtained. You can buy from someone or trade."
                    });
                }

                const randomName = availablePulls[Math.floor(Math.random() * availablePulls.length)];
                const infoUrl = info(randomName);
                const charImage = show(randomName, null);

                let charData;
                try {
                    const res = await axios.get(infoUrl);
                    if (!res.data) throw new Error();
                    charData = formatCharacterData(res.data);
                } catch {
                    charData = {
                        Price: 10000,
                        Fullname: randomName
                    };
                }
                const {
                    Price,
                    Fullname
                } = charData;
                const senderMoney = await usersData.getMoney(sender);

                if (Price > senderMoney) {
                    return x.send({
                        body: `You need at least $${Price} to pull this character.`
                    });
                }

                await usersData.subtractMoney(sender, Price);
                senderCollection.push({
                    name: randomName, Price, Fullname
                });
                globalCollection.push(randomName);

                await globalData.set('ba', globalCollection, "data.globalCollection");
                //await globalData.set("ba", {sender, total: senderCollection.length}, "data.Collection");
                await usersData.set(sender, senderCollection, "data.ba");

                return x.stream(`Nice! You got ${Fullname}.`, charImage);

                case 'inv':

                    const page = parseInt(args[1]) || 1;
                    const inv = (await usersData.get(event.senderID, "data.ba", [])).map(obj => obj.name).map(name => `${baseGit}${name}.jpg`);
                    const name = await usersData.getName(event.senderID);
                    const nameToDraw = name.length > 14 ? name.split(" ")[0] || name.slice(0, 14): name;
                    const s = await drawInv(page, nameToDraw, inv);
                    s.path = "ba_"+Date.now()+"_inv.png";
                    x.send({
                        attachment: s
                    });
                    break;

                case 'sell':
                    let sellName,
                    sellId;
                    if (isNaN(parseInt(args[1]))) {
                        sellName = args[1].charAt(0).toUpperCase() + args[1].slice(1).toLowerCase();
                    } else {
                        sellId = parseInt(args[1]);
                    }

                    if (!sellName && !sellId) {
                        return x.send({
                            body: "Specify the character you want to sell."
                        });
                    }

                    let sellCharacter = sellId ? collection[sellId - 1]: sellName;
                    if (!sellCharacter || !senderCollection.some(obj => obj.name === sellCharacter)) {
                        return x.send({
                            body: "You don't own this character."
                        });
                    }

                    let charData_ = senderCollection.find(obj => obj.name === sellCharacter);
                    let sellPrice = Math.floor(charData_.Price * 0.6);

                    await usersData.addMoney(sender, sellPrice);
                    senderCollection = senderCollection.filter(obj => obj.name !== sellCharacter);
                    await usersData.set(sender, senderCollection, "data.ba");
                    globalCollection = globalCollection.filter(name => name !== sellCharacter);
                    await globalData.set("ba", globalCollection, "data.globalCollection");
                    //await globalData.set("ba", {sender, total: senderCollection.length}, "Collection");
                    x.send({
                        body: `You sold ${charData_.Fullname} for $${sellPrice}.`
                    });
                    break;

                default:
                    return x.send({
                        body: "Use: show, pull, sell"
                    });
                }
        };

        function formatCharacterData(data) {
            const rarityPrices = {
                "R": 10000,
                "SR": 20000,
                "SSR": 40000,
                "UR": 50000,
                "L": 100000
        };
        const basePrice = (rarityPrices[data.character.rarity] || 10000) + (data.character.baseStar * 5000);

        const statMultiplier = (data.stat.attackLevel100 + data.stat.defenseLevel100 + data.stat.maxHPLevel100) / 100;
        return {
            Rare: data.character.rarity,
            Price: basePrice + (statMultiplier * 200),
            Fullname: data.character.fullname,
            BaseStar: data.character.baseStar,
            Weapon: data.character.weaponType,
            PortraitImg: data.image.portrait
    };
}

async function drawInv(page = 1, name = "Unknown", inv = []) {
    const TtShape = "https://i.ibb.co/8FfJv99/icons8-poker-64.png";
    // Background
    const bgUrl = "https://raw.githubusercontent.com/Varnosbit/Ba/refs/heads/main/inv/bg.jpg";
    const bgImage = await loadImage(bgUrl);
    const {
        width: imgW,
        height: imgH
    } = bgImage;

    const minWidth = 2000;
    const minHeight = 1200;

    const scale = Math.max(minWidth / imgW, minHeight / imgH);
    const canvasWidth = Math.round(imgW * scale);
    const canvasHeight = Math.round(imgH * scale);

    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(bgImage, 0, 0, canvasWidth, canvasHeight);

    const rows = 2;
    const cols = 5;
    const perPage = rows * cols;
    const totalPages = Math.ceil(inv.length / perPage);

    if (page < 1) page = 1;
    if (page > totalPages) page = totalPages;

    const startIndex = (page - 1) * perPage;
    const endIndex = Math.min(startIndex + perPage, inv.length);
    const pageItems = inv.slice(startIndex, endIndex);

    const startX = (70*2);
    const startY = 200;
    const rowPadding = 40;
    const colPadding = 120;

    const imgHeight = canvasHeight * 0.4;
    const imgWidth = canvasWidth / 8;

    for (let i = 0; i < pageItems.length; i++) {
        const img = await loadImage(pageItems[i]);
        const col = i % cols;
        const row = Math.floor(i / cols);

        const x = startX + col * (imgWidth + colPadding);
        const y = startY + row * (imgHeight + rowPadding);

        const aspectRatio = img.width / img.height;
        let drawWidth = imgWidth;
        let drawHeight = imgHeight;

        if (aspectRatio > 1) {
            drawHeight = imgWidth / aspectRatio;
        } else {
            drawWidth = imgHeight * aspectRatio;
        }

        const offsetX = (imgWidth - drawWidth) / 2;
        const offsetY = (imgHeight - drawHeight) / 2;
        const radius = 15;

        ctx.save();
        ctx.beginPath();
        ctx.roundRect(x + offsetX, y + offsetY, drawWidth, drawHeight, radius);
        ctx.clip();
        ctx.drawImage(img, x + offsetX, y + offsetY, drawWidth, drawHeight);
        ctx.restore();
    }

    //Tt
    const shape = await loadImage(TtShape);
    ctx.shadowColor = "rgba(255, 255, 255, 0.9)";
    ctx.shadowBlur = 20;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    ctx.drawImage(shape, startX - 40, 40, 100, 100);
    ctx.fillStyle = "white";
    ctx.font = "bold 40px sans-serif";
    ctx.fillText(`User Collection [${inv.length}]`, startX + shape.width + 10, 80);
    ctx.font = "bold 28px sans-serif";
    ctx.fillText(`${name}'s blue archive inventory`, startX + shape.width + 10, 120);
    ctx.shadowColor = "transparent";
    ctx.shadowBlur = 0;
    ctx.font = "bold 40px sans-serif";
    ctx.fillText(`Page ${page} of ${totalPages}`, canvasWidth - 360, 120);

    return canvas.createPNGStream();
}
