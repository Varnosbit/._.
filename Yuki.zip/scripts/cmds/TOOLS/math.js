const config = {
  author: "Allou Mohamed",
  name: "calc",
  aliases: ["calculate", "math"],
  description: "Evaluate complex mathematical expressions with symbols like π, √, ^, etc.",
  usage: "[expression]",
  version: "1.0.0",
  countDown: 3,
  guide: {
  usage: "Evaluate mathematical expressions, including operations, functions, symbols, and superscripts.",
  params: "[expression]: The mathematical expression to evaluate. Example: 2 + 3 * √(16) - π²",
  syntax: "%bdcalc <expression>%\n\n%bdExamples:%\n• calc 2 + 3 * 4 → 14\n• calc √(16) + π² → 13.869...\n• calc sin(π/2) + cos(0) → 2\n• calc 10¹³⁰ → 10^130\n• calc |−5| + 3! → 11"
   }
};

async function onStart({ message, args }) {
  const input = args.join(" ");
  if (!input) return message.reply("❌ Please provide a mathematical expression.");

  const result = calculateExpression(input);

  if (result.success) {
    return message.reply(
      `🧮 %bdExpression:% \n${result.original}\n\n📟 %bdConverted:% \n${result.converted}\n\n✅ %bdResult:% \n${result.result}`
    );
  } else {
    return message.reply(`❌ %bdError:% ${result.error}`);
  }
}

function calculateExpression(expression) {
  try {
    if (typeof expression !== 'string' || expression.trim() === '') {
      throw new Error('Expression must be a non-empty string');
    }
    const original = expression;
    let cleanExpression = preprocessExpression(expression);
    cleanExpression = convertMathSymbols(cleanExpression);
    if (!isValidExpression(cleanExpression)) {
      throw new Error('Invalid characters or syntax');
    }
    const result = evaluateExpression(cleanExpression);
    return { original, converted: cleanExpression, result, success: true };
  } catch (error) {
    return { original: expression, converted: typeof cleanExpression !== "undefined" ? cleanExpression : expression, error: error.message, success: false };
  }
}

function preprocessExpression(expression) {
  return expression.replace(/\s+/g, '').replace(/(\d),(\d)/g, '$1.$2');
}

function convertMathSymbols(expression) {
  let e = expression;
  e = e.replace(/π/g, 'Math.PI').replace(/𝑒/g, 'Math.E').replace(/\be\b(?!\w)/g, 'Math.E');
  e = e.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
  e = handlePowerOperations(e);
  e = handleSuperscripts(e);
  e = handleRootFunctions(e);
  e = e.replace(/\bsin\(/gi, 'Math.sin(').replace(/\bcos\(/gi, 'Math.cos(')
       .replace(/\btan\(/gi, 'Math.tan(').replace(/\basin\(/gi, 'Math.asin(')
       .replace(/\bacos\(/gi, 'Math.acos(').replace(/\batan\(/gi, 'Math.atan(')
       .replace(/\bln\(/gi, 'Math.log(').replace(/\blog\(/gi, 'Math.log10(')
       .replace(/\babs\(/gi, 'Math.abs(').replace(/\bfloor\(/gi, 'Math.floor(')
       .replace(/\bceil\(/gi, 'Math.ceil(').replace(/\bround\(/gi, 'Math.round(')
       .replace(/\bexp\(/gi, 'Math.exp(').replace(/\bmax\(/gi, 'Math.max(')
       .replace(/\bmin\(/gi, 'Math.min(');
  e = handleAbsoluteBars(e);
  e = handleFactorial(e);
  e = handleImplicitMultiplication(e);
  return e;
}

function handleSuperscripts(e) {
  // Map of superscript characters to regular numbers
  const superscriptMap = {
    '⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4',
    '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9'
  };
  
  // Find all superscript sequences and convert them
  return e.replace(/([⁰¹²³⁴⁵⁶⁷⁸⁹]+)/g, (match) => {
    const normalNumbers = match.split('').map(char => superscriptMap[char] || char).join('');
    return `**${normalNumbers}`;
  });
}

function handlePowerOperations(e) {
  while (e.includes('^')) {
    const i = e.lastIndexOf('^');
    let bS = i - 1, p = 0;
    if (e[i - 1] === ')') {
      p = 1; bS = i - 2;
      while (bS >= 0 && p > 0) {
        if (e[bS] === ')') p++;
        if (e[bS] === '(') p--;
        bS--;
      }
      bS++;
    } else {
      while (bS >= 0 && /[0-9.a-zA-Z_]/.test(e[bS])) bS--;
      if (bS >= 0 && e.substring(bS - 3, bS + 1) === 'Math') {
        bS -= 4;
        while (bS >= 0 && /[a-zA-Z.]/.test(e[bS])) bS--;
      }
      bS++;
    }
    let eE = i + 1; p = 0;
    if (e[i + 1] === '(') {
      p = 1; eE = i + 2;
      while (eE < e.length && p > 0) {
        if (e[eE] === '(') p++;
        if (e[eE] === ')') p--;
        eE++;
      }
    } else {
      if (e[eE] === '-') eE++;
      while (eE < e.length && /[0-9.]/.test(e[eE])) eE++;
    }
    const base = e.substring(bS, i), exp = e.substring(i + 1, eE);
    e = e.substring(0, bS) + `Math.pow(${base},${exp})` + e.substring(eE);
  }
  return e;
}

function handleRootFunctions(e) {
  while (e.includes('√')) {
    const i = e.indexOf('√');
    let s = i + 1, eE = s;
    if (e[s] === '(') {
      let p = 1; eE = s + 1;
      while (eE < e.length && p > 0) {
        if (e[eE] === '(') p++;
        if (e[eE] === ')') p--;
        eE++;
      }
    } else {
      while (eE < e.length && /[0-9.MathEPI_a-zA-Z]/.test(e[eE])) eE++;
    }
    const operand = e.substring(s, eE);
    e = e.substring(0, i) + `Math.sqrt(${operand})` + e.substring(eE);
  }
  e = e.replace(/∛\(([^)]+)\)/g, 'Math.pow($1,1/3)');
  e = e.replace(/∛([0-9.]+|Math\.\w+)/g, 'Math.pow($1,1/3)');
  return e;
}

function handleAbsoluteBars(e) {
  let result = '', g = '', b = 0;
  for (let i = 0; i < e.length; i++) {
    if (e[i] === '|') {
      if (b === 0) { result += g + 'Math.abs('; g = ''; b = 1; }
      else { result += g + ')'; g = ''; b = 0; }
    } else { g += e[i]; }
  }
  return result + g;
}

function handleFactorial(e) {
  const f = `(function factorial(n){if(n<0)return NaN;if(n===0||n===1)return 1;if(n>170)return Infinity;let r=1;for(let i=2;i<=n;i++)r*=i;return r;})`;
  return e.replace(/(\d+(?:\.\d+)?|Math\.\w+|\([^)]+\))!/g, `${f}($1)`);
}

function handleImplicitMultiplication(e) {
  return e
    .replace(/(\d)\(/g, '$1*(')
    .replace(/\)(\d)/g, ')*$1')
    .replace(/\)\(/g, ')*(')
    .replace(/(\d)(Math\.[A-Z_]+)(?!\w)/g, '$1*$2')
    .replace(/(\d)(Math\.\w+\()/g, '$1*$2')
    .replace(/(Math\.[A-Z_]+)(\d)/g, '$1*$2')
    .replace(/\)(Math\.\w+)/g, ')*$1');
}

function isValidExpression(e) {
  const valid = /^[0-9+\-*/.()MathPIEsincotaglbxpowqrtfloceimaxyrundomn=>,\s]*$/i;
  if (!valid.test(e)) return false;
  let p = 0;
  for (const c of e) {
    if (c === '(') p++;
    if (c === ')') p--;
    if (p < 0) return false;
  }
  return p === 0;
}

function evaluateExpression(e) {
  const fn = new Function('Math', `"use strict"; return (${e})`);
  const r = fn(Math);
  if (typeof r !== 'number') throw new Error('Result is not a number');
  return r;
}

module.exports = { config, onStart };
