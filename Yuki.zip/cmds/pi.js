const axios = require('axios');
const fs = require('fs');
const path = require('path');

const saveAudio = (fileData, fileName) => {
  const dir = path.join(__dirname, 'tmp');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const filePath = path.join(dir, fileName);
  fs.writeFileSync(filePath, fileData);
  setTimeout(() => {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  }, 10000);
  return filePath;
};

const retryAsync = async (fn, retries = 5, delay = 1000) => {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === retries) throw error;
      await new Promise(res => setTimeout(res, delay));
    }
  }
};

module.exports = {
  config: {
    name: "pi",
    version: "1.1",
    role: 0,
    author: "tanvir",
    shortDescription: { en: "Talk to Pi assistant" },
    longDescription: { en: "Chat with the Pi assistant. An assistant with feelings and can talk" },
    category: "ai",
    guide: { en: "{pn} prompt\n\n{pn} voice on/off\n\n{pn} set model (1-8)\n\n{pn} clear" },
  },

  onStart: async function({ args, message, event, usersData }) {
    const senderID = event.senderID;
    const userData = (await usersData.get(senderID)) || { data: {} };
    const piData = userData.data.pi || {};
    if (!args[0]) return message.SyntaxError();

    try {
      switch (args[0].toLowerCase()) {
        case 'voice': {
          if (!args[1]) return message.reply("Please specify 'on' or 'off' for voice mode.");
          const voiceMode = args[1].toLowerCase();
          if (voiceMode === 'on') {
            piData.voice = true;
          } else if (voiceMode === 'off') {
            piData.voice = false;
          } else {
            return message.reply("Invalid option. Use 'on' or 'off' for voice mode.");
          }
          userData.data.pi = piData;
          await usersData.set(senderID, userData);
          return message.reply(`Voice mode ${voiceMode === 'on' ? 'enabled' : 'disabled'}.`);
        }
        case 'set': {
          if (!piData.voice) return message.reply("Turn on voice mode to set a voice model.");
          const voiceModel = parseInt(args[1], 10);
          if (!voiceModel || voiceModel < 1 || voiceModel > 8)
            return message.reply("Invalid voice model. Choose a model between 1 to 8.");
          piData.voiceModel = voiceModel;
          userData.data.pi = piData;
          await usersData.set(senderID, userData);
          return message.reply(`Voice model set to ${voiceModel}.`);
        }
        case 'clear': {
          const voice = piData.voice;
          const voiceModel = piData.voiceModel;
          userData.data.pi = { voice, voiceModel };
          await usersData.set(senderID, userData);
          return message.reply("Cleared Pi data");
        }
        default: {
          const prompt = args.join(" ");
          const voiceModel = piData.voiceModel || 3;
          const voice = piData.voice || false;

          try {
            message.reaction("🤔", event.messageID);
            const cookies = piData.cookies || await retryAsync(() => getPiCookies(senderID, usersData));
            const chatResponse = await retryAsync(() => chatWithPi(prompt, cookies));

            if (voice) {
              const audioResponse = await retryAsync(() => getPiVoice(chatResponse.messageId, cookies, voiceModel));
              const filePath = saveAudio(audioResponse, `${chatResponse.messageId}_voice.mp3`);
              const replyMessage = await message.reply({
                body: chatResponse.response,
                attachment: fs.createReadStream(filePath),
              });
              GoatBot.onReply.set(replyMessage.messageID, {
                commandName: "pi",
                author: senderID,
                messageID: replyMessage.messageID,
              });
              return;
            } else {
              const replyMessage = await message.reply(chatResponse.response);
              GoatBot.onReply.set(replyMessage.messageID, {
                commandName: "pi",
                author: senderID,
                messageID: replyMessage.messageID,
              });
              return;
            }
          } catch (error) {
            message.reaction("❌", event.messageID);
            return message.reply("❌ | Err, Try again.");
          }
        }
      }
    } catch (error) {
      console.error(error);
      message.reaction("❌", event.messageID);
      return message.reply("❌ | Err, Try again.");
    }
  },

  onReply: async function({ event, message, args, Reply, usersData }) {
    if (Reply.author !== event.senderID) return;
    if (!args[0]) return message.SyntaxError();

    try {
      const senderID = event.senderID;
      const userData = (await usersData.get(senderID)) || { data: {} };
      const piData = userData.data.pi || {};

      if (args.join(" ").toLowerCase() === "clear") {
        const voice = piData.voice;
        const voiceModel = piData.voiceModel;
        userData.data.pi = { voice, voiceModel };
        await usersData.set(senderID, userData);
        return message.reply("Cleared Pi data");
      }

      const prompt = args.join(" ");
      const voiceModel = piData.voiceModel || 3;
      const voice = piData.voice || false;

      message.reaction("🤔", event.messageID);
      const cookies = piData.cookies || await retryAsync(() => getPiCookies(senderID, usersData));
      const chatResponse = await retryAsync(() => chatWithPi(prompt, cookies));

      if (voice) {
        const audioResponse = await retryAsync(() => getPiVoice(chatResponse.messageId, cookies, voiceModel));
        const filePath = saveAudio(audioResponse, `${chatResponse.messageId}_voice.mp3`);
        GoatBot.onReply.delete(Reply.messageID);
        const replyMessage = await message.reply({
          body: chatResponse.response,
          attachment: fs.createReadStream(filePath),
        });
        GoatBot.onReply.set(replyMessage.messageID, {
          commandName: "pi",
          author: senderID,
          messageID: replyMessage.messageID,
        });
        return;
      } else {
        GoatBot.onReply.delete(Reply.messageID);
        const replyMessage = await message.reply(chatResponse.response);
        GoatBot.onReply.set(replyMessage.messageID, {
          commandName: "pi",
          author: senderID,
          messageID: replyMessage.messageID,
        });
        return;
      }
    } catch (error) {
      console.error(error);
      message.reaction("❌", event.messageID);
      return message.reply("❌ | Err, Try again.");
    }
  },
};

const getPiCookies = async (id, usersData) => {
  return retryAsync(async () => {
    const userData = (await usersData.get(id)) || { data: {} };
    const response = await axios.post('https://ios-app.heypi.com/api/user', {}, {
      headers: {
        'User-Agent': 'Pi/1.4 (Android 14; Samsung; SM-S21)',
        'Accept-Encoding': 'gzip',
        'Content-Type': 'application/json; charset=UTF-8',
      },
    });
    const cookies = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');
    userData.data.pi = { ...userData.data.pi, cookies };
    await usersData.set(id, userData);
    return cookies;
  });
};

const chatWithPi = async (prompt, cookies) => {
  return retryAsync(async () => {
    const startConvo = await axios.post('https://ios-app.heypi.com/api/chat/start', {}, {
      headers: {
        'User-Agent': 'Pi/1.4 (Android 14; Samsung; SM-S21)',
        'Accept-Encoding': 'gzip',
        'x-api-version': '2',
        'Content-Type': 'application/json; charset=utf-8',
        'Cookie': cookies,
      },
    });
    const chatResponse = await axios.post('https://ios-app.heypi.com/api/chat', { text: prompt }, {
      headers: {
        'User-Agent': 'Pi/1.4 (Android 14; Samsung; SM-S21)',
        'Accept-Encoding': 'gzip',
        'Content-Type': 'application/json',
        'x-api-version': '3',
        'Accept': 'text/event-stream',
        'Cookie': cookies,
      },
      responseType: 'stream',
    });

    let response = '';
    let messageId = '';

    chatResponse.data.on('data', (chunk) => {
      const data = chunk.toString();
      const event = data.split('\n').find(line => line.startsWith('event:'));
      const eventData = data.split('\n').find(line => line.startsWith('data:'));

      if (event && eventData) {
        const eventType = event.split('event: ')[1].trim();
        const parsedData = JSON.parse(eventData.split('data: ')[1].trim());

        if (eventType === 'message') {
          messageId = parsedData.sid;
        }

        if (eventType === 'partial') {
          response += parsedData.text;
        }
      }
    });

    return new Promise((resolve, reject) => {
      chatResponse.data.on('end', () => resolve({ response, messageId }));
      chatResponse.data.on('error', (error) => reject(new Error('Error during Pi chat')));
    });
  });
};

const getPiVoice = async (messageId, cookies, voiceModel) => {
  return retryAsync(async () => {
    const voiceResponse = await axios.get('https://ios-app.heypi.com/api/chat/voice', {
      params: { messageSid: messageId, voice: `voice${voiceModel}`, duplex: true },
      headers: {
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 14; SM-S21 Build/SA.21.0)',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'identity',
        'Icy-MetaData': '1',
        'Cookie': cookies,
      },
      responseType: 'arraybuffer',
    });
    return voiceResponse.data;
  });
};