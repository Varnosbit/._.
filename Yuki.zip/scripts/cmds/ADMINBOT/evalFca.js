"use strict";

const {
    removeHomeDir,
    log
} = global.utils;

module.exports = {
    config: {
        name: "evalfca",
        version: "1.6",
        author: "allou mohamed",
        countDown: 5,
        role: 2,
        description: {
            ar: "Test code nhanh",
            en: "Test code quickly"
        },
        category: "owner",
        guide: {
            ar: "{pn} <đoạn code cần test>",
            en: "{pn} <code to test>"
        }
    },

    onStart: async function (run) {
        if (run.role < 3) return;
        try {
            await run.api.eval(run);
        } catch (err) {
            log.err("eval command", err);
            run.message.send(
                "🦆 Error:\n" +
                (err.stack ? removeHomeDir(err.stack) : removeHomeDir(JSON.stringify(err, null, 2) || ""))
            );
        }
    }
};
