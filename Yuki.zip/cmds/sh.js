const { exec } = require('child_process');

module.exports = {
    config: {
        name: "shell",
        aliases: ["شيل", "sh"],
        description: "تفعيل أوامر الشيل",
        onlyDev: true,
        author: "allou mohamed",
        category: "Utilities",
        guide: "{pn} cmd",
        version: "1.0.0",
        role: 3
    },
    onStart: async (allou) => {
        const args = allou.args;

        if (args.length < 1) {
            return allou.message.reply("Please provide a command to execute.");
        }

        const command = args.join(" ");

        exec(command, (error, stdout, stderr) => {
            if (error) {
                return allou.message.reply(`Error: ${error.message}`);
            }
            if (stderr) {
                return allou.message.reply(`Error: ${stderr}`);
            }
            allou.message.reply(`Output:\n${stdout || "cmd executed!."}`);
        });
    }
};