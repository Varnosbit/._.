/*const { exec } = require("child_process");
const fs = require("fs");
const coc = process.cwd() + "/yt.txt";
const yts = require("yt-search");

exports.config = {
    name: 'ytb',
    description: 'Download YouTube videos as MP3 or MP4',
    role: 0,
    category: 'Media',
    version: '1.0.0',
    guide: `
Usage: {pn} <url> [options]

Options:
  --type [mp3|mp4]   Specify the output type (default: mp4)
  --q <quality>      Optional parameter for video/audio quality
    `,
    countDown: 10
};

exports.onStart = async ({ message, args, commandName, event }) => {
    if (!args[1]) return message.reply("❌ Please provide a format (mp4/mp3) and a YouTube search query.");

    const type = args[0] === "mp4" ? "mp4" : args[0] === "mp3" ? "mp3" : null;
    if (!type) return message.reply("❌ The first argument must be 'mp4' or 'mp3'.");

    const searchQuery = args.slice(1).join(" ");
    const res = await yts(searchQuery);

    if (!res.videos.length) return message.reply("❌ No results found.");

    const topVideos = res.videos.slice(0, 6);
    const resText = "🎥 Most (6) suggested videos:\n" + 
        topVideos.map((video, index) => `${index + 1}. ${video.title} (${video.timestamp})`).join("\n\n");

    const imageUrls = topVideos.map(video => video.image);
    const videoUrls = topVideos.map(video => video.url);
    const videoTitles = topVideos.map(video => video.title);
    
    const s = await message.stream(resText, imageUrls);
    if (s.messageID) {
        global.YukiBot.onReply.set(s.messageID, {
            commandName,
            videoUrls,
            au: event.senderID,
            type,
            videoTitles,
            mid_1: s.messageID
        });
    }
};

/*
exports.onStart = async ({ message, args, commandName, event }) => {
    if (!args[1]) return message.reply("❌ Please provide a format (mp4/mp3) and a YouTube search query.");

    const type = args[0] === "mp4" ? "mp4" : args[0] === "mp3" ? "mp3" : null;
    if (!type) return message.reply("❌ The first argument must be 'mp4' or 'mp3'.");

    const searchQuery = args.slice(1).join(" ");
    const res = await yts(searchQuery);

    if (!res.videos.length) return message.reply("❌ No results found.");

    const sortedVideos = res.videos.sort((a, b) => b.views - a.views).slice(0, 6);
    const resText = "🎥 Top 6 videos by views:\n" + 
        sortedVideos.map((video, index) => `${index + 1}. ${video.title} (${video.timestamp}) - ${video.views.toLocaleString()} views`).join("\n\n");

    const imageUrls = sortedVideos.map(video => video.image);
    const videoUrls = sortedVideos.map(video => video.url);
    const videoTitles = sortedVideos.map(video => video.title);
    
    const s = await message.stream(resText, imageUrls);
    if (s.messageID) {
        global.YukiBot.onReply.set(s.messageID, {
            commandName,
            videoUrls,
            au: event.senderID,
            type,
            videoTitles,
            mid_1: s.messageID
        });
    }
};
* here /
exports.onReply = async ({ message, args, commandName, event, Reply }) => {
    const { videoUrls, au, type, videoTitles, mid_1 } = Reply;
    if (event.senderID !== au) return;
    const selection = parseInt(args[0]);
    if (isNaN(selection) || selection < 1 || selection > videoUrls.length) {
        return message.reply("❌ Invalid selection. Please choose a number from the list.");
    }

    const url = videoUrls[selection - 1];
    const tt = videoTitles[selection - 1];
    if (!url) return message.reply("❌ Could not retrieve the video URL.");
    
    const formatOption = type === "mp3" 
        ? "-x --audio-format mp3" 
        : '-f "bestvideo[height<=720]+bestaudio/best[height<=720]"';
    const fileExtension = type === "mp3" ? "mp3" : "mp4";
    const tempFileBase = `downloaded_video.${fileExtension}`;
    const tempFileWebM = `downloaded_video.${fileExtension}.webm`;
    const cmdToExec = `./yt-dlp --cookies ${coc} ${formatOption} -o "${tempFileBase}" "${url}"`;
    message.unsend(mid_1);
    const mid_2 = ((await message.reply(`🔁 Downloading ${tt}.`)).messageID);

    exec(cmdToExec, async (err, stdout, stderr) => {
        if (err) {
            return message.reply(`❌ Download failed: ${stderr || err.message}`);
        }

        const finalFile = fs.existsSync(tempFileBase) ? tempFileBase : fs.existsSync(tempFileWebM) ? tempFileWebM : null;
        if (!finalFile) return message.reply("❌ The file could not be found after downloading.");

        try {
            const stream = fs.createReadStream(finalFile);
            await message.send({ body: `✅ Downloaded successfully.\n🎦 ${tt}\n\n▶️ YtbUrl: ${url}`, attachment: stream }, () => {
                message.unsend(mid_2);
                fs.unlinkSync(finalFile);
            });
        } catch (error) {
            message.reply("❌ Failed to send the file.");
        }
    });
};*/
const fs = require("fs");
const yts = require("yt-search");
const { exec } = require("child_process");
const coc = process.cwd() + "/yt.txt";

exports.config = {
    name: 'ytb',
    description: 'Download YouTube videos as MP3 or MP4',
    role: 0,
    category: 'Media',
    version: '1.1.0',
    guide: `
Usage: {pn} <mp4|mp3> <url or search query>
Examples:
  {pn} mp3 shape of you
  {pn} mp4 https://youtube.com/...
    `,
    countDown: 10
};

exports.onStart = async ({ message, args, commandName, event }) => {
    if (!args[1]) return message.reply("❌ Please provide a format (mp4/mp3) and a URL or search query.");

    const type = args[0] === "mp4" ? "mp4" : args[0] === "mp3" ? "mp3" : null;
    if (!type) return message.reply("❌ The first argument must be 'mp4' or 'mp3'.");

    const query = args.slice(1).join(" ");
    const ytUrlRegex = /^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//i;

    if (ytUrlRegex.test(query)) {
        return downloadFromUrl({ message, url: query, type });
    }

    const res = await yts(query);
    if (!res.videos.length) return message.reply("❌ No results found.");

    const topVideos = res.videos.slice(0, 6);
    const resText = "🎥 Most (6) suggested videos:\n" + 
        topVideos.map((video, index) => `${index + 1}. ${video.title} (${video.timestamp})`).join("\n\n");

    const imageUrls = topVideos.map(video => video.image);
    const videoUrls = topVideos.map(video => video.url);
    const videoTitles = topVideos.map(video => video.title);
    const durations = topVideos.map(video => video.duration.seconds || 0);

    const s = await message.stream(resText, imageUrls);
    if (s.messageID) {
        global.YukiBot.onReply.set(s.messageID, {
            commandName,
            videoUrls,
            au: event.senderID,
            type,
            videoTitles,
            durations,
            mid_1: s.messageID
        });
    }
};

exports.onReply = async ({ message, args, commandName, event, Reply }) => {
    const { videoUrls, au, type, videoTitles, durations, mid_1 } = Reply;
    if (event.senderID !== au) return;

    const selection = parseInt(args[0]);
    if (isNaN(selection) || selection < 1 || selection > videoUrls.length) {
        return message.reply("❌ Invalid selection. Please choose a number from the list.");
    }

    const url = videoUrls[selection - 1];
    const title = videoTitles[selection - 1];
    const duration = durations[selection - 1];

    message.unsend(mid_1);
    await downloadFromUrl({ message, url, type, title, duration });
};

async function downloadFromUrl({ message, url, type, title, duration = 0 }) {
    const maxHeight = duration < 72 ? 720 : 360;
    const formatOption = type === "mp3"
        ? "-x --audio-format mp3"
        : `-f "bestvideo[height<=${maxHeight}]+bestaudio/best[height<=${maxHeight}]"`;

    const fileExtension = type === "mp3" ? "mp3" : "mp4";
    const tempFileBase = `downloaded_video.${fileExtension}`;
    const tempFileWebM = `downloaded_video.${fileExtension}.webm`;
    const cmdToExec = `./yt-dlp --cookies ${coc} ${formatOption} -o "${tempFileBase}" "${url}"`;

    const mid = ((await message.reply(`🔁 Downloading ${title || "video"}...`)).messageID);

    exec(cmdToExec, async (err, stdout, stderr) => {
        if (err) return message.reply(`❌ Download failed: ${stderr || err.message}`);

        const finalFile = fs.existsSync(tempFileBase) ? tempFileBase : fs.existsSync(tempFileWebM) ? tempFileWebM : null;
        if (!finalFile) return message.reply("❌ The file could not be found after downloading.");

        try {
            const stream = fs.createReadStream(finalFile);
            await message.send({ body: `✅ Downloaded successfully.\n🎦 ${title || "From URL"}\n\n▶️ YtbUrl: ${url}`, attachment: stream }, () => {
                message.unsend(mid);
                fs.unlinkSync(finalFile);
            });
        } catch (error) {
            message.reply("❌ Failed to send the file.");
        }
    });
}
