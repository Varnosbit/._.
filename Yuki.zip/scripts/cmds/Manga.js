const axios = require("axios");
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
module.exports = {
    config: {
        name: "مانجا",
        aliases: ["مانهوا",
            "مانها"],
        version: "1.0.0",
        author: "عبدالرحمن محمد",
        role: 0,
        countDown: 0,
        description: "مشاهده مانجا او مانهوا",
        category: "ثريدز",
    },
    onStart: async ({
        message: message, event, commandName
    }) => {
        const msg = `🔥 |  مكتــبة المانجا 🏫📚

        ←› يرجى الرد على هذه الرسالة بكلمات البحث لاسم المانجا او المانهوا المراد البحث عنه .

        ⌯︙يفضل استخدام الحروف الانجليزية .
        ⌯︙يمكنك البحث عن مانهوا مانجا مانها .`;

        message.reply(msg, (err, info) => {
            global.GoatBot.onReply.set(info.messageID, {
                commandName,
                messageID: info.messageID,
                author: event.senderID,
                type: "letsSearch"
            });
        });
    },
    onReply: async ({
        Reply, message: message, event, commandName
    }) => {
        const {
            type,
            result,
            author
        } = Reply;
        if (author != event.senderID) return;
        const messageBody = event.body.trim().toLowerCase();
        const body = parseInt(messageBody);

        if (type === "letsSearch") {
            const keywords = messageBody;
            message.reaction("🔎", event.messageID);
            try {
                const response = await axios.get(
                    `https://allou.is-a-cool.dev/search/${encodeURIComponent(
                        keywords
                    )}`
                );
                const mangaData = response.data.data;
                const NumberOfSearch = mangaData.length;

                if (NumberOfSearch === 0) {
                    message.reaction("❌", event.messageID);
                    return message.reply(`❌︙لم يتم العثور على "${keywords}"🫠`);
                }

                let formattedmessage = `〄 تم العثور على ${NumberOfSearch} مانجا 🔎⤷\n\n`;

                mangaData.forEach((anime, index) => {
                    formattedmessage += `${index + 1}- الاسم ←› ${anime.manga_name}🤍\n`;
                    formattedmessage += `←› التصانيف: ${anime.manga_genres}🗝\n`;
                    formattedmessage += `←› التقييم: ${anime.manga_rating}✨\n\n`;
                });

                let please = `⌯︙قم بالرد برقم بين 1 و ${NumberOfSearch} 🧞‍♂`;
                if (NumberOfSearch === 1) {
                    please = "⌯︙ قم بالرد برقم واحد 1 .";
                }

                message.reply(
                    `
                    ${formattedmessage}
                    ${please}
                    `,
                    (err, info) => {
                        global.GoatBot.onReply.set(info.messageID, {
                            commandName,
                            messageID: info.messageID,
                            resultmessageID: info.messageID,
                            author: event.senderID,
                            type: "animeResults",
                            result: mangaData,
                        });
                    }
                );
            } catch (error) {
                console.error("Error occurred while fetching anime data:", error);
                return message.reply(`❌︙لم يتم العثور على "${keywords}"🧞‍♂`);
            }
        }

        if (type === "animeResults") {
            try {
                if (isNaN(body) || body < 1 || body > result.length) {
                    return message.reply(`⌯︙قم بالرد برقم بين 1 و ${result.length} 🧞‍♂`);
                }
                const index = body - 1;
                const playUrl = result[index].manga_id;

                const response = await axios.get(
                    `https://allou.is-a-cool.dev/details/${encodeURIComponent(
                        playUrl
                    )}`
                );
                const mangaData = response.data;
                let rating = "لا يوجد";
                if (mangaData.manga_rating) {
                    rating = mangaData.manga_rating;
                }
                let season = "لا يوجد";
                if (mangaData.manga_status) {
                    season = mangaData.manga_status;
                }
                let categories = "لا يوجد";
                if (mangaData.manga_genres) {
                    categories = mangaData.manga_genres
                }
                const downloadLinks = "";
                let downloadmessage = "";

                const msg = `
                • ┉ • ┉ • ┉ • ┉ • ┉ •
                ←› الاسم : ${mangaData.manga_name} ☸
                ←› التاريخ : ${mangaData.manga_release_date} ✴
                ←› الشخصية الرئيسية : ${mangaData.manga_theater} 🗝
                ←› النوع : ${season} 🔱
                ←› الفئات : ${categories} 🔖
                ←› التقييم : ${rating} ✳

                • ┉ • ┉ • ┉ • ┉ • ┉ •
                ←› القصة : ${mangaData.manga_description} 📖
                • ┉ • ┉ • ┉ • ┉ • ┉ •
                ←› لقرائة المانجا : الرجاء الرد على الرساله بكلمة "قراءة"
                `;
                const stream = await utils.getStreamFromUrl(mangaData.manga_cover_image_url);
                message.reply(
                    {
                        body: msg,
                        attachment: stream,
                    },
                    (err, info) => {
                        const downloadLinks = "";
                        let downloadMsg = "";

                        global.GoatBot.onReply.set(info.messageID, {
                            commandName,
                            messageID: info.messageID,
                            resultmessageID: info.messageID,
                            author: event.senderID,
                            type: "mangaChapte",
                            result: mangaData
                        });
                    }
                );
            } catch (error) {
                console.error("Error occurred while fetching anime details:", error);
                return message.reply("❌︙حدث خطأ أثناء جلب تفاصيل المانجا. الرجاء المحاولة مرة أخرى في وقت لاحق.");
            }
        }

        if (type == "mangaChapte" && messageBody === "قراءة") {
            var res = await axios.get(`https://allou.is-a-cool.dev/manga/${result.manga_id}`);
            const resData = res.data.data[0];
            let msg = `⋆˚ ⬷ تحتوي هذه المانغا/مانهوا على ${resData.chapter_number} رد برقم الفصل لبدك تقرأه ⋆˚ ⬷`;
            message.reply(msg, (err, info) => {
                global.GoatBot.onReply.set(info.messageID, {
                    commandName,
                    messageID: info.messageID,
                    resultmessageID: info.messageID,
                    author: event.senderID,
                    type: "ReadChapt",
                    result: result,
                });
            });
        }


        if (type == "ReadChapt") {
            if (isNaN(messageBody)) return message.reply("رد برقم يااا");
            let num = messageBody;
            var res = await axios.get(`https://allou.is-a-cool.dev/manga/${result.manga_id}`);
            let data = res.data.data;
            let chapter = data.find(obj => obj.chapter_number == num);

            var res = await axios.get(`https://allou.is-a-cool.dev/chapter/${chapter.chapter_id}`);
            let rr = res.data.data;
            let arr = []
            for (let i = 1; i < rr.length; ++i) {
                arr.push(await utils.getStreamFromUrl(rr[i].page_image_url))
            }
            let index = 0;

            for (let i = 1; i < rr.length; ++i) {
                let imagesToSend = arr.slice(index, index + 9);
                message.send({
                    body: `⋆˚ ┊ تفضل ┊ ⋆˚ ⁭`,
                    attachment: imagesToSend
                });
                index += 9;
                await delay(8000);
                if (index >= arr.length) break;
            }
        }
    }
};