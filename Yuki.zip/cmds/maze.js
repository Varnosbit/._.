const { createCanvas } = require('canvas');

exports.config = {
    name: "maze",
    author: "allou moha",
    role: 0,
    countDown: 40,
    description: "play maze",
    version: "3.0.0",
    guide: "{pn} [easy|medium|hard] - Start a maze game\n{pn} leaderboard [page] - View top players\n{pn} info [@mention|reply] - View player stats"
};

function generateMazeImage(difficulty = 15, grid = null, cols = null, highlightPath = null, wrongPath = null, currentPosition = null, progressPath = null) {
    difficulty = Math.max(1, Math.min(difficulty, 15));

    const base = 10;
    const scale = 0.4;
    const size = Math.floor(base + difficulty * scale);
    const rows = grid ? grid.length / cols : size;
    const cellSize = 30;
    if (!grid) {
        cols = size;
        grid = [];
        const stack = [];

        for (let y = 0; y < rows; y++) {
            for (let x = 0; x < cols; x++) {
                grid.push({
                    x,
                    y,
                    walls: { top: true, right: true, bottom: true, left: true },
                    visited: false
                });
            }
        }

        function index(x, y) {
            if (x < 0 || y < 0 || x >= cols || y >= rows) return -1;
            return x + y * cols;
        }

        function getNeighbors(cell) {
            const neighbors = [];
            const { x, y } = cell;

            const top = grid[index(x, y - 1)];
            const right = grid[index(x + 1, y)];
            const bottom = grid[index(x, y + 1)];
            const left = grid[index(x - 1, y)];

            if (top && !top.visited) neighbors.push(top);
            if (right && !right.visited) neighbors.push(right);
            if (bottom && !bottom.visited) neighbors.push(bottom);
            if (left && !left.visited) neighbors.push(left);

            return neighbors;
        }

        function removeWalls(a, b) {
            const dx = a.x - b.x;
            const dy = a.y - b.y;

            if (dx === 1) {
                a.walls.left = false;
                b.walls.right = false;
            } else if (dx === -1) {
                a.walls.right = false;
                b.walls.left = false;
            }

            if (dy === 1) {
                a.walls.top = false;
                b.walls.bottom = false;
            } else if (dy === -1) {
                a.walls.bottom = false;
                b.walls.top = false;
            }
        }

        let current = grid[0];
        current.visited = true;

        while (true) {
            const neighbors = getNeighbors(current);

            if (neighbors.length > 0) {
                stack.push(current);
                const next = neighbors[Math.floor(Math.random() * neighbors.length)];
                removeWalls(current, next);
                next.visited = true;
                current = next;
            } else if (stack.length > 0) {
                current = stack.pop();
            } else {
                break;
            }
        }
    } else {
        if (!cols) {
            cols = Math.sqrt(grid.length);
        }
    }

    const width = cols * cellSize;
    const height = rows * cellSize;

    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    const start = currentPosition || grid[0];
    const end = grid[grid.length - 1];

    function index(x, y) {
        if (x < 0 || y < 0 || x >= cols || y >= rows) return -1;
        return x + y * cols;
    }

    function solveMaze() {
        const queue = [start];
        const visited = new Set([index(start.x, start.y)]);
        const parent = {};

        while (queue.length > 0) {
            const cell = queue.shift();
            if (cell === end) break;

            const { x, y, walls } = cell;

            const moves = [
                !walls.top && grid[index(x, y - 1)],
                !walls.right && grid[index(x + 1, y)],
                !walls.bottom && grid[index(x, y + 1)],
                !walls.left && grid[index(x - 1, y)]
            ];

            for (const next of moves) {
                if (!next) continue;
                const idx = index(next.x, next.y);
                if (!visited.has(idx)) {
                    visited.add(idx);
                    parent[idx] = cell;
                    queue.push(next);
                }
            }
        }

        const path = [];
        let cur = end;
        while (cur !== start) {
            path.push(cur);
            cur = parent[index(cur.x, cur.y)];
        }
        path.push(start);
        return path.reverse();
    }

    const solutionPath = solveMaze();

    function getSolutionCode(path) {
        let code = "";
        for (let i = 0; i < path.length - 1; i++) {
            const a = path[i];
            const b = path[i + 1];
            if (b.x === a.x + 1) code += "r";
            else if (b.x === a.x - 1) code += "l";
            else if (b.y === a.y + 1) code += "d";
            else if (b.y === a.y - 1) code += "u";
        }
        return code;
    }

    const solutionCode = getSolutionCode(solutionPath);

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);
    if (progressPath && progressPath.length > 1) {
        ctx.strokeStyle = "rgba(255,235,59,0.8)";
        ctx.lineWidth = 6;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        ctx.beginPath();
        for (let i = 0; i < progressPath.length; i++) {
            const cell = progressPath[i];
            const cx = cell.x * cellSize + cellSize / 2;
            const cy = cell.y * cellSize + cellSize / 2;
            
            if (i === 0) {
                ctx.moveTo(cx, cy);
            } else {
                ctx.lineTo(cx, cy);
            }
        }
        ctx.stroke();
    }
    if (highlightPath && highlightPath.length > 1) {
        ctx.strokeStyle = "rgba(76,175,80,0.7)";
        ctx.lineWidth = 6;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        ctx.beginPath();
        for (let i = 0; i < highlightPath.length; i++) {
            const cell = highlightPath[i];
            const cx = cell.x * cellSize + cellSize / 2;
            const cy = cell.y * cellSize + cellSize / 2;
            
            if (i === 0) {
                ctx.moveTo(cx, cy);
            } else {
                ctx.lineTo(cx, cy);
            }
        }
        ctx.stroke();
    }
    if (wrongPath && wrongPath.length > 1) {
        ctx.strokeStyle = "rgba(244,67,54,0.7)";
        ctx.lineWidth = 6;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        ctx.beginPath();
        for (let i = 0; i < wrongPath.length; i++) {
            const cell = wrongPath[i];
            const cx = cell.x * cellSize + cellSize / 2;
            const cy = cell.y * cellSize + cellSize / 2;
            
            if (i === 0) {
                ctx.moveTo(cx, cy);
            } else {
                ctx.lineTo(cx, cy);
            }
        }
        ctx.stroke();
    }

    ctx.fillStyle = "#d0d0d0";
    const markerSize = cellSize * 0.15;
    grid.forEach(cell => {
        const cx = cell.x * cellSize + cellSize / 2;
        const cy = cell.y * cellSize + cellSize / 2;
        ctx.fillRect(cx - markerSize / 2, cy - markerSize / 2, markerSize, markerSize);
    });

    ctx.font = `${Math.floor(cellSize * 0.7)}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    ctx.fillStyle = "#87a8f2";
    ctx.fillRect(start.x * cellSize, start.y * cellSize, cellSize, cellSize);
    ctx.fillStyle = "#000000";
    ctx.fillText("A", start.x * cellSize + cellSize / 2, start.y * cellSize + cellSize / 2);

    ctx.fillStyle = "#f28b82";
    ctx.fillRect(end.x * cellSize, end.y * cellSize, cellSize, cellSize);
    ctx.fillStyle = "#000000";
    ctx.fillText("B", end.x * cellSize + cellSize / 2, end.y * cellSize + cellSize / 2);

    ctx.strokeStyle = "#000";
    ctx.lineWidth = 2;

    grid.forEach(cell => {
        const x = cell.x * cellSize;
        const y = cell.y * cellSize;
        const w = cell.walls;

        if (w.top) {
            ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + cellSize, y); ctx.stroke();
        }
        if (w.right) {
            ctx.beginPath(); ctx.moveTo(x + cellSize, y); ctx.lineTo(x + cellSize, y + cellSize); ctx.stroke();
        }
        if (w.bottom) {
            ctx.beginPath(); ctx.moveTo(x, y + cellSize); ctx.lineTo(x + cellSize, y + cellSize); ctx.stroke();
        }
        if (w.left) {
            ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + cellSize); ctx.stroke();
        }
    });

    return {
        image: canvas.createPNGStream(),
        solution: solutionCode,
        solutionPath,
        grid,
        cols
    };
}

function trans(emos) {
    return emos
        .replace(/⬆️/gi, "u")
        .replace(/➡️/gi, "r")
        .replace(/⬇️/gi, "d")
        .replace(/⬅️/gi, "l");
}

function getPathFromCode(code, grid, cols, startCell = null) {
    const rows = grid.length / cols;
    const start = startCell || grid[0];
    const path = [start];
    let current = start;

    function index(x, y) {
        if (x < 0 || y < 0 || x >= cols || y >= rows) return -1;
        return x + y * cols;
    }

    for (const move of code) {
        let nx = current.x;
        let ny = current.y;

        if (move === "u") ny--;
        if (move === "d") ny++;
        if (move === "l") nx--;
        if (move === "r") nx++;

        const idx = index(nx, ny);
        if (idx === -1) break;

        const next = grid[idx];
        const valid =
            (move === "u" && !current.walls.top) ||
            (move === "d" && !current.walls.bottom) ||
            (move === "l" && !current.walls.left) ||
            (move === "r" && !current.walls.right);

        if (!valid) break;

        path.push(next);
        current = next;
    }

    return path;
}

function isPartialSolutionCorrect(userPath, solutionPath) {
    if (userPath.length > solutionPath.length) return false;
    
    for (let i = 0; i < userPath.length; i++) {
        if (userPath[i].x !== solutionPath[i].x || userPath[i].y !== solutionPath[i].y) {
            return false;
        }
    }
    return true;
}

// Helper function to get or create player data
async function getPlayerData(globalData, userID) {
    const rank = await globalData.get("maze", "data", []);
    let player = rank.find(obj => obj.id == userID);
    
    if (!player) {
        player = {
            id: userID,
            wins: {
                easy: 0,
                medium: 0,
                hard: 0
            },
            loses: 0,
            points: 0,
            totalGames: 0,
            totalPlayTime: 0,
            winTimes: [],
            fastestWin: null,
            slowestWin: null
        };
        rank.push(player);
    }
    
    return { player, rank };
}

// Helper function to calculate statistics
function calculateStats(player) {
    const totalWins = player.wins.easy + player.wins.medium + player.wins.hard;
    const winrate = player.totalGames > 0 ? ((totalWins / player.totalGames) * 100).toFixed(1) : 0;
    
    const avgWinTime = player.winTimes.length > 0 
        ? Math.floor(player.winTimes.reduce((a, b) => a + b, 0) / player.winTimes.length)
        : 0;
    
    const avgPlayTime = player.totalGames > 0 
        ? Math.floor(player.totalPlayTime / player.totalGames)
        : 0;
    
    return {
        totalWins,
        winrate,
        avgWinTime,
        avgPlayTime
    };
}

// Helper function to format time
function formatTime(seconds) {
    if (seconds < 60) return `${seconds}s`;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
}

// Ranking functions
async function leaderboard(globalData, event, usersData, page = 1) {
    const rank = await globalData.get("maze", "data", []);
    
    if (rank.length === 0) {
        return "📊 No players have played yet. Be the first!";
    }
    
    // Sort by points (descending), then by winrate, then by total wins
    rank.sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points;
        
        const aStats = calculateStats(a);
        const bStats = calculateStats(b);
        
        if (bStats.winrate !== aStats.winrate) return bStats.winrate - aStats.winrate;
        return bStats.totalWins - aStats.totalWins;
    });
    
    const itemsPerPage = 10;
    const totalPages = Math.ceil(rank.length / itemsPerPage);
    page = Math.max(1, Math.min(page, totalPages));
    
    const startIdx = (page - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const pageData = rank.slice(startIdx, endIdx);
    
    let message = `🏆 MAZE GAME LEADERBOARD 🏆\n`;
    message += `______________\n`;
    message += `📄 Page ${page}/${totalPages}\n\n`;
    
    for (let i = 0; i < pageData.length; i++) {
        const player = pageData[i];
        const globalRank = startIdx + i + 1;
        const stats = calculateStats(player);
        
        let rankEmoji = "";
        if (globalRank === 1) rankEmoji = "🥇";
        else if (globalRank === 2) rankEmoji = "🥈";
        else if (globalRank === 3) rankEmoji = "🥉";
        else rankEmoji = `${globalRank}.`;
        
        const userName = (await usersData.getName(player.id)) || "Unknown";
        
        message += `${rankEmoji} ${userName}\n`;
        message += `   💎 Points: ${player.points} | 🎯 WR: ${stats.winrate}%\n`;
        message += `   🏅 Wins: ${stats.totalWins} (E:${player.wins.easy} M:${player.wins.medium} H:${player.wins.hard})\n`;
        message += `   ❌ Loses: ${player.loses}\n\n`;
    }
    
    message += `______________\n`;
    message += `💡 Use: maze leaderboard [page]\n`;
    message += `Total players: ${rank.length}`;
    
    return message;
}

async function info(globalData, event, usersData) {
    const rank = await globalData.get("maze", "data", []);
    const id = Object.keys(event.mentions || {})?.[0] || event.messageReply?.senderID || event.senderID;
    const target = rank.find(obj => obj.id == id);
    
    if (!target) {
        return "❌ No stats found for this player. Play a game first!";
    }
    
    const stats = calculateStats(target);
    const userName = (await usersData.getName(id)) || "Unknown";
    rank.sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points;
        const aStats = calculateStats(a);
        const bStats = calculateStats(b);
        if (bStats.winrate !== aStats.winrate) return bStats.winrate - aStats.winrate;
        return bStats.totalWins - aStats.totalWins;
    });
    
    const playerRank = rank.findIndex(p => p.id == id) + 1;
    
    let message = `📊 PLAYER STATS: ${userName}\n`;
    message += `______________\n\n`;
    message += `🏆 Global Rank: #${playerRank}/${rank.length}\n`;
    message += `💎 Total Points: ${target.points}\n\n`;
    
    message += `📈 GAME STATISTICS:\n`;
    message += `______________\n`;
    message += `🎮 Total Games: ${target.totalGames}\n`;
    message += `✅ Total Wins: ${stats.totalWins}\n`;
    message += `   🟢 Easy: ${target.wins.easy}\n`;
    message += `   🟡 Medium: ${target.wins.medium}\n`;
    message += `   🔴 Hard: ${target.wins.hard}\n`;
    message += `❌ Total Loses: ${target.loses}\n`;
    message += `🎯 Win Rate: ${stats.winrate}%\n\n`;
    
    message += `⏱️ TIME STATISTICS:\n`;
    message += `______________\n`;
    message += `⏰ Total Play Time: ${formatTime(target.totalPlayTime)}\n`;
    message += `📊 Avg Game Time: ${formatTime(stats.avgPlayTime)}\n`;
    
    if (target.winTimes.length > 0) {
        message += `🏁 Avg Win Time: ${formatTime(stats.avgWinTime)}\n`;
        if (target.fastestWin) message += `⚡ Fastest Win: ${formatTime(target.fastestWin)}\n`;
        if (target.slowestWin) message += `🐢 Slowest Win: ${formatTime(target.slowestWin)}\n`;
    }
    
    return message;
}

async function updatePlayerStats(globalData, userID, won, difficulty, playTime) {
    const { player, rank } = await getPlayerData(globalData, userID);
    
    player.totalGames++;
    player.totalPlayTime += playTime;
    
    if (won) {
        player.wins[difficulty]++;
        player.winTimes.push(playTime);
        
        // Update fastest/slowest wins
        if (!player.fastestWin || playTime < player.fastestWin) {
            player.fastestWin = playTime;
        }
        if (!player.slowestWin || playTime > player.slowestWin) {
            player.slowestWin = playTime;
        }
        
        // Award points based on difficulty
        const pointsMap = { easy: 10, medium: 25, hard: 50 };
        player.points += pointsMap[difficulty];
        
        // Bonus points for fast completion
        if (playTime < 30) player.points += 10;
        else if (playTime < 60) player.points += 5;
    } else {
        player.loses++;
    }
    
    await globalData.set("maze", rank, "data");
}

const activeGames = new Map();

exports.onStart = async ({ message, event, commandName, args, globalData, usersData }) => {
    if (args[0]?.toLowerCase() === "leaderboard" || args[0]?.toLowerCase() === "lb") {
        const page = parseInt(args[1]) || 1;
        const msg = await leaderboard(globalData, event, usersData, page);
        return message.reply(msg);
    }
    
    if (args[0]?.toLowerCase() === "info" || args[0]?.toLowerCase() === "stats") {
        const msg = await info(globalData, event, usersData);
        return message.reply(msg);
    }
    
    const userID = event.senderID;
    if (activeGames.has(userID)) {
        const previousGame = activeGames.get(userID);
        const playTime = Math.floor((Date.now() - previousGame.startTime) / 1000);
        
        await updatePlayerStats(globalData, userID, false, previousGame.difficulty, playTime);
        
        if (previousGame.messageID) {
            YamiBot.onReply.delete(previousGame.messageID);
        }
        
        message.reply("⚠️ Your previous game was counted as a loss due to abandonment.");
    }
    const difficultyArg = args[0]?.toLowerCase();
    let difficulty, difficultyName, difficultyValue;
    
    if (difficultyArg === "medium") {
        difficulty = 10;
        difficultyName = "medium";
        difficultyValue = "🟡 Medium";
    } else if (difficultyArg === "hard") {
        difficulty = 15;
        difficultyName = "hard";
        difficultyValue = "🔴 Hard";
    } else {
        difficulty = 5;
        difficultyName = "easy";
        difficultyValue = "🟢 Easy";
    }
    
    const data = generateMazeImage(difficulty);
    data.image.path = utils.randomString(4) + ".png";

    const reply = await message.reply({
        body: `🧩 Solve the maze using emojis (⬆️ ➡️ ⬇️ ⬅️)\n\n• Difficulty: ${difficultyValue}\n• Send your complete path or partial path\n• If correct, continue from where you stopped\n• You have 3 attempts for wrong answers\n\n⚠️ Starting a new game will count this as a loss!`,
        attachment: data.image
    });

    const gameData = {
        commandName,
        au: userID,
        solution: data.solution,
        solutionPath: data.solutionPath,
        grid: data.grid,
        cols: data.cols,
        attempts: 0,
        currentProgress: "",
        currentPosition: data.grid[0],
        difficulty: difficultyName,
        startTime: Date.now(),
        messageID: reply.messageID
    };

    YamiBot.onReply.set(reply.messageID, gameData);

    activeGames.set(userID, {
        messageID: reply.messageID,
        difficulty: difficultyName,
        startTime: Date.now()
    });
};

exports.onReply = async ({ message, event, Reply, globalData }) => {
    const { au, solution, solutionPath, grid, cols, currentProgress, difficulty, startTime } = Reply;
    if (event.senderID !== au) return;

    const userEmoji = event.body.trim();
    const userCode = trans(userEmoji);
    const fullCode = currentProgress + userCode;

    const userPath = getPathFromCode(fullCode, grid, cols, grid[0]);
    const isCorrectPath = isPartialSolutionCorrect(userPath, solutionPath) && userPath.length === fullCode.length + 1;
    
    if (isCorrectPath && fullCode === solution) {
        const playTime = Math.floor((Date.now() - startTime) / 1000);
        const data = generateMazeImage(15, grid, cols, solutionPath, null);
        data.image.path = utils.randomString(4) + ".png";
        await updatePlayerStats(globalData, event.senderID, true, difficulty, playTime);
        activeGames.delete(event.senderID);

        await message.reply({
            body: `🎉 Correct! You solved the maze!\n\n⏱️ Time: ${formatTime(playTime)}\n💎 Points earned: ${difficulty === "easy" ? 10 : difficulty === "medium" ? 25 : 50}${playTime < 30 ? " +10 (speed bonus!)" : playTime < 60 ? " +5 (speed bonus!)" : ""}`,
            attachment: data.image
        });
        YamiBot.onReply.delete(event.messageID);
        return;
    }
    
    if (isCorrectPath && userPath.length > 1) {
        const currentCell = userPath[userPath.length - 1];
        Reply.currentProgress = fullCode;
        Reply.currentPosition = currentCell;
        const data = generateMazeImage(5, grid, cols, null, null, currentCell, userPath);
        data.image.path = utils.randomString(4) + ".png";
        YamiBot.onReply.delete(event.messageID);

        const newReply = await message.reply({
            body: `✅ Correct path! Continue from your position.\n\n📍 Progress: ${fullCode.length}/${solution.length} moves\n🎯 Keep going to reach point B!`,
            attachment: data.image
        });
        
        const newGameData = {
            commandName: Reply.commandName,
            au: Reply.au,
            solution: Reply.solution,
            solutionPath: Reply.solutionPath,
            grid: Reply.grid,
            cols: Reply.cols,
            attempts: Reply.attempts,
            currentProgress: fullCode,
            currentPosition: currentCell,
            difficulty: Reply.difficulty,
            startTime: Reply.startTime,
            messageID: newReply.messageID
        };
        
        YamiBot.onReply.set(newReply.messageID, newGameData);
        activeGames.set(event.senderID, {
            messageID: newReply.messageID,
            difficulty: Reply.difficulty,
            startTime: Reply.startTime
        });
        return;
    }
    
    Reply.attempts++;
    if (Reply.attempts >= 3) {
        const playTime = Math.floor((Date.now() - startTime) / 1000);
        const wrongPath = getPathFromCode(fullCode, grid, cols, grid[0]);
        const data = generateMazeImage(15, grid, cols, solutionPath, wrongPath);
        data.image.path = utils.randomString(4) + ".png";
        await updatePlayerStats(globalData, event.senderID, false, difficulty, playTime);
        activeGames.delete(event.senderID);
        await message.reply({
            body: `❌ Game over! You ran out of attempts.\n\n✅ Correct solution shown in green\n❌ Your path shown in red\n⏱️ Time played: ${formatTime(playTime)}`,
            attachment: data.image
        });
        YamiBot.onReply.delete(event.messageID);
    } else {
        await message.reply(`❌ Wrong path! Try again.\n\n🔄 Attempts remaining: ${3 - Reply.attempts}`);
    }
};