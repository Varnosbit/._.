const Canvas = require("canvas");
const jimp = require("jimp");

this.config = {
	name: "divorce",
	aliases: ["طلقني"],
	version: "1.0.0",
	author: "Ntkhang in Goat V1 moded for Goat V2 By Allou Mohamed.",
	countDown: 5,
	role: 0,
	description: {
	    en: "divorce '-'.",
	    ar: "يطلقك 🗿"
	},
	category: "image",
	guide: "{pn}"
};

module.exports = {
	config: this.config,
	onStart: async function ({ api, args, threadsData, message, event, usersData }) {

		async function circleImage(buffer) {
			const imageBuffer = await jimp.read(buffer);
			imageBuffer.circle();
			return await imageBuffer.getBufferAsync("image/png");
		}

		const { threadID, senderID, messageID } = event;
		const threadData = await threadsData.get(threadID);
		const { members } = threadData;
		const sender = members.find(x => x.userID == senderID);
		const senderGender = sender.gender;
		const senderName = sender.name;
        const otherGender = members.filter(x => x.gender != senderGender && x.inGroup == true); //عشان ما يزوجنا اشخاص طلعو من الجروب 🐦
        const randomPersona = otherGender[Math.floor(Math.random() * otherGender.length)];
        const random = randomPersona.userID;
        const pairName = randomPersona.name;
        
		const frame = await Canvas.loadImage("https://i.imgur.com/Miin6Jw.jpeg");
		const avatarAuthor = await Canvas.loadImage(await circleImage(await usersData.getAvatarUrl(senderID)));
		const avatarRandom = await Canvas.loadImage(await circleImage(await usersData.getAvatarUrl(random)));

		const canvas = Canvas.createCanvas(frame.width, frame.height);
		const ctx = canvas.getContext("2d");

		const infoFrame = [
			{
				gender: "MALE",
				x: 280,
				y: 50,
				size: 120
			},
			{
				gender: "FEMALE",
				x: 160,
				y: 465,
				size: 125
			}
		];
		const drawAuthor = infoFrame.find(item => item.gender == senderGender);
		const drawRandom = infoFrame.find(item => item.gender != senderGender);

		ctx.drawImage(frame, 0, 0, frame.width, frame.height);
		ctx.drawImage(avatarAuthor, drawAuthor.x, drawAuthor.y, drawAuthor.size, drawAuthor.size);
		ctx.drawImage(avatarRandom, drawRandom.x, drawRandom.y, drawRandom.size, drawRandom.size);

        const stream = canvas.createPNGStream();
        stream.path = 'pair.png';
        const msg = `${pairName} رسميا أنتي طالق 💔🐦.`;
        message.send({
          body: msg,
          attachment: stream,
          mentions: [{tag: senderName, id: senderID},{tag: pairName, id:random}]
        });
	}
};