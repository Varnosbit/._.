"use strict";

const utils = require("../utils");
const log = require("npmlog");

function formatGroupData(resData) {
 if (!resData.create_group || !resData.create_group.group) {
 return null;
 }

 const group = resData.create_group.group;
 
 return {
 id: group.id,
 name: group.full_name || group.name,
 url: group.url || group.groupVisitUri,
 privacy: group.privacy_info ? group.privacy_info.title.text : "Unknown",
 memberCount: group.group_snippets && group.group_snippets.nodes.length > 0
 ? group.group_snippets.nodes[0].title.text
 : "Unknown",
 profilePicture: group.profile_picture ? group.profile_picture.uri : null,
 groupType: group.join_action && group.join_action.group 
 ? group.join_action.group.group_type_name_for_content 
 : "GROUP"
 };
}

module.exports = function (defaultFuncs, api, ctx) {
 return function createFbGroup(groupName, options, callback) {
 let resolveFunc = function () { };
 let rejectFunc = function () { };
 const returnPromise = new Promise(function (resolve, reject) {
 resolveFunc = resolve;
 rejectFunc = reject;
 });

 if (utils.getType(options) === "Function") {
 callback = options;
 options = {};
 }

 options = options || {};

 if (!callback) {
 callback = function (err, data) {
 if (err) {
 return rejectFunc(err);
 }
 resolveFunc(data);
 };
 }

 if (!groupName || typeof groupName !== "string") {
 return callback({ error: "Group name is required and must be a string" });
 }

 const privacy = options.privacy || "PUBLIC";
 const members = options.members || [];
 const description = options.description || "";
 const isForum = options.isForum || false;

 const variables = {
 input: {
 attribution_id_v2: `GroupsCometCreateRoot.react,comet.group.create,mega_menu,${Date.now()},870952,,,`,
 bulk_invitee_members: [],
 cover_focus: null,
 discoverability: privacy === "PUBLIC" ? "ANYONE" : "MEMBERS_ONLY",
 enable_contextual_actors: false,
 is_forum: isForum,
 is_purchaser_automatic_membership_approval_enabled: false,
 members: members,
 name: groupName,
 privacy: privacy,
 referrer: "LHC_COMET_HOME_CREATE_DROPDOWN",
 set_affiliation: false,
 should_invite_followers: false,
 actor_id: ctx.i_userID || ctx.userID,
 client_mutation_id: "1"
 },
 scale: 2
 };

 if (description) {
 variables.input.description = description;
 }

 const form = {
 av: ctx.i_userID || ctx.userID,
 __aaid: "0",
 __user: ctx.i_userID || ctx.userID,
 __a: "1",
 __req: "1s",
 __hs: ctx.__hs || "",
 dpr: "2",
 __ccg: "GOOD",
 __rev: ctx.__rev || "",
 __s: ctx.__s || "",
 __hsi: ctx.__hsi || "",
 __dyn: ctx.__dyn || "",
 __csr: ctx.__csr || "",
 __comet_req: "15",
 fb_dtsg: ctx.fb_dtsg,
 jazoest: ctx.jazoest || "25228",
 lsd: ctx.lsd || "",
 __spin_r: ctx.__spin_r || "",
 __spin_b: "trunk",
 __spin_t: Math.floor(Date.now() / 1000).toString(),
 qpl_active_flow_ids: "431630887",
 fb_api_caller_class: "RelayModern",
 fb_api_req_friendly_name: "useGroupsCometCreateMutation",
 server_timestamps: "true",
 variables: JSON.stringify(variables),
 doc_id: "25679281761738036",
 fb_api_analytics_tags: JSON.stringify(["qpl_active_flow_ids=431630887"])
 };

 defaultFuncs
 .post("https://web.facebook.com/api/graphql/", ctx.jar, form)
 .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
 .then(function (resData) {
 if (resData.errors) {
 throw resData;
 }
 
 const groupData = formatGroupData(resData.data);
 
 if (!groupData) {
 throw { error: "Failed to create group or retrieve group data" };
 }
 
 return callback(null, groupData);
 })
 .catch(function (err) {
 log.error("createGroup", err);
 return callback(err);
 });

 return returnPromise;
 };
};
