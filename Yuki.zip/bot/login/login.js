process.stdout.write("\x1b]2;Yami Bot V2 - Made by Allou Mohamed\x1b\x5c");
const defaultRequire = require;

const gradient = defaultRequire("gradient-string");
const axios = defaultRequire("axios");
const path = defaultRequire("path");
const fs = defaultRequire("fs-extra");
const login = defaultRequire(`${process.cwd()}/fb-chat-api`);
const https = defaultRequire("https");
const {
    writeFileSync,
    readFileSync,
    existsSync,
    watch
} = require("fs-extra");
const handlerWhenListenHasError = require("./handlerWhenListenHasError.js");
const check_live_appstate = require("./check_live_appstate.js");
const getCoc = require("./PotatoChan.js");
const {
    callbackListenTime,
    storage5Message
} = global.YamiBot;
const {
    log,
    logColor,
    getPrefix,
    jsonStringifyColor,
    getText,
    convertTime,
    colors,
    randomString
} = global.utils;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const currentVersion = require(`${process.cwd()}/package.json`).version;

function centerText(text, length) {
    const width = process.stdout.columns;
    const leftPadding = Math.floor((width - (length || text.length)) / 2);
    const rightPadding = width - leftPadding - (length || text.length);
    const paddedString = ' '.repeat(leftPadding > 0 ? leftPadding: 0) + text + ' '.repeat(rightPadding > 0 ? rightPadding: 0);
    console.log(paddedString);
}
const titles = [
    [
        "██╗░░░██╗██╗░░░██╗██╗░░██╗██╗ ██████╗░░█████╗░████████╗",
        "╚██╗░██╔╝██║░░░██║██║░██╔╝██║ ██╔══██╗██╔══██╗╚══██╔══╝",
        "░╚████╔╝░██║░░░██║█████═╝░██║ ██████╦╝██║░░██║░░░██║░░░",
        "░░╚██╔╝░░██║░░░██║██╔═██╗░██║ ██╔══██╗██║░░██║░░░██║░░░",
        "░░░██║░░░╚██████╔╝██║░╚██╗██║ ██████╦╝╚█████╔╝░░░██║░░░",
        "░░░╚═╝░░░░╚═════╝░╚═╝░░╚═╝╚═╝ ╚═════╝░░╚════╝░░░░╚═╝░░░"
    ],
    [
        "█▄█ █░█ █▄▀ █ █▄▄ █▀█ ▀█▀",
        "░█░ █▄█ █░█ █ █▄█ █▄█ ░█░"
    ],
    [
        "Y U K I  V 2 @" + currentVersion
    ],
    [
        "YamiBot V2"
    ]
];
const maxWidth = 40;
const title = maxWidth > 58 ?
titles[0]:
maxWidth > 36 ?
titles[1]:
maxWidth > 26 ?
titles[2]:
titles[3];

console.log(gradient("#f5af19", "#f12711")(createLine(null, true)));
console.log();
for (const text of title) {
    const textColor = gradient("#FA8BFF", "#2BD2FF", "#2BFF88")(text);
    centerText(textColor, text.length);
}
let subTitle = `YamiBot V2@${currentVersion}- A simple Messenger ChatBot.`;
const subTitleArray = [];
if (subTitle.length > maxWidth) {
    while (subTitle.length > maxWidth) {
        let lastSpace = subTitle.slice(0, maxWidth).lastIndexOf(' ');
        lastSpace = lastSpace == -1 ? maxWidth: lastSpace;
        subTitleArray.push(subTitle.slice(0, lastSpace).trim());
        subTitle = subTitle.slice(lastSpace).trim();
    }
    subTitle ? subTitleArray.push(subTitle): '';
} else {
    subTitleArray.push(subTitle);
}
const author = ("Remaked By ProArCoderTeam.");
const srcUrl = ("Contact: https://facebook.com/proarcoder");
const fakeRelease = ("Source Code By Ntkhang Remaked By Allou Mohamed");
for (const t of subTitleArray) {
    const textColor2 = gradient("#9F98E8", "#AFF6CF")(t);
    centerText(textColor2, t.length);
}
centerText(gradient("#9F98E8", "#AFF6CF")(author), author.length);
centerText(gradient("#9F98E8", "#AFF6CF")(srcUrl), srcUrl.length);
centerText(gradient("#f5af19", "#f12711")(fakeRelease), fakeRelease.length);

let widthConsole = process.stdout.columns;
if (widthConsole > 50)
    widthConsole = 50;

function createLine(content, isMaxWidth = false) {
    if (!content)
        return Array(isMaxWidth ? process.stdout.columns: widthConsole).fill("─").join("");
    else {
        content = ` ${content.trim()} `;
        const lengthContent = content.length;
        const lengthLine = isMaxWidth ? process.stdout.columns - lengthContent: widthConsole - lengthContent;
        let left = Math.floor(lengthLine / 2);
        if (left < 0 || isNaN(left))
            left = 0;
        const lineOne = Array(left).fill("─").join("");
        return lineOne + content + lineOne;
    }
}
const character = createLine();
const clearLines = (n) => {
    for (let i = 0; i < n; i++) {
        const y = i === 0 ? null: -1;
        process.stdout.moveCursor(0, y);
        process.stdout.clearLine(1);
    }
    process.stdout.cursorTo(0);
    process.stdout.write('');
};
const {
    dirAccount
} = global.client;

function checkAndTrimString(string) {
    if (typeof string == "string")
        return string.trim();
    return string;
}

function filterKeysAppState(appState) {
    return appState.filter(item => ["c_user", "xs", "datr", "fr", "sb", "i_user"].includes(item.key));
}
global.statusAccountBot = 'good';
let changeFbStateByCode = false;
let latestChangeContentAccount = fs.statSync(dirAccount).mtimeMs;
let dashBoardIsRunning = false;

function isNetScapeCookie(cookie) {
    if (typeof cookie !== 'string')
        return false;
    return /(.+)\t(1|TRUE|true)\t([\w\/.-]*)\t(1|TRUE|true)\t\d+\t([\w-]+)\t(.+)/i.test(cookie);
}

function netScapeToCookies(cookieData) {
    const cookies = [];
    const lines = cookieData.split('\n');
    lines.forEach((line) => {
        if (line.trim().startsWith('#')) {
            return;
        }
        const fields = line.split('\t').map((field) => field.trim()).filter((field) => field.length > 0);
        if (fields.length < 7) {
            return;
        }
        const cookie = {
            key: fields[5],
            value: fields[6],
            domain: fields[0],
            path: fields[2],
            hostOnly: fields[1] === 'TRUE',
            creation: new Date(fields[4] * 1000).toISOString(),
            lastAccessed: new Date().toISOString()
        };
        cookies.push(cookie);
    });
    return cookies;
}

async function getAppStateToLogin() {
    let appState = [];

    if (!existsSync(dirAccount))
        return log.error("LOGIN FACEBOOK", getText('login', 'notFoundDirAccount', colors.green(dirAccount)));

    const accountText = readFileSync(dirAccount, "utf8").trim();

    if (!accountText) {
        log.error("LOGIN FACEBOOK", "Cookie file is empty, fetching new cookies...");
        const { email, password } = global.YamiBot.config.facebookAccount;
        appState = await getCoc({ username: email, password });

        appState = appState.map(item => ({
            ...item,
            domain: "facebook.com",
            path: "/",
            hostOnly: false,
            creation: new Date().toISOString(),
            lastAccessed: new Date().toISOString()
        })).filter(i => i.key && i.value && i.key !== "x-referer");

        writeFileSync(dirAccount, JSON.stringify(appState, null, 2));
        return appState;
    }

    try {
        const splitAccountText = accountText.replace(/\|/g, '\n').split('\n').map(i => i.trim()).filter(i => i);

        if (/^(?:\s*\w+\s*=\s*[^;]*;?)+$/.test(accountText)) {
            appState = accountText.split(';').map(i => {
                const [key, value] = i.split('=');
                return {
                    key: (key || "").trim(),
                    value: (value || "").trim(),
                    domain: "facebook.com",
                    path: "/",
                    hostOnly: true,
                    creation: new Date().toISOString(),
                    lastAccessed: new Date().toISOString()
                };
            }).filter(i => i.key && i.value && i.key !== "x-referer");
        } else if (isNetScapeCookie(accountText)) {
            appState = netScapeToCookies(accountText);
        } else {
            appState = JSON.parse(accountText);

            if (appState.some(i => i.name)) {
                appState = appState.map(i => {
                    i.key = i.name;
                    delete i.name;
                    return i;
                });
            }

            appState = appState.map(item => ({
                ...item,
                domain: "facebook.com",
                path: "/",
                hostOnly: false,
                creation: new Date().toISOString(),
                lastAccessed: new Date().toISOString()
            })).filter(i => i.key && i.value && i.key !== "x-referer");
        }

        const isLive = await check_live_appstate(appState);
        if (!isLive.success) throw new Error("DEAD_COOKIE");

        return appState;

    } catch (e) {
        console.log(e);
        const { email, password } = global.YamiBot.config.facebookAccount;
        appState = await getCoc({ username: email, password });

        appState = appState.map(item => ({
            ...item,
            domain: "facebook.com",
            path: "/",
            hostOnly: false,
            creation: new Date().toISOString(),
            lastAccessed: new Date().toISOString()
        })).filter(i => i.key && i.value && i.key !== "x-referer");

        writeFileSync(dirAccount, JSON.stringify(appState, null, 2));
        return appState;
    }
}

function stopListening(keyListen) {
    keyListen = keyListen || Object.keys(callbackListenTime).pop();
    return new Promise((resolve) => {
        global.YamiBot.fcaApi.stopListening?.(() => {
            if (callbackListenTime[keyListen]) {
                callbackListenTime[keyListen] = () => {};
            }
            resolve();
        }) || resolve();
    });
}

async function startBot() {
    console.log(colors.hex("#f5ab00")(createLine("START LOGGING IN", true)));
    const currentVersion = require("../../package.json").version;
    const tooOldVersion = (await axios.get("https://raw.githubusercontent.com/ntkhang03/Goat-Bot-V2-Storage/main/tooOldVersions.txt")).data || "0.0.0";
    if (global.YamiBot.Listening) await stopListening();
    log.info("LOGIN FACEBOOK", getText('login', 'currentlyLogged'));

    let appState = await getAppStateToLogin();
    changeFbStateByCode = true;
    appState = filterKeysAppState(appState);
    writeFileSync(dirAccount, JSON.stringify(appState, null, 2));
    setTimeout(() => changeFbStateByCode = false, 1000);
    // ——————————————————— LOGIN ———————————————————— //
    (function loginBot(appState) {
        global.YamiBot.commands = new Map();
        global.YamiBot.eventCommands = new Map();
        global.YamiBot.aliases = new Map();
        global.YamiBot.onChat = [];
        global.YamiBot.onEvent = [];
        global.YamiBot.onReply = new Map();
        global.YamiBot.onReaction = new Map();
        clearInterval(global.intervalRestartListenMqtt);
        delete global.intervalRestartListenMqtt;
        let isSendNotiErrorMessage = false;
        login({
            appState
        }, global.YamiBot.config.optionsFca, async function (error, {
                api, mqtt
            }) {
            if (error) {
                log.err("LOGIN FACEBOOK", getText('login', 'loginError'), error);
                global.statusAccountBot = 'can\'t login';
                process.exit();
            }

            global.YamiBot.fcaApi = api;
            global.YamiBot.botID = api.getCurrentUserID();
            log.info("LOGIN FACEBOOK", getText('login', 'loginSuccess'));
            let hasBanned = false;
            global.botID = api.getCurrentUserID();
            logColor("#f5ab00", createLine("BOT INFO"));
            log.info("NODE VERSION", process.version);
            log.info("PROJECT VERSION", currentVersion);
            log.info("BOT ID", `${global.botID} - YamiBot`);
            log.info("PREFIX", global.YamiBot.config.prefix);
            log.info("LANGUAGE", global.YamiBot.config.language);
            log.info("BOT NICK NAME", global.YamiBot.config.nickNameBot || "Yami BOT");
            // ———————————————————— GBAN ————————————————————— //
            log.warn("Global Ban", "No Gban Code.");
            // ——————————————————— LOAD DATA ——————————————————— //
            const {
                threadModel,
                userModel,
                dashBoardModel,
                globalModel,
                threadsData,
                usersData,
                dashBoardData,
                globalData,
                sequelize
            } = await require("./loadData.js")(api, createLine);
            // ————————————————— CUSTOM SCRIPTS ————————————————— //
            await require("../custom.js")({
                api, threadModel, userModel, dashBoardModel, globalModel, threadsData, usersData, dashBoardData, globalData, getText
            });
            // —————————————————— LOAD SCRIPTS —————————————————— //
            await require("./loadScripts.js")(api, threadModel, userModel, dashBoardModel, globalModel, threadsData, usersData, dashBoardData, globalData, createLine);
            // ———————————— CHECK AUTO LOAD SCRIPTS ———————————— //
            if (global.YamiBot.config.autoLoadScripts?.enable == true) {
                const ignoreCmds = global.YamiBot.config.autoLoadScripts.ignoreCmds?.replace(/[ ,]+/g, ' ').trim().split(' ') || [];
                const ignoreEvents = global.YamiBot.config.autoLoadScripts.ignoreEvents?.replace(/[ ,]+/g, ' ').trim().split(' ') || [];

                watch(`${process.cwd()}/scripts/cmds`, async (event, filename) => {
                    if (filename.endsWith('.js')) {
                        if (ignoreCmds.includes(filename) || filename.endsWith('.eg.js'))
                            return;
                        if ((event == 'change' || event == 'rename') && existsSync(`${process.cwd()}/scripts/cmds/${filename}`)) {
                            try {
                                const contentCommand = global.temp.contentScripts.cmds[filename] || "";
                                const currentContent = readFileSync(`${process.cwd()}/scripts/cmds/${filename}`, 'utf-8');
                                if (contentCommand == currentContent)
                                    return;
                                global.temp.contentScripts.cmds[filename] = currentContent;
                                filename = filename.replace('.js', '');

                                const infoLoad = global.utils.loadScripts("cmds", filename, log, global.YamiBot.configCommands, api, threadModel, userModel, dashBoardModel, globalModel, threadsData, usersData, dashBoardData, globalData);
                                if (infoLoad.status == "success")
                                    log.master("AUTO LOAD SCRIPTS", `Command ${filename}.js (${infoLoad.command.config.name}) has been reloaded`);
                                else
                                    log.err("AUTO LOAD SCRIPTS", `Error when reload command ${filename}.js`, infoLoad.error);
                            }
                            catch (err) {
                                log.err("AUTO LOAD SCRIPTS", `Error when reload command ${filename}.js`, err);
                            }
                        }
                    }
                });

                watch(`${process.cwd()}/scripts/events`,
                    async (event, filename) => {
                        if (filename.endsWith('.js')) {
                            if (ignoreEvents.includes(filename) || filename.endsWith('.eg.js'))
                                return;
                            if ((event == 'change' || event == 'rename') && existsSync(`${process.cwd()}/scripts/events/${filename}`)) {
                                try {
                                    const contentEvent = global.temp.contentScripts.events[filename] || "";
                                    const currentContent = readFileSync(`${process.cwd()}/scripts/events/${filename}`, 'utf-8');
                                    if (contentEvent == currentContent)
                                        return;
                                    global.temp.contentScripts.events[filename] = currentContent;
                                    filename = filename.replace('.js', '');

                                    const infoLoad = global.utils.loadScripts("events", filename, log, global.YamiBot.configCommands, api, threadModel, userModel, dashBoardModel, globalModel, threadsData, usersData, dashBoardData, globalData);
                                    if (infoLoad.status == "success")
                                        log.master("AUTO LOAD SCRIPTS", `Event ${filename}.js (${infoLoad.command.config.name}) has been reloaded`);
                                    else
                                        log.err("AUTO LOAD SCRIPTS", `Error when reload event ${filename}.js`, infoLoad.error);
                                }
                                catch (err) {
                                    log.err("AUTO LOAD SCRIPTS", `Error when reload event ${filename}.js`, err);
                                }
                            }
                        }
                    });
            }
            // ——————————————————— DASHBOARD ——————————————————— //
            if (global.YamiBot.config.dashBoard?.enable == true && dashBoardIsRunning == false) {
                logColor('#f5ab00', createLine('DASHBOARD'));
                try {
                    await require("../../dashboard/app.js")(api, mqtt);
                    log.info("DASHBOARD", getText('login', 'openDashboardSuccess'));
                    dashBoardIsRunning = true;
                }
                catch (err) {
                    log.err("DASHBOARD", getText('login', 'openDashboardError'), err);
                }
            }
            // ———————————————————— ADMIN BOT ———————————————————— //
            logColor('#f5ab00', character);
            let i = 0;
            const adminBot = global.YamiBot.config.adminBot
            .filter(item => !isNaN(item))
            .map(item => item = item.toString());
            for (const uid of adminBot) {
                try {
                    const userName = await usersData.getName(uid);
                    log.master("ADMINBOT", `[${++i}] ${uid} | ${userName}`);
                }
                catch (e) {
                    log.master("ADMINBOT", `[${++i}] ${uid}`);
                }
            }
            log.master("NOTIFICATION", ("Respect khang bro (:" || "").trim());
            log.master("SUCCESS", getText('login', 'runBot'));
            log.master("LOAD TIME", `${convertTime(Date.now() - global.YamiBot.startTime)}`);
            logColor("#f5ab00", createLine("COPYRIGHT"));
            // —————————————————— COPYRIGHT INFO —————————————————— //
            console.log(`\x1b[1m\x1b[33m${("COPYRIGHT:")}\x1b[0m\x1b[1m\x1b[37m \x1b[0m\x1b[1m\x1b[36m${("Project YamiBot based on goat bot v2 created by ntkhang03 (https://github.com/ntkhang03) <3")}\x1b[0m`);
            logColor("#f5ab00", character);
            global.YamiBot.config.adminBot = adminBot;
            writeFileSync(global.client.dirConfig, JSON.stringify(global.YamiBot.config, null, 2));
            writeFileSync(global.client.dirConfigCommands, JSON.stringify(global.YamiBot.configCommands, null, 2));

            // ——————————————————————————————————————————————————— //
            const {
                restartListenMqtt
            } = global.YamiBot.config;
            let intervalCheckLiveCookieAndRelogin = false;
            // —————————————————— CALLBACK LISTEN —————————————————— //
            async function callBackListen(error, event) {
                if (error) {
                    // ------------------ FB SCRAP NOTIFICATION HANDLING ------------------ //
                    const {
                        status
                    } = await check_live_appstate(appState, true);
                    if (!status) log.warn("BOT", "Looks like it's not fb scrap warn.");
                    if (status) {
                        log.error("DETECTED", "Facebook Scrap Warning.");

                        await sleep(1000);
                        await api.byPassScrap();

                        async function restartListener() {
                            try {
                                await stopListening();
                                await sleep(1000);

                                global.YamiBot.Listening = api.listenMqtt(createCallBackListen());
                                log.info("LISTEN_MQTT", getText("login", "restartListenMessage2"));
                            } catch (error) {
                                log.err("LISTEN_MQTT", getText("login", "restartListenMessageError"), error);
                            }
                        }

                        await restartListener();
                    } else if (
                        error.error == "Not logged in" ||
                        error.error == "Not logged in." ||
                        error.error == "Connection refused: Server unavailable"
                    ) {
                        log.err("NOT LOGGEG IN", getText('login', 'notLoggedIn'), error);
                        global.statusAccountBot = 'can\'t login';
                        if (!isSendNotiErrorMessage) {
                            await handlerWhenListenHasError({
                                api, threadModel, userModel, dashBoardModel, globalModel, threadsData, usersData, dashBoardData, globalData, error
                            });
                            isSendNotiErrorMessage = true;
                        }

                        if (global.YamiBot.config.autoRestartWhenListenMqttError)
                            process.exit(2);
                        else {
                            const keyListen = Object.keys(callbackListenTime).pop();
                            if (callbackListenTime[keyListen])
                                callbackListenTime[keyListen] = () => {};
                            const cookieString = appState.map(i => i.key + "=" + i.value).join("; ");
                            let times = 5;
                            const countTimes = setInterval(() => {
                                times--;
                                if (times == 0)
                                    times = 5;
                            },
                                1000);
                        }
                        return;
                    } else if (error == "Connection closed." || error == "Connection closed by user.") /* by stopListening; */ {
                        return;
                    } else {
                        await handlerWhenListenHasError({
                            api, threadModel, userModel, dashBoardModel, globalModel, threadsData, usersData, dashBoardData, globalData, error
                        });
                        return log.err("LISTEN_MQTT", getText('login', 'callBackError'), error);
                    }
                }
                global.statusAccountBot = 'good';
                const configLog = global.YamiBot.config.logEvents;
                if (isSendNotiErrorMessage == true)
                    isSendNotiErrorMessage = false;
                // check if listenMqtt loop
                if (event?.messageID && event.type == "message") {
                    if (storage5Message.includes(event.messageID))
                        Object.keys(callbackListenTime).slice(0, -1).forEach(key => {
                        callbackListenTime[key] = () => {};
                    });
                    else
                        storage5Message.push(event.messageID);
                    if (storage5Message.length > 5)
                        storage5Message.shift();
                }

                if (configLog.disableAll === false && configLog[event.type] !== false) {
                    const participantIDs_ = [...event.participantIDs || []];
                    if (event.participantIDs)
                        event.participantIDs = 'Array(' + event.participantIDs.length + ')';

                    console.log(colors.green((event.type || "").toUpperCase() + ":"), jsonStringifyColor(event, null, 2));

                    if (event.participantIDs)
                        event.participantIDs = participantIDs_;
                }

                const handlerAction = require("../handler/handlerAction.js")(api, threadModel, userModel, dashBoardModel, globalModel, usersData, threadsData, dashBoardData, globalData, mqtt);

                //add gban here also
                handlerAction(event);
            }
            // ————————————————— CREATE CALLBACK ————————————————— //
            function createCallBackListen(key) {
                key = randomString(10) + (key || Date.now());
                callbackListenTime[key] = callBackListen;
                return function (error, event) {
                    callbackListenTime[key](error, event);
                };
            }
            // ———————————————————— START BOT ———————————————————— //
            await stopListening();
            global.YamiBot.Listening = api.listenMqtt(createCallBackListen());
            global.YamiBot.callBackListen = callBackListen;

            // ———————————————————— RESTART LISTEN ———————————————————— //
            if (restartListenMqtt.enable == true) {
                if (restartListenMqtt.logNoti == true) {
                    log.info("LISTEN_MQTT", getText('login', 'restartListenMessage', convertTime(restartListenMqtt.timeRestart, true)));
                    log.info("BOT_STARTED", getText('login', 'startBotSuccess'));

                    logColor("#f5ab00", character);
                }
                const restart = setInterval(async function () {
                    if (restartListenMqtt.enable == false) {
                        clearInterval(restart);
                        return log.warn("LISTEN_MQTT", getText('login', 'stopRestartListenMessage'));
                    }
                    try {
                        await stopListening();
                        await sleep(1000);
                        global.YamiBot.Listening = api.listenMqtt(createCallBackListen());
                        log.info("LISTEN_MQTT", getText('login', 'restartListenMessage2'));
                    }
                    catch (e) {
                        log.err("LISTEN_MQTT", getText('login', 'restartListenMessageError'), e);
                    }
                },
                    restartListenMqtt.timeRestart);
                global.intervalRestartListenMqtt = restart;
            }
        });
    })(appState);

    if (global.YamiBot.config.autoReloginWhenChangeAccount) {
        setTimeout(function () {
            watch(dirAccount, async (type) => {
                if (type == 'change' && changeFbStateByCode == false && latestChangeContentAccount != fs.statSync(dirAccount).mtimeMs) {
                    clearInterval(global.intervalRestartListenMqtt);
                    global.compulsoryStopLisening = true;
                    latestChangeContentAccount = fs.statSync(dirAccount).mtimeMs;
                    startBot();
                }
            });
        }, 10000);
    }
}

global.YamiBot.reLoginBot = startBot;
startBot();
