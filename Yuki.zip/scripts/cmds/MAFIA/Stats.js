const Config = require('./Config');
const Database = require('./Database');
const Variables = require('./Variables');

async function showLeaderboard(mqtt, threadID, usersData) {
  const leaderboard = Variables.getLeaderboard();
  
  if (!leaderboard || leaderboard.length === 0) {
    return mqtt.sendMessage("❈ لا توجد إحصائيات. إلعبو لتكونو أول من يتصدر القائمة 🕴️.", threadID);
  }
  
  let msg = `🏆 | الأفضل حاليا:
____________________________________

`;
  const medals = ["🥇", "🥈", "🥉"];
  for (let i = 0; i < Math.min(leaderboard.length, 10); i++) {
    const entry = leaderboard[i];
    const name = await usersData.getName(entry.userID);
    const medal = medals[i] || `${i + 1}`;
    msg += `${medal} ${name}\n`;
    msg += `  ❆ نقاط: ${entry.score} | ⍟ فوز: ${entry.wins} | 📈 ${entry.winRate}%\n`;
  }
  msg += `____________________________\n- لا تلعب كال🫏 اذا أردت إسمك هنا.`;
  await mqtt.sendMessage(msg, threadID);
}

async function showPlayerStats(mqtt, userID, threadID, usersData) {
  const stats = Database.getPlayerStats(userID);
  const name = await usersData.getName(userID);
  
  let msg = `📊 إحصائيات ${name} 📊
____________________________

🎮 الألعاب: ${stats.gamesPlayed}
🏆 انتصارات: ${stats.wins} 🔥
💔 هزائم: ${stats.losses}
📈 نسبة فوز: ${stats.winRate}% ${stats.winRate >= 50 ? "🌟" : ""}
💪 نسبة نجاة: ${stats.survivalRate}% ${stats.survivalRate >= 60 ? "🛡️" : ""}
🔪 قتلى: ${stats.kills}
✅ تصويت صحيح: ${stats.correctVotes}
❌ تصويت خاطئ: ${stats.wrongVotes}
✨ قدرات ناجحة: ${stats.successfulSkills}
💥 قدرات فاشلة: ${stats.failedSkills}
😈 قتل زملاء: ${stats.teamKills}
💰 المال: ${stats.money.toLocaleString()}
⭐ النقاط: ${stats.points.toLocaleString()}
`;
  
  const leaderboard = Variables.getLeaderboard();
  const rank = leaderboard.findIndex(e => e.userID === userID) + 1;
  
  if (rank > 0) {
    msg += `\n🏅 ترتيبك: #${rank}`;
    if (rank <= 3) {
      msg += ` ${rank === 1 ? "👑" : rank === 2 ? "🥈" : "🥉"}`;
    }
  } else {
    msg += `\n📍 ترتيبك: غير مصنف بعد`;
  }
  
  const skillRatio = stats.successfulSkills + stats.failedSkills > 0 
    ? ((stats.successfulSkills / (stats.successfulSkills + stats.failedSkills)) * 100).toFixed(1)
    : 0;
  
  msg += `\n🎯 نسبة نجاح القدرات: ${skillRatio}%`;
  msg += `\n____________________________\n`;
  
  if (stats.teamKills > 5) {
    msg += `⚠️ كثرة قتل الزملاء! انتبه لأفعالك 😠`;
  } else if (stats.wrongVotes > stats.correctVotes && stats.wrongVotes > 6) {
    msg += `📊 تصويتك يحتاج تحسين! فكر قبل التصويت 🤔`;
  } else if (stats.winRate >= 60) {
    msg += `🌟 لاعب محترف! استمر بهذا المستوى 💪`;
  } else {
    msg += `💡 استمر باللعب لتحسين إحصائياتك! 🎮`;
  }
  
  await mqtt.sendMessage(msg, threadID);
}

async function showTopKillers(mqtt, threadID, usersData, limit = 5) {
  const allStats = Database.getAllPlayerStats();
  const entries = Object.entries(allStats)
    .map(([id, stats]) => ({ userID: id, kills: stats.kills }))
    .sort((a, b) => b.kills - a.kills)
    .slice(0, limit);
  
  if (entries.length === 0) {
    return mqtt.sendMessage("❌ لا توجد إحصائيات قتل بعد!", threadID);
  }
  
  let msg = `🔪 أكثر القتلة دموية 🔪
____________________________

`;
  
  for (let i = 0; i < entries.length; i++) {
    const name = await usersData.getName(entries[i].userID);
    msg += `${i + 1}. ${name} - ${entries[i].kills} قتلى 💀\n`;
  }
  
  msg += `\n____________________________\n💡 القتل ليس كل شيء!`;
  await mqtt.sendMessage(msg, threadID);
}

async function showWinRates(mqtt, threadID, usersData, limit = 5) {
  const allStats = Database.getAllPlayerStats();
  const entries = Object.entries(allStats)
    .filter(([id, stats]) => stats.gamesPlayed >= 3)
    .map(([id, stats]) => ({ 
      userID: id, 
      winRate: parseFloat(stats.winRate) || 0,
      wins: stats.wins,
      games: stats.gamesPlayed
    }))
    .sort((a, b) => b.winRate - a.winRate)
    .slice(0, limit);
  
  if (entries.length === 0) {
    return mqtt.sendMessage("❌ لا توجد إحصائيات كافية بعد! (يتطلب 3 ألعاب على الأقل)", threadID);
  }
  
  let msg = `📊 أعلى نسب الفوز 📊
____________________________

`;
  
  for (let i = 0; i < entries.length; i++) {
    const name = await usersData.getName(entries[i].userID);
    msg += `${i + 1}. ${name}\n`;
    msg += `   📈 ${entries[i].winRate}% (${entries[i].wins}/${entries[i].games})\n`;
  }
  
  msg += `\n____________________________\n⭐ الفوز يحتاج استراتيجية!`;
  await mqtt.sendMessage(msg, threadID);
}

async function showPersonalBests(mqtt, userID, threadID, usersData) {
  const stats = Database.getPlayerStats(userID);
  const name = await usersData.getName(userID);
  
  let msg = `🏅 أفضل إنجازات ${name} 🏅
____________________________

💰 أغنى: ${stats.money.toLocaleString()} عملة
⭐ أكثر نقاط: ${stats.points.toLocaleString()}
🔪 أكثر قتل: ${stats.kills}
🏆 أكثر فوز: ${stats.wins}
✅ أفضل تصويت: ${stats.correctVotes}
✨ قدرات ناجحة: ${stats.successfulSkills}

____________________________

`;
  
  if (stats.gamesPlayed === 0) {
    msg += `📝 ابدأ اللعب لتسجيل إنجازاتك!`;
  } else {
    const avgKills = (stats.kills / stats.gamesPlayed).toFixed(2);
    const avgCorrectVotes = (stats.correctVotes / stats.gamesPlayed).toFixed(2);
    msg += `📊 المتوسطات:\n`;
    msg += `🔪 ${avgKills} قتل/لعبة\n`;
    msg += `✅ ${avgCorrectVotes} تصويت صحيح/لعبة\n`;
    msg += `\n💡 استمر بالتحسن!`;
  }
  
  await mqtt.sendMessage(msg, threadID);
}

async function compareStats(mqtt, userID1, userID2, threadID, usersData) {
  const stats1 = Database.getPlayerStats(userID1);
  const stats2 = Database.getPlayerStats(userID2);
  const name1 = await usersData.getName(userID1);
  const name2 = await usersData.getName(userID2);
  
  let msg = `⚔️ مقارنة الإحصائيات ⚔️
____________________________

👤 ${name1} vs ${name2}

🎮 ألعاب: ${stats1.gamesPlayed} vs ${stats2.gamesPlayed}
🏆 انتصارات: ${stats1.wins} vs ${stats2.wins}
📈 نسبة فوز: ${stats1.winRate}% vs ${stats2.winRate}%
🔪 قتلى: ${stats1.kills} vs ${stats2.kills}
✅ تصويت صحيح: ${stats1.correctVotes} vs ${stats2.correctVotes}
💰 مال: ${stats1.money.toLocaleString()} vs ${stats2.money.toLocaleString()}

____________________________

`;
  
  const score1 = Variables.calculatePlayerScore(stats1);
  const score2 = Variables.calculatePlayerScore(stats2);
  
  if (score1 > score2) {
    msg += `🏆 الفائز: ${name1} (${score1} نقاط)`;
  } else if (score2 > score1) {
    msg += `🏆 الفائز: ${name2} (${score2} نقاط)`;
  } else {
    msg += `🤝 تعادل! (${score1} نقاط لكل منهما)`;
  }
  
  await mqtt.sendMessage(msg, threadID);
}

async function showRoleStats(mqtt, userID, threadID, usersData) {
  const name = await usersData.getName(userID);
  
  let msg = `🎭 إحصائيات الأدوار - ${name} 🎭
____________________________

⚠️ ميزة قريباً!

ستتمكن قريباً من رؤية:
• أكثر الأدوار لعباً
• أفضل أداء بكل دور
• نسب الفوز لكل دور
• الأدوار المفضلة

____________________________

💡 استمر باللعب!`;
  
  await mqtt.sendMessage(msg, threadID);
}

async function resetStats(mqtt, userID, threadID, usersData) {
  Database.resetPlayerStats(userID);
  const name = await usersData.getName(userID);
  
  await mqtt.sendMessage(
    `🔄 تم إعادة تعيين إحصائيات ${name}!\n\n⚠️ تم حذف جميع الإحصائيات\n💰 تم الحفاظ على المال والنقاط\n\n✨ ابدأ من جديد!`,
    threadID
  );
}

module.exports = {
  showLeaderboard,
  showPlayerStats,
  showTopKillers,
  showWinRates,
  showPersonalBests,
  compareStats,
  showRoleStats,
  resetStats
};
