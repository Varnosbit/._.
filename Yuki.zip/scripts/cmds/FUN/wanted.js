const fs = require("fs");
const { loadImage, registerFont, createCanvas } = require("canvas");

const BACKGROUND_URL = "https://i.pinimg.com/736x/7a/78/0a/7a780a67357b32676db02b15d15b9b31.jpg";
const NUMBERS_FONT_PATH = process.cwd() + "/scripts/cmds/canvas/fonts/wantedNums.ttf";
const NAME_FONT_PATH = process.cwd() + "/scripts/cmds/canvas/fonts/wanted.ttf";

function resolveFont(fontPath, familyName, nativeFallback) {
 if (fs.existsSync(fontPath)) {
 registerFont(fontPath, { family: familyName });
 return `"${familyName}"`;
 }
 return nativeFallback;
}

const NAME_FONT_FALLBACK = `"Georgia", "Times New Roman", "Palatino Linotype", "Book Antiqua", serif`;
const PRICE_FONT_FALLBACK = `"Arial Black", "Impact", "Trebuchet MS", "Verdana", sans-serif`;

const nameFontFamily = resolveFont(NAME_FONT_PATH, "WantedName", NAME_FONT_FALLBACK);
const priceFontFamily = resolveFont(NUMBERS_FONT_PATH, "WantedNums", PRICE_FONT_FALLBACK);

exports.config = {
 name: "wanted",
 aliases: ["مطلوب"],
 by: "Allou Mohamed",
 description: {
 en: "One Piece wanted poster",
 ar: "وان بيس وانتد 🗿🔥"
 },
 version: "1.0.0",
 role: 0,
 countDown: 20,
 guide: "{pn}"
};

exports.onStart = async ({ message, event, args, usersData }) => {
 const argText = args.join(" ");

 let bountyString = null;

 const bountyParamMatch = argText.match(/--(?:bounty|bt)\s+([0-9]+)/i);
 if (bountyParamMatch) {
 bountyString = bountyParamMatch[1];
 } else if (args.length > 0 && /^\d+$/.test(args[0])) {
 bountyString = args[0];
 }

 if (bountyString) {
 bountyString = Number(bountyString.slice(0, 10));
 }

 const idParamMatch = argText.match(/--id\s+<@!?(\d+)>/i);
 const targetId =
 idParamMatch?.[1] ||
 Object.keys(event?.mentions || {})[0] ||
 event.messageReply?.senderID ||
 event.senderID;

 const nameParamMatch = argText.match(/--name\s+(.+?)(?=\s--|$)/i);
 let rawName = nameParamMatch ? nameParamMatch[1].trim() : null;

 if (!rawName) {
 try {
 rawName = await usersData.getName(targetId);
 } catch {
 rawName = null;
 }
 }

 let displayName = "CRIMINAL";

 if (typeof rawName === "string") {
 const parts = rawName.split(/\s+/).filter(Boolean);
 if (parts.length === 1) {
 displayName = parts[0];
 } else if (parts.length > 1) {
 displayName =
 parts[0].length >= parts[1].length ? parts[0] : parts[1];
 }
 }

 const useReplyImage = argText.includes("--imgfromreply") || argText.includes("--rpimg");
 const imageUrl = useReplyImage
 ? event.messageReply?.attachments?.[0]?.url
 : await usersData.getAvatarUrl(targetId);

 if (!bountyString) {
 const digitCount = Math.random() < 0.5 ? 9 : 10;
 let generated = "";
 for (let i = 0; i < digitCount; i++) {
 generated += Math.floor(Math.random() * 10);
 }
 bountyString = Number(generated);
 }

 await renderWantedPoster(
 imageUrl,
 displayName,
 bountyString,
 message
 );
};

async function renderWantedPoster(avatarUrl, displayName, bounty, message) {
 const backgroundImage = await loadImage(BACKGROUND_URL);
 const { width, height } = backgroundImage;

 const canvas = createCanvas(width, height);
 const ctx = canvas.getContext("2d");

 ctx.drawImage(backgroundImage, 0, 0, width, height);

 const avatarImage = await loadImage(avatarUrl);

 const targetWidth = width / 1.21;
 const targetHeight = height / 2.34;
 const targetRatio = targetWidth / targetHeight;

 let sourceWidth = avatarImage.width;
 let sourceHeight = avatarImage.height;
 let sourceX = 0;
 let sourceY = 0;

 const sourceRatio = sourceWidth / sourceHeight;

 if (sourceRatio > targetRatio) {
 sourceWidth = sourceHeight * targetRatio;
 sourceX = (avatarImage.width - sourceWidth) / 2;
 } else {
 sourceHeight = sourceWidth / targetRatio;
 sourceY = (avatarImage.height - sourceHeight) / 2;
 }

 const imageX = (width - targetWidth) / 2 - 5;
 const imageY = 226;

 ctx.drawImage(
 avatarImage,
 sourceX,
 sourceY,
 sourceWidth,
 sourceHeight,
 imageX,
 imageY,
 targetWidth,
 targetHeight
 );

 ctx.fillStyle = "#3F2D29";
 ctx.textAlign = "center";
 ctx.textBaseline = "middle";

 const nameY = height - 260;
 const maxTextWidth = width - 150;
 const maxFontSize = 110;

 let nameFontSize = maxFontSize;
 ctx.font = `bold ${nameFontSize}px ${nameFontFamily}`;

 const measuredWidth = ctx.measureText(displayName).width;
 nameFontSize = Math.min(
 Math.floor(nameFontSize * (maxTextWidth / measuredWidth)),
 maxFontSize
 );

 ctx.font = `bold ${nameFontSize}px ${nameFontFamily}`;
 ctx.fillText(displayName, width / 2 - 15, nameY);

 ctx.font = `64px ${priceFontFamily}`;
 ctx.fillText(bounty.toLocaleString(), width / 2 - 5, nameY + 118);

 message.canvas(canvas);
}