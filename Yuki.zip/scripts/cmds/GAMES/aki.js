const cloudscraper = require('cloudscraper');

// Configure cloudscraper with proper defaults
const scraper = cloudscraper.defaults({
 agentOptions: {
 ciphers: 'ECDHE-ECDSA-AES128-GCM-SHA256'
 },
 cloudflareTimeout: 6000, // Respect Cloudflare's 5-6 second timeout
 cloudflareMaxTimeout: 30000
});

// Intelligent retry function with exponential backoff
async function retryRequest(requestFunc, maxRetries = 5, baseDelay = 2000) {
 let lastError;
 
 for (let attempt = 1; attempt <= maxRetries; attempt++) {
 try {
 const result = await requestFunc();
 return result;
 } catch (error) {
 lastError = error;
 
 // Check error type
 const errorType = error.errorType || 0;
 
 // Don't retry on CAPTCHA (errorType 1) or fatal errors
 if (errorType === 1) {
 throw new Error('Cloudflare returned CAPTCHA. Cannot proceed.');
 }
 
 // If it's the last attempt, throw the error
 if (attempt === maxRetries) {
 throw error;
 }
 
 // Calculate delay with exponential backoff and jitter
 const exponentialDelay = baseDelay * Math.pow(2, attempt - 1);
 const jitter = Math.random() * 1000; // Add random jitter up to 1 second
 const delay = Math.min(exponentialDelay + jitter, 30000); // Cap at 30 seconds
 
 console.log(`Request failed (attempt ${attempt}/${maxRetries}). Retrying in ${Math.round(delay)}ms...`);
 console.log(`Error: ${error.message || error}`);
 
 // Wait before retrying
 await new Promise(resolve => setTimeout(resolve, delay));
 }
 }
 
 throw lastError;
}

async function NewGame() {
 return retryRequest(async () => {
 const html = await scraper.post({
 uri: 'https://ar.akinator.com/game',
 formData: {
 cm: 'false',
 sid: '1'
 },
 headers: {
 "Referer": "https://ar.akinator.com/",
 "Origin": "https://ar.akinator.com"
 }
 });

 // Parse the HTML response
 const questionMatch = html.match(/<p class="question-text" id="question-label">(.+)<\/p>/);
 const sessionMatch = html.match(/session: '(.+)'/);
 const signatureMatch = html.match(/signature: '(.+)'/);

 if (!questionMatch || !sessionMatch || !signatureMatch) {
 throw new Error('Failed to parse game initialization response');
 }

 return {
 question: questionMatch[1],
 si: sessionMatch[1],
 co: signatureMatch[1],
 progression: "0.0000",
 step: "0"
 };
 }, 5, 3000); // 5 retries with 3 second base delay
}

async function NextGame(si, co, answer, progression, step) {
 return retryRequest(async () => {
 const response = await scraper.post({
 uri: 'https://ar.akinator.com/answer',
 formData: {
 step: step,
 progression: progression,
 sid: 'NaN',
 cm: 'false',
 answer: answer,
 step_last_proposition: '',
 session: si,
 signature: co
 },
 headers: {
 "Referer": "https://ar.akinator.com/",
 "Origin": "https://ar.akinator.com"
 },
 json: true
 });

 if (!response) {
 throw new Error('Empty response from server');
 }

 response.akitude = "https://ar.akinator.com/assets/img/akitudes_670x1096/" + response.akitude;
 return response;
 }, 5, 2000); // 5 retries with 2 second base delay
}

async function BackGame(si, co, progression, step) {
 return retryRequest(async () => {
 const response = await scraper.post({
 uri: 'https://ar.akinator.com/cancel_answer',
 formData: {
 step: step,
 progression: progression,
 sid: 'NaN',
 cm: 'false',
 session: si,
 signature: co
 },
 headers: {
 "Referer": "https://ar.akinator.com/",
 "Origin": "https://ar.akinator.com"
 },
 json: true
 });

 if (!response) {
 throw new Error('Empty response from server');
 }

 response.akitude = "https://ar.akinator.com/assets/img/akitudes_670x1096/" + response.akitude;
 return response;
 }, 5, 2000); // 5 retries with 2 second base delay
}

module.exports = {
 config: {
 name: "اكيناتور",
 aliases: ["المارد", "aki"],
 version: "2.0",
 author: "عمر",
 role: 0,
 countDown: 5,
 description: "حزر الشخص الذي في بالك",
 category: "ثريدز",
 },

 onStart: async function ({ event, api, args, message, commandName }) {
 try {
 // Add initial delay to seem more human
 await new Promise(resolve => setTimeout(resolve, 1000));
 
 const GenGame = await NewGame();
 
 const message_ = GenGame.question;
 return message.reply({ 
 body: `${message_} 👀\n\nالرجاء الرد ب\n\nنعم | لا | لا اعلم | من الممكن | الضاهر لا | رجوع` 
 }, (error, info) => {
 global.GoatBot.onReply.set(info.messageID, {
 commandName,
 author: event.senderID,
 messageID: info.messageID,
 progression: GenGame.progression,
 si: GenGame.si,
 co: GenGame.co,
 step: GenGame.step,
 retryCount: 0
 });
 });
 } catch (error) {
 console.error('Error in onStart:', error);
 return message.reply("⚠️ حدث خطأ أثناء بدء اللعبة. قد يكون الموقع محمي بشدة الآن.\n\nالرجاء المحاولة مرة أخرى بعد دقيقة.");
 }
 },

 onReply: async function ({ api, event, Reply, message, commandName }) {
 const { author, messageID, progression, si, co, step, retryCount = 0 } = Reply;
 if (event.senderID != author) return;
 
 let answer;
 switch (event.body) {
 case "نعم":
 answer = "0";
 break;
 case "لا":
 answer = "1";
 break;
 case "لا اعلم":
 answer = "2";
 break;
 case "من الممكن":
 answer = "3";
 break;
 case "الضاهر لا":
 answer = "4";
 break;
 case "رجوع":
 answer = "e";
 break;
 default:
 return message.reply("الرجاء الرد ب\n\nنعم | لا | لا اعلم | رجوع | من الممكن | الضاهر لا | رجوع");
 }

 try {
 // Add small random delay to appear more human
 const humanDelay = 500 + Math.random() * 1500; // 0.5-2 seconds
 await new Promise(resolve => setTimeout(resolve, humanDelay));
 
 let result;
 if (answer == "e") {
 result = await BackGame(si, co, progression, step);
 } else {
 result = await NextGame(si, co, answer, progression, step);
 }

 if (result?.name_proposition) {
 const name = result.name_proposition;
 const des = result.description_proposition;
 const imged = await utils.getStreamFromUrl(result.photo);
 return message.reply({
 body: `🪄|إســـم الشـخصـية: ❨${name}❩\n⌯↢نبــــذة عنها:${des}`,
 attachment: imged
 });
 }
 
 const replymessage = result.question;

 return message.reply({ 
 body: `${replymessage} 🚶\n\nالرجاء الرد ب\n\nنعم | لا | لا اعلم | من الممكن | الضاهر لا | رجوع` 
 }, (error, info) => {
 global.GoatBot.onReply.set(info.messageID, {
 commandName,
 author: event.senderID,
 messageID: info.messageID,
 progression: result.progression,
 si: si,
 co: co,
 step: result.step,
 retryCount: 0
 });
 });
 } catch (error) {
 console.error('Error in onReply:', error);
 
 // Track retry count
 const newRetryCount = retryCount + 1;
 
 if (newRetryCount >= 3) {
 return message.reply("⚠️ تعذر الاتصال باللعبة بعد عدة محاولات.\n\nالرجاء بدء لعبة جديدة.");
 }
 
 return message.reply("⚠️ حدث خطأ مؤقت. الرجاء إعادة المحاولة بنفس الإجابة.");
 }
 },
};