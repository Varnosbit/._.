const Config = require('./Config');
const Database = require('./Database');
const Utils = require('./Utils');

async function showShop(mqtt, userID, threadID, usersData, commandName) {
  const stats = Database.getPlayerStats(userID);
  const purchases = Database.getPlayerPurchases(userID);
  
  let msg = `🛒 المتجر - قدرات خاصة 🛒
____________________________

💰 رصيدك: ${stats.money.toLocaleString()} 
⭐ نقاطك: ${stats.points.toLocaleString()}

🎁 المنتجات المتاحة:
____________________________

`;
  
  let index = 1;
  for (const [key, item] of Object.entries(Config.SHOP_ITEMS)) {
    msg += `${index}. ${item.emoji} ${item.name}\n`;
    msg += `   📝 ${item.desc}\n`;
    msg += `   💵 السعر: ${item.price.toLocaleString()} 💰\n`;
    if (purchases[key] && purchases[key].count > 0) {
      msg += `   ✅ لديك: ${purchases[key].count}\n`;
    }
    msg += `\n`;
    index++;
  }
  
  msg += `____________________________

💱 سعر الصرف: ${Config.exchangeRate} نقطة = 1 💰

📌 للشراء: رد برقم المنتج
📦 للمخزون: اكتب "مخزوني"
💸 للصرف: اكتب "صرف + عدد النقاط"

مثال: صرف 1000`;
  
  const { messageID } = await mqtt.sendMessage(msg, threadID);
  global.YamiBot.onReply.set(messageID, {
    commandName: commandName,
    type: "shop_menu",
    userID: userID
  });
}

async function handleShopPurchase(Reply, event, mqtt, usersData) {
  const userID = Reply.userID;
  const input = event.body.trim();
  
  if (input === "مخزوني" || input === "المخزون" || input.toLowerCase() === "inventory") {
    return showInventory(mqtt, userID, event.threadID, usersData, Reply.commandName);
  }
  
  if (input.startsWith("بيع ") || input.toLowerCase().startsWith("sell ")) {
    const parts = input.split(" ");
    const itemNum = parseInt(parts[1]);
    return handleSell(mqtt, userID, event.threadID, itemNum, usersData);
  }
  
  if (input.startsWith("صرف ") || input.toLowerCase().startsWith("exchange ")) {
    const parts = input.split(" ");
    const points = parseInt(parts[1]);
    return handleExchange(mqtt, userID, event.threadID, points, usersData);
  }
  
  const itemIndex = parseInt(input) - 1;
  if (isNaN(itemIndex)) return;
  const items = Object.keys(Config.SHOP_ITEMS);
  
  if (itemIndex < 0 || itemIndex >= items.length) {
    return mqtt.sendMessage("❌ رقم خاطئ! استخدم الأرقام من القائمة 🔢", event.threadID);
  }
  
  const itemKey = items[itemIndex];
  const item = Config.SHOP_ITEMS[itemKey];
  const stats = Database.getPlayerStats(userID);
  
  if (stats.money < item.price) {
    return mqtt.sendMessage(
      `💸 رصيدك غير كافٍ!\n\n💵 السعر: ${item.price.toLocaleString()} 💰\n💰 رصيدك: ${stats.money.toLocaleString()} 💰\n\n💡 اربح المزيد من الألعاب أو اصرف نقاطك!`, 
      event.threadID
    );
  }
  
  if (!Database.deductMoney(userID, item.price)) {
    return mqtt.sendMessage("❌ فشلت عملية الشراء! حاول مرة أخرى", event.threadID);
  }
  
  Database.addPurchaseToInventory(userID, itemKey);
  const newBalance = Database.getPlayerStats(userID).money;
  
  await mqtt.sendMessage(
    `✅ تم الشراء بنجاح! 🎉\n\n${item.emoji} ${item.name}\n\n💸 دفعت: ${item.price.toLocaleString()} 💰\n💰 الرصيد المتبقي: ${newBalance.toLocaleString()} 💰\n\n📦 تحقق من مخزونك: اكتب "مخزوني"`, 
    event.threadID
  );
}

async function showInventory(mqtt, userID, threadID, usersData, commandName) {
  const purchases = Database.getPlayerPurchases(userID);
  const stats = Database.getPlayerStats(userID);
  
  let msg = `📦 مخزونك 📦
____________________________

💰 رصيدك: ${stats.money.toLocaleString()}
⭐ نقاطك: ${stats.points.toLocaleString()}

🎁 المشتريات:
____________________________

`;
  
  const items = Object.entries(purchases).filter(([key, data]) => data.count > 0);
  
  if (items.length === 0) {
    msg += `❌ لا توجد مشتريات بعد!\n\n💡 زر المتجر لشراء قدرات خاصة 🛒`;
  } else {
    let index = 1;
    for (const [key, data] of items) {
      const item = Config.SHOP_ITEMS[key];
      msg += `${index}. ${item.emoji} ${item.name}\n`;
      msg += `   📊 العدد: ${data.count}\n`;
      msg += `   💵 قيمة البيع: ${Math.floor(item.price * 0.7).toLocaleString()} 💰\n\n`;
      index++;
    }
    msg += `____________________________\n\n📌 للبيع: بيع + رقم\n   مثال: بيع 1`;
  }
  
  msg += `\n\n💱 للصرف: صرف + عدد النقاط\n   مثال: صرف 1000\n\n💡 سعر الصرف: ${Config.exchangeRate} نقطة = 1 💰`;
  
  const { messageID } = await mqtt.sendMessage(msg, threadID);
  global.YamiBot.onReply.set(messageID, {
    commandName: commandName,
    type: "shop_menu",
    userID: userID
  });
}

async function handleSell(mqtt, userID, threadID, itemNum, usersData) {
  const purchases = Database.getPlayerPurchases(userID);
  const items = Object.entries(purchases).filter(([key, data]) => data.count > 0);
  
  if (itemNum < 1 || itemNum > items.length) {
    return mqtt.sendMessage("❌ رقم خاطئ! حاول مرة أخرى 🔢", threadID);
  }
  
  const [itemKey, data] = items[itemNum - 1];
  const item = Config.SHOP_ITEMS[itemKey];
  const sellPrice = Math.floor(item.price * 0.7);
  
  if (!Database.removePurchaseFromInventory(userID, itemKey)) {
    return mqtt.sendMessage("❌ فشل البيع! حاول مرة أخرى", threadID);
  }
  
  const newBalance = Database.addMoney(userID, sellPrice);
  
  await mqtt.sendMessage(
    `✅ تم البيع بنجاح! 💸\n\n${item.emoji} ${item.name}\n\n💰 حصلت على: ${sellPrice.toLocaleString()} 💰\n💵 الرصيد الحالي: ${newBalance.toLocaleString()} 💰`,
    threadID
  );
}

async function handleExchange(mqtt, userID, threadID, points, usersData) {
  if (isNaN(points) || points < 1) {
    return mqtt.sendMessage("❌ عدد نقاط غير صحيح! أدخل رقماً صحيحاً 🔢", threadID);
  }
  
  const result = Database.exchangePoints(userID, points);
  
  if (!result.success) {
    if (result.reason === "insufficient_points") {
      const stats = Database.getPlayerStats(userID);
      return mqtt.sendMessage(
        `❌ ليس لديك نقاط كافية!\n\n⭐ نقاطك: ${stats.points.toLocaleString()}\n💡 احتجت: ${points.toLocaleString()}`, 
        threadID
      );
    } else if (result.reason === "below_minimum") {
      const stats = Database.getPlayerStats(userID);
      return mqtt.sendMessage(
        `❌ تحتاج ${Config.exchangeRate} نقطة على الأقل للصرف!\n\n⭐ نقاطك: ${stats.points.toLocaleString()}`, 
        threadID
      );
    }
  }
  
  await mqtt.sendMessage(
    `✅ تم الصرف بنجاح! 💱\n\n⭐ صرفت: ${result.pointsUsed.toLocaleString()} نقطة\n💰 حصلت على: ${result.money.toLocaleString()} 💰\n\n____________________________\n⭐ النقاط المتبقية: ${result.remainingPoints.toLocaleString()}\n💵 الرصيد الحالي: ${result.remainingMoney.toLocaleString()} 💰`,
    threadID
  );
}

async function handleShopItemUse(player, input, mqtt, game, usersData) {
  const parts = input.toLowerCase().split(" ");
  if (parts.length < 2) {
    return Utils.sendToPlayerOrRoom(mqtt, player, 
      "❌ استخدم: استخدام + نوع القدرة\n____________________________\n🛡️ حماية\n🔍 تحقيق\n👥 كشف"
    );
  }
  
  const itemType = parts[1];
  
  if (itemType === "حماية" || itemType === "protection") {
    if (!Database.hasPurchase(player.userID, "protection")) {
      return Utils.sendToPlayerOrRoom(mqtt, player, 
        "❌ ليس لديك هذه القدرة! 😔\n____________________________\n💡 اشترها من المتجر أولاً 🛒"
      );
    }
    if (game.nightActions[player.userID] && game.nightActions[player.userID].type === "self_protect") {
      return Utils.sendToPlayerOrRoom(mqtt, player, "⚠️ استخدمت الحماية بالفعل الليلة! 🛡️");
    }
    Database.removePurchaseFromInventory(player.userID, "protection");
    game.nightActions[player.userID] = { type: "self_protect" };
    player.protected = true;
    return Utils.sendToPlayerOrRoom(mqtt, player, 
      `✅ تم استخدام الحماية! 🛡️\n____________________________\n💪 أنت محمي من القتل الليلة!\n✨ حماية مضمونة 100%`
    );
  } else if (itemType === "تحقيق" || itemType === "investigation") {
    if (!Database.hasPurchase(player.userID, "investigation")) {
      return Utils.sendToPlayerOrRoom(mqtt, player, 
        "❌ ليس لديك هذه القدرة! 😔\n____________________________\n💡 اشترها من المتجر أولاً 🛒"
      );
    }
    const playersList = await Utils.listPlayers(game, usersData, false);
    const msg = `🔍 اختر رقم اللاعب للتحقيق منه:\n____________________________\n${playersList}\n____________________________\n💡 سيتم الكشف عن دوره بدقة!`;
    const { messageID } = await Utils.sendToPlayerOrRoom(mqtt, player, msg);
    global.YamiBot.onReply.set(messageID, {
      commandName: game.commandName,
      gameID: game.id,
      playerID: player.userID,
      type: "shop_investigation"
    });
  } else if (itemType === "كشف" || itemType === "reveal") {
    if (!Database.hasPurchase(player.userID, "reveal_team")) {
      return Utils.sendToPlayerOrRoom(mqtt, player, 
        "❌ ليس لديك هذه القدرة! 😔\n____________________________\n💡 اشترها من المتجر أولاً 🛒"
      );
    }
    const playersList = await Utils.listPlayers(game, usersData, false);
    const msg = `👥 اختر رقم اللاعب لكشف فريقه:\n____________________________\n${playersList}\n____________________________\n💡 سيتم كشف فريقه فقط!`;
    const { messageID } = await Utils.sendToPlayerOrRoom(mqtt, player, msg);
    global.YamiBot.onReply.set(messageID, {
      commandName: game.commandName,
      gameID: game.id,
      playerID: player.userID,
      type: "shop_reveal_team"
    });
  } else {
    return Utils.sendToPlayerOrRoom(mqtt, player, 
      "❌ نوع قدرة غير معروف!\n____________________________\n🛡️ حماية\n🔍 تحقيق\n👥 كشف"
    );
  }
}

async function handleShopInvestigation(Reply, event, mqtt, usersData) {
  const Variables = require('./Variables');
  const game = Variables.getGame(Reply.gameID);
  if (!game) return;
  
  const player = game.players[Reply.playerID];
  if (!player || !player.alive) return;
  
  if (!Database.hasPurchase(player.userID, "investigation")) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ ليس لديك هذه القدرة! 😔");
  }
  
  const targetIndex = parseInt(event.body.trim());
  if (isNaN(targetIndex)) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ رد برقم صحيح! 🔢");
  }
  
  const target = Variables.getPlayerByIndex(game, targetIndex);
  if (!target) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ رقم خاطئ! 📋");
  }
  
  Database.removePurchaseFromInventory(player.userID, "investigation");
  const targetName = await usersData.getName(target.userID);
  const roleData = Config.ROLES[target.role];
  
  await Utils.sendToPlayerOrRoom(mqtt, player,
    `🔍 نتيجة التحقيق الخاص! 🔍\n____________________________\n\n👤 ${targetName}\n🎭 الدور: ${roleData.emoji} ${roleData.name}\n\n____________________________\n✅ تحقيق دقيق 100%!`
  );
}

async function handleShopRevealTeam(Reply, event, mqtt, usersData) {
  const Variables = require('./Variables');
  const game = Variables.getGame(Reply.gameID);
  if (!game) return;
  
  const player = game.players[Reply.playerID];
  if (!player || !player.alive) return;
  
  if (!Database.hasPurchase(player.userID, "reveal_team")) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ ليس لديك هذه القدرة! 😔");
  }
  
  const targetIndex = parseInt(event.body.trim());
  if (isNaN(targetIndex)) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ رد برقم صحيح! 🔢");
  }
  
  const target = Variables.getPlayerByIndex(game, targetIndex);
  if (!target) {
    return Utils.sendToPlayerOrRoom(mqtt, player, "❌ رقم خاطئ! 📋");
  }
  
  Database.removePurchaseFromInventory(player.userID, "reveal_team");
  const targetName = await usersData.getName(target.userID);
  const roleData = Config.ROLES[target.role];
  
  await Utils.sendToPlayerOrRoom(mqtt, player,
    `👥 نتيجة كشف الفريق! 👥\n____________________________\n\n👤 ${targetName}\n🎯 الفريق: ${Utils.getTeamName(roleData.team)}\n\n____________________________\n✅ معلومة مؤكدة!`
  );
}

module.exports = {
  showShop,
  handleShopPurchase,
  showInventory,
  handleSell,
  handleExchange,
  handleShopItemUse,
  handleShopInvestigation,
  handleShopRevealTeam
};
