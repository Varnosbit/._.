const { commands: cmds } = YukiBot;

exports.config = {
    name: "help",
    aliases: ["cmds"],
    role: 0,
    description: "Show list of available commands or detailed information about a specific command",
    guide: {
        syntax: "help [command_name]",
        params: "command_name",
        usage: "Optional"
    },
    countDown: 5,
    category: "Helper",
    hide: false,
    author: "Allou Mohamed",
    version: "2.0.0",
    price: "Free"
};

exports.onStart = async function({ message, role, args, event }) {
    const userInput = args.join(' ').trim();
    if (!userInput || !isNaN(parseInt(userInput))) {
        let helpList = `# %bd𝗖𝗼𝗺𝗺𝗮𝗻𝗱 𝗟𝗶𝘀𝘁%\n\n`;
        
        // Get all visible commands
        const allCommands = Array.from(cmds.values()).filter(cmd => !cmd.config.hide || role >= 2);
        
        // Group commands by category
        const categorizedCommands = {};
        
        allCommands.forEach(cmd => {
            const category = getCommandCategory(cmd);
            if (!categorizedCommands[category]) {
                categorizedCommands[category] = [];
            }
            categorizedCommands[category].push(cmd.config.name);
        });
        
        // Sort categories alphabetically
        const sortedCategories = Object.keys(categorizedCommands).sort();
        
        // Build the formatted list
        sortedCategories.forEach(category => {
            const commands = categorizedCommands[category].sort();
            const count = commands.length;
            
            helpList += `- %bd${category}% (${count})\n`;
            helpList += `${commands.join(', ')}\n\n`;
        });
        
        helpList += `Use %bd.help <command>% for more information.`;
        
        return message.reply(helpList);
    }
    
    // Show detailed command info
    let commandName = userInput.toLowerCase();
    let command = YukiBot.commands.get(commandName) || YukiBot.commands.get(YukiBot.aliases.get(commandName));
    
    if (!command) {
        return message.reply("I don't have this command.");
    }
    
    const {config} = command;
    const name = config.name || "Unnamed";
    const description = getCmdDesc(command);
    const cooldown = config.countDown || 0;
    const price = config.price || "Free";
    const guideInfo = getGuideInfo(command);
    const syntax = getSyntax(command);

    let Details = `# %bd𝗖𝗼𝗺𝗺𝗮𝗻𝗱 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻%\n${description}\n\n`;
    Details += `• %bd𝗡𝗮𝗺𝗲%: ${name}\n`;
    Details += `• %bd𝗣𝗿𝗶𝗰𝗲%: ${price}\n\n`;
    Details += `• %bd𝗔𝗿𝗴𝘂𝗺𝗲𝗻𝘁𝘀%\n`;
    Details += `- %bd𝗨𝘀𝗮𝗴𝗲%: ${guideInfo.usage}\n`;
    Details += `- %bd𝗣𝗮𝗿𝗮𝗺𝘀%: ${guideInfo.params}\n\n`;
    Details += `• %bd𝗖𝗼𝗼𝗹𝗱𝗼𝘄𝗻%: ${cooldown} seconds\n\n`;
    Details += `• %bd𝗦𝘆𝗻𝘁𝗮𝘅%\n${syntax}`;
    
    return message.reply(Details);
};

function getCmdDesc(cmd) {
    const possibleObjNames = ["description", "desc", "shortDescription", "longDescription"];

    for (const name of possibleObjNames) {
        const descObj = cmd.config[name];

        if (typeof descObj === 'string') return descObj;

        if (typeof descObj === 'object' && descObj !== null) {
            if (descObj["en"]) return descObj["en"];
            // Return first available value if no 'en' key
            const values = Object.values(descObj);
            if (values.length > 0) return values[0];
        }
    }

    return "No description available.";
}

function getCommandCategory(cmd) {
    const category = cmd.config.category;
    
    if (typeof category === 'string') {
        return category;
    } else if (Array.isArray(category)) {
        // Use first element of array
        return category[0] || "Other";
    } else if (typeof category === 'object' && category !== null) {
        if (category["en"]) return category["en"];
        // Return first available value
        const values = Object.values(category);
        if (values.length > 0) return values[0];
    }
    
    return "Other";
}

function getGuideInfo(cmd) {
    const guide = cmd.config.guide;
    let usage = "Optional";
    let params = "none";
    
    if (typeof guide === 'string') {
        // Extract parameters from guide string
        const matches = guide.match(/<([^>]+)>/g);
        if (matches) {
            usage = "Required";
            params = matches.map(match => match.replace(/[<>]/g, '')).join(', ');
        }
    } else if (typeof guide === 'object' && guide !== null) {
        // Handle guide object with syntax, params, usage properties
        const guideObj = guide["en"] || guide;
        
        if (guideObj.usage) {
            usage = guideObj.usage;
        } else if (guideObj.params) {
            usage = "Required";
        }
        
        if (guideObj.params) {
            if (typeof guideObj.params === 'string') {
                params = guideObj.params;
            } else if (Array.isArray(guideObj.params)) {
                params = guideObj.params.join(', ');
            }
        } else if (guideObj.syntax) {
            // Extract params from syntax
            const matches = guideObj.syntax.match(/<([^>]+)>/g);
            if (matches) {
                usage = "Required";
                params = matches.map(match => match.replace(/[<>]/g, '')).join(', ');
            }
        }
    }
    
    return { usage, params };
}

function getSyntax(cmd) {
    const prefix = "";
    const name = cmd.config.name;
    const guide = cmd.config.guide;
    
    if (typeof guide === 'string') {
        // If guide is a string, use it as syntax
        return guide.startsWith(name) ? guide.replace(name, `${prefix}${name}`) : `${prefix}${guide}`;
    } else if (typeof guide === 'object' && guide !== null) {
        // Handle guide object
        const guideObj = guide["en"] || guide;
        
        if (guideObj.syntax) {
            return guideObj.syntax.startsWith(name) ? 
                guideObj.syntax.replace(name, `${prefix}${name}`) : 
                `${prefix}${guideObj.syntax}`;
        } else if (typeof guideObj === 'string') {
            return guideObj.startsWith(name) ? 
                guideObj.replace(name, `${prefix}${name}`) : 
                `${prefix}${guideObj}`;
        }
    }
    
    return `${prefix}${name}`;
}
