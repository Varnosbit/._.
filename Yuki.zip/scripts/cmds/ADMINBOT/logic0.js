module.exports = {
    config: {
        name: "logic",
        aliases: ["ماين.لوجيك"],
        version: "1.0",
        author: "allou mohamed",
        countDown: 50,
        role: 0,
        shortDescription: {
            en: "answer for logic game MC.",
            ar: "حلول لعبة في ماين كرافت."
        },
        longDescription: {
            ar: "حلول لعبة في ماين كرافت.",
            en: "gen Minecraft logic map answers for any level 🧙."
        },
        category: "Canvas"
    },

    onStart: async function ({ message, args }) {
        const x = parseInt(args.join(' '), 10); // Ensure it's an integer
        const MinecraftLogicGameAnswer = (x) => {
            if (isNaN(x) || x < 1 || x > 50) return message.reply("Choose [ 1 ... 50 ] 🧙");
            return message.stream('Lvl: ' + x, `https://everbloomgames.com/logic0solution/${x}.jpg`);
        };
        MinecraftLogicGameAnswer(x); // Pass x to the function
    }
};module.exports = {
    config: {
        name: "logic",
        aliases: ["ماين.لوجيك"],
        version: "1.0",
        author: "allou mohamed",
        countDown: 50,
        role: 0,
        shortDescription: {
            en: "answer for logic game MC.",
            ar: "حلول لعبة في ماين كرافت."
        },
        longDescription: {
            ar: "حلول لعبة في ماين كرافت.",
            en: "gen Minecraft logic map answers for any level 🧙."
        },
        category: "Canvas"
    },

    onStart: async function ({ message, args }) {
        const x = parseInt(args.join(' '), 10); // Ensure it's an integer
        const MinecraftLogicGameAnswer = (x) => {
            if (isNaN(x) || x < 1 || x > 50) return message.reply("Choose [ 1 ... 50 ] 🧙");
            return message.stream('Lvl: ' + x, `https://everbloomgames.com/logic0solution/${x}.jpg`);
        };
        MinecraftLogicGameAnswer(x); // Pass x to the function
    }
};