const Config = require('./Config');
const Utils = require('./Utils');
const Variables = require('./Variables');
const Database = require('./Database');

async function resolveActions(mqtt, game, usersData) {
  const actions = game.nightActions;
  const results = [];
  const deaths = [];
  
  for (const p of Object.values(game.players)) {
    if (p.alive && Database.hasPurchase(p.userID, "extra_life")) {
      p.hasExtraLife = true;
    }
  }
  
  const swaps = {};
  for (const [actorID, action] of Object.entries(actions)) {
    if (action.type === "transport") {
      swaps[action.target1] = action.target2;
      swaps[action.target2] = action.target1;
    }
  }
  
  const applySwap = (targetID) => swaps[targetID] || targetID;
  
  const sortedActions = Object.entries(actions).sort((a, b) => {
    const roleA = Config.ROLES[game.players[a[0]].role];
    const roleB = Config.ROLES[game.players[b[0]].role];
    return (roleB.priority || 0) - (roleA.priority || 0);
  });
  
  for (const [actorID, action] of sortedActions) {
    const actor = game.players[actorID];
    if (!actor || !actor.alive) continue;
    
    if (action.type === "roleblock") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        target.roleblocked = true;
        results.push(`💤 تم إشغال شخص ما!`);
      }
    } else if (action.type === "heal") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        target.protected = true;
        results.push(`💊 الطبيب حمى شخصاً ما!`);
      }
    } else if (action.type === "bodyguard") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        target.bodyguarded = actorID;
      }
    } else if (action.type === "vest" || action.type === "self_protect") {
      actor.protected = true;
    } else if (action.type === "alert") {
      actor.alerted = true;
    } else if (action.type === "trap") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        target.trapped = actorID;
      }
    } else if (action.type === "crusade") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        target.crusaded = actorID;
      }
    } else if (action.type === "frame") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        target.framed = true;
      }
    } else if (action.type === "blackmail") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        target.blackmailed = true;
        results.push(`🤫 شخص ما تم ابتزازه!`);
      }
    }
  }
  
  for (const [actorID, action] of sortedActions) {
    const actor = game.players[actorID];
    if (!actor || !actor.alive || actor.roleblocked) continue;
    
    const killActions = ["kill", "vigi_kill", "sk_kill", "maul", "sheriff_check", "vh_check"];
    if (killActions.includes(action.type)) {
      const killResult = await handleKillAction(game, actor, action, applySwap, deaths, results, mqtt, usersData);
      if (killResult === "actor_died") continue;
    } else if (action.type === "ignite") {
      await handleIgniteAction(game, actor, deaths, results, mqtt, usersData);
    }
  }
  
  await handleInformationActions(mqtt, game, actions, applySwap, usersData, results);
  await announceNightResults(mqtt, game, deaths, results, usersData);
}

async function handleKillAction(game, actor, action, applySwap, deaths, results, mqtt, usersData) {
  let targetID = applySwap(action.target);
  const target = game.players[targetID];
  if (!target || !target.alive) return;
  
  const isTeamKill = Utils.isMafiaRole(actor.role) && Utils.isMafiaRole(target.role);
  
  if (target.alerted) {
    actor.alive = false;
    const funnyMessages = [
      "😂 هههههه! هاجم المحارب القديم وانجلد! 🤡",
      "🤣 غبي! راح للمحارب القديم بنفسه! 💀",
      "😆 المحارب القديم كان مستني حد أبله! 🎯"
    ];
    const funnyMsg = Utils.getRandomElement(funnyMessages);
    deaths.push({ userID: actor.userID, reason: `⚔️ ${funnyMsg}` });
    results.push(`⚔️ المحارب القديم قتل مهاجماً غبياً! 💀😂`);
    await Utils.sendToPlayerOrRoom(mqtt, actor, `☠️ قُتلت!\n____________________________\n${funnyMsg}\n💀 المحارب القديم لا يُهزم!`);
    Database.recordKill(target.userID, actor.userID, false);
    return "actor_died";
  }
  
  if (target.trapped) {
    actor.alive = false;
    deaths.push({ userID: actor.userID, reason: "🪤 وقع في فخ الصياد المحترف! 😏" });
    results.push(`🪤 الصياد اصطاد شخصاً غبياً! 💀🎣`);
    await Utils.sendToPlayerOrRoom(mqtt, actor, `☠️ قُتلت!\n____________________________\n🪤 وقعت في فخ محكم!\n😏 كان ينتظرك الصياد!`);
    Database.recordKill(target.trapped, actor.userID, false);
    return "actor_died";
  }
  
  if (target.crusaded) {
    actor.alive = false;
    deaths.push({ userID: actor.userID, reason: "⚔️🛡️ قتله الصليبي الشجاع! 🗡️" });
    results.push(`⚔️🛡️ الصليبي دافع وقتل مهاجماً! 💀⚔️`);
    await Utils.sendToPlayerOrRoom(mqtt, actor, `☠️ قُتلت!\n____________________________\n⚔️🛡️ الصليبي كان يحرس!\n🗡️ دفاع قوي!`);
    Database.recordKill(target.crusaded, actor.userID, false);
    return "actor_died";
  }
  
  if (target.protected) {
    results.push(`🛡️ تم منع محاولة قتل! الحماية نجحت! ✅`);
    await Utils.sendToPlayerOrRoom(mqtt, target, `✅ تم إنقاذك!\n🛡️ الحماية نجحت!\n💪 أنت بخير!`);
    Database.recordSkillUse(actor.userID, false);
    return;
  }
  
  if (target.bodyguarded) {
    const bg = game.players[target.bodyguarded];
    if (bg && bg.alive) {
      bg.alive = false;
      deaths.push({ userID: bg.userID, reason: "🛡️ ضحى كحارس شخصي بطل! 💪" });
      results.push(`🛡️ الحارس الشخصي ضحى بنفسه! 💔😢`);
      const targetName = await usersData.getName(target.userID);
      await Utils.sendToPlayerOrRoom(mqtt, bg, `☠️ ضحيت بنفسك!\n____________________________\n🛡️ حميت ${targetName}!\n💪 موت بطولي!`);
      await Utils.sendToPlayerOrRoom(mqtt, target, `✅ تم إنقاذك!\n🛡️ الحارس ضحى بنفسه!\n💔 ديون لا تُنسى!`);
      Database.recordKill(actor.userID, bg.userID, false);
      return;
    }
  }
  
  if (target.hasExtraLife && Database.hasPurchase(target.userID, "extra_life")) {
    Database.removePurchaseFromInventory(target.userID, "extra_life");
    target.hasExtraLife = false;
    results.push(`❤️ الحياة الإضافية أنقذت شخصاً! ✨`);
    await Utils.sendToPlayerOrRoom(mqtt, target, `❤️ نجوت بأعجوبة!\n____________________________\n✨ الحياة الإضافية أنقذتك!\n🎁 فرصة ثانية!`);
    Database.recordSkillUse(actor.userID, false);
    return;
  }
  
  if (action.type === "sheriff_check" || action.type === "vh_check") {
    const roleData = Config.ROLES[target.role];
    const isTarget = (action.type === "sheriff_check" && roleData.team === "mafia") ||
                    (action.type === "vh_check" && (roleData.team === "vampire" || target.convertedToVampire));
    if (isTarget) {
      target.alive = false;
      deaths.push({ userID: target.userID, reason: action.type === "sheriff_check" ? "⭐ قتله العمدة العادل! ⚖️" : "🧄 قتله صائد مصاصي الدماء! 🧛" });
      Database.recordKill(actor.userID, target.userID, isTeamKill);
      await Utils.sendToPlayerOrRoom(mqtt, actor, `✅ كان ${action.type === "sheriff_check" ? "مافيا 🔴" : "مصاص دماء 🧛"} وقتلته!\n🎯 إصابة دقيقة!`);
    } else {
      await Utils.sendToPlayerOrRoom(mqtt, actor, `✅ ليس ${action.type === "sheriff_check" ? "مافيا 🔵" : "مصاص دماء 👤"}\n😌 مواطن بريء`);
      Database.recordSkillUse(actor.userID, true);
    }
    return;
  }
  
  target.alive = false;
  let deathMsg = "☠️ قُتل";
  if (action.type === "vigi_kill") deathMsg = "🔫 قتله الحارس الشجاع! 🎯";
  else if (action.type === "sk_kill") deathMsg = "🔪💀 قتله القاتل المتسلسل! 😱";
  else if (action.type === "maul") deathMsg = "🐺 مزقه المستذئب بوحشية! 🩸";
  deaths.push({ userID: target.userID, reason: deathMsg });
  
  Database.recordKill(actor.userID, target.userID, isTeamKill);
  
  if (Utils.isMafiaRole(actor.role)) {
    Variables.decrementMafiaKill(game);
  }
  
  if (action.type === "maul") {
    for (const [visitorID, visitorAction] of Object.entries(game.nightActions)) {
      if (visitorAction.target === target.userID && visitorID !== actor.userID) {
        const visitor = game.players[visitorID];
        if (visitor && visitor.alive) {
          visitor.alive = false;
          deaths.push({ userID: visitor.userID, reason: "🐺 مزقه المستذئب أيضاً! 🩸😱" });
          await Utils.sendToPlayerOrRoom(mqtt, visitor, `☠️ قُتلت!\n____________________________\n🐺 المستذئب مزقك!\n😱 كنت في المكان الخطأ!`);
          Database.recordKill(actor.userID, visitor.userID, false);
        }
      }
    }
  }
}

async function handleIgniteAction(game, actor, deaths, results, mqtt, usersData) {
  const dousedPlayers = Object.values(game.players).filter(p => p.doused && p.alive);
  for (const target of dousedPlayers) {
    if (!target.protected && !(target.hasExtraLife && Database.hasPurchase(target.userID, "extra_life"))) {
      target.alive = false;
      deaths.push({ userID: target.userID, reason: "🔥 احترق في نار الحارق! 🔥💀" });
      Database.recordKill(actor.userID, target.userID, false);
    } else if (target.hasExtraLife && Database.hasPurchase(target.userID, "extra_life")) {
      Database.removePurchaseFromInventory(target.userID, "extra_life");
      target.hasExtraLife = false;
      await Utils.sendToPlayerOrRoom(mqtt, target, `❤️ الحياة الإضافية أنقذتك من الحريق! 🔥`);
    }
  }
  if (dousedPlayers.length > 0) {
    results.push(`🔥 حريق هائل اجتاح المدينة! 💥😱`);
  }
}

async function handleInformationActions(mqtt, game, actions, applySwap, usersData, results) {
  const sortedActions = Object.entries(actions).sort((a, b) => {
    const roleA = Config.ROLES[game.players[a[0]].role];
    const roleB = Config.ROLES[game.players[b[0]].role];
    return (roleB.priority || 0) - (roleA.priority || 0);
  });
  
  for (const [actorID, action] of sortedActions) {
    const actor = game.players[actorID];
    if (!actor || !actor.alive) continue;
    
    if (action.type === "investigate") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        const roleData = Config.ROLES[target.role];
        let result = target.framed ? "🔴 مافيا" : roleData.disguised ? "🔵 مواطن" : roleData.team === "mafia" ? "🔴 مافيا" : "🔵 مواطن";
        const targetName = await usersData.getName(target.userID);
        await Utils.sendToPlayerOrRoom(mqtt, actor, `👮 نتيجة التحقيق:\n____________________________\n${targetName}\n🔍 ${result}\n\n${result === "🔴 مافيا" ? "⚠️ مشبوه!" : "✅ يبدو بريئاً"}`);
        Database.recordSkillUse(actorID, true);
      }
    } else if (action.type === "precise_check") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        const roleData = Config.ROLES[target.role];
        const targetName = await usersData.getName(target.userID);
        await Utils.sendToPlayerOrRoom(mqtt, actor, `🎯 كشف دقيق!\n____________________________\n${targetName}\n🎭 ${roleData.emoji} ${roleData.name}\n\n✅ معلومة مؤكدة 100%!`);
        Database.recordSkillUse(actorID, true);
      }
    } else if (action.type === "lookout") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        const visitors = [];
        for (const [vID, vAction] of Object.entries(actions)) {
          if (vAction.target === targetID && vID !== actorID) {
            visitors.push(vID);
          }
        }
        const targetName = await usersData.getName(target.userID);
        if (visitors.length > 0) {
          let msg = `👁️ تقرير المراقبة\n____________________________\n\n🏠 منزل ${targetName}\n\n👥 الزوار:\n`;
          for (const vID of visitors) {
            const vName = await usersData.getName(vID);
            msg += `• ${vName}\n`;
          }
          msg += `\n✅ معلومات دقيقة!`;
          await Utils.sendToPlayerOrRoom(mqtt, actor, msg);
        } else {
          await Utils.sendToPlayerOrRoom(mqtt, actor, `👁️ تقرير المراقبة\n____________________________\n\n🏠 منزل ${targetName}\n\n❌ لا زوار الليلة\n😴 ليلة هادئة`);
        }
        Database.recordSkillUse(actorID, true);
      }
    } else if (action.type === "track") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive) {
        const targetAction = actions[targetID];
        const targetName = await usersData.getName(target.userID);
        if (targetAction && targetAction.target) {
          const visitedName = await usersData.getName(targetAction.target);
          await Utils.sendToPlayerOrRoom(mqtt, actor, `🔎 تقرير التعقب\n____________________________\n\n🎯 ${targetName}\n\n📍 زار: ${visitedName}\n\n✅ تعقب ناجح!`);
        } else {
          await Utils.sendToPlayerOrRoom(mqtt, actor, `🔎 تقرير التعقب\n____________________________\n\n🎯 ${targetName}\n\n❌ لم يزر أحداً\n🏠 بقي في منزله`);
        }
        Database.recordSkillUse(actorID, true);
      }
    } else if (action.type === "douse") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive && target.userID !== actorID) {
        target.doused = true;
        const targetName = await usersData.getName(target.userID);
        await Utils.sendToPlayerOrRoom(mqtt, actor, `🔥 تم إشعال ${targetName}!\n____________________________\n✅ جاهز للحرق!\n💥 اكتب "حرق" لإشعال الجميع`);
        Database.recordSkillUse(actorID, true);
      }
    } else if (action.type === "convert_vamp") {
      const targetID = applySwap(action.target);
      const target = game.players[targetID];
      if (target && target.alive && target.userID !== actorID) {
        const roleData = Config.ROLES[target.role];
        if (roleData.team === "citizen" || roleData.team === "neutral") {
          target.convertedToVampire = true;
          const targetName = await usersData.getName(target.userID);
          await Utils.sendToPlayerOrRoom(mqtt, actor, `🧛 تم تحويل ${targetName}!\n____________________________\n✅ أصبح مصاص دماء!\n🌙 توسع الإمبراطورية`);
          await Utils.sendToPlayerOrRoom(mqtt, target, `🧛 تم تحويلك!\n____________________________\n🌙 أصبحت مصاص دماء!\n🎯 هدفك: السيطرة على المدينة`);
          Database.recordSkillUse(actorID, true);
        } else {
          await Utils.sendToPlayerOrRoom(mqtt, actor, `❌ فشل التحويل!\n____________________________\n⚠️ لا يمكن تحويله`);
          Database.recordSkillUse(actorID, false);
        }
      }
    } else if (action.type === "remember") {
      const target = game.players[action.target];
      if (target && !target.alive) {
        const newRole = target.role;
        actor.role = newRole;
        actor.abilities = {};
        const roleData = Config.ROLES[newRole];
        if (roleData.uses) {
          actor.abilities[roleData.ability] = roleData.uses;
        }
        const targetName = await usersData.getName(target.userID);
        await Utils.sendToPlayerOrRoom(mqtt, actor, `❓ تذكرت الماضي!\n____________________________\n\n👤 ${targetName}\n🎭 ${roleData.emoji} ${roleData.name}\n\n✅ أصبحت مثله!\n📝 ${roleData.desc}`);
        Database.recordSkillUse(actorID, true);
      }
    } else if (action.type === "revive") {
      const target = game.players[action.target];
      if (target && !target.alive) {
        target.revived = true;
        target.revivedRole = target.role;
        const targetName = await usersData.getName(target.userID);
        await Utils.sendToPlayerOrRoom(mqtt, actor, `💀➡️ تم إحياء ${targetName}!\n____________________________\n✅ عاد للحياة ليلة واحدة!\n⚡ يمكنه استخدام قدرته`);
        await Utils.notifyMainChat(mqtt, game, `💫 إحياء! تم إحياء ${targetName} بواسطة قدرة خاصة! ✨`);
        Database.recordSkillUse(actorID, true);
      }
    }
  }
}

async function announceNightResults(mqtt, game, deaths, results, usersData) {
  let announcement = `${Utils.formatPhaseMessage("day", game.day)}\n\n`;
  
  if (deaths.length > 0) {
    announcement += `☠️ الموتى الليلة:\n____________________________\n\n`;
    for (const death of deaths) {
      const victim = game.players[death.userID];
      const victimName = await usersData.getName(victim.userID);
      announcement += `💀 ${victimName}\n   ${death.reason}\n\n`;
      await Utils.sendToPlayerOrRoom(mqtt, victim, `☠️ قُتلت!\n____________________________\n${death.reason}`);
      await Utils.revealRoleInMainChat(mqtt, game, victim.userID, usersData, "ميت");
    }
  } else {
    announcement += `✅ لا موتى الليلة! 🎉\n____________________________\n💪 الجميع نجا!\n\n`;
  }
  
  if (results.length > 0) {
    announcement += `📰 أحداث الليلة:\n____________________________\n`;
    results.forEach(r => { announcement += `• ${r}\n`; });
    announcement += `\n`;
  }
  
  announcement += `____________________________\n\n${Utils.formatGameStatus(game)}`;
  await mqtt.sendMessage(announcement, game.main);
  
  const endResult = Utils.checkGameEnd(game);
  if (endResult.ended) {
    const Functions = require('./Functions');
    return Functions.handleGameEnd(mqtt, game, endResult, usersData);
  }
  
  setTimeout(() => {
    const Day = require('./Day');
    Day.startDayPhase(mqtt, game.id, usersData);
  }, Config.gameSettings.phaseTransitionDelayMs);
}

module.exports = {
  resolveActions
};
