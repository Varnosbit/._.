module.exports = {
	config: {
		name: "r",
		aliases: ["تسجيل", "register"],
		version: "1.4",
		author: "allou Mohamed",
		countDown: 5,
		role: 2,
		description: {
			en: "Register groups.",
			ar: "تسجيل المجموعات. إذا كانت المجموعة غير مسجلة، يتجاهلها البوت كليًا."
		},
		category: "admin",
		guide: {
			en: "{pn} blank, remove, or list",
			ar: "{pn} blank, remove, or list"
		}
	},
	onStart: async function({ message, event, threadsData, args }) {
		const tid = args[1] || event.threadID;
		const action = args[0]?.toLowerCase();
		
		const isRegistered = await threadsData.get(tid, "data.approved");

		if (!args.length) {
			if (isRegistered) {
				return message.reply("This group is already registered.");
			}
			await threadsData.set(tid, true, "data.approved");
			return message.reply("This group has been successfully registered.");
		}

		if (action === "rm" || action === "remove") {
			if (!isRegistered) {
				return message.reply("This group is not registered.");
			}
			await threadsData.set(tid, false, "data.approved");
			return message.reply("This group is no longer registered.");
		}

		if (action === "list") {
			const all = await threadsData.getAll();
			const registered = all.filter(group => group.data?.approved);

			if (!registered.length) {
				return message.reply("No groups are registered.");
			}

			let reply = "Registered Groups:\n";
			registered.forEach((group, index) => {
				reply += `${index + 1}. ${group.threadName} (ID: ${group.threadID})\n`;
			});
			return message.reply(reply);
		}

		if (action === "loop") {
			const all = await threadsData.getAll();
			const registered = all.filter(group => group.data?.approved);

			if (!registered.length) {
				return message.reply("No registered groups found.");
			}

			const loop = registered.map(group => group.threadID).join(" ");
			return message.reply(loop);
		}

		if (action === "rmloop") {
			if (args.length < 2) {
				return message.reply("Please provide thread IDs to remove.");
			}

			const loop = args.slice(1).join(" ").split(" ").map(x => x.trim());
			loop.forEach(async (tid) => {
				await threadsData.set(tid, false, "data.approved");
			});
			return message.reply("The specified groups have been unregistered.");
		}

		return message.reply("Invalid action. Please use 'remove', 'list', 'loop', or leave blank to register.");
	}
};
