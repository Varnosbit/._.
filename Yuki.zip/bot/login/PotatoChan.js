const axios = require('axios');
const crypto = require('crypto');
const querystring = require('querystring');
const { v4: uuidv4 } = require('uuid');
const { authenticator } = require('otplib');

async function getCoc(Creds) {
const { username, password } = Creds;
let twofactor = '0';
let _2fa = authenticator.generate('HJU34GOQL4RS5UJSXYU3DNZCPSDA4D7O');
 
if (!username || !password) {
return 'Please enter all required information!';
}

try {
const form = {
adid: uuidv4(),
email: username,
password,
format: 'json',
device_id: uuidv4(),
cpl: 'true',
family_device_id: uuidv4(),
locale: 'en_US',
client_country_code: 'US',
credentials_type: 'device_based_login_password',
generate_session_cookies: '1',
generate_analytics_claim: '1',
generate_machine_id: '1',
currently_logged_in_userid: '0',
irisSeqID: 1,
try_num: '1',
enroll_misauth: 'false',
meta_inf_fbmeta: 'NO_FILE',
source: 'login',
machine_id: randomString(24),
fb_api_req_friendly_name: 'authenticate',
fb_api_caller_class: 'com.facebook.account.login.protocol.Fb4aAuthHandler',
api_key: '882a8490361da98702bf97a021ddc14d',
access_token: '350685531728%7C62f8ce9f74b12f84c123cc23437a4a32'
};

form.sig = encodeSig(sort(form));

const options = {
url: 'https://b-graph.facebook.com/auth/login',
method: 'post',
data: querystring.stringify(form),
headers: {
'content-type': 'application/x-www-form-urlencoded',
'x-fb-friendly-name': form.fb_api_req_friendly_name,
'x-fb-http-engine': 'Liger',
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
}
};

try {
const response = await axios.request(options);
response.data.access_token_eaad6v7 = await convertToken(response.data.access_token);
response.data.cookies = await convertCookie(response.data.session_cookies);
return MakeCookies(response.data);
} catch (error) {
if (error.response?.data?.error?.code === 401) {
if(error.response.data.error.error_subcode === 1348131){
return "Error in Approving Login Add 2fa in ur account for better stability"
} else
return error.response.data;
}
//handle 2fa as a pro
return handle2FA(_2fa, error, form);
}
} catch (e) {
return 'your account credentials!';
}
}

async function handle2FA(_2fa, error, form) {
try {
const data = error.response.data.error.error_data;
form.twofactor_code = _2fa;
form.encrypted_msisdn = '';
form.userid = data.uid;
form.machine_id = data.machine_id;
form.first_factor = data.login_first_factor;
form.credentials_type = 'two_factor';
delete form.sig;
form.sig = encodeSig(sort(form));

const options2FA = {
url: 'https://b-graph.facebook.com/auth/login',
method: 'post',
data: querystring.stringify(form),
headers: {
'content-type': 'application/x-www-form-urlencoded',
'x-fb-http-engine': 'Liger',
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
}
};

const response2FA = await axios.request(options2FA);
response2FA.data.cookies = await convertCookie(response2FA.data.session_cookies);
response2FA.data.session_cookies = response2FA.data.session_cookies.map(e => ({
key: e.name,
value: e.value,
domain: e.domain.slice(1),
path: e.path,
hostOnly: false
}));

return MakeCookies(response2FA.data.cookies)
} catch (e) {
return console.log('err 2fa')
}
}

async function convertCookie(session) {
return session.map(({ name, value }) => `${name}=${value}`).join('; ');
}

function MakeCookies(cookieString) {
const cookies = cookieString.split('; ').map(cookie => {
const [key, value] = cookie.split('=');
return {
"key": key,
"value": encodeURIComponent(value),
"domain": "facebook.com",
"path": "/",
"hostOnly": false,
"creation": new Date().toISOString(),
"lastAccessed": new Date().toISOString()
};
});

return cookies;
}
function randomString(length = 10) {
const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
return [...Array(length)].map(() => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function encodeSig(data) {
const stringData = Object.keys(data).map(key => `${key}=${data[key]}`).join('');
return md5(stringData + '62f8ce9f74b12f84c123cc23437a4a32');
}

function md5(string) {
return crypto.createHash('md5').update(string).digest('hex');
}

function sort(object) {
return Object.keys(object).sort().reduce((acc, key) => {
acc[key] = object[key];
return acc;
}, {});
}

module.exports = getCoc;
