//by nub alu
const axios = require("axios");
const { URLSearchParams } = require("url");
const screenshotmachine = require("screenshotmachine");

exports.config = {
  name: "ss",
  category: "tools",
  role: 3,
  version: "1.0.0",
  author: "Allou Mohamed"
};

const cookie = "PHPSESSID=c5dft5b312j2t2cslsrqs51m9d; homepage-tab=screenshot";
const customerKey = "34f366";
const secretPhrase = "";

async function fetchScreenshotsLeft(cookie) {
  try {
    const resp = await axios.get("https://www.screenshotmachine.com/dashboard.php", {
      headers: {
        accept:
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-language": "en,fr;q=0.9,ar;q=0.8",
        "cache-control": "max-age=0",
        "sec-ch-ua": '"Chromium";v="140", "Not=A?Brand";v="24", "Google Chrome";v="140"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        cookie: cookie,
        Referer: "https://www.screenshotmachine.com/"
      }
    });

    const html = resp.data;
    const match = html.match(/<div class="h1 mb-0 text-success">([\d\s]+)<\/div>/i);
    if (!match) return null;

    const remaining = parseInt(match[1].replace(/\s/g, ""), 10);
    return remaining;
  } catch (err) {
    console.error("Error fetching dashboard:", err.message);
    return "0";
  }
}

function isValidUrl(string) {
  try {
    const url = new URL(string);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch (_) {
    return false;
  }
}

function ensureProtocol(url) {
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    return "https://" + url;
  }
  return url;
}

function trimText(text) {
  if (!text) return text;
  return text.toString().trim();
}

function parseNumericValue(value) {
  const trimmed = trimText(value);
  return !isNaN(trimmed) && trimmed !== "" ? parseFloat(trimmed) : null;
}

function parseIntegerValue(value) {
  const trimmed = trimText(value);
  return !isNaN(trimmed) && trimmed !== "" ? parseInt(trimmed) : null;
}

async function captureOfficial(url, options) {
  let device = options.device || "desktop";
  let isFull = typeof options.full !== "undefined" ? options.full : false;
  let dimension;

  if (device === "desktop") dimension = isFull ? "1024xfull" : "1024x768";
  else if (device === "phone") dimension = isFull ? "480xfull" : "480x800";
  else if (device === "tablet") dimension = isFull ? "800xfull" : "800x1280";
  else dimension = isFull ? "1366xfull" : "1366x768";

  const params = {
    url,
    device,
    dimension,
    cacheLimit: options.cacheLimit || "0",
    format: options.format || "png",
    timeout: options.timeout || "200000"
  };

  if (options.delay) params.delay = options.delay;
  if (options.zoom) params.zoom = options.zoom;
  if (options.quality) params.quality = options.quality;
  if (options.selector) params.selector = trimText(options.selector);
  if (options.hide) params.hide = trimText(options.hide);
  if (options.click) params.click = trimText(options.click);
  if (options.wait) params.wait = trimText(options.wait);
  if (options.cookie) params.cookie = trimText(options.cookie);
  if (options.auth) params.auth = trimText(options.auth);
  if (options.width) params.width = options.width;
  if (options.height) params.height = options.height;
  if (options.trim) params.trim = options.trim;
  if (options.background) params.background = trimText(options.background);
  if (options.scale) params.scale = options.scale;
  if (options.mobile) params.mobile = options.mobile;
  if (options.pdf) params.pdf = options.pdf;
  if (options.orientation) params.orientation = trimText(options.orientation);
  if (options.margins) params.margins = trimText(options.margins);
  if (options.pageSize) params.pageSize = trimText(options.pageSize);
  if (options.blur) params.blur = options.blur;
  if (options.grayscale) params.grayscale = options.grayscale;
  if (options.darkMode) params.darkMode = options.darkMode;
  if (options.fullPage) params.fullPage = options.fullPage;
  if (options.clipSelector) params.clipSelector = trimText(options.clipSelector);
  if (options.javascript) params.javascript = trimText(options.javascript);
  if (options.css) params.css = trimText(options.css);
  if (options.headers) params.headers = trimText(options.headers);
  if (options.proxy) params.proxy = trimText(options.proxy);
  if (options.userAgent) params.userAgent = trimText(options.userAgent);
  if (options.viewport) params.viewport = trimText(options.viewport);
  if (options.timezone) params.timezone = trimText(options.timezone);
  if (options.locale) params.locale = trimText(options.locale);
  if (options.geolocation) params.geolocation = trimText(options.geolocation);
  if (options.emulateMedia) params.emulateMedia = trimText(options.emulateMedia);

  const apiUrl = screenshotmachine.generateScreenshotApiUrl(customerKey, secretPhrase, params);

  const resp = await axios.get(apiUrl, {
    responseType: "stream",
    timeout: 30000,
    headers: {
      "User-Agent":
        options.device === "phone"
          ? "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1"
          : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
  });

  if (!resp.data) {
    throw new Error("Empty response from official API");
  }

  return resp.data;
}

async function captureScraper(url, { device = "desktop", full, delay }) {
  const base = "https://www.screenshotmachine.com";
  const params = new URLSearchParams({
    url,
    device: device === "phone" ? "phone" : "desktop",
    cacheLimit: 0
  });

  if (full) params.append("dimension", "1366xfull");
  if (delay) params.append("delay", delay);

  const userAgent =
    device === "phone"
      ? "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1"
      : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";

  const postResp = await axios.post(base + "/capture.php", params, {
    timeout: 30000,
    headers: {
      "User-Agent": userAgent,
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      Origin: "https://www.screenshotmachine.com",
      Referer: "https://www.screenshotmachine.com/"
    }
  });

  if (!postResp.data || postResp.data.status !== "success" || !postResp.data.link) {
    const errorMsg = (postResp.data && (postResp.data.error || postResp.data.message)) || "Unknown error";
    throw new Error(`Scraper API error: ${errorMsg}`);
  }

  const setCookie = postResp.headers["set-cookie"] || [];
  const cookiePairs = setCookie.map(sc => sc.split(";")[0].trim()).filter(Boolean);
  const cookieHeader = cookiePairs.join("; ");

  const imageUrl = base + "/" + postResp.data.link;

  const getResp = await axios.get(imageUrl, {
    timeout: 30000,
    headers: {
      "User-Agent": userAgent,
      Referer: "https://www.screenshotmachine.com/",
      Cookie: cookieHeader
    },
    responseType: "stream"
  });

  if (!getResp.data) {
    throw new Error("Empty image response from scraper");
  }

  return getResp.data;
}

exports.onStart = async ({ message, args, event }) => {
  if (!args || args.length === 0) {
    return message.reply(
      "⚠️ ضع رابط الموقع بعد الأمر\nمثال: ss fast.com --device phone --full --delay 1000\n\nجميع المعاملات المدعومة:\n--device (desktop/phone) --full --delay --zoom --quality --format --selector --hide --click --wait --cookie --auth --width --height --trim --background --scale --mobile --pdf --orientation --margins --pageSize --blur --grayscale --darkMode --fullPage --clipSelector --javascript --css --headers --proxy --userAgent --viewport --timezone --locale --geolocation --emulateMedia --cacheLimit --timeout --scrap"
    );
  }

  let url;
  let sC = false;
  let options = {};

  for (let i = 0; i < args.length; i++) {
    const arg = trimText(args[i]);

    if (arg.startsWith("--")) {
      const param = arg.substring(2);
      const value = args[i + 1] ? trimText(args[i + 1]) : null;

      switch (param) {
        case "device":
        case "d":
          if (value) {
            options.device =
              value.toLowerCase() === "phone" || value.toLowerCase() === "mobile"
                ? "phone"
                : value.toLowerCase() === "tablet"
                ? "tablet"
                : "desktop";
            i++;
          }
          break;
        case "full":
          options.full = true;
          break;
        case "scrap":
          sC = true;
          break;
        case "delay":
          const delayVal = parseIntegerValue(value);
          if (delayVal !== null) {
            options.delay = delayVal;
            i++;
          }
          break;
        case "zoom":
          const zoomVal = parseIntegerValue(value);
          if (zoomVal !== null) {
            options.zoom = zoomVal;
            i++;
          }
          break;
        case "quality":
          const qualityVal = parseIntegerValue(value);
          if (qualityVal !== null) {
            options.quality = qualityVal;
            i++;
          }
          break;
        case "format":
          if (value) {
            options.format = value;
            i++;
          }
          break;
      }
    } else if (!url) {
      url = arg;
    }
  }

  if (!url) {
    return message.reply("⚠️ يرجى تحديد رابط الموقع");
  }

  url = ensureProtocol(url);

  if (!isValidUrl(url)) {
    return message.reply("⚠️ الرابط المدخل غير صحيح");
  }

  try {
    message.reaction("⏳", event.messageID);

    if (sC) {
      message.send("capture with scraper...");
      try {
        const stream = await captureScraper(url, options);
        message.reaction("✅", event.messageID);
        return message.reply({ attachment: stream });
      } catch (scraperError) {
        message.reaction("❌", event.messageID);
        return message.send(`Err Scraper: ${scraperError.message}`);
      }
    }

    let stream;
    try {
      stream = await captureOfficial(url, options);
      message.reaction("✅", event.messageID);
    } catch (officialError) {
      console.log("Official API failed, trying scraper method:", officialError.message);
      try {
        stream = await captureScraper(url, options);
        message.reaction("✅", event.messageID);
      } catch (scraperError) {
        message.reaction("❌", event.messageID);
        throw new Error(
          `Both methods failed. Official: ${officialError.message}, Scraper: ${scraperError.message}`
        );
      }
    }
    let fm = { attachment: stream };
    if (!sC) fm.body = "- Left ss: "+await fetchScreenshotsLeft(cookie);
    await message.reply(fm);
  } catch (error) {
    console.error("Screenshot error:", error);
    const errorMessage = error.message || "حدث خطأ غير معروف";
    message.reply(`❌ فشل في أخذ لقطة الشاشة: ${errorMessage}`);
  }
};
