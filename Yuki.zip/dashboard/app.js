const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const axios = require("axios");
const http = require("http");
const server = http.createServer(app);
const fs = require("fs");
const path = require('path');
const { exec } = require('child_process');

module.exports = async (api, mqtt) => {
	if (!api)
		await require("./connectDB.js")();

	const { config } = global.YamiBot;
	const getText = global.utils.getText;

	const {
		threadModel,
		userModel,
		dashBoardModel,
		threadsData,
		usersData,
		dashBoardData,
		globalData
	} = global.db;

	app.use(bodyParser.json());
	app.use(bodyParser.urlencoded({ extended: true }));
        app.post("/send_msg", async (req, res) => {
    try {
        const { form, threadID } = req.body;
        if (!form || !threadID) return res.status(400).json({ error: "Missing required fields." });
        await mqtt.sendMessage(form, threadID);
        res.status(200).json({ message: "Message sent successfully" });
    } catch {
        res.status(500).json({ error: "Internal Server Error" });
    }
});
    
app.get("/stats", (req, res) => {
  const uptime = process.uptime(); // seconds

  const stats = {
    uptime,
    adminBot: YamiBot.config.adminBot || [],
    devsBot: YamiBot.config.devsBot || [],
    botName: YamiBot.config.nickNameBot || "Unknown",
    prefix: YamiBot.config.prefix || "/",
    nodeVersion: process.version,
    database: {
      type: YamiBot.config.database?.type || "unknown"
    }
  };

  res.json(stats);
});
    
app.post("/link", async (req, res) => {
   utils.log.info("MINECRAFT", "Link request.");
    try {
        const { key, mc_name, id } = req.body;
        if (!key || !mc_name || !id) return res.status(400).json({ error: "Bad request." });
        global.minecraft.set(key, { name: mc_name, id });
        res.status(200).json({
            message: `Key generated:\n${key}\nUse /mc link ${key}`
        });
    } catch {
        res.status(500).json({ error: "Internal Server Error" });
	utils.log.error("LINK", error);
    }
});
	
	app.get("/onLinePlayers", async (req, res) => {
    try {
        const allUsers = await usersData.getAll();
        const playersMap = {};

        for (const user of allUsers) {
            const mc = user?.data?.minecraft;
            if (mc?.name) {
                playersMap[mc.name] = {
                    name: mc.name,
                    onGame: mc.onGame === true
                };
            }
        }

        const nonLinked = await globalData.get("minecraft", "data.not_linked", {});
        for (const [id, info] of Object.entries(nonLinked)) {
            if (!playersMap[info.mc_name]) {
                playersMap[info.mc_name] = {
                    name: info.mc_name,
                    onGame: info.onGame === true
                };
            }
        }

        const players = Object.values(playersMap);

        const tableRows = players.map(player => `
  <tr>
    <td>${player.name}</td>
    <td>
      <span class="status-circle ${player.onGame ? "online" : "offline"}"></span>
      ${player.onGame ? "Online" : "Offline"}
    </td>
  </tr>
`).join("");

        const htmlPath = path.join(__dirname, 'Html', 'onLinePlayers.html');
        let html = fs.readFileSync(htmlPath, 'utf-8');
        html = html.replace('[TBROWS]', tableRows);
        res.setHeader("Content-Type", "text/html");
        res.send(html);

    } catch (err) {
        res.status(500).send("INTERNAL_SERVER_ERROR");
    }
});
    
    app.post("/usersData", async (req, res) => {
  try {
    const { func, a,b,c } = req.body;

    if (!func || typeof usersData[func] !== "function") {
      return res.status(400).json({ error: "Invalid or missing function name" });
    }

    const args = [a,b,c].filter(v => v !== undefined);
    const result = await usersData[func](...args);

    res.json(result);
  } catch (error) {
    console.error("Error in /usersData:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});
    
app.post("/threadsData", async (req, res) => {
  try {
    const { func, a, b, c } = req.body;

    if (!func || typeof threadsData[func] !== "function") {
      return res.status(400).json({ error: "Invalid or missing function name" });
    }

    const args = [a,b,c].filter(v => v !== undefined);
    const result = await threadsData[func](...args);

    res.json(result);
  } catch (error) {
    console.error("Error in /threadsData:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});
    
    app.post("/api", async (req, res) => {
  try {
    const { func, a, b, c, d, e } = req.body;

    if (!func || typeof mqtt[func] !== "function") {
      return res.status(400).json({ error: "Invalid or missing function name" });
    }

    const args = [a, b, c, d, e].filter(v => v !== undefined);
    const result = await mqtt[func](...args);

    res.json(result);
  } catch (error) {
    console.error("Error in /api:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});
    
app.post("/mqtt", async (req, res) => {
  try {
    const { func, a, b, c, d, e } = req.body;

    if (!func || typeof mqtt[func] !== "function") {
      return res.status(400).json({ error: "Invalid or missing function name" });
    }

    const args = [a, b, c, d, e].filter(v => v !== undefined);
    const result = await mqtt[func](...args);

    res.json(result);
  } catch (error) {
    console.error("Error in /mqtt:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});
    
    app.get("/dash", (req, res) => {
    const key = req.query.key; // ?key=ALLOU77H
    if (key !== "azulfellak") {
        return res.status(403).send("Forbidden: Invalid key");
    }

    const htmlPath = path.join(__dirname, 'Html', 'index.html');
    res.sendFile(htmlPath);
});
    
  app.get("/", (req, res) => {
const htmlPath = path.join(__dirname, 'Html', 'upt.html');
    res.sendFile(htmlPath);
     });
	
	const PORT = config.dashBoard.port || config.serverUptime.port || 30152;
	await server.listen(PORT);
	utils.log.info("DASHBOARD", `Dashboard is running on port ${PORT}.`);
};
