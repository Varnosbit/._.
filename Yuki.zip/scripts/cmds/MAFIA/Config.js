module.exports = {
  InboxMode: false,
  
  gameSettings: {
    minPlayers: 4,
    maxPlayers: 18,
    joinTimeMs: 180000,
    joinReminderTimesMs: [90000, 150000],
    nightDurationMs: 40000,
    nightReminderMs: 30000,
    dayDurationMs: 60000,
    dayReminderMs: 30000,
    votingDurationMs: 60000,
    votingReminderMs: 30000,
    phaseTransitionDelayMs: 3000,
    actionDelayMs: 1500,
    maxGameAgeMs: 24 * 60 * 60 * 1000,
    cleanupIntervalMs: 60 * 60 * 1000
  },

  availableGroupIDs: [
    "10094252270604707", "29355635377353562", "9227752777260681", "9301459426611190",
    "28703348225980440", "9075587479230439", "28739924468985551", "9250352948406018",
    "9161676927293097", "29257925920465305", "9827690807250166", "9499591600061217",
    "9541738132550024", "9667704829927404", "9643655792353007", "9347203865375607",
    "29140870055503895", "9208772235908400", "9763741193660755", "9432637010133127"
  ],

  ROLES: {
    mafia: {
      team: "mafia",
      name: "مافيا",
      desc: "يقتل لاعباً كل ليلة في الظلام 🌙",
      night: true,
      canKill: true,
      priority: 5,
      emoji: "🔪",
      killsPerAbility: 2
    },
    godfather: {
      team: "mafia",
      name: "عراب المافيا",
      desc: "زعيم المافيا القوي، يظهر كمواطن للشرطي 🎭",
      night: true,
      canKill: true,
      disguised: true,
      priority: 5,
      emoji: "👔",
      killsPerAbility: 2
    },
    consigliere: {
      team: "mafia",
      name: "المستشار",
      desc: "يكتشف دور أي لاعب بدقة تامة كل ليلة 🎯",
      night: true,
      ability: "precise_check",
      priority: 8,
      emoji: "🎯"
    },
    framer: {
      team: "mafia",
      name: "المزور",
      desc: "يزور لاعباً ويجعله يظهر كمافيا للشرطي 😈",
      night: true,
      ability: "frame",
      priority: 7,
      emoji: "😈"
    },
    janitor: {
      team: "mafia",
      name: "عامل النظافة",
      desc: "يخفي دور الضحية بعد موتها 🧹",
      night: true,
      ability: "clean",
      uses: 2,
      priority: 4,
      emoji: "🧹"
    },
    blackmailer: {
      team: "mafia",
      name: "المبتز",
      desc: "يبتز لاعباً ويمنعه من الكلام والتصويت نهاراً 🤫",
      night: true,
      ability: "blackmail",
      priority: 3,
      uses: 2,
      emoji: "🤫"
    },
    cop: {
      team: "citizen",
      name: "شرطي",
      desc: "يفحص لاعباً كل ليلة ليعرف إذا كان مافيا أم لا 👮",
      night: true,
      ability: "investigate",
      priority: 8,
      emoji: "👮"
    },
    sheriff: {
      team: "citizen",
      name: "عمدة",
      desc: "يفحص لاعباً ويقتله فوراً إذا كان من المافيا ⭐",
      night: true,
      ability: "sheriff_check",
      priority: 6,
      emoji: "⭐"
    },
    doctor: {
      team: "citizen",
      name: "طبيب",
      desc: "يحمي لاعباً من محاولات القتل الليلية 💊",
      night: true,
      ability: "heal",
      priority: 6,
      emoji: "💊"
    },
    bodyguard: {
      team: "citizen",
      name: "حارس شخصي",
      desc: "يحمي لاعباً ويموت بدلاً منه إذا تعرض للقتل 🛡️",
      night: true,
      ability: "bodyguard",
      priority: 6,
      emoji: "🛡️"
    },
    vigilante: {
      team: "citizen",
      name: "حارس",
      desc: "يقتل لاعباً مشبوهاً ليلاً (استخدامات محدودة) 🔫",
      night: true,
      ability: "vigi_kill",
      uses: 2,
      priority: 5,
      emoji: "🔫"
    },
    veteran: {
      team: "citizen",
      name: "محارب قديم",
      desc: "يتحصن في منزله ويقتل كل من يزوره ⚔️",
      night: true,
      ability: "alert",
      uses: 3,
      priority: 10,
      emoji: "⚔️"
    },
    lookout: {
      team: "citizen",
      name: "مراقب",
      desc: "يراقب منزل لاعب ويرى كل من يزوره ليلاً 👁️",
      night: true,
      ability: "lookout",
      priority: 9,
      emoji: "👁️"
    },
    tracker: {
      team: "citizen",
      name: "متعقب",
      desc: "يتعقب لاعباً ليرى من زار في تلك الليلة 🔎",
      night: true,
      ability: "track",
      priority: 9,
      emoji: "🔎"
    },
    escort: {
      team: "citizen",
      name: "رقاصة",
      desc: "يشغل لاعباً طوال الليل ويمنعه من استخدام قدرته 💃",
      night: true,
      ability: "roleblock",
      priority: 2,
      emoji: "💃"
    },
    transporter: {
      team: "citizen",
      name: "ناقل",
      desc: "يبدل مكان لاعبين، كل من يزور أحدهما يزور الآخر 😂",
      night: true,
      ability: "transport",
      priority: 1,
      emoji: "🚗"
    },
    mayor: {
      team: "citizen",
      name: "رئيس البلدية",
      desc: "يكشف عن نفسه نهاراً وصوته يساوي 3 أصوات 🎖️",
      night: false,
      ability: "reveal",
      uses: 1,
      priority: 0,
      emoji: "🎖️"
    },
    spy: {
      team: "citizen",
      name: "جاسوس",
      desc: "يراقب المافيا ويرى من يفحصونه أو يستهدفونه 🕵️",
      night: true,
      ability: "spy",
      priority: 9,
      emoji: "🕵️"
    },
    crusader: {
      team: "citizen",
      name: "صليبي",
      desc: "يحرس لاعباً ويهاجم أي شخص يحاول إيذاءه ⚔️🛡️",
      night: true,
      ability: "crusade",
      priority: 7,
      emoji: "⚔️🛡️"
    },
    retributionist: {
      team: "citizen",
      name: "منتقم",
      desc: "يحيي لاعباً ميتاً ليستخدم قدرته مرة واحدة فقط 💀➡️",
      night: true,
      ability: "revive",
      uses: 1,
      priority: 8,
      emoji: "💀➡️"
    },
    trapper: {
      team: "citizen",
      name: "صياد",
      desc: "ينصب فخاً مميتاً على منزل لاعب 🪤",
      night: true,
      ability: "trap",
      priority: 8,
      emoji: "🪤"
    },
    psychic: {
      team: "citizen",
      name: "عراف",
      desc: "يرى رؤيا عن لاعبين، أحدهما شرير بالتأكيد 🔮",
      night: true,
      ability: "psychic_vision",
      priority: 9,
      emoji: "🔮"
    },
    medium: {
      team: "citizen",
      name: "وسيط روحي",
      desc: "يتحدث مع روح ميت عشوائي كل ليلة 👻",
      night: true,
      ability: "seance",
      priority: 0,
      emoji: "👻"
    },
    citizen: {
      team: "citizen",
      name: "مواطن",
      desc: "مواطن عادي يصوت ويحلل ويحاول كشف المافيا 👤",
      night: false,
      priority: 0,
      emoji: "👤"
    },
    jester: {
      team: "neutral",
      name: "جوكر",
      desc: "يفوز إذا تم إقصاؤه بالتصويت! الفوز بالخسارة 🤡",
      night: false,
      win_condition: "lynched",
      priority: 0,
      emoji: "🤡"
    },
    executioner: {
      team: "neutral",
      name: "جلاد",
      desc: "لديه هدف محدد، يفوز إذا تم إقصاء هدفه 🪓",
      night: false,
      win_condition: "target_lynched",
      priority: 0,
      emoji: "🪓"
    },
    witch: {
      team: "neutral",
      name: "ساحرة",
      desc: "تسيطر على لاعب وتجبره على استهدف شخص آخر 🧙",
      night: true,
      ability: "control",
      priority: 3,
      emoji: "🧙"
    },
    survivor: {
      team: "neutral",
      name: "ناجٍ",
      desc: "يفوز إذا بقي حياً حتى النهاية، لديه دروع واقية 🦺",
      night: true,
      ability: "vest",
      uses: 4,
      win_condition: "survive",
      priority: 6,
      emoji: "🦺"
    },
    arsonist: {
      team: "neutral",
      name: "حارق",
      desc: "يشعل اللاعبين واحداً تلو الآخر ثم يحرقهم جميعاً 🔥",
      night: true,
      ability: "douse",
      win_condition: "burn_all",
      priority: 5,
      emoji: "🔥"
    },
    serial_killer: {
      team: "neutral",
      name: "قاتل متسلسل",
      desc: "يقتل كل ليلة ولا يمكن إيقافه أبداً 🔪💀",
      night: true,
      ability: "sk_kill",
      win_condition: "last_alive",
      priority: 5,
      emoji: "🔪💀"
    },
    werewolf: {
      team: "neutral",
      name: "مستذئب",
      desc: "يهاجم في الليالي الفردية ويقتل الضحية وكل زواره 🐺",
      night: true,
      ability: "maul",
      win_condition: "last_alive",
      priority: 5,
      emoji: "🐺",
      uses: 2
    },
    amnesiac: {
      team: "neutral",
      name: "فاقد الذاكرة",
      desc: "يتذكر دور لاعب ميت ويصبح مثله تماماً ❓",
      night: true,
      ability: "remember",
      uses: 1,
      priority: 0,
      emoji: "❓"
    },
    vampire: {
      team: "vampire",
      name: "مصاص دماء",
      desc: "يحول لاعباً إلى مصاص دماء كل ليلتين 🧛",
      night: true,
      ability: "convert_vamp",
      win_condition: "vampire_majority",
      priority: 4,
      emoji: "🧛"
    },
    vampire_hunter: {
      team: "citizen",
      name: "صائد مصاصي الدماء",
      desc: "يفحص ويقتل مصاصي الدماء فوراً 🧄",
      night: true,
      ability: "vh_check",
      priority: 6,
      emoji: "🧄"
    }
  },

  SHOP_ITEMS: {
    extra_life: {
      name: "حياة إضافية",
      desc: "تحميك من الموت مرة واحدة فقط! استخدام تلقائي 💝",
      price: 5000,
      emoji: "❤️",
      type: "passive"
    },
    investigation: {
      name: "تحقيق خاص",
      desc: "اكتشف دور لاعب بدقة 100% في الليل 🔍",
      price: 3000,
      emoji: "🔍",
      type: "night"
    },
    protection: {
      name: "حماية شخصية",
      desc: "احمي نفسك من القتل ليلة واحدة 🛡️",
      price: 2500,
      emoji: "🛡️",
      type: "night"
    },
    vote_power: {
      name: "قوة تصويت",
      desc: "صوتك يساوي صوتين في التصويت القادم ⚡",
      price: 4000,
      emoji: "⚡",
      type: "day"
    },
    reveal_team: {
      name: "كشف الفريق",
      desc: "اعرف فريق لاعب (مافيا/مواطن/محايد) 👥",
      price: 3500,
      emoji: "👥",
      type: "night"
    },
    revive_self: {
      name: "إحياء ذاتي",
      desc: "تعود للحياة تلقائياً عند الموت مرة واحدة 💫",
      price: 8000,
      emoji: "💫",
      type: "passive"
    }
  },

  rewards: {
    win: { money: 2000, points: 200 },
    loss: { money: 0, points: 0 },
    survived: { money: 500, points: 50 },
    kill: { points: 8 },
    correctVote: { points: 5 },
    wrongVote: { points: -3 }
  },

  exchangeRate: 100,

  messages: {
    joinText: `🎭 مافيا | نسخة المسنجر 🤡
- المطور: fb.me/proarcoder
- إذا عمرك أرسلت لهذا البوت رسالة خاص و طلب صداقة فأرسل له الان و تعال ضع رياكشن هنا 🕴️ كي يضيفك في شات خاص بك و تلعب فيه :-:
- اذا البوت ليس صديقك في الفايسبوك فقد يكون الشات غالبا في طلبات المراسلة تفقده.
- اتبع تعليمات رسالتك التي تصلك في الشات و العب بذكاء و ليس كال🫏
- اللعبة باختصار هي فريق من المافيا و فريق من المواطنين هدف كل واحد منهم الفوز بقتل الاخر 🕴️🤡
- اللعبة فيها ادوار كثيرة ممتعة ضع رياكشن في هذه الرسالة بسرعة كي تلعب.
---> حط رياكشن 😠 ترا مجاني <---`,

    reminder90: (count) => `⏰ تبقى 90 ثانية للانضمام! ⏰
____________________________
👥 المنتظرون حالياً: ${count} لاعب
____________________________`,

    reminder30: (count) => `😠 باقي 30 ثانية فقط حط رياكشن هنا ⏰
____________________________
👥 المنتظرون حالياً: ${count} لاعب
____________________________`,

    gameStart: (playerCount, mafiaCount) => `🎉 بدأت اللعبة! استعدوا! 🎉
____________________________

👥 عدد اللاعبين: ${playerCount}
🔴 عدد المافيا: ${mafiaCount}
🎲 تم توزيع الأدوار عشوائياً!

____________________________

🌙 الليلة الأولى ستبدأ بعد 10 ثواني...
🤫 استعدوا للخداع والمكر! 😈`,

    nightPhase: (day) => `🌙 الليلة ${day} 🌙
____________________________
🌑 المافيا تتحرك في الظلام...
🔪 احذر من حولك!`,

    dayPhase: (day) => `☀️ النهار ${day} ☀️
____________________________
💬 وقت النقاش والتحليل
🕵️ ابحث عن المشبوهين!`,

    votingPhase: (day) => `🗳️ التصويت - اليوم ${day} 🗳️
____________________________
⚖️ من المشبوه؟
🎯 اختر بحكمة! و لا تصوت كال🫏 رجاءا`
  }
};
