const moment = require('moment');

function generateTransactionID() {
    const timestamp = Date.now().toString(36);
    const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `IKYU-${timestamp}-${randomPart}`;
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function calculateInterest(principal, rate, timeInDays) {
    if (!principal || principal <= 0 || timeInDays <= 0) return 0;
    const dailyRate = rate / 100;
    const compoundInterest = Math.floor(principal * Math.pow(1 + dailyRate, timeInDays) - principal);
    return Math.max(0, compoundInterest);
}

function calculateLoanPenalty(loanAmount, daysOverdue) {
    if (daysOverdue <= 0) return 0;
    const penaltyRate = 0.05;
    return Math.floor(loanAmount * penaltyRate * daysOverdue);
}

const BANK_CONFIG = {
    INTEREST_RATE: 2.5,
    MIN_DEPOSIT: 100,
    MIN_WITHDRAWAL: 50,
    MAX_LOAN_RATIO: 0.8,
    LOAN_INTEREST_RATE: 5,
    LOAN_DURATION_DAYS: 2,
    MAX_HISTORY_ENTRIES: 10,
    ACCOUNT_LEVELS: {
        BRONZE: { min: 0, max: 50000, bonus: 1.0 },
        SILVER: { min: 50001, max: 200000, bonus: 1.2 },
        GOLD: { min: 200001, max: 500000, bonus: 1.5 },
        PLATINUM: { min: 500001, max: Infinity, bonus: 2.0 }
    }
};

exports.config = {
    name: "bank",
    aliases: ["تخزين", "بنك", "banking"],
    by: "Allou Mohamed - Enhanced",
    version: "2.0.0",
    countDown: 5,
    role: 0,
    category: "Economy",
    guide: {
      usage: "Required",
      params: "amount, @user",
      syntax:
        "bank view\n" +
        "bank deposit [amount]\n" +
        "bank withdraw [amount]\n" +
        "bank loan [amount]\n" +
        "bank repay [amount]\n" +
        "bank history\n" +
        "bank leaderboard\n" +
        "bank transfer [amount] [@user]"
    }
};

exports.onStart = async (params) => {
    const { args, message, event, usersData } = params;
    const action = args[0]?.toLowerCase();

    try {
        await initializeBankData(event.senderID, usersData);

        switch (action) {
            case 'deposit':
            case 'إيداع':
                await handleDeposit(params);
                break;
            case 'withdraw':
            case 'سحب':
                await handleWithdraw(params);
                break;
            case 'info':
            case 'عرض':
            case 'balance':
                await showAccountInfo(params);
                break;
            case 'loan':
            case 'قرض':
                await handleLoan(params);
                break;
            case 'repay':
            case 'سداد':
                await handleLoanRepayment(params);
                break;
            case 'history':
            case 'تاريخ':
                await showTransactionHistory(params);
                break;
            case 'leaderboard':
            case 'الأغنى':
            case 'top':
                await showLeaderboard(params);
                break;
            case 'transfer':
            case 'تحويل':
                await handleTransfer(params);
                break;
            case 'help':
            case 'مساعدة':
                await showHelp(params);
                break;
            default:
                await showAccountInfo(params);
                break;
        }
    } catch (error) {
        console.error('Bank system error:', error);
        return message.reply("❌ | حدث خطأ في النظام البنكي. حاول مرة أخرى.");
    }
};

exports.onReply = async ({ commandName, message, api, usersData, role, args, event, Reply }) => {
    const { author, timestamp } = Reply;
    if (author !== event.senderID) return;

    if (Date.now() - timestamp > 180000) {
        return message.reply("⏰ | انتهت صلاحية هذه الرسالة. حاول مجددًا.");
    }

    try {
        const userMoney = await usersData.getMoney(event.senderID);
        const bankData = await getBankData(event.senderID, usersData);
        const replyText = event.body?.toLowerCase().trim();

        switch (Reply?.action) {
            case 'depositAll':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeDepositAll(event.senderID, userMoney, bankData, usersData, message);
                } else {
                    return message.reply("❌ | تم إلغاء العملية.");
                }
                break;
            case 'withdrawAll':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeWithdrawAll(event.senderID, bankData, usersData, message);
                } else {
                    return message.reply("❌ | تم إلغاء العملية.");
                }
                break;
            case 'confirmLoan':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeLoan(event.senderID, Reply.amount, bankData, usersData, message);
                } else {
                    return message.reply("❌ | تم إلغاء طلب القرض.");
                }
                break;
        }
    } catch (error) {
        console.error('Bank reply error:', error);
        return message.reply("❌ | حدث خطأ أثناء معالجة الرد.");
    }
};

async function initializeBankData(userID, usersData) {
    const bankData = await usersData.get(userID, "bank");
    if (!bankData.loan) {
        const initialData = {
            balance: 0,
            loan: {
                amount: 0,
                dueDate: null,
                interestRate: BANK_CONFIG.LOAN_INTEREST_RATE
            },
            lastInterestCalculation: null,
            history: [],
            accountLevel: 'BRONZE',
            totalEarned: 0,
            totalDeposited: 0,
            totalWithdrawn: 0,
            createdAt: Date.now()
        };
        await usersData.set(userID, initialData, "bank");
    }
}

async function getBankData(userID, usersData) {
    await initializeBankData(userID, usersData);
    return await usersData.get(userID, "bank");
}

function getAccountLevel(balance) {
    for (const [level, config] of Object.entries(BANK_CONFIG.ACCOUNT_LEVELS)) {
        if (balance >= config.min && balance <= config.max) {
            return level;
        }
    }
    return 'BRONZE';
}

function addTransactionToHistory(bankData, type, amount, details = '') {
    const transaction = {
        type,
        amount,
        details,
        date: moment().format('HH:mm:ss DD/MM/YYYY'),
        id: generateTransactionID()
    };
    
    bankData.history.unshift(transaction);
    if (bankData.history.length > BANK_CONFIG.MAX_HISTORY_ENTRIES) {
        bankData.history = bankData.history.slice(0, BANK_CONFIG.MAX_HISTORY_ENTRIES);
    }
}

async function handleDeposit({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const userMoney = await usersData.getMoney(event.senderID);
    const bankData = await getBankData(event.senderID, usersData);

    if (!amount || amount < BANK_CONFIG.MIN_DEPOSIT) {
        const { messageID } = await message.reply(
            `💰 | الحد الأدنى للإيداع هو ${formatNumber(BANK_CONFIG.MIN_DEPOSIT)}\n` +
            `💼 | رصيدك الحالي: ${formatNumber(userMoney)}\n` +
            `💬 | للقيام بإيداع كل رصيدك، رد بـ 'نعم'`
        );
        
        const Reply = {
            commandName: 'bank',
            action: "depositAll",
            author: event.senderID,
            timestamp: Date.now()
        };
        global.YukiBot.onReply.set(messageID, Reply);
        return;
    }

    if (amount > userMoney) {
        return message.reply(`❌ | رصيدك غير كافي!\n💼 | رصيدك الحالي: ${formatNumber(userMoney)}`);
    }

    await executeDeposit(event.senderID, amount, bankData, usersData, message);
}

async function executeDeposit(userID, amount, bankData, usersData, message) {
    await usersData.subtractMoney(userID, amount);
    bankData.balance += amount;
    bankData.totalDeposited += amount;
    
    if (!bankData.lastInterestCalculation) {
        bankData.lastInterestCalculation = Date.now();
    }
    
    const newLevel = getAccountLevel(bankData.balance);
    const levelChanged = newLevel !== bankData.accountLevel;
    bankData.accountLevel = newLevel;
    
    addTransactionToHistory(bankData, 'إيداع', amount, `إيداع مبلغ ${formatNumber(amount)}`);
    
    await usersData.set(userID, bankData, "bank");
    
    let response = `✅ | تم الإيداع بنجاح!\n` +
                  `💸 | المبلغ المودع: ${formatNumber(amount)}\n` +
                  `🏦 | الرصيد البنكي: ${formatNumber(bankData.balance)}\n` +
                  `👛 | الرصيد الخارجي: ${formatNumber(await usersData.getMoney(userID))}\n` +
                  `⭐ | مستوى الحساب: ${bankData.accountLevel}`;
    
    if (levelChanged) {
        response += `\n🎉 | تهانينا! تم ترقية حسابك إلى مستوى ${newLevel}!`;
    }
    
    return message.reply(response);
}

async function executeDepositAll(userID, amount, bankData, usersData, message) {
    if (amount < BANK_CONFIG.MIN_DEPOSIT) {
        return message.reply(`❌ | يجب أن يكون لديك على الأقل ${formatNumber(BANK_CONFIG.MIN_DEPOSIT)} لإيداع كل الرصيد.`);
    }
    
    await executeDeposit(userID, amount, bankData, usersData, message);
}

async function handleWithdraw({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const bankData = await getBankData(event.senderID, usersData);

    if (!amount || amount < BANK_CONFIG.MIN_WITHDRAWAL) {
        const { messageID } = await message.reply(
            `💰 | الحد الأدنى للسحب هو ${formatNumber(BANK_CONFIG.MIN_WITHDRAWAL)}\n` +
            `🏦 | رصيدك البنكي: ${formatNumber(bankData.balance)}\n` +
            `💬 | لسحب كل رصيدك البنكي، رد بـ 'نعم'`
        );
        
        const Reply = {
            commandName: 'bank',
            action: "withdrawAll",
            author: event.senderID,
            timestamp: Date.now()
        };
        global.YukiBot.onReply.set(messageID, Reply);
        return;
    }

    if (amount > bankData.balance) {
        return message.reply(`❌ | رصيدك البنكي غير كافي!\n🏦 | رصيدك البنكي: ${formatNumber(bankData.balance)}`);
    }

    await executeWithdraw(event.senderID, amount, bankData, usersData, message);
}

async function executeWithdraw(userID, amount, bankData, usersData, message) {
    const interest = calculateAccumulatedInterest(bankData);
    
    await usersData.addMoney(userID, amount + interest);
    bankData.balance -= amount;
    bankData.totalWithdrawn += amount;
    bankData.totalEarned += interest;
    bankData.lastInterestCalculation = Date.now();
    
    addTransactionToHistory(bankData, 'سحب', amount, `سحب مبلغ ${formatNumber(amount)} + فوائد ${formatNumber(interest)}`);
    
    await usersData.set(userID, bankData, "bank");
    
    const response = `✅ | تم السحب بنجاح!\n` +
                    `💸 | المبلغ المسحوب: ${formatNumber(amount)}\n` +
                    `✨ | الفوائد المضافة: ${formatNumber(interest)}\n` +
                    `🏦 | الرصيد البنكي: ${formatNumber(bankData.balance)}\n` +
                    `👛 | الرصيد الخارجي: ${formatNumber(await usersData.getMoney(userID))}`;
    
    return message.reply(response);
}

async function executeWithdrawAll(userID, bankData, usersData, message) {
    if (bankData.balance <= 0) {
        return message.reply("❌ | لا يوجد رصيد للسحب!");
    }
    
    await executeWithdraw(userID, bankData.balance, bankData, usersData, message);
}

function calculateAccumulatedInterest(bankData) {
    if (!bankData.lastInterestCalculation || bankData.balance <= 0) return 0;
    
    const daysSinceLastCalculation = moment().diff(moment(bankData.lastInterestCalculation), 'days', true);
    const levelBonus = BANK_CONFIG.ACCOUNT_LEVELS[bankData.accountLevel]?.bonus || 1.0;
    const effectiveRate = BANK_CONFIG.INTEREST_RATE * levelBonus;
    
    return calculateInterest(bankData.balance, effectiveRate, daysSinceLastCalculation);
}

async function handleLoan({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const bankData = await getBankData(event.senderID, usersData);
    
    if (bankData?.loan?.amount > 0) {
        const daysOverdue = moment().diff(moment(bankData.loan.dueDate), 'days');
        const penalty = calculateLoanPenalty(bankData.loan.amount, Math.max(0, daysOverdue));
        const totalOwed = bankData.loan.amount + penalty;
        
        return message.reply(
            `❌ | لديك قرض مستحق بالفعل!\n` +
            `💸 | مبلغ القرض: ${formatNumber(bankData.loan.amount)}\n` +
            `⚠️ | الغرامة: ${formatNumber(penalty)}\n` +
            `💰 | المبلغ الإجمالي: ${formatNumber(totalOwed)}\n` +
            `📅 | تاريخ الاستحقاق: ${moment(bankData.loan.dueDate).format('DD/MM/YYYY')}\n` +
            `💡 | استخدم "بنك سداد ${totalOwed}" لسداد القرض`
        );
    }
    
    const maxLoanAmount = Math.floor(bankData.balance * BANK_CONFIG.MAX_LOAN_RATIO);
    
    if (!amount || amount <= 0) {
        return message.reply(
            `💰 | أدخل مبلغ القرض المطلوب\n` +
            `📊 | الحد الأقصى للقرض: ${formatNumber(maxLoanAmount)}\n` +
            `📈 | معدل الفائدة: ${BANK_CONFIG.LOAN_INTEREST_RATE}% يومياً\n` +
            `⏰ | مدة السداد: ${BANK_CONFIG.LOAN_DURATION_DAYS} أيام`
        );
    }
    
    if (amount > maxLoanAmount) {
        return message.reply(
            `❌ | لا يمكنك اقتراض أكثر من ${formatNumber(maxLoanAmount)}\n` +
            `💡 | قم بزيادة رصيدك البنكي للحصول على قروض أكبر`
        );
    }
    
    const interestAmount = Math.floor(amount * (BANK_CONFIG.LOAN_INTEREST_RATE / 100) * BANK_CONFIG.LOAN_DURATION_DAYS);
    const totalRepayment = amount + interestAmount;
    const dueDate = moment().add(BANK_CONFIG.LOAN_DURATION_DAYS, 'days');
    
    const { messageID } = await message.reply(
        `📋 | تفاصيل القرض:\n` +
        `💸 | مبلغ القرض: ${formatNumber(amount)}\n` +
        `📈 | الفوائد: ${formatNumber(interestAmount)}\n` +
        `💰 | إجمالي السداد: ${formatNumber(totalRepayment)}\n` +
        `📅 | تاريخ الاستحقاق: ${dueDate.format('DD/MM/YYYY HH:mm')}\n` +
        `⚠️ | غرامة التأخير: 5% يومياً\n\n` +
        `💬 | هل توافق على شروط القرض؟ رد بـ 'نعم' للموافقة`
    );
    
    const Reply = {
        commandName: 'bank',
        action: "confirmLoan",
        amount: amount,
        author: event.senderID,
        timestamp: Date.now()
    };
    global.YukiBot.onReply.set(messageID, Reply);
}

async function executeLoan(userID, amount, bankData, usersData, message) {
    const dueDate = moment().add(BANK_CONFIG.LOAN_DURATION_DAYS, 'days');
    
    await usersData.addMoney(userID, amount);
    
    bankData.loan = {
        amount: amount,
        originalAmount: amount,
        dueDate: dueDate.toISOString(),
        interestRate: BANK_CONFIG.LOAN_INTEREST_RATE,
        takenAt: Date.now()
    };
    
    addTransactionToHistory(bankData, 'قرض', amount, `قرض بمبلغ ${formatNumber(amount)} - استحقاق ${dueDate.format('DD/MM/YYYY')}`);
    
    await usersData.set(userID, bankData, "bank");
    
    return message.reply(
        `✅ | تم منح القرض بنجاح!\n` +
        `💸 | مبلغ القرض: ${formatNumber(amount)}\n` +
        `📅 | تاريخ الاستحقاق: ${dueDate.format('DD/MM/YYYY HH:mm')}\n` +
        `👛 | رصيدك الحالي: ${formatNumber(await usersData.getMoney(userID))}\n` +
        `⚠️ | تذكر: غرامة 5% يومياً عند التأخير!`
    );
}

async function handleLoanRepayment({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const bankData = await getBankData(event.senderID, usersData);
    const userMoney = await usersData.getMoney(event.senderID);
    
    if (bankData?.loan?.amount <= 0) {
        return message.reply("✅ | ليس لديك أي قروض مستحقة!");
    }
    
    const daysOverdue = moment().diff(moment(bankData.loan.dueDate), 'days');
    const penalty = calculateLoanPenalty(bankData.loan.amount, Math.max(0, daysOverdue));
    const totalOwed = bankData.loan.amount + penalty;
    
    if (!amount || amount <= 0) {
        return message.reply(
            `💰 | أدخل مبلغ السداد\n` +
            `💸 | مبلغ القرض الأصلي: ${formatNumber(bankData.loan.amount)}\n` +
            `⚠️ | الغرامة: ${formatNumber(penalty)}\n` +
            `💰 | المبلغ الإجمالي المطلوب: ${formatNumber(totalOwed)}\n` +
            `👛 | رصيدك الحالي: ${formatNumber(userMoney)}`
        );
    }
    
    if (amount > userMoney) {
        return message.reply(`❌ | رصيدك غير كافي للسداد!\n👛 | رصيدك الحالي: ${formatNumber(userMoney)}`);
    }
    
    await usersData.subtractMoney(event.senderID, amount);
    
    const remainingDebt = Math.max(0, totalOwed - amount);
    
    if (remainingDebt <= 0) {
        const overpayment = amount - totalOwed;
        if (overpayment > 0) {
            await usersData.addMoney(event.senderID, overpayment);
        }
        
        bankData.loan = { amount: 0, dueDate: null, interestRate: 0 };
        addTransactionToHistory(bankData, 'سداد', totalOwed, `سداد كامل للقرض + غرامة ${formatNumber(penalty)}`);
        
        await usersData.set(event.senderID, bankData, "bank");
        
        let response = `✅ | تم سداد القرض بالكامل!\n💸 | المبلغ المدفوع: ${formatNumber(totalOwed)}`;
        if (overpayment > 0) {
            response += `\n💰 | المبلغ الإضافي المسترد: ${formatNumber(overpayment)}`;
        }
        response += `\n👛 | رصيدك الحالي: ${formatNumber(await usersData.getMoney(event.senderID))}`;
        
        return message.reply(response);
    } else {
        bankData.loan.amount = remainingDebt;
        addTransactionToHistory(bankData, 'سداد جزئي', amount, `سداد جزئي - متبقي ${formatNumber(remainingDebt)}`);
        
        await usersData.set(event.senderID, bankData, "bank");
        
        return message.reply(
            `💰 | تم السداد الجزئي\n` +
            `💸 | المبلغ المدفوع: ${formatNumber(amount)}\n` +
            `⚠️ | المبلغ المتبقي: ${formatNumber(remainingDebt)}\n` +
            `👛 | رصيدك الحالي: ${formatNumber(await usersData.getMoney(event.senderID))}`
        );
    }
}

async function handleTransfer({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const targetUserMention = args[2];
    
    if (!amount || amount <= 0) {
        return message.reply("💰 | أدخل مبلغ التحويل\n📝 | مثال: بنك تحويل 1000 @المستخدم");
    }
    
    if (!targetUserMention || !targetUserMention.includes('@')) {
        return message.reply("👤 | قم بمنشن المستخدم المراد التحويل إليه\n📝 | مثال: بنك تحويل 1000 @المستخدم");
    }
    
    const targetUserID = targetUserMention.replace('@', '');
    
    if (targetUserID === event.senderID) {
        return message.reply("❌ | لا يمكنك تحويل المال لنفسك!");
    }
    
    const senderBankData = await getBankData(event.senderID, usersData);
    const transferFee = Math.max(100, Math.floor(amount * 0.02));
    const totalDeduction = amount + transferFee;
    
    if (senderBankData.balance < totalDeduction) {
        return message.reply(
            `❌ | رصيدك البنكي غير كافي!\n` +
            `💸 | مبلغ التحويل: ${formatNumber(amount)}\n` +
            `💳 | رسوم التحويل: ${formatNumber(transferFee)}\n` +
            `💰 | المطلوب: ${formatNumber(totalDeduction)}\n` +
            `🏦 | رصيدك البنكي: ${formatNumber(senderBankData.balance)}`
        );
    }
    
    try {
        const targetBankData = await getBankData(targetUserID, usersData);
        
        senderBankData.balance -= totalDeduction;
        targetBankData.balance += amount;
        
        addTransactionToHistory(senderBankData, 'تحويل صادر', totalDeduction, `تحويل ${formatNumber(amount)} + رسوم ${formatNumber(transferFee)}`);
        addTransactionToHistory(targetBankData, 'تحويل وارد', amount, `استلام تحويل ${formatNumber(amount)}`);
        
        await usersData.set(event.senderID, senderBankData, "bank");
        await usersData.set(targetUserID, targetBankData, "bank");
        
        return message.reply(
            `✅ | تم التحويل بنجاح!\n` +
            `💸 | المبلغ المحول: ${formatNumber(amount)}\n` +
            `💳 | رسوم التحويل: ${formatNumber(transferFee)}\n` +
            `🏦 | رصيدك البنكي: ${formatNumber(senderBankData.balance)}`
        );
        
    } catch (error) {
        return message.reply("❌ | المستخدم المحدد غير موجود أو لم يفعل النظام البنكي بعد.");
    }
}

// Missing functions for the bank system

async function showTransactionHistory({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    
    if (!bankData.history || bankData.history.length === 0) {
        return message.reply("📝 | لا توجد معاملات سابقة في حسابك البنكي.");
    }
    
    let historyText = `📋 | سجل المعاملات البنكية\n━━━━━━━━━━━━━━━━━━━━\n`;
    
    bankData.history.forEach((transaction, index) => {
        const typeEmoji = getTransactionEmoji(transaction.type);
        historyText += `${typeEmoji} | ${transaction.type}: ${formatNumber(transaction.amount)}\n`;
        historyText += `📅 | ${transaction.date}\n`;
        if (transaction.details) {
            historyText += `📝 | ${transaction.details}\n`;
        }
        historyText += `🆔 | ${transaction.id}\n`;
        if (index < bankData.history.length - 1) {
            historyText += `━━━━━━━━━━━━━━━━━━━━\n`;
        }
    });
    
    return message.reply(historyText);
}

async function showLeaderboard({ message, usersData }) {
    try {
        // Get all users data (this might need to be adjusted based on your usersData implementation)
        const allUsers = await usersData.getAll();
        const bankAccounts = [];
        
        for (const [userID, userData] of Object.entries(allUsers)) {
            if (userData.bank && userData.bank.balance > 0) {
                const interest = calculateAccumulatedInterest(userData.bank);
                bankAccounts.push({
                    userID,
                    balance: userData.bank.balance + interest,
                    level: userData.bank.accountLevel || 'BRONZE',
                    name: userData.name || `المستخدم ${userID.slice(-4)}`
                });
            }
        }
        
        if (bankAccounts.length === 0) {
            return message.reply("📊 | لا توجد حسابات بنكية نشطة حالياً!");
        }
        
        // Sort by balance descending
        bankAccounts.sort((a, b) => b.balance - a.balance);
        
        // Take top 10
        const top10 = bankAccounts.slice(0, 10);
        
        let leaderboardText = `🏆 | قائمة أغنى الحسابات البنكية\n━━━━━━━━━━━━━━━━━━━━\n`;
        
        top10.forEach((account, index) => {
            const medal = getMedalEmoji(index);
            const levelEmoji = getLevelEmoji(account.level);
            leaderboardText += `${medal} | ${account.name}\n`;
            leaderboardText += `💰 | ${formatNumber(account.balance)} ${levelEmoji}\n`;
            if (index < top10.length - 1) {
                leaderboardText += `━━━━━━━━━━━━━━━━━━━━\n`;
            }
        });
        
        return message.reply(leaderboardText);
        
    } catch (error) {
        console.error('Leaderboard error:', error);
        return message.reply("❌ | حدث خطأ أثناء عرض قائمة الأغنياء.");
    }
}

async function showHelp({ message }) {
    const helpText = `
🏦 | دليل النظام البنكي
━━━━━━━━━━━━━━━━━━━━
💰 | الأوامر الأساسية:
• بنك عرض - عرض معلومات حسابك
• بنك إيداع [المبلغ] - إيداع المال
• بنك سحب [المبلغ] - سحب المال + الفوائد
• بنك تاريخ - عرض سجل المعاملات

💳 | أوامر القروض:
• بنك قرض [المبلغ] - طلب قرض
• بنك سداد [المبلغ] - سداد القرض

🔄 | أوامر أخرى:
• بنك تحويل [المبلغ] [@المستخدم] - تحويل المال
• بنك الأغنى - قائمة أغنى الحسابات
• بنك مساعدة - عرض هذا الدليل

━━━━━━━━━━━━━━━━━━━━
📊 | مستويات الحسابات:
🥉 برونزي: 0 - 50,000 (فائدة 2.5%)
🥈 فضي: 50,001 - 200,000 (فائدة 3%)
🥇 ذهبي: 200,001 - 500,000 (فائدة 3.75%)
💎 بلاتيني: 500,001+ (فائدة 5%)

💡 | ملاحظات:
• الفوائد تحسب يومياً ومركبة
• القروض تستحق خلال 7 أيام
• غرامة التأخير 5% يومياً
• رسوم التحويل 2% (أدنى 100)
`;
    
    return message.reply(helpText);
}

// Helper functions
function getTransactionEmoji(type) {
    const emojis = {
        'إيداع': '💰',
        'سحب': '💸',
        'قرض': '💳',
        'سداد': '💵',
        'سداد جزئي': '💴',
        'تحويل صادر': '📤',
        'تحويل وارد': '📥'
    };
    return emojis[type] || '💱';
}

function getMedalEmoji(index) {
    const medals = ['🥇', '🥈', '🥉'];
    return medals[index] || `${index + 1}️⃣`;
}

function getLevelEmoji(level) {
    const levelEmojis = {
        'BRONZE': '🥉',
        'SILVER': '🥈',
        'GOLD': '🥇',
        'PLATINUM': '💎'
    };
    return levelEmojis[level] || '🥉';
}

// Fix the incomplete showAccountInfo function
async function showAccountInfo({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    const userMoney = await usersData.getMoney(event.senderID);
    const interest = calculateAccumulatedInterest(bankData);
    
    let loanStatus = "";
    if (bankData?.loan?.amount > 0) {
        const daysOverdue = moment().diff(moment(bankData.loan.dueDate), 'days');
        const penalty = calculateLoanPenalty(bankData.loan.amount, Math.max(0, daysOverdue));
        const totalOwed = bankData.loan.amount + penalty;
        
        loanStatus = `\n🚨 | القرض المستحق: ${formatNumber(totalOwed)}`;
        if (daysOverdue > 0) {
            loanStatus += `\n⚠️ | متأخر: ${daysOverdue} يوم - غرامة: ${formatNumber(penalty)}`;
        }
    }
    
    const levelBonus = BANK_CONFIG.ACCOUNT_LEVELS[bankData.accountLevel]?.bonus || 1.0;
    const effectiveRate = BANK_CONFIG.INTEREST_RATE * levelBonus;
    const levelEmoji = getLevelEmoji(bankData.accountLevel);
    
    const accountInfo = `
🏦 | حسابك البنكي - مستوى ${bankData.accountLevel} ${levelEmoji}
━━━━━━━━━━━━━━━━━━━━
💰 | الرصيد البنكي: ${formatNumber(bankData.balance)}
👛 | الرصيد الخارجي: ${formatNumber(userMoney)}
✨ | الفوائد المتراكمة: ${formatNumber(interest)}
📈 | معدل الفائدة: ${effectiveRate}% يومياً${loanStatus}
━━━━━━━━━━━━━━━━━━━━
📊 | إحصائيات الحساب:
💵 | إجمالي الإيداعات: ${formatNumber(bankData.totalDeposited)}
💸 | إجمالي السحوبات: ${formatNumber(bankData.totalWithdrawn)}
💎 | إجمالي الأرباح: ${formatNumber(bankData.totalEarned)}
📅 | تاريخ الإنشاء: ${moment(bankData.createdAt).format('DD/MM/YYYY')}
━━━━━━━━━━━━━━━━━━━━
💡 | استخدم "بنك مساعدة" لعرض جميع الأوامر
`;
    
    return message.reply(accountInfo);
}
