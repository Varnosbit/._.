const responses = [
  "أراك شخصًا مليئًا بالطاقة الإيجابية ✨",
  "أشعر أنك تبحث عن الحقيقة دائمًا 🔍",
  "تبدو لي كإنسان طموح جدًا 🚀",
  "أراك صادقًا مع نفسك ومع الآخرين 🤝",
  "أشعر أنك تحمل قلبًا طيبًا 💙",
  "تبدو وكأنك تفكر بعمق في كل شيء 🌌",
  "أراك قويًا رغم كل التحديات 💪"
];

module.exports = {
  config: {
    name: "howuseeme",
    role: 0,
    countDown: 5,
    guide: {
      syntax: "كيف تراني",
      params: "none",
      usage: "Easter egg command triggered by saying كيف تراني"
    },
    description: "A hidden easter egg command that replies with random Arabic text.",
    version: "1.0.0"
  },

  onStart: async ({ message, args }) => {
    // empty
  },

  onChat: async ({ event, message, args }) => {
    if (event.body && event.body.trim() === "كيف تراني") {
      const replyText = responses[Math.floor(Math.random() * responses.length)];
      return message.reply(replyText);
    }
  }
};
