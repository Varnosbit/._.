const { getStreamFromURL } = global.utils;
const { top4top } = helpers;

module.exports = {
	config: {
		name: "antichangeinfobox",
		aliases: ["حماية"],
		version: "2.0",
		author: "allou mohamed",
		countDown: 5,
		role: 0,
		description: {
			en: "Turn on/off anti change info box",
			ar: "تفعيل/إيقاف حماية معلومات المجموعة"
		},
		category: "box chat",
		guide: {
			en: " {pn} avt [on | off]: anti change avatar box chat"
				+ "\n {pn} name [on | off]: anti change name box chat"
				+ "\n {pn} nickname [on | off]: anti change nickname in box chat"
				+ "\n {pn} theme [on | off]: anti change theme (chủ đề) box chat"
				+ "\n {pn} emoji [on | off]: anti change emoji box chat"
				+ "\n\n Or use {pn} to see list and toggle protections",
			ar: " {pn} avt [on | off]: حماية صورة المجموعة"
				+ "\n {pn} name [on | off]: حماية اسم المجموعة"
				+ "\n {pn} nickname [on | off]: حماية الألقاب في المجموعة"
				+ "\n {pn} theme [on | off]: حماية ثيم المجموعة"
				+ "\n {pn} emoji [on | off]: حماية إيموجي المجموعة"
				+ "\n\n أو استخدم {pn} لعرض القائمة وتبديل الحماية"
		},
	},

	langs: {
		en: {
			antiChangeAvatarOn: "Turn on anti change avatar box chat",
			antiChangeAvatarOff: "Turn off anti change avatar box chat",
			missingAvt: "You have not set avatar for box chat",
			antiChangeNameOn: "Turn on anti change name box chat",
			antiChangeNameOff: "Turn off anti change name box chat",
			antiChangeNicknameOn: "Turn on anti change nickname box chat",
			antiChangeNicknameOff: "Turn off anti change nickname box chat",
			antiChangeThemeOn: "Turn on anti change theme box chat",
			antiChangeThemeOff: "Turn off anti change theme box chat",
			antiChangeEmojiOn: "Turn on anti change emoji box chat",
			antiChangeEmojiOff: "Turn off anti change emoji box chat",
			antiChangeAvatarAlreadyOn: "Your box chat is currently on anti change avatar",
			antiChangeAvatarAlreadyOnButMissingAvt: "Your box chat is currently on anti change avatar but your box chat has not set avatar",
			antiChangeNameAlreadyOn: "Your box chat is currently on anti change name",
			antiChangeNicknameAlreadyOn: "Your box chat is currently on anti change nickname",
			antiChangeThemeAlreadyOn: "Your box chat is currently on anti change theme",
			antiChangeEmojiAlreadyOn: "Your box chat is currently on anti change emoji",
			protectionList: "🛡️ Group Protection Settings\n__________________\n\n{list}\n\n💡 Reply with numbers to toggle (e.g., 1 3 5)\n⚠️ React to this message to save settings",
			protectionUpdated: "✅ Protection settings updated!\n\n{list}\n\n💡 Reply with numbers to toggle more\n⚠️ React to this message to save settings",
			settingsSaved: "✅ Protection settings saved successfully!",
			invalidNumbers: "❌ Invalid numbers. Please reply with valid numbers (1-5)",
			noAvatar: "⚠️ Cannot enable avatar protection: Group has no avatar set"
		},
		ar: {
			antiChangeAvatarOn: "تم تفعيل حماية صورة المجموعة",
			antiChangeAvatarOff: "تم إيقاف حماية صورة المجموعة",
			missingAvt: "لم يتم تعيين صورة للمجموعة",
			antiChangeNameOn: "تم تفعيل حماية اسم المجموعة",
			antiChangeNameOff: "تم إيقاف حماية اسم المجموعة",
			antiChangeNicknameOn: "تم تفعيل حماية الألقاب في المجموعة",
			antiChangeNicknameOff: "تم إيقاف حماية الألقاب في المجموعة",
			antiChangeThemeOn: "تم تفعيل حماية ثيم المجموعة",
			antiChangeThemeOff: "تم إيقاف حماية ثيم المجموعة",
			antiChangeEmojiOn: "تم تفعيل حماية إيموجي المجموعة",
			antiChangeEmojiOff: "تم إيقاف حماية إيموجي المجموعة",
			antiChangeAvatarAlreadyOn: "حماية صورة المجموعة مفعلة حالياً",
			antiChangeAvatarAlreadyOnButMissingAvt: "حماية صورة المجموعة مفعلة ولكن المجموعة لا تحتوي على صورة",
			antiChangeNameAlreadyOn: "حماية اسم المجموعة مفعلة حالياً",
			antiChangeNicknameAlreadyOn: "حماية الألقاب مفعلة حالياً",
			antiChangeThemeAlreadyOn: "حماية الثيم مفعلة حالياً",
			antiChangeEmojiAlreadyOn: "حماية الإيموجي مفعلة حالياً",
			protectionList: "🛡️ إعدادات حماية المجموعة\n________________\n\n{list}\n\n--> رد بالأرقام للتبديل",
			protectionUpdated: "✅ تم تحديث إعدادات الحماية!\n\n{list}\n\n--> رد بالأرقام للتبديل أكثر",
			settingsSaved: "✅ تم حفظ إعدادات الحماية بنجاح!",
			invalidNumbers: "❌ أرقام غير صحيحة. الرجاء الرد بأرقام صحيحة (1-5)",
			noAvatar: "⚠️ لا يمكن تفعيل حماية الصورة: المجموعة لا تحتوي على صورة"
		}
	},

	onStart: async function ({ message, event, args, threadsData, getLang, commandName }) {
		const { threadID } = event;
	
		if (args.length === 0) {
			const dataAntiChangeInfoBox = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
			const threadData = await threadsData.get(threadID);
			
			// Get language code to determine labels
			const langCode = getLang("antiChangeAvatarOn").includes("Turn") ? "en" : "ar";
			
			const protections = [
				{ key: "avatar", label: langCode === "en" ? "Group Image" : "صورة المجموعة", hasData: !!threadData.imageSrc },
				{ key: "name", label: langCode === "en" ? "Group Name" : "اسم المجموعة", hasData: true },
				{ key: "nickname", label: langCode === "en" ? "Nicknames" : "الألقاب", hasData: true },
				{ key: "theme", label: langCode === "en" ? "Group Theme" : "ثيم المجموعة", hasData: true },
				{ key: "emoji", label: langCode === "en" ? "Group Emoji" : "إيموجي المجموعة", hasData: true }
			];
			
			const listText = protections.map((p, i) => {
				const status = dataAntiChangeInfoBox[p.key] ? "✅" : "❌";
				return `${i + 1}. [ ${status} ] ${p.label}`;
			}).join("\n");
			
			const replyMsg = await message.reply(getLang("protectionList").replace("{list}", listText));
			
			// Initialize with empty pendingChanges object
			global.YamiBot.onReply.set(replyMsg.messageID, {
				commandName,
				messageID: replyMsg.messageID,
				author: event.senderID,
				type: "toggleProtection",
				pendingChanges: {} // Fixed: Initialize pendingChanges here
			});
			
			return;
		}
	
		if (!["on", "off"].includes(args[1]))
			return message.SyntaxError();
		
		const dataAntiChangeInfoBox = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
		async function checkAndSaveData(key, data) {
			if (args[1] === "off")
				delete dataAntiChangeInfoBox[key];
			else
				dataAntiChangeInfoBox[key] = data;

			await threadsData.set(threadID, dataAntiChangeInfoBox, "data.antiChangeInfoBox");
			message.reply(getLang(`antiChange${key.slice(0, 1).toUpperCase()}${key.slice(1)}${args[1].slice(0, 1).toUpperCase()}${args[1].slice(1)}`));
		}
		switch (args[0]) {
			case "avt":
			case "avatar":
			case "image": {
				const { imageSrc } = await threadsData.get(threadID);
				if (!imageSrc)
					return message.reply(getLang("missingAvt"));
				const newImageSrc = await uploadImgbb(imageSrc);
				await checkAndSaveData("avatar", newImageSrc.image.url);
				break;
			}
			case "name": {
				const { threadName } = await threadsData.get(threadID);
				await checkAndSaveData("name", threadName);
				break;
			}
			case "nickname": {
				const { members } = await threadsData.get(threadID);
				await checkAndSaveData("nickname", members.map(user => ({ [user.userID]: user.nickname })).reduce((a, b) => ({ ...a, ...b }), {}));
				break;
			}
			case "theme": {
				const { threadThemeID } = await threadsData.get(threadID);
				await checkAndSaveData("theme", threadThemeID);
				break;
			}
			case "emoji": {
				const { emoji } = await threadsData.get(threadID);
				await checkAndSaveData("emoji", emoji);
				break;
			}
			default: {
				return message.SyntaxError();
			}
		}
	},

	onReply: async function ({ message, event, Reply, threadsData, getLang, api, commandName, args }) {
		const { threadID, messageReply, senderID } = event;
		
		if (Reply.author !== senderID)
			return;
		
		if (Reply.type === "toggleProtection") {
			const numbers = args.join(" ").split(/\s+/).map(n => parseInt(n));
			const validNumbers = numbers.filter(n => n >= 1 && n <= 5);
			
			if (validNumbers.length === 0)
				return message.reply(getLang("invalidNumbers"));
			
			// Fixed: Now properly initialized in onStart
			const pendingChanges = Reply.pendingChanges || {};
			const threadData = await threadsData.get(threadID);
			const dataAntiChangeInfoBox = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
			
			const protectionKeys = ["avatar", "name", "nickname", "theme", "emoji"];
			
			for (const num of validNumbers) {
				const key = protectionKeys[num - 1];
				
				// Check if this protection is currently enabled in database
				const currentlyEnabled = !!dataAntiChangeInfoBox[key];
				
				// Check if it's in pending changes
				const inPending = pendingChanges.hasOwnProperty(key);
				
				if (inPending) {
					// Remove from pending (toggle off the pending change)
					delete pendingChanges[key];
				} else {
					// Add to pending changes
					let data;
					switch (key) {
						case "avatar":
							if (!threadData.imageSrc) {
								message.reply(getLang("noAvatar"));
								continue;
							}
							const newImageSrc = await top4top(threadData.imageSrc);
							data = newImageSrc;
							break;
						case "name":
							data = threadData.threadName;
							break;
						case "nickname":
							data = threadData.members.map(user => ({ [user.userID]: user.nickname })).reduce((a, b) => ({ ...a, ...b }), {});
							break;
						case "theme":
							data = threadData.threadThemeID;
							break;
						case "emoji":
							data = threadData.emoji;
							break;
					}
					
					// Mark for toggling
					if (currentlyEnabled) {
						// Currently ON, so pending change is to turn OFF
						pendingChanges[key] = null; // null means delete
					} else {
						// Currently OFF, so pending change is to turn ON
						pendingChanges[key] = data;
					}
				}
			}
			
			// Get language code to determine labels
			const langCode = getLang("antiChangeAvatarOn").includes("Turn") ? "en" : "ar";
			
			const protections = [
				{ key: "avatar", label: langCode === "en" ? "Group Image" : "صورة المجموعة" },
				{ key: "name", label: langCode === "en" ? "Group Name" : "اسم المجموعة" },
				{ key: "nickname", label: langCode === "en" ? "Nicknames" : "الألقاب" },
				{ key: "theme", label: langCode === "en" ? "Group Theme" : "ثيم المجموعة" },
				{ key: "emoji", label: langCode === "en" ? "Group Emoji" : "إيموجي المجموعة" }
			];
			
			// Fixed: Correct logic for determining final status
			const listText = protections.map((p, i) => {
				const currentlyEnabled = !!dataAntiChangeInfoBox[p.key];
				const hasPendingChange = pendingChanges.hasOwnProperty(p.key);
				
				let willBeEnabled;
				if (hasPendingChange) {
					// There's a pending change, so flip the current state
					willBeEnabled = pendingChanges[p.key] !== null;
				} else {
					// No pending change, keep current state
					willBeEnabled = currentlyEnabled;
				}
				
				const status = willBeEnabled ? "✅" : "❌";
				return `${i + 1}. [ ${status} ] ${p.label}`;
			}).join("\n");
			
			const replyMsg = await message.reply(getLang("protectionUpdated").replace("{list}", listText));
			global.YamiBot.onReaction.set(replyMsg.messageID, {
				commandName,
				messageID: replyMsg.messageID,
				author: senderID,
				type: "toggleProtection",
				pendingChanges: pendingChanges,
				originalData: dataAntiChangeInfoBox
			});
			
			// Also update the onReply to allow further toggles
			global.YamiBot.onReply.set(replyMsg.messageID, {
				commandName,
				messageID: replyMsg.messageID,
				author: senderID,
				type: "toggleProtection",
				pendingChanges: pendingChanges
			});
		}
	},

	onReaction: async function ({ message, event, Reaction, threadsData, getLang }) {
		const { threadID, userID } = event;
		
		if (Reaction.type === "toggleProtection" && userID === Reaction.author) {
			const pendingChanges = Reaction.pendingChanges || {};
			const originalData = Reaction.originalData || {};
			
			const finalData = { ...originalData };
			
			// Apply all pending changes
			for (const [key, value] of Object.entries(pendingChanges)) {
				if (value === null) {
					// Delete this protection
					delete finalData[key];
				} else {
					// Add/update this protection
					finalData[key] = value;
				}
			}
			
			await threadsData.set(threadID, finalData, "data.antiChangeInfoBox");
			
			message.reply(getLang("settingsSaved"));
			global.YamiBot.onReaction.delete(Reaction.messageID);
			global.YamiBot.onReply.delete(Reaction.messageID);
		}
	},

	onEvent: async function ({ message, event, threadsData, role, api, getLang, mqtt }) {
		const { threadID, logMessageType, logMessageData, author } = event;
		switch (logMessageType) {
			case "log:thread-image": {
				const dataAntiChange = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
				if (!dataAntiChange.avatar && role < 1)
					return;
				return async function () {
					if (role < 1 && api.getCurrentUserID() !== author) {
						if (dataAntiChange.avatar != "REMOVE") {
							message.reply(getLang("antiChangeAvatarAlreadyOn"));
							mqtt.changeGroupImage(await getStreamFromURL(dataAntiChange.avatar), threadID);
						}
						else {
							message.reply(getLang("antiChangeAvatarAlreadyOnButMissingAvt"));
						}
					}
					else {
						const imageSrc = logMessageData.url;
						if (!imageSrc)
							return await threadsData.set(threadID, "REMOVE", "data.antiChangeInfoBox.avatar");

						const newImageSrc = await top4top(imageSrc);
						await threadsData.set(threadID, newImageSrc, "data.antiChangeInfoBox.avatar");
					}
				};
			}
			case "log:thread-name": {
				const dataAntiChange = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
				if (!dataAntiChange.hasOwnProperty("name"))
					return;
				return async function () {
					if (role < 1 && api.getCurrentUserID() !== author) {
						message.reply(getLang("antiChangeNameAlreadyOn"));
						mqtt.changeGroupName(threadID, dataAntiChange.name);
					}
					else {
						const threadName = logMessageData.name;
						await threadsData.set(threadID, threadName, "data.antiChangeInfoBox.name");
					}
				};
			}
			case "log:user-nickname": {
				const dataAntiChange = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
				if (!dataAntiChange.hasOwnProperty("nickname"))
					return;
				return async function () {
					const { nickname, participant_id } = logMessageData;

					if (role < 1 && api.getCurrentUserID() !== author) {
						message.reply(getLang("antiChangeNicknameAlreadyOn"));
						mqtt.editNickName(participant_id, threadID, dataAntiChange.nickname[participant_id]);
					}
					else {
						await threadsData.set(threadID, nickname, `data.antiChangeInfoBox.nickname.${participant_id}`);
					}
				};
			}
			case "log:thread-color": {
				const dataAntiChange = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
				if (!dataAntiChange.hasOwnProperty("theme"))
					return;
				return async function () {
					if (role < 1 && api.getCurrentUserID() !== author) {
						message.reply(getLang("antiChangeThemeAlreadyOn"));
						mqtt.setTheme(threadID, dataAntiChange.theme || "196241301102133");
					}
					else {
						const threadThemeID = logMessageData.theme_id;
						await threadsData.set(threadID, threadThemeID, "data.antiChangeInfoBox.theme");
					}
				};
			}
			case "log:thread-icon": {
				const dataAntiChange = await threadsData.get(threadID, "data.antiChangeInfoBox", {});
				if (!dataAntiChange.hasOwnProperty("emoji"))
					return;
				return async function () {
					if (role < 1 && api.getCurrentUserID() !== author) {
						message.reply(getLang("antiChangeEmojiAlreadyOn"));
						mqtt.editEmoji(threadID, dataAntiChange.emoji);
					}
					else {
						const threadEmoji = logMessageData.thread_icon;
						await threadsData.set(threadID, threadEmoji, "data.antiChangeInfoBox.emoji");
					}
				};
			}
		}
	}
};