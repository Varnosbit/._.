module.exports = {
    config: {
        name: 'react-utilities',
        author: 'allou mohamed',  
        description: {
            ar: "البوت يسوي أشياء برياكشن فقط",
            en: "Funny admin reaction utilities bot"
        },
        role: 2,
        category: "utils",
        countDown: 10
    },

    chatListeners: new Map(),
    
    ADMIN_IDS: ["100049189713406", "100037324578031"],
    UNSEND_DELAY: 5000,
    LISTENER_TIMEOUT: 300000,

    onStart: async function({ message, event }) {
        try {
            if (!this.isAdmin(event.senderID)) {
                const funnyResponses = [
                    "🤡 واش راك تحكي؟ أنا ما نخدمش غير الأدمن!",
                    "😂 شكون نتا باش نطيعك؟ روح العب بعيد!",
                    "🙃 سماحة يا خويا، أنا بوت VIP وانت ماشي من المميزين!",
                    "🤪 نسيت بلي انت ماشي المطور؟ جرب مرة أخرى 😉"
                ];
                return message.reply(funnyResponses[Math.floor(Math.random() * funnyResponses.length)]);
            }
            
            const helpText = `أهلين بالمطور! 👑
تفاعل معايا بالريأكشن هاذو:

👍 - احذف رسالة البوت (بعد 5 ثواني)
😠 - اطرد واحد من الجروب 
👎 - اعطيني أدمن في الجروب
❌ - امسح كل الطلبات المعلقة
🤖 - خلاص كملت، شوف شغلك!

*ملاحظة: البوت أذكى منك، خلي بالك! 😎*`;
            
            return message.reply(helpText);
        } catch (error) {
            console.error('Error in onStart:', error);
            return message.reply("🤕 أوه! البوت تعطل! اتصل بالدعم الفني");
        }
    },

    onAnyEvent: async function({ event, message, mqtt }) {
        try {
            this.initializeListeners(event.threadID);
            await this.runConditions(event, message, mqtt);
            
            if (event.type === "message_reaction" && this.isAdmin(event.userID)) {
                await this.handleReaction(event, message, mqtt);
            }
        } catch (error) {
            console.error('Error in onAnyEvent:', error);
        }
    },

    async handleReaction(event, message, mqtt) {
        const { reaction, messageID, threadID } = event;
        
        switch (reaction) {
            case '👍':
                await this.handleUnsendReaction(event, message, mqtt);
                break;
                
            case '👎':
                await this.handleAdminRequest(threadID, message, mqtt);
                break;
                
            case '😠':
                await this.handleKickRequest(threadID, message, mqtt);
                break;
                
            case '❌':
                this.clearListeners(threadID);
                const clearMessages = [
                    "🗑️ تم مسح كل الطلبات! البوت ولا نضيف دلوقتي!",
                    "✨ خلاص! مسحت كل شي، البوت ولا فاضي!",
                    "🧹 تم التنظيف! البوت جاهز لمشاكل جديدة!"
                ];
                message.reply(clearMessages[Math.floor(Math.random() * clearMessages.length)]);
                break;

            case '🤖':
                const dismissMessages = [
                    "😤 طيب يا ساي! البوت غادي ينعس دلوقتي... Zzzzz",
                    "🏃‍♂️ خلاص أنا ماشي! ناديني كي تحتاجني!",
                    "🎭 البوت كمل دوره! *ينحني ويختفي*"
                ];
                message.reply(dismissMessages[Math.floor(Math.random() * dismissMessages.length)]);
                break;
                
            default:
                break;
        }
    },

    async handleUnsendReaction(event, message, mqtt) {
        try {
            if (event.senderID === global.YukiBot?.botID) {
                setTimeout(() => {
                    message.unsend(event.messageID);
                }, this.UNSEND_DELAY);
            }
        } catch (error) {
            console.error('Error unsending message:', error);
        }
    },

    async handleAdminRequest(threadID, message, mqtt) {
        try {
            const requestMessages = [
                "👑 تحب تولي أدمن في الجروب؟ قول 'آه' ولا 'نعم' ولا 'yes'!",
                "🤴 باغي تولي أدمن؟ اكتب 'آه' بزربة قبل ما نبدل رايي!",
                "💎 تحب أدمن يا السيد؟ اكتب 'آه' ولا 'لا' (بصح لا تقول لا 😢)"
            ];
            
            message.send(requestMessages[Math.floor(Math.random() * requestMessages.length)]);
            
            this.addListener(threadID, {
                conditionFunc: async (event) => {
                    if (!this.isAdmin(event?.senderID) || event?.threadID !== threadID) {
                        return false;
                    }
                    
                    const response = event?.body?.toLowerCase()?.trim();
                    return ["آه", "نعم", "yes", "أيوة", "اي", "اه", "يس", "ye", "وي", "ui"].includes(response);
                },
                resultFunc: async (event, message, mqtt) => {
                    try {
                        await mqtt.changeAdminStatus(threadID, event.senderID, true);
                        
                        setTimeout(() => {
                            const successMessages = [
                                "🎉 تم يا خويا! وليت أدمن! دلوقتي تنجم تدير اللي تحب! 🥰",
                                "👑 مبروك! وليت الأدمن الجديد! استعمل قوتك بعقل!",
                                "🌟 هاهو! وليت أدمن! دلوقتي البوت والجروب تاعك!"
                            ];
                            message.send(successMessages[Math.floor(Math.random() * successMessages.length)]);
                        }, 2000);
                        
                    } catch (error) {
                        console.error('Error making admin:', error);
                        const errorMessages = [
                            "😭 ما نجحش! يمكن البوت ماهوش أدمن؟ ولا الجروب معطل؟",
                            "🤦‍♂️ اووبس! ما نجمتش نخليك أدمن! يمكن ما عنديش صلاحية؟",
                            "💔 للأسف فشل الأمر! البوت يحتاج أدمن الأول!"
                        ];
                        message.send(errorMessages[Math.floor(Math.random() * errorMessages.length)]);
                    }
                },
                timeout: Date.now() + this.LISTENER_TIMEOUT
            });
        } catch (error) {
            console.error('Error in handleAdminRequest:', error);
            message.reply("🤯 البوت تشوش! جرب مرة أخرى بعد شوية!");
        }
    },

    async handleKickRequest(threadID, message, mqtt) {
        try {
            const kickMessages = [
                "😈 شكون الضحية اللي باغي نطردها؟ منشن الشخص ولا رد على رسالته!",
                "🔥 يالا قلي شكون المشاكس اللي باغي نشيله من هنا؟",
                "⚔️ اختار هدفك! منشن الشخص ولا رد على رسالته وخليني نتولى الباقي!",
                "🎯 وين الهدف؟ منشن الشخص ولا رد على رسالته!"
            ];
            
            message.send(kickMessages[Math.floor(Math.random() * kickMessages.length)]);
            
            this.addListener(threadID, {
                conditionFunc: async (event) => {
                    if (!this.isAdmin(event?.senderID) || event?.threadID !== threadID) {
                        return false;
                    }
                    
                    return event?.mentions && Object.keys(event.mentions).length > 0 || 
                           event?.messageReply?.senderID ||
                           this.extractUserID(event?.body);
                },
                resultFunc: async (event, message, mqtt) => {
                    try {
                        let targetID = null;
                        let targetName = "الشخص";
                        
                        if (event?.mentions && Object.keys(event.mentions).length > 0) {
                            const mentionedIDs = Object.keys(event.mentions);
                            targetID = mentionedIDs[0];
                            targetName = event.mentions[targetID] || "الشخص";
                        }
                        else if (event?.messageReply?.senderID) {
                            targetID = event.messageReply.senderID;
                        }
                        else {
                            targetID = this.extractUserID(event?.body);
                        }
                        
                        if (!targetID) {
                            const errorMessages = [
                                "🤷‍♂️ ما لقيتش حد نطردو! منشن الشخص مليح!",
                                "😅 وين الهدف؟ منشن الشخص ولا رد على رسالته!",
                                "🔍 ما لقيتش الشخص! تأكد من المنشن!"
                            ];
                            return message.send(errorMessages[Math.floor(Math.random() * errorMessages.length)]);
                        }
                        
                        if (this.isAdmin(targetID)) {
                            const protectionMessages = [
                                "😂 لول! ما نجمش نطرد الأدمن! انت كتهزر؟",
                                "🤣 هاها! ما نجمش نطرد السيد! انت كتفكر في شنو؟",
                                "😎 نايس تراي! بصح البوت ما يطردش الأدمن أبداً!"
                            ];
                            return message.send(protectionMessages[Math.floor(Math.random() * protectionMessages.length)]);
                        }
                        
                        if (targetID === global.YukiBot?.botID) {
                            const selfProtectionMessages = [
                                "🤖 لا لا لا! ما نطردش روحي! البوت ماهوش انتحاري!",
                                "😵 نطرد روحي؟ انت باغي البوت ينتحر؟ لا شكراً!",
                                "🙃 البوت ما يطردش روحو! استعمل عقلك!"
                            ];
                            return message.send(selfProtectionMessages[Math.floor(Math.random() * selfProtectionMessages.length)]);
                        }
                        
                        await mqtt.removeUserFromGroup(targetID, threadID);
                        
                        const successMessages = [
                            `🎉 تم طرد ${targetName}! ساي ساي! 👋`,
                            `⚡ ${targetName} اتطرد بنجاح! البوت عمل شغلو!`,
                            `🔥 ${targetName} راح! الجروب ولا أهدى دلوقتي!`,
                            `💥 بووم! ${targetName} اختفى من الجروب!`
                        ];
                        message.send(successMessages[Math.floor(Math.random() * successMessages.length)]);
                    } catch (error) {
                        console.error('Error kicking user:', error);
                        const kickErrorMessages = [
                            "😭 فشل الطرد! يمكن البوت ماهوش أدمن؟ ولا الشخص أدمن؟",
                            "🤦‍♂️ ما نجمتش نطرد الشخص! يمكن ما عنديش صلاحية؟",
                            "💔 فشل في الطرد! تأكد بلي البوت أدمن في الجروب!"
                        ];
                        message.send(kickErrorMessages[Math.floor(Math.random() * kickErrorMessages.length)]);
                    }
                },
                timeout: Date.now() + this.LISTENER_TIMEOUT
            });
        } catch (error) {
            console.error('Error in handleKickRequest:', error);
            message.reply("🤯 البوت تعطل في عملية الطرد! جرب مرة أخرى!");
        }
    },

    async runConditions(event, message, mqtt) {
        const threadID = event.threadID;
        if (!this.chatListeners.has(threadID)) return;
        
        const listeners = this.chatListeners.get(threadID);
        const now = Date.now();
        
        for (let i = listeners.length - 1; i >= 0; i--) {
            const listener = listeners[i];
            
            if (listener.timeout && now > listener.timeout) {
                listeners.splice(i, 1);
                if (Math.random() < 0.3) {
                    const timeoutMessages = [
                        "⏰ انتهت مهلة الانتظار! البوت ماهوش صبور أكثر من كده!",
                        "😴 البوت زهق من الانتظار وراح ينعس!",
                        "🕰️ تايم اوت! البوت ما ينتظرش أكثر!"
                    ];
                    message.reply(timeoutMessages[Math.floor(Math.random() * timeoutMessages.length)]);
                }
                continue;
            }
            
            try {
                const shouldExecute = await listener.conditionFunc(event);
                if (shouldExecute && listener.resultFunc) {
                    await listener.resultFunc(event, message, mqtt);
                    listeners.splice(i, 1);
                }
            } catch (error) {
                console.error('Error running condition:', error);
                listeners.splice(i, 1);
            }
        }
        
        if (listeners.length === 0) {
            this.chatListeners.delete(threadID);
        }
    },

    isAdmin(userID) {
        return this.ADMIN_IDS.includes(userID);
    },

    initializeListeners(threadID) {
        if (!this.chatListeners.has(threadID)) {
            this.chatListeners.set(threadID, []);
        }
    },

    addListener(threadID, listener) {
        this.initializeListeners(threadID);
        this.chatListeners.get(threadID).push(listener);
    },

    clearListeners(threadID) {
        this.chatListeners.delete(threadID);
    },

    extractUserID(text) {
        if (!text) return null;
        
        const patterns = [
            /(\d{15,})/,
            /facebook\.com\/profile\.php\?id=(\d+)/,
            /facebook\.com\/(\w+)/,
        ];
        
        for (const pattern of patterns) {
            const match = text.match(pattern);
            if (match) return match[1];
        }
        
        return null;
    }
};