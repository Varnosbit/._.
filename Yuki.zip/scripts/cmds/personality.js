const questions = [
	{
		id: 1,
		question: "كيف تتعامل مع المواقف الصعبة؟",
		options: [
			{ text: "أضع خطة مفصلة وأنفذها خطوة بخطوة", type: "محلل" },
			{ text: "أتصرف بحماس وأواجه التحدي مباشرة", type: "قائد" },
			{ text: "أبحث عن حلول إبداعية غير تقليدية", type: "مبدع" },
			{ text: "لا شيء من هذه الطرق يناسبني", type: "متوازن" }
		]
	},
	{
		id: 2,
		question: "ما الذي يحفزك للعمل بجد؟",
		options: [
			{ text: "تحقيق أهدافي الشخصية والمهنية", type: "طموح" },
			{ text: "مساعدة الآخرين وإحداث فرق إيجابي", type: "اجتماعي" },
			{ text: "حل المشاكل المعقدة والألغاز الصعبة", type: "محلل" },
			{ text: "لا شيء من هذه الأسباب يحفزني", type: "متوازن" }
		]
	},
	{
		id: 3,
		question: "كيف تفضل قضاء عطلة نهاية الأسبوع؟",
		options: [
			{ text: "في نشاطات اجتماعية مع الأصدقاء والعائلة", type: "اجتماعي" },
			{ text: "في مشاريع شخصية أو هوايات فنية", type: "مبدع" },
			{ text: "في التخطيط وتنظيم الأسبوع القادم", type: "طموح" },
			{ text: "لا شيء من هذه الأنشطة يجذبني", type: "متوازن" }
		]
	},
	{
		id: 4,
		question: "ما أسلوبك في اتخاذ القرارات المهمة؟",
		options: [
			{ text: "أجمع المعلومات وأحلل الخيارات بعناية", type: "محلل" },
			{ text: "أثق في حدسي وأقرر بسرعة", type: "قائد" },
			{ text: "أستشير الأشخاص المقربين أولاً", type: "اجتماعي" },
			{ text: "لا أتبع أي من هذه الطرق", type: "متوازن" }
		]
	},
	{
		id: 5,
		question: "ما نوع الكتب التي تفضل قراءتها؟",
		options: [
			{ text: "كتب التطوير الذاتي والأعمال", type: "طموح" },
			{ text: "الروايات والأدب والشعر", type: "مبدع" },
			{ text: "الكتب العلمية والتقنية", type: "محلل" },
			{ text: "لا أحب أي من هذه الأنواع", type: "متوازن" }
		]
	},
	{
		id: 6,
		question: "كيف تتعامل مع النقد والملاحظات؟",
		options: [
			{ text: "أرحب به وأستخدمه لتحسين أدائي", type: "طموح" },
			{ text: "أدافع عن وجهة نظري إذا كنت مقتنعاً بها", type: "قائد" },
			{ text: "أتأثر عاطفياً لكنني أحاول الاستفادة منه", type: "اجتماعي" },
			{ text: "لا أتعامل معه بأي من هذه الطرق", type: "متوازن" }
		]
	},
	{
		id: 7,
		question: "ما الذي يميز طريقة تفكيرك؟",
		options: [
			{ text: "التفكير المنطقي والتحليل العميق", type: "محلل" },
			{ text: "الخيال الواسع والتفكير خارج الصندوق", type: "مبدع" },
			{ text: "التفكير الاستراتيجي والرؤية بعيدة المدى", type: "قائد" },
			{ text: "لا شيء من هذه الأنماط يصفني", type: "متوازن" }
		]
	},
	{
		id: 8,
		question: "كيف تفضل التعلم واكتساب المهارات الجديدة؟",
		options: [
			{ text: "من خلال الدورات المنظمة والكتب المتخصصة", type: "محلل" },
			{ text: "من خلال التجربة والممارسة العملية", type: "قائد" },
			{ text: "من خلال التعلم التفاعلي مع الآخرين", type: "اجتماعي" },
			{ text: "لا أفضل أياً من هذه الطرق", type: "متوازن" }
		]
	},
	{
		id: 9,
		question: "ما هو أكبر مخاوفك في الحياة؟",
		options: [
			{ text: "عدم تحقيق إمكانياتي الكاملة", type: "طموح" },
			{ text: "فقدان الأشخاص المهمين في حياتي", type: "اجتماعي" },
			{ text: "عدم فهم العالم من حولي بشكل كامل", type: "محلل" },
			{ text: "لا شيء من هذه المخاوف يقلقني", type: "متوازن" }
		]
	},
	{
		id: 10,
		question: "كيف تتعامل مع ضغوط العمل؟",
		options: [
			{ text: "أنظم أولوياتي وأضع جدولاً زمنياً محدداً", type: "طموح" },
			{ text: "أقسم المهام وأفوض جزءاً منها للآخرين", type: "قائد" },
			{ text: "أخذ استراحات إبداعية لتجديد طاقتي", type: "مبدع" },
			{ text: "لا أتبع أي من هذه الاستراتيجيات", type: "متوازن" }
		]
	},
	{
		id: 11,
		question: "ما نوع البيئة التي تفضل العمل فيها؟",
		options: [
			{ text: "بيئة هادئة ومنظمة للتركيز العميق", type: "محلل" },
			{ text: "بيئة تعاونية مع فرق العمل", type: "اجتماعي" },
			{ text: "بيئة ديناميكية مليئة بالتحديات", type: "قائد" },
			{ text: "لا أفضل أي من هذه البيئات", type: "متوازن" }
		]
	},
	{
		id: 12,
		question: "كيف تنظر إلى الفشل؟",
		options: [
			{ text: "فرصة للتعلم والنمو الشخصي", type: "طموح" },
			{ text: "جزء طبيعي من رحلة النجاح", type: "قائد" },
			{ text: "مؤشر على ضرورة تغيير الاستراتيجية", type: "محلل" },
			{ text: "لا أنظر إليه بأي من هذه الطرق", type: "متوازن" }
		]
	}
];

const personalityTypes = {
	طموح: {
		title: "الشخصية الطموحة",
		emoji: "🎯",
		description: "أنت شخص يسعى باستمرار لتحقيق أهدافه ولديه رؤية واضحة لمستقبلك. تتميز بالانضباط والمثابرة في العمل نحو أحلامك.",
		traits: ["هادف", "منضبط", "مثابر", "متحفز", "منظم"]
	},
	قائد: {
		title: "الشخصية القيادية",
		emoji: "👑",
		description: "تتمتع بالقدرة على إلهام الآخرين وقيادتهم. تحب التحديات وتتخذ قرارات حاسمة في المواقف الصعبة.",
		traits: ["حاسم", "شجاع", "ملهم", "واثق", "استراتيجي"]
	},
	محلل: {
		title: "الشخصية التحليلية",
		emoji: "🔍",
		description: "تحب التفكير العميق وتحليل المعلومات بدقة. تتخذ قراراتك بناءً على البيانات والمنطق السليم.",
		traits: ["منطقي", "دقيق", "متأني", "منهجي", "موضوعي"]
	},
	مبدع: {
		title: "الشخصية المبدعة",
		emoji: "🎨",
		description: "لديك خيال واسع وقدرة على التفكير خارج الصندوق. تجد حلولاً مبتكرة للمشاكل وتقدر الجمال والفن.",
		traits: ["مبتكر", "خيالي", "أصيل", "مرن", "فني"]
	},
	اجتماعي: {
		title: "الشخصية الاجتماعية",
		emoji: "🤝",
		description: "تهتم بالآخرين وتبني علاقات قوية. تجد الطاقة والإلهام من التفاعل مع الناس ومساعدتهم.",
		traits: ["متعاطف", "ودود", "مساعد", "تعاوني", "مستمع"]
	},
	متوازن: {
		title: "الشخصية المتوازنة",
		emoji: "⚖️",
		description: "تتمتع بمرونة في التفكير والتصرف. تستطيع التكيف مع مختلف المواقف ولا تميل لنمط واحد محدد.",
		traits: ["مرن", "متكيف", "متوازن", "عملي", "واقعي"]
	}
};

module.exports = {
	config: {
		name: "شخصيتي",
		aliases: ["personality", "اختبار"],
		version: "2.0",
		author: "X7 team",
		countDown: 3,
		role: 0,
		description: {
			ar: "اختبار الشخصية المطور - اكتشف نوع شخصيتك من خلال 12 سؤالاً دقيقاً",
			en: "Advanced personality quiz - discover your personality type through 12 precise questions"
		},
		category: "game",
		guide: {
			ar: "{pn} - لبدء اختبار الشخصية\n{pn} reset - لإعادة تعيين الاختبار",
			en: "{pn} - to start personality quiz\n{pn} reset - to reset quiz"
		},
		envConfig: {
			reward: 1500
		}
	},

	langs: {
		en: {
			welcome: "🧠 مرحباً بك في اختبار الشخصية المطور!\n\nسأطرح عليك 12 سؤالاً دقيقاً لتحديد نوع شخصيتك.\nاختر الإجابة الأقرب لك (A, B, C) أو D إذا لم تناسبك أي إجابة.\n\n",
			question: "📊 السؤال %1 من 12:\n\n❓ %2\n\nA. %3\nB. %4\nC. %5\nD. %6\n\n💡 اكتب الحرف المناسب (A, B, C, D)",
			invalidAnswer: "❌ يرجى اختيار أحد الخيارات: A, B, C, أو D",
			notPlayer: "⚠️ أنت لست صاحب هذا الاختبار",
			finalResult: "🎉 انتهى الاختبار! النتيجة:\n\n%1 %2\n\n📝 %3\n\n✨ صفاتك المميزة:\n%4\n\n🎁 مكافأتك: %5$\n\n🔄 اكتب 'شخصيتي' لإعادة الاختبار",
			alreadyTaken: "🎭 شخصيتك المحددة مسبقاً: %1\n\n💡 اكتب 'شخصيتي reset' لإعادة الاختبار",
			resetSuccess: "✅ تم إعادة تعيين الاختبار بنجاح!",
			errorOccurred: "❌ حدث خطأ. يرجى المحاولة مرة أخرى."
		}
	},

	onStart: async function ({ message, event, getLang, usersData, args, commandName }) {
		try {
			if (args[0] === 'reset') {
				await usersData.set(event.senderID, null, "data.personality");
				return message.reply(getLang("resetSuccess"));
			}

			const existingPersonality = await usersData.get(event.senderID, "data.personality");
			if (existingPersonality) {
				return message.reply(getLang("alreadyTaken", existingPersonality));
			}

			const firstQuestion = questions[0];
			const questionText = getLang("welcome") + getLang("question",
				1,
				firstQuestion.question,
				firstQuestion.options[0].text,
				firstQuestion.options[1].text,
				firstQuestion.options[2].text,
				firstQuestion.options[3].text
			);

			// Clean up existing handlers
			for (const [msgID, data] of global.GoatBot.onReply.entries()) {
				if (data.author === event.senderID) {
					global.GoatBot.onReply.delete(msgID);
				}
			}

			message.reply(questionText, (err, info) => {
				if (!err) {
					global.GoatBot.onReply.set(info.messageID, {
						commandName,
						messageID: info.messageID,
						author: event.senderID,
						currentQuestion: 0,
						answers: []
					});
				}
			});
		} catch {
			return message.reply(getLang("errorOccurred"));
		}
	},

	onReply: async function ({ message, Reply, event, getLang, usersData, envCommands, commandName }) {
		try {
			const { author, currentQuestion, answers, messageID } = Reply;

			if (event.senderID !== author) {
				return message.reply(getLang("notPlayer"));
			}

			const userAnswer = event.body.trim().toUpperCase();
			if (!['A', 'B', 'C', 'D'].includes(userAnswer)) {
				return message.reply(getLang("invalidAnswer"));
			}

			const question = questions[currentQuestion];
			const selectedOption = question.options[userAnswer.charCodeAt(0) - 65];
			const updatedAnswers = [...answers, { type: selectedOption.type }];

			// Check if quiz is complete
			if (currentQuestion + 1 >= questions.length) {
				const result = calculatePersonalityResult(updatedAnswers);
				const personalityType = personalityTypes[result];
				const traitsText = personalityType.traits.map(trait => `• ${trait}`).join('\n');
				
				global.GoatBot.onReply.delete(messageID);
				
				const reward = envCommands[commandName]?.reward || 1500;
				await usersData.addMoney(event.senderID, reward);
				await usersData.set(event.senderID, personalityType.title, "data.personality");
				
				return message.reply(getLang("finalResult",
					personalityType.emoji,
					personalityType.title,
					personalityType.description,
					traitsText,
					reward
				));
			}

			// Continue to next question
			const nextQuestionIndex = currentQuestion + 1;
			const nextQuestion = questions[nextQuestionIndex];
			const nextQuestionText = getLang("question",
				nextQuestionIndex + 1,
				nextQuestion.question,
				nextQuestion.options[0].text,
				nextQuestion.options[1].text,
				nextQuestion.options[2].text,
				nextQuestion.options[3].text
			);

			// Clean up and set new handler
			global.GoatBot.onReply.delete(messageID);
			
			message.reply(nextQuestionText, (err, info) => {
				if (!err) {
					global.GoatBot.onReply.set(info.messageID, {
						commandName,
						messageID: info.messageID,
						author: event.senderID,
						currentQuestion: nextQuestionIndex,
						answers: updatedAnswers
					});
				}
			});
		} catch {
			if (Reply?.messageID) {
				global.GoatBot.onReply.delete(Reply.messageID);
			}
			return message.reply(getLang("errorOccurred"));
		}
	}
};

function calculatePersonalityResult(answers) {
	const typeCount = {};
	
	answers.forEach(answer => {
		if (answer.type) {
			typeCount[answer.type] = (typeCount[answer.type] || 0) + 1;
		}
	});

	if (Object.keys(typeCount).length === 0) {
		return "متوازن";
	}

	return Object.keys(typeCount).reduce((a, b) => 
		typeCount[a] > typeCount[b] ? a : b
	);
}
