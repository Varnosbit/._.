//1.5
const axios = require("axios");

module.exports = {
  config: {
    name: "translate",
    aliases: ["ترجم", "tr"], // first alias in Arabic
    version: "1.5",
    author: "Allou Mohamed",
    countDown: 5,
    role: 0,
    category: "tools",
    desc: {
      en: "Translate text using Google Translate API.",
      ar: "ترجمة النصوص باستخدام واجهة Google Translate"
    },
    guide: {
      en: "%1 <target_lang> <text>  - Translate text to the specified language (e.g., en, id, fr)\nExample: %1 en saya suka kamu",
      ar: "%1 <اللغة_الهدف> <النص>  - ترجمة النص إلى اللغة المحددة (مثال: en, id, fr)\nمثال: %1 en مرحبا بالعالم"
    }
  },

  langs: {
    en: {
      usage: "❌ Usage: %1 <target_lang> <text or reply to text>",
      translation: "✅ Translation:",
      error: "❌ Failed to translate. Check the language code or try again later."
    },
    ar: {
      usage: "❌ الاستخدام: %1 <اللغة_الهدف> <النص أو الرد على نص>\nمثال: %1 en مرحبا بالعالم",
      translation: "✅ الترجمة:",
      error: "❌ فشل في الترجمة. تحقق من كود اللغة أو حاول مرة أخرى لاحقاً."
    }
  },

  onStart: async function ({ message, args, event, commandName, prefix, getLang }) {
    const targetLang = args[0] || "ar";
    const replyText = event.messageReply?.body;
    const textToTranslate = args.slice(1).join(" ") || replyText;

    if (!targetLang || !textToTranslate) {
      return message.reply(getLang("usage", prefix + commandName));
    }

    try {
      const res = await axios.get("https://translate.googleapis.com/translate_a/single", {
        params: {
          client: "gtx",
          sl: "auto",
          tl: targetLang,
          dt: "t",
          q: textToTranslate
        }
      });

      const translated = res.data[0].map(part => part[0]).join("");
      return message.reply(`${getLang("translation")}\n\n${translated}`);
    } catch (err) {
      console.error(err);
      return message.reply(getLang("error"));
    }
  }
};