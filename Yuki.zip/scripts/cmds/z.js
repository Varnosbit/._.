const os = require("os");
const canvas = require("canvas");
const fs = require("fs");
const path = require("path");
const disk = require("diskusage");
module.exports = {
    config: {
        name: 'z',
        author: 'allou mohamed',
        aliases: ["statistics", "upt"],
        description: {
            ar: "معلومات البوت و المطور",
            en: "some project informations"
        },
        role: 0,
        countDown: 10,
        category: "stats"
    },
    onStart: async function ({ usersData, threadsData, message }) {
        const image = canvas.createCanvas(1384, 720);
        const ctx = image.getContext("2d");
        
        await background(ctx);
        drawRoundedRect(ctx, image, 40, 20);
        const diskUsage = getDiskUsage();
        await information(ctx, diskUsage);

        const imagePath = path.join(__dirname, 'cache', 'analysis.png');
        const buffer = image.toBuffer('image/png');
        fs.writeFileSync(imagePath, buffer);
        message.reply({ attachment: fs.createReadStream(imagePath) }, async () => {
            fs.unlinkSync(imagePath);
        });

        async function background(ctx) {
            const bg = /*"https://i.ibb.co/2yY0dXq/Picsart-24-08-22-14-17-09-456.png" "https://i.ibb.co/k0wWJjV/Picsart-24-08-26-19-09-54-606.png";*/"https://i.supa.codes/9df3m7.jpg";
            const lbg = await canvas.loadImage(bg);
            ctx.drawImage(lbg, 0, 0, image.width, image.height);
        }

        async function information(ctx, diskUsage) {
            const fontPath = path.join(__dirname, "canvas", "status", "status.ttf");
            canvas.registerFont(fontPath, { family: 'info' });

            ctx.font = 'bold 30px info';
            ctx.fillStyle = 'white';
            ctx.textAlign = 'left';
           // ctx.globalAlpha = 0.5;
            ctx.fillText(getCurrentTimeInAlgiers(), 850, 118);
            ctx.globalAlpha = 0.8;
            ctx.font = 'bold 40px info';
            ctx.fillText("Yuki Bot II", 850, 78);
            ctx.font = 'bold 46px info';
            ctx.fillText("• Statistics:", 52, 86);
            
         //   ctx.globalAlpha = 0.5;
            const packageJsonPath = path.join('package.json');
            const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
            const version = packageJson.version;
            ctx.fillStyle = 'white';
            ctx.font = 'bold 30px info';
            ctx.fillText(`♪ Project version: ${version}`, 46, 180);
            ctx.fillText(`♪ NodeJs V: 20.16.0`, 46, 230);

            const allUsers = await usersData.getAll();
            ctx.fillText(`♪ Total Users: ${allUsers.length}`, 46, 230 + 90);
            const banned = allUsers.filter(i => i.banned.status);
            ctx.fillText(`♪ Total Banned Users: ${banned.length}`, 46, 230 + 90 + 40);
            const males = allUsers.filter(i => i.gender == 2);
            ctx.fillText(`♪ Total Users Males: ${males.length}`, 46, 230 + 90 + 80);
            const otherG = allUsers.filter(i => i.gender != 2);
            ctx.fillText(`♪ Girls and gays: ${otherG.length}`, 46, 230 + 90 + 120);

            const allGroups = await threadsData.getAll();
            ctx.fillText(`♪ Total Groups: ${allGroups.length}`, 46, 440 + 80);
            const banned2 = allGroups.filter(i => i.banned.status);
            ctx.fillText(`♪ Total Banned Groups: ${banned2.length}`, 46, 440 + 120);
            const approved = allGroups.filter(i => i.data.approved);
            const deapproved = allGroups.filter(i => i.data.approved == false);
            ctx.fillText(`♪ Total registered: ${approved.length}`, 46, 440 + 160);
            ctx.fillText(`♪ Total deapproved: ${deapproved.length}`, 46, 440 + 200);

            const { totalMemory, freeMemory } = ram();
            const usedMemory = totalMemory - freeMemory;
            const memoryUsagePercentage = (usedMemory / totalMemory) * 100;
            ctx.fillText(`♪ Ram Usage: ${Math.floor(memoryUsagePercentage)}%`, 980, 185);
            await drawSlider(ctx, 1020, 200, freeMemory, totalMemory, 15, 300, 'white', 'grey');

            const { totalSpace, freeSpace } = diskUsage;
            const usedSpace = totalSpace - freeSpace;
            const spaceUsagePercentage = (usedSpace / totalSpace) * 100;
            ctx.fillStyle = 'white';
            ctx.fillText(`♪ Disk Usage: ${Math.floor(spaceUsagePercentage)}%`, 980, 260);
            await drawSlider(ctx, 1020, 280, freeSpace, totalSpace, 15, 300, 'white', 'grey');
            ctx.fillStyle = 'white';
        //    ctx.globalAlpha = 0.5;
            const upt = formatUptime();
            ctx.fillText(`♪ Upt ${upt}`, 46 * 20 + 45, 350);
        //    ctx.fillText(`Soon...`, 46 * 12.7 + 45, 280);
        //    ctx.fillText(`Soon...`, 46 * 12.7 + 45, 550);
            ctx.font = 'bold 24px info';
            ctx.fillText(`By Allou Mohamed ©`, 46 * 20 + 108, 650);

        }

        function formatUptime() {
            const uptimeInSeconds = process.uptime();

            const days = Math.floor(uptimeInSeconds / (24 * 60 * 60));
            const hours = Math.floor((uptimeInSeconds % (24 * 60 * 60)) / (60 * 60));
            const minutes = Math.floor((uptimeInSeconds % (60 * 60)) / 60);
            const seconds = Math.floor(uptimeInSeconds % 60);

            return `${days} d ${hours} h ${minutes} m, ${seconds} s`;
        }

        function getCurrentTimeInAlgiers() {
            const algeriaOffset = 1;
            const now = new Date();
            const utc = now.getTime() + now.getTimezoneOffset() * 60000;
            const algeriaTime = new Date(utc + (3600000 * algeriaOffset));

            const day = String(algeriaTime.getDate()).padStart(2, '0');
            const month = String(algeriaTime.getMonth() + 1).padStart(2, '0');
            const year = algeriaTime.getFullYear();
            const hours24 = algeriaTime.getHours();
            const hours12 = hours24 % 12 || 12;
            const minutes = String(algeriaTime.getMinutes()).padStart(2, '0');
            const seconds = String(algeriaTime.getSeconds()).padStart(2, '0');
            const ampm = hours24 >= 12 ? 'PM' : 'AM';
            const offset = `GMT+${algeriaOffset}`;

            return `${day}/${month}/${year}, ${hours12}:${minutes}:${seconds} ${ampm} ${offset}`;
        }

        function ram() {
            const totalMemory = os.totalmem();
            const freeMemory = os.freemem();
            return {
                totalMemory,
                freeMemory
            };
        }

        function getDiskUsage() {
            const path = os.platform() === 'win32' ? 'C:' : '/';
            const { total, free } = disk.checkSync(path);
            return { freeSpace: free, totalSpace: total };
        }

        function secNSec2ms(secNSec) {
            return secNSec[0] * 1000 + secNSec[1] / 1e6;
        }

        async function drawSlider(ctx, x, y, free, total, height, width, freeColor, totalColor) {
     //       ctx.globalAlpha = 0.5;
            const usedMemory = total - free;
            const usageRatio = usedMemory / total;

            ctx.clearRect(x, y, width, height);

            ctx.fillStyle = totalColor;
            ctx.fillRect(x, y, width, height);

            ctx.fillStyle = freeColor;
            ctx.fillRect(x, y, width * usageRatio, height);
  //          ctx.globalAlpha = 0.5;
        }
    }
};
function drawRoundedRect(ctx, canvas, padding, radius) {
    const width = canvas.width - 2 * padding;
    const height = canvas.height - 2 * padding;
    const x = padding;
    const y = padding;

    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = "black";
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.arcTo(x + width, y, x + width, y + radius, radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.arcTo(x + width, y + height, x + width - radius, y + height, radius);
    ctx.lineTo(x + radius, y + height);
    ctx.arcTo(x, y + height, x, y + height - radius, radius);
    ctx.lineTo(x, y + radius);
    ctx.arcTo(x, y, x + radius, y, radius);
    ctx.closePath();

    ctx.fill();
    ctx.restore();
}
