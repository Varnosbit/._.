const axios = require("axios");
const fs = require("fs");
async function genM(prompt, title, style) {
    let myobj = (await axios.post("https://genmusic-production.up.railway.app/generate-music", {
        prompt: prompt, title: title, style: style
    })).data.data[0];
    return {
        aud: "https://cdn1.suno.ai/" + myobj.firstContent.id + ".mp3",
        aud2: "https://cdn1.suno.ai/" + myobj.completeContent.id + ".mp3",
        vid: "https://cdn1.suno.ai/" + myobj.firstContent.id + ".mp4",
        vid2: "https://cdn1.suno.ai/" + myobj.completeContent.id + ".mp4",
        img: myobj.firstContent.image_url,
        img2: myobj.completeContent.image_url
    };
};
async function lers(title) {
    let response = await axios.post(
        "https://loudme.ai/api/trpc/music.generateLyric?batch=1",
        {
            "0": {
                json: {
                    description: title
                }
            }
        },
        {
            headers: {
                "accept": "*/*",
                "accept-language": "en;q=0.6",
                "content-type": "application/json",
                "priority": "u=1, i",
                "sec-ch-ua": "\"Brave\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "sec-gpc": "1",
                "cookie": "user_group=137; first-visit-url=https%3A%2F%2Floudme.ai%2Fai-music-generator; __Host-next-auth.csrf-token=eb5bf02aebc0effa6f949df5558d857ac9851bd0135976d28f9a722e500ede23%7Cfd93c61e4df8794ab372dde37dc5e15ead494d0ebaf339648d87b3f0487c2796; __Secure-next-auth.callback-url=https%3A%2F%2Floudme.ai%2Fai-music-generator; ph_phc_b6wHyYuOOkZdp3P38sFdPnuapy3Hw2FeSWgw0T6nlZ3_posthog=%7B%22distinct_id%22%3A%22cm56swxw503w6ofmx4b0315aq%22%2C%22%24sesid%22%3A%5B1735306883416%2C%220194084e-e5e4-76fb-8e0a-9d351c22127b%22%2C1735306175972%5D%2C%22%24epp%22%3Atrue%7D; __Secure-next-auth.session-token=eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..IWiZEfnhfjsG17Gm.Ie3kfHzXt0bSWFnOjjT896lfoSSypg2l21hfSCkciJc1beolqlaLdiXRRMq0mh1rwj7iay9dZYECWxkXcxplDX8-eWNiwlpfTXCkCKRUcPQ3yWQVkL1dNvIa6ols5VmrE4y8zWWbEAkE3YsrGz-Vzq2-apEZ2vbJ9fEKgFFhyWNklkRlo09gnMzGhgQ5wAnMLmDtFhNeFzVAvLhCKnv-Cn3ilkD3QLalmlmQ2g1Z1vuSlwXxssso7PQ4TBiOj6xlQExf_3ic1q3UbBMIrjLzmnuopuAsC-LMTF2jjAKxT1_vSdaZzLCZz81HI-Po0BYajDtlG2XXWHfPQuIVq30F6fkoUyadVZ0pESS-VsliKxEQkmbND6-HPMNoK9LSDx-ZQNp3EmERvpRvLg6AWA5RDcvSLJcn-PJsGpYZgxqcEVdlfCZjRZ-j98Cqz1jG3toauJjB.XlV2IV4ZyykF5ggyGElxxg; user_info=%7B%22id%22%3A%22cm56swxw503w6ofmx4b0315aq%22%2C%22name%22%3A%22Gry%20KJ%22%2C%22email%22%3A%222k7o6lj9zi%40qejjyl.com%22%2C%22firstName%22%3A%22Gry%22%2C%22lastName%22%3A%22KJ%22%2C%22image%22%3A%22%22%7D",
                "Referer": "https://loudme.ai/ai-music-generator",
                "Referrer-Policy": "strict-origin-when-cross-origin"
            }
        }
    )
    return response.data[0].result.data.json;
}
module.exports = {
    config: {
        name: "suno",
        version: "1.0.0",
        author: "Takt Asahina",
        role: 2,
        countDown: 0,
        description: "عمل اغنيه من نص بل ai",
        category: "Ai",
    },
    onStart: async function ({
        message, event, commandName
    }) {
        message.reply("رد على الرسال بل عنوان ▶️")
        .then(x => { 
        global.YukiBot.onReply.set(x.messageID, {
            commandName,
            messageID: x.messageID,
            action: "title",
            author: event.senderID,
        });
      });
    },
    onReply: async function ({
        message, args, event, Reply, commandName
    }) {
        const {
            action,
            author,
            title,
            tags,
            res,
            chon
        } = Reply;
        if (action === "title") {
            const newTitle = event.body;
             message.reply(" رد باسلوب الاغنية الذي تريد")
             .then(x => {
            global.YukiBot.onReply.set(x.messageID, {
                commandName,
                messageID: x.messageID,
                action: "tags",
                author: event.senderID,
                title: newTitle,
            });
          });
        }
        if (action === "tags") {
            const tagsArray = event.body.split(",").map(i => i.trim());
            message.reply("الان رد بكلمات الاغنية 🎵 🎶\n\n☔: او رد بكلمة 'عشوائي' لانشاء كلمات تطابق العنوان")
            .then(x => { 
            global.YukiBot.onReply.set(x.messageID, {
                commandName,
                messageID: x.messageID,
                action: "prompt",
                author: event.senderID,
                title,
                tags: tagsArray,
            });
          });
        }
        if (action === "prompt") {
            message.reply("☔ ¦ جاري الانشاء...");
            let prompt = event.body;
            if (prompt == "عشوائي") {
                prompt = await lers(title);
            }
            try {
                let res = await genM(prompt, title, tags.join(" "))
                message.stream("تم انشاء الاغنية رد بلرقم 1 او 2 لاختيار اصدار الاغنية العنوان: "
                    + title, [res.img, res.img2])
                .then(x => {
                global.YukiBot.onReply.set(x.messageID, {
                    commandName,
                    messageID: x.messageID,
                    action: "chos",
                    author: event.senderID,
                    res,
                    title: prompt
                });
              });
            } catch (error) {
                message.reply("❌ ¦ فشل");
                console.log(error);
            }
        }
        if (action === "chos") {
            const i = parseInt(event.body);

            let stream;

            if (i == 1) {
                stream = 1;
            } else if (i == 2) {
                stream = 2;
            } else {
                return;
            };
            try {
                message.reply(`🎥 ¦ الان رد ب "فيديو" او "صوت" لارسال الاغنية`)
                .then(x => { 
                global.YukiBot.onReply.set(x.messageID, {
                    commandName,
                    messageID: x.messageID,
                    action: "send",
                    author: event.senderID,
                    res,
                    title,
                    chon: stream
                });
              });
            } catch (error) {
                message.reply("❌ ¦ فشل");
                console.log(error);
            }
        }

        if (action === "send" && event.body == "صوت") {
            try {
                let resp;
                if (chon == 1) {
                    resp = res.aud
                }
                if (chon == 2) {
                    resp = res.aud2
                }
                message.reaction("⏳", event.messageID);
                let st = "f";
                let yr;
                while (st == "f") {
                    try {
                        yr = await axios({
                            method: 'GET',
                            url: resp,
                            responseType: 'arraybuffer'
                        });
                        st = "s";
                    } catch (e) {
                        st = "f";
                    }
                }

                message.stream("Your music 🎵🎶", resp);
            } catch (error) {
                message.reply("❌ ¦ فشل");
                console.log(error);
            }
        };

        if (action === "send" && event.body == "فيديو") {
            try {
                let resp;
                if (chon == 1) {
                    resp = res.vid
                }
                if (chon == 2) {
                    resp = res.vid2
                }
                message.send("✨ ¦ الرجاء الانتضار لبعض الوقت...")
                let st = "f";
                let yr;
                while (st == "f") {
                    try {
                        yr = await axios({
                            method: 'GET',
                            url: resp,
                            responseType: 'arraybuffer'
                        });
                        st = "s";
                    } catch (e) {
                        st = "f";
                    }
                }
                message.stream("Your music 🎵🎶", resp);
            } catch (error) {
                message.reply("❌ ¦ فشل");
                console.log(error);
            }
        }
    },
};