exports.config = {
    name: "shortcut",
    aliases: ["ردود"],
    version: "5.0.4",
    role: 0,
    author: "Allou Mohamed",
    description: "Shortcut Manager.",
    guide: {
        params: "Args",
        usage: "Optional",
        syntax: "{pn} add key => value"
              + "\n{pn} delete key"
              + "\n {pn} list"
              + "\n {pn} remove"
              + "\n{pn} edit key => new value"
              + "\n%bd# Exp:%"
              + "\n{pn} add hi => hello"
              + "\n{pn} delete hi"
              + "\n{pn} edit hi => hello world"
              + "\n{pn} remove (will remove all shortcuts of gc) & {pn} list (will show the list of shortcuts in the gc)"
              + "\n%bd# For Admin Only:%"
              + "\n{pn} add key => value (reply to sticker)"
              + "\n{pn} add key => value --imgs imgurl1 imgurl2 imgurl3"
              + "\n{pn} add key => value --role 1"
              + "\n{pn} add key => value --react 🐦"
              + "\n{pn} add key --react 🐦 (reply to sticker/attachment)"
              + "\n{pn} add key --imgs imgurl1 imgurl2 --react 🐦"
              
    },
    category: "group",
    countDown: 10
};

exports.langs = {
    en: {
        invalidCommand: "❌ Invalid command. Use 'list' to see available options.",
        invalidSyntax: "❌ Invalid syntax. Please provide at least a key name.",
        noContent: "❌ Shortcut must have at least one of: reply text, sticker, images, or reaction.",
        cannotEdit: "❌ You cannot edit \"%1\" - only the creator or admins can modify existing shortcuts.",
        updated: "✅ Shortcut \"%1\" updated successfully!",
        added: "✅ Shortcut \"%1\" added successfully!",
        invalidEditSyntax: "❌ Invalid syntax. Use: edit key => new value",
        notFound: "❌ Shortcut \"%1\" not found.",
        deleteSpecify: "❌ Please specify the shortcut key to delete.",
        cannotDelete: "❌ You can only delete shortcuts you created, unless you're an admin.",
        deleted: "✅ Shortcut \"%1\" deleted successfully!",
        noShortcuts: "📝 No shortcuts found in this group.",
        shortcutsList: "📝 Shortcuts in this group:\n\n%1\n\nTotal: %2 shortcuts",
        onlyAdmins: "❌ Only admins can remove all shortcuts.",
        confirmRemoveAll: "⚠️ Are you sure you want to remove ALL shortcuts from this group?\n\nReact with 👍 to confirm or 👎 to cancel.",
        removeCancelled: "❌ Removal cancelled.",
        allRemoved: "🗑️ All shortcuts have been removed from this group."
    },
    ar: {
        invalidCommand: "❌ امر غلط، اكتب list عشان تشوف الاوامر المتاحة",
        invalidSyntax: "❌ كتابة غلط، لازم تكتب اسم الرد على الاقل",
        noContent: "❌ الرد لازم يكون فيه حاجة: كلام، ستيكر، صور، او رياكشن",
        cannotEdit: "❌ ما تقدر تعدل \"%1\" - بس اللي سواه او الادمن يقدر يعدل",
        updated: "✅ تم تحديث الرد \"%1\" بنجاح",
        added: "✅ تمت اضافة الرد \"%1\" بنجاح",
        invalidEditSyntax: "❌ كتابة غلط، استخدم: edit key => new value",
        notFound: "❌ الرد \"%1\" مو موجود",
        deleteSpecify: "❌ حدد اسم الرد اللي تبي تمسحه",
        cannotDelete: "❌ تقدر تمسح بس الردود اللي انت سويتها، الا اذا انت ادمن",
        deleted: "✅ تم مسح الرد \"%1\" بنجاح",
        noShortcuts: "📝 ما في ردود في الجروب",
        shortcutsList: "📝 ردود الجروب:\n\n%1\n\nالمجموع: %2 رد",
        onlyAdmins: "❌ بس الادمن يقدر يمسح كل الردود",
        confirmRemoveAll: "⚠️ متأكد انك تبي تمسح كل الردود من الجروب؟\n\nحط 👍 للتأكيد او 👎 للالغاء",
        removeCancelled: "❌ تم الغاء المسح",
        allRemoved: "🗑️ تم مسح كل الردود من الجروب"
    }
};

exports.onStart = async ({ message, args, threadsData, event, role, getLang }) => {
    const shortcuts = await threadsData.get(event.threadID, "data.shortcuts", []);
    const Do = _(args[0]);
    const isAdmin = role >= 2;

    switch (Do) {
        case "add":
            await handleAdd(message, args, threadsData, event, shortcuts, isAdmin, utils, getLang);
            break;
        case "edit":
            await handleEdit(message, args, threadsData, event, shortcuts, isAdmin, getLang);
            break;
        case "delete":
        case "remove":
            await handleDelete(message, args, threadsData, event, shortcuts, isAdmin, getLang);
            break;
        case "list":
            await handleList(message, shortcuts, getLang);
            break;
        case "removeall":
            await handleRemoveAll(message, threadsData, event, isAdmin, getLang);
            break;
        default:
            message.reply(getLang("invalidCommand"));
            break;
    }
};

exports.onChat = async ({ message, event, threadsData, role }) => {
    const shortcuts = await threadsData.get(event.threadID, "data.shortcuts", []);
    const messageBody = event.body?.toLowerCase().trim();
    
    if (!messageBody) return;
    
    const shortcut = shortcuts.find(s => normalizeText(s.word) === normalizeText(messageBody));
    
    if (shortcut) {
        await sendShortcut(message, shortcut, event, utils, role || 0);
    }
};

exports.onReaction = async ({ message, Reaction, event, threadsData, role, getLang }) => {
    const { author, messageID } = Reaction;
    const { reaction } = event;
    if (author !== event.userID) return;
    
    const isAdmin = role >= 2;
    
    if (!isAdmin) {
        return message.reply(getLang("onlyAdmins"));
    }
    
    if (reaction === "👍") {
        await threadsData.set(event.threadID, [], "data.shortcuts");
        message.reply(getLang("allRemoved"));
    } else if (reaction === "👎") {
        message.reply(getLang("removeCancelled"));
    }
    
    global.GoatBot.onReaction.delete(messageID);
};

function normalizeText(text) {
    if (!text || typeof text !== 'string') return '';
    try {
        return text.toLowerCase().trim();
    } catch (error) {
        return text.trim();
    }
}

function _(a) {
    if (!a) return null;
    const actions = {
        add: [
            "add",
            "اضف", "أضف",
            "اضافة", "إضافة"
        ],
        edit: [
            "edit",
            "تعديل",
            "عدل",
            "تحرير"
        ],
        delete: [
            "delete",
            "حذف",
            "امسح", "أمسح", "إمسح",
            "مسح",
            "شيل"
        ],
        remove: [
            "remove",
            "احذف",
            "ازالة", "إزالة",
            "ازل", "أزل",
            "نحي"
        ],
        list: [
            "list",
            "عرض",
            "قائمة",
            "لائحة",
            "اظهر", "أظهر", "إظهر",
            "استعراض", "إستعراض"
        ],
        removeall: [
            "removeall",
            "حذفالكل",
            "امسحالكل", "أمسحالكل", "إمسحالكل",
            "ازالةالكل", "إزالةالكل",
            "مسحالكل",
            "افرغ", "أفرغ", "إفرغ"
        ]
    };

    for (const [action, words] of Object.entries(actions)) {
        if (words.includes(normalizeText(a))) return action;
    }
    return null;
}

function parseParameters(input) {
    let requiredRole = 0;
    let reaction = null;
    let imgs = null;
    let cleanInput = input;
    
    const roleMatch = input.match(/--role\s+(\d+)/);
    if (roleMatch) {
        requiredRole = parseInt(roleMatch[1]);
        cleanInput = cleanInput.replace(/--role\s+\d+/, "").trim();
    }
    
    const reactMatch = input.match(/--react\s+(\S+)/);
    if (reactMatch) {
        reaction = reactMatch[1].trim();
        cleanInput = cleanInput.replace(/--react\s+\S+/, "").trim();
    }
    
    const imgsMatch = input.match(/--imgs\s+(.+?)(?=\s+--|$)/);
    if (imgsMatch) {
        const imgUrls = imgsMatch[1].trim().split(/\s+/);
        imgs = imgUrls.filter(url => url.trim().length > 0);
        cleanInput = cleanInput.replace(/--imgs\s+.+?(?=\s+--|$)/, "").trim();
    }
    
    return {
        requiredRole,
        reaction,
        imgs,
        cleanInput
    };
}

async function handleAdd(message, args, threadsData, event, shortcuts, isAdmin, utils, getLang) {
    let input = args.slice(1).join(" ");
    
    const { requiredRole, reaction, imgs, cleanInput } = parseParameters(input);
    
    let key = "";
    let value = "";
    let stickerID = null;
    let attachmentUrls = null;
    
    if (event.messageReply) {
        stickerID = event.messageReply.attachments?.[0]?.ID || null;
        if (!stickerID && event.messageReply.attachments?.length > 0) {
            attachmentUrls = event.messageReply.attachments.map(att => att.url).filter(url => url);
        }
    }
    
    if (cleanInput.includes("=>")) {
        const parts = cleanInput.split("=>").map(p => p.trim());
        key = parts[0];
        value = parts[1] || "";
    } else {
        key = cleanInput.trim();
        value = "";
    }
    
    if (!key) {
        return message.reply(getLang("invalidSyntax"));
    }
    
    const hasContent = value || stickerID || imgs || attachmentUrls || reaction;
    
    if (!hasContent) {
        return message.reply(getLang("noContent"));
    }
    
    const existingIndex = shortcuts.findIndex(s => normalizeText(s.word) === normalizeText(key));
    
    const shortcut = {
        word: key,
        reply: value,
        stickerID,
        reactWith: reaction,
        author: event.senderID,
        imgs: imgs || attachmentUrls,
        role: requiredRole,
        createdAt: Date.now()
    };
    
    if (existingIndex !== -1) {
        const existingShortcut = shortcuts[existingIndex];
        if (existingShortcut.author !== event.senderID && !isAdmin) {
            return message.reply(getLang("cannotEdit", key));
        }
        shortcuts[existingIndex] = shortcut;
        message.reply(getLang("updated", key));
    } else {
        shortcuts.push(shortcut);
        message.reply(getLang("added", key));
    }
    
    await threadsData.set(event.threadID, shortcuts, "data.shortcuts");
}

async function handleEdit(message, args, threadsData, event, shortcuts, isAdmin, getLang) {
    let input = args.slice(1).join(" ");
    
    const { requiredRole, reaction, imgs, cleanInput } = parseParameters(input);
    
    let key = "";
    let newValue = "";
    
    if (cleanInput.includes("=>")) {
        const parts = cleanInput.split("=>").map(p => p.trim());
        key = parts[0];
        newValue = parts[1] || "";
    } else {
        return message.reply(getLang("invalidEditSyntax"));
    }
    
    const existingIndex = shortcuts.findIndex(s => normalizeText(s.word) === normalizeText(key));
    
    if (existingIndex === -1) {
        return message.reply(getLang("notFound", key));
    }
    
    const existingShortcut = shortcuts[existingIndex];
    
    if (existingShortcut.author !== event.senderID && !isAdmin) {
        return message.reply(getLang("cannotEdit", key));
    }
    
    shortcuts[existingIndex] = {
        ...existingShortcut,
        reply: newValue,
        reactWith: reaction !== null ? reaction : existingShortcut.reactWith,
        imgs: imgs !== null ? imgs : existingShortcut.imgs,
        role: requiredRole !== 0 ? requiredRole : existingShortcut.role,
        createdAt: Date.now()
    };
    
    await threadsData.set(event.threadID, shortcuts, "data.shortcuts");
    message.reply(getLang("updated", key));
}

async function handleDelete(message, args, threadsData, event, shortcuts, isAdmin, getLang) {
    const key = args.slice(1).join(" ").trim();
    
    if (!key) {
        return message.reply(getLang("deleteSpecify"));
    }
    
    const shortcutIndex = shortcuts.findIndex(s => normalizeText(s.word) === normalizeText(key));
    
    if (shortcutIndex === -1) {
        return message.reply(getLang("notFound", key));
    }
    
    const shortcut = shortcuts[shortcutIndex];
    
    if (shortcut.author !== event.senderID && !isAdmin) {
        return message.reply(getLang("cannotDelete"));
    }
    
    shortcuts.splice(shortcutIndex, 1);
    await threadsData.set(event.threadID, shortcuts, "data.shortcuts");
    
    message.reply(getLang("deleted", key));
}

async function handleList(message, shortcuts, getLang) {
    if (shortcuts.length === 0) {
        return message.reply(getLang("noShortcuts"));
    }
    
    const sortedShortcuts = shortcuts.sort((a, b) => a.word.localeCompare(b.word));
    
    const shortcutList = sortedShortcuts.map((s, i) => {
        let info = `${i + 1}. "${s.word}"`;
        if (s.role > 0) info += ` (Role ${s.role}+)`;
        if (s.stickerID) info += " 🎯";
        if (s.imgs && s.imgs.length > 0) info += " 🖼️";
        if (s.reactWith) info += " 👍";
        if (!s.reply && (s.stickerID || s.imgs || s.reactWith)) info += " [No Text]";
        return info;
    }).join("\n");
    
    message.reply(getLang("shortcutsList", shortcutList, shortcuts.length));
}

async function handleRemoveAll(message, threadsData, event, isAdmin, getLang) {
    if (!isAdmin) {
        return message.reply(getLang("onlyAdmins"));
    }
    
    const sentMessage = await message.reply(getLang("confirmRemoveAll"));
    
    global.YamiBot.onReaction.set(sentMessage.messageID, {
        commandName: exports.config.name,
        messageID: sentMessage.messageID,
        threadID: event.threadID,
        author: event.senderID
    });
}

async function sendShortcut(message, shortcut, event, utils, senderRole = 0) {
    if (senderRole < shortcut.role) return;
    
    let withSticker = false;
    const form = {};
    
    if (shortcut.reply && shortcut.reply.trim()) {
        form.body = shortcut.reply;
    }
    
    if (shortcut.stickerID) {
        withSticker = true;
    }
    
    if (shortcut.imgs && shortcut.imgs.length > 0) {
        try {
            const streams = [];
            for (const url of shortcut.imgs) {
                if (url && url.trim()) {
                    const stream = await utils.getStreamFromUrl(url.trim());
                    if (stream) streams.push(stream);
                }
            }
            if (streams.length > 0) {
                form.attachment = streams;
            }
        } catch (error) {
            console.log("Error loading images:", error);
        }
    }
    
    if (Object.keys(form).length > 0) {
        message.reply(form, () => {
            if (withSticker) {
                message.send({ sticker: shortcut.stickerID });
            }
        });
    } else if (withSticker) {
        message.send({ sticker: shortcut.stickerID });
    }
    
    if (shortcut.reactWith) {
        message.reaction(shortcut.reactWith, event.messageID);
    }
}