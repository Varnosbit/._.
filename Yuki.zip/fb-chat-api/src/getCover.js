module.exports = function (defaultFuncs, api, ctx) {
  return function getCover(url) {
    try {
      const u = new URL(url);

      const fbid = u.searchParams.get("fbid");
      if (!fbid) throw new Error("Invalid URL: fbid not found");

      const setRaw = u.searchParams.get("set");
      if (!setRaw) throw new Error("Invalid URL: set not found");

      const setID = setRaw.replace("a.", "").trim();

      const variables = {
        feedbackSource: 65,
        feedLocation: "COMET_MEDIA_VIEWER",
        focusCommentID: null,
        isMediaset: true,
        mediasetToken: `a.${setID}`,
        nodeID: fbid,
        privacySelectorRenderLocation: "COMET_MEDIA_VIEWER",
        renderLocation: "comet_media_viewer",
        scale: 2,
        useDefaultActor: false
      };

      return defaultFuncs
        .post("https://web.facebook.com/api/graphql/", ctx.jar, {
          av: ctx.userID,
          fb_api_caller_class: "RelayModern",
          fb_api_req_friendly_name: "CometPhotoRootContentQuery",
          variables: JSON.stringify(variables),
          server_timestamps: true,
          doc_id: "25081326651561232",
          fb_dtsg: ctx.fb_dtsg
        })
        .then(resData => {
          if (!resData) throw new Error("No response data received");

          const txt = JSON.stringify(resData);

          const urls = [...txt.matchAll(/"prefetch_uris_v2"[\s\S]*?"uri":"([^"]+)"/g)]
            .map(m => m[1]);

          if (!urls.length) throw new Error("No cover URLs found");

          return urls;
        })
        .catch(err => {
          throw new Error(`getCoverFca error: ${err.message}`);
        });

    } catch (err) {
      return Promise.reject(new Error(`getCoverFca error: ${err.message}`));
    }
  };
};
