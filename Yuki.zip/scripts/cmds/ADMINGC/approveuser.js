//2.1.1
exports.config = {
  name: "approveuser",
  aliases: ["قبول"],
  author: "allou mohamed",
  category: "group",
  description: {
en: "Approve members in approval mode",
ar: "قبول كل من في طلبات الانضمام اذا البوت ادمن"
     },
  role: 1
};

exports.onStart = async ({ api, message, event, usersData, commandName, args }) => {
  const threadInfo = await api.getThreadInfo(event.threadID);
  const arrayQueue = threadInfo.approvalQueue || [];

  if (arrayQueue.length === 0) {
    return message.reply("✅ Approval queue is empty.");
  }

  const toAddUids = await Promise.all(arrayQueue.map(async (item, index) => {
    const name = await usersData.getName(item.requesterID) || "Unknown User";
    return {
      index: index + 1,
      name,
      uid: item.requesterID
    };
  }));

  const perPage = 10;
  const totalPages = Math.ceil(toAddUids.length / perPage);
  const currentPage = /^[0-9]+$/.test(args[0]) ? Math.max(0, Math.min(Number(args[0]), totalPages - 1)) : 0;

  const pageUsers = toAddUids.slice(currentPage * perPage, (currentPage + 1) * perPage);

  if (pageUsers.length === 0) {
    return message.reply("⚠️ No users found on this page.");
  }

  const listText = pageUsers.map(user => `${user.index}. ${user.name} (${user.uid})`).join("\n");

  message.send(
    `📋 Approval Queue (Page ${currentPage + 1}/${totalPages})\n\n${listText}\n\nReply with:\n- A number (e.g. 3) to approve one\n- Multiple numbers (e.g. 1 4 7)\n- "all" to approve all users`,
    (err, msg) => {
      if (err) return message.reply(`❌ ${err.message}`);
      global.GoatBot.onReply.set(msg.messageID, {
        commandName,
        toAddUids,
        op: event.senderID,
        threadID: event.threadID
      });
    }
  );
};

exports.onReply = async function({ event, api, mqtt, message, Reply, args }) {
  if (Reply.op !== event.senderID) return;

  const toAddUids = Reply.toAddUids;
  const threadID = Reply.threadID;
  let selected = [];

  if (args[0] === "all") {
    selected = toAddUids;
  } else {
    const indexes = args.map(x => parseInt(x)).filter(x => !isNaN(x));
    selected = toAddUids.filter(user => indexes.includes(user.index));
  }

  if (selected.length === 0) {
    return message.reply("⚠️ No valid users selected.");
  }

  const failed = [];
  const success = [];

  for (const user of selected) {
    try {
      if (typeof mqtt?.approvalQueue === "function") {
        await mqtt.approvalQueue(threadID, [user.uid], true);
      } else {
        await api.addUserToGroup(user.uid, threadID);
      }
      success.push(`${user.name} (${user.uid})`);
    } catch {
      failed.push(`${user.name} (${user.uid})`);
    }
  }

  let replyMsg = `✅ Approved ${success.length} users:\n${success.join("\n")}`;
  if (failed.length > 0) {
    replyMsg += `\n\n❌ Failed to approve ${failed.length}:\n${failed.join("\n")}`;
  }

  return message.reply(replyMsg);
};
