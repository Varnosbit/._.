const FormData = require("form-data");
const axios = require("axios");
const sharp = require("sharp");
const fs = require("fs");

class MidjourneyAutomation {
  constructor(apiSecret) {
    this.apiSecret = apiSecret;
  }

  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async submitImagine(prompt, botType = 'MID_JOURNEY') {
    try {
      const response = await fetch('https://ai.trueai.org/mj/submit/imagine', {
        method: 'POST',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Accept-Encoding': 'gzip, deflate, br, zstd',
          'Content-Type': 'application/json',
          'authorization': `Bearer ${this.apiSecret}`,
          'sec-ch-ua-platform': '"Windows"',
          'accept-language': 'en-US',
          'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
          'sec-ch-ua-mobile': '?0',
          'origin': 'https://ai.trueai.org',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': 'https://ai.trueai.org/',
          'priority': 'u=1, i'
        },
        body: JSON.stringify({
          botType: botType,
          prompt: prompt,
          base64Array: [],
          state: 'midjourney-proxy-admin',
          accountFilter: {}
        })
      });

      const data = await response.json();
      
      if (data.code === 1 && data.result) {
        return data.result;
      } else {
        throw new Error(data.description || 'Task submission failed');
      }
    } catch (error) {
      throw error;
    }
  }

  async submitAction(taskId, customId) {
    try {
      const response = await fetch('https://ai.trueai.org/mj/submit/action', {
        method: 'POST',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Accept-Encoding': 'gzip, deflate, br, zstd',
          'Content-Type': 'application/json',
          'authorization': `Bearer ${this.apiSecret}`,
          'sec-ch-ua-platform': '"Windows"',
          'accept-language': 'en-US',
          'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
          'sec-ch-ua-mobile': '?0',
          'origin': 'https://ai.trueai.org',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': 'https://ai.trueai.org/',
          'priority': 'u=1, i'
        },
        body: JSON.stringify({
          taskId: taskId,
          customId: customId,
          state: 'midjourney-proxy-admin',
          chooseSameChannel: true,
          enableRemix: false
        })
      });

      const data = await response.json();
      
      if (data.code === 1 && data.result) {
        return data.result;
      } else {
        throw new Error(data.description || 'Action submission failed');
      }
    } catch (error) {
      throw error;
    }
  }

  async checkTaskStatus(taskId) {
    try {
      const response = await fetch('https://ai.trueai.org/mj/task/list-by-ids', {
        method: 'POST',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Accept-Encoding': 'gzip, deflate, br, zstd',
          'Content-Type': 'application/json',
          'authorization': `Bearer ${this.apiSecret}`,
          'sec-ch-ua-platform': '"Windows"',
          'accept-language': 'en-US',
          'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
          'sec-ch-ua-mobile': '?0',
          'origin': 'https://ai.trueai.org',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': 'https://ai.trueai.org/',
          'priority': 'u=1, i'
        },
        body: JSON.stringify({ ids: [taskId] })
      });

      const data = await response.json();
      
      if (data && data.length > 0) {
        return data[0];
      }
      return null;
    } catch (error) {
      throw error;
    }
  }

  async waitForCompletion(taskId, maxAttempts = 160) {
    for (let i = 0; i < maxAttempts; i++) {
      const task = await this.checkTaskStatus(taskId);
      
      if (task) {
        if (task.status === 'SUCCESS' && task.isCompleted) {
          return task;
        } else if (task.status === 'FAILURE') {
          throw new Error(`Task failed: ${task.failReason}`);
        }
      }
      
      await this.sleep(5000);
    }
    
    throw new Error('Task timeout');
  }
}

exports.langs = {
    en: {
      selectBot: "Please select:\n1. Midjourney\n2. Niji Journey",
      invalidOption: "Invalid option. Please choose 1 or 2.",
      enterPrompt: "Enter your prompt:",
      emptyPrompt: "Prompt cannot be empty.",
      taskFailed: "Failed to submit the task.",
      completionFailed: "Failed to complete the task.",
      taskSuccess: "✓ Task Successful",
      availableActions: "Available Actions:",
      replyAction: "➡ Reply with an action (U1-U5, V1-V4, or P1-P4)",
      provideAction: "Please provide an action (U1-U5, V1-V4, or P1-P4).",
      invalidPreview: "Invalid preview. Use P1–P4.",
      invalidAction: "Invalid action. Use U1-U5, V1-V4, or P1-P4.",
      upscaleRequest: "⏳ Processing...\n⚠️ This may take 45+ seconds, please wait.",
      upscaledAll: "✓ All 4 images upscaled successfully!",
      upscaledFor: "✓ Processed image for",
      processingError: "Error occurred while processing the image.",
      errorDetails: "Error Details:",
      variationProcessing: "⏳ Creating variation...\n⚠️ This may take up to 60 seconds, please wait."
    },
    ar: {
      selectBot: "الرجاء الاختيار:\n1. Midjourney\n2. Niji Journey",
      invalidOption: "خيار غير صالح. الرجاء اختيار 1 أو 2.",
      enterPrompt: "أدخل الوصف الخاص بك:",
      emptyPrompt: "لا يمكن أن يكون الوصف فارغاً.",
      taskFailed: "فشل في إرسال المهمة.",
      completionFailed: "فشل في إكمال المهمة.",
      taskSuccess: "✓ نجحت المهمة",
      availableActions: "الإجراءات المتاحة:",
      replyAction: "➡ الرد بإجراء (U1-U5، V1-V4، أو P1-P4)",
      provideAction: "الرجاء تقديم إجراء (U1-U5، V1-V4، أو P1-P4).",
      invalidPreview: "معاينة غير صالحة. استخدم P1–P4.",
      invalidAction: "إجراء غير صالح. استخدم U1-U5، V1-V4، أو P1-P4.",
      upscaleRequest: "⏳ جاري المعالجة...\n⚠️ قد يستغرق هذا 45+ ثانية، يرجى الانتظار.",
      upscaledAll: "✓ تم معالجة جميع الصور الأربع بنجاح!",
      upscaledFor: "✓ تم معالجة الصورة لـ",
      processingError: "حدث خطأ أثناء معالجة الصورة.",
      errorDetails: "تفاصيل الخطأ:",
      variationProcessing: "⏳ جاري إنشاء التنويع...\n⚠️ قد يستغرق هذا 60 ثانية، يرجى الانتظار."
    }
};

exports.config = {
    name: "mjdev",
    role: 3,
    category: "ai",
    version: "16.0.0"
};

const key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjIwNTIxMTYzIiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbmFtZSI6ImJhYyoqKio4NjQ5IiwibmJmIjoxNzY3MjkwODE1LCJleHAiOjE3OTg4MjY4MTUsImlzcyI6Imh1YW53YW5nYWkifQ.JhhKX6qCFqS-jqfkejMaUgfjfDlPSd-Qlc8QHzEaWrg"; // Add your Bearer token here

exports.onStart = async ({ commandName, event, message, getLang }) => {
    try {
        const info = await message.reply(getLang('selectBot'));
        global.YamiBot.onReply.set(info.messageID, {
            commandName,
            author: event.senderID,
            bots: ["MID_JOURNEY", "NIJI_JOURNEY"]
        });
    } catch (error) {
        return message.reply(`${getLang('errorDetails')}\n\`\`\`\n${error.stack}\n\`\`\``);
    }
};

exports.onReply = async ({ args, commandName, event, message, Reply, getLang }) => {
    try {
        if (Reply.author !== event.senderID) return;

        if (Reply.bots) {
            const index = parseInt(args[0]) - 1;
            if (isNaN(index) || index < 0 || index >= Reply.bots.length) {
                return message.reply(getLang('invalidOption'));
            }
            const info = await message.reply(getLang('enterPrompt'));
            global.YamiBot.onReply.set(info.messageID, {
                commandName,
                author: event.senderID,
                bot: Reply.bots[index]
            });
            return;
        }

        if (Reply.bot) {
            const prompt = args.join(" ");
            if (!prompt) return message.reply(getLang('emptyPrompt'));

            const mj = new MidjourneyAutomation(key);

            const taskId = await mj.submitImagine(prompt, Reply.bot);
            if (!taskId) return message.reply(getLang('taskFailed'));

            const completedTask = await mj.waitForCompletion(taskId);
            if (!completedTask) return message.reply(getLang('completionFailed'));

            const imageUrl = completedTask.imageUrl;

            let txt = `${getLang('taskSuccess')}\n`;
            txt += `# ${getLang('availableActions')}\n\n`;
            txt += `U1 U2 U3 U4 U5 (Upscale)\n`;
            txt += `V1 V2 V3 V4 (Variation)\n`;
            txt += `P1 P2 P3 P4 (Preview)\n`;
            txt += `\n(U5 = Upscale all 4 images)`;

            const info = await message.stream(txt + "\n\n" + getLang('replyAction'), imageUrl);

            global.YamiBot.onReply.set(info.messageID, {
                commandName,
                author: event.senderID,
                imageUrl,
                taskId: completedTask.id,
                buttons: completedTask.buttons
            });

            return;
        }

        if (Reply.imageUrl) {
            const choice = args[0]?.toUpperCase();
            if (!choice) return message.reply(getLang('provideAction'));

            // Handle P# - Preview selection
            if (choice.startsWith("P")) {
                const index = parseInt(choice.substring(1)) - 1;
                if (isNaN(index) || index < 0 || index >= 4) {
                    return message.reply(getLang('invalidPreview'));
                }

                const info = await message.stream(`📤 P${index + 1}`, Reply.imageUrl);

                global.YamiBot.onReply.set(info.messageID, {
                    commandName,
                    author: event.senderID,
                    action: "LOCAL_UPSCALE",
                    img: Reply.imageUrl,
                    quadrant: index + 1,
                    taskId: Reply.taskId,
                    buttons: Reply.buttons
                });

                return;
            }

            // Handle U# - Upscale (always local)
            if (choice.startsWith("U")) {
                return localCropAndUpscale(Reply.imageUrl, choice, message, getLang);
            }

            // Handle V# - Variation
            if (choice.startsWith("V")) {
                const index = parseInt(choice.substring(1));
                if (isNaN(index) || index < 1 || index > 4) {
                    return message.reply(getLang('invalidAction'));
                }
                
                const mj = new MidjourneyAutomation(key);
                const button = Reply.buttons.find(b => b.label === choice);
                
                if (!button) {
                    return message.reply(getLang('invalidAction'));
                }
                
                const notice = await message.reply(getLang('variationProcessing'));
                const newTaskId = await mj.submitAction(Reply.taskId, button.customId);
                const completedTask = await mj.waitForCompletion(newTaskId);
                
                let txt = `${getLang('taskSuccess')} - Variation ${index}\n`;
                txt += `# ${getLang('availableActions')}\n\n`;
                txt += `U1 U2 U3 U4 U5 (Upscale)\n`;
                txt += `V1 V2 V3 V4 (Variation)\n`;
                txt += `P1 P2 P3 P4 (Preview)`;
                
                const info = await message.stream(txt, completedTask.imageUrl);
                
                global.YamiBot.onReply.set(info.messageID, {
                    commandName,
                    author: event.senderID,
                    imageUrl: completedTask.imageUrl,
                    taskId: completedTask.id,
                    buttons: completedTask.buttons
                });
                
                message.unsend(notice.messageID);
                return;
            }

            return message.reply(getLang('invalidAction'));
        }

        // Handle upscale/variation on selected preview
        if (Reply.action === "LOCAL_UPSCALE" && args[0]?.toUpperCase().startsWith("U")) {
            return localCropAndUpscale(Reply.img, args[0].toUpperCase(), message, getLang);
        }
        
        if (Reply.action === "LOCAL_UPSCALE" && args[0]?.toUpperCase().startsWith("V")) {
            const choice = args[0].toUpperCase();
            const index = parseInt(choice.substring(1));
            if (isNaN(index) || index < 1 || index > 4) {
                return message.reply(getLang('invalidAction'));
            }
            
            const mj = new MidjourneyAutomation(key);
            const button = Reply.buttons.find(b => b.label === choice);
            
            if (!button) {
                return message.reply(getLang('invalidAction'));
            }
            
            const notice = await message.reply(getLang('variationProcessing'));
            const newTaskId = await mj.submitAction(Reply.taskId, button.customId);
            const completedTask = await mj.waitForCompletion(newTaskId);
            
            await message.stream(getLang('taskSuccess'), completedTask.imageUrl);
            message.unsend(notice.messageID);
            return;
        }
    } catch (error) {
        return message.reply(`${getLang('errorDetails')}\n\`\`\`\n${error.stack}\n\`\`\``);
    }
};

async function createStreamFromUrl(url) {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(response.data);
    const tempPath = `temp_${Date.now()}.png`;
    fs.writeFileSync(tempPath, buffer);
    return fs.createReadStream(tempPath);
}

async function localCropAndUpscale(imageUrl, action, message, getLang) {
    const options = ["U1", "U2", "U3", "U4", "U5"];
    if (!options.includes(action)) {
        return message.reply(getLang('invalidAction'));
    }

    try {
        const upscaleNotice = await message.reply(getLang('upscaleRequest'));
        const imageBuffer = await axios.get(imageUrl, { responseType: 'arraybuffer' }).then(res => Buffer.from(res.data));
        const metadata = await sharp(imageBuffer).metadata();
        const width = metadata.width;
        const height = metadata.height;

        const halfWidth = Math.floor(width / 2);
        const halfHeight = Math.floor(height / 2);

        const cropMap = {
            "U1": { left: 0, top: 0, width: halfWidth, height: halfHeight },
            "U2": { left: halfWidth, top: 0, width: halfWidth, height: halfHeight },
            "U3": { left: 0, top: halfHeight, width: halfWidth, height: halfHeight },
            "U4": { left: halfWidth, top: halfHeight, width: halfWidth, height: halfHeight }
        };

        // Handle U5 - Upscale all 4 images
        if (action === "U5") {
            const regions = [cropMap.U1, cropMap.U2, cropMap.U3, cropMap.U4];

            const attachments = await Promise.all(regions.map(async (region, i) => {
                const cropped = await sharp(imageBuffer).extract(region).toBuffer();
                const upscaled = await upscaleImage(cropped);
                const pathFile = `upscaled_U${i + 1}.png`;
                fs.writeFileSync(pathFile, upscaled);
                return fs.createReadStream(pathFile);
            }));

            await message.reply({ 
                body: getLang('upscaledAll'), 
                attachment: attachments 
            }, () => {
                attachments.forEach(s => fs.unlinkSync(s.path));
                message.unsend(upscaleNotice.messageID);
            });

            return;
        }

        // Handle U1-U4 - Upscale single image
        const region = cropMap[action];
        const croppedImage = await sharp(imageBuffer).extract(region).toBuffer();
        const upscaledImage = await upscaleImage(croppedImage);

        const filePath = `upscaled_${action}.png`;
        fs.writeFileSync(filePath, upscaledImage);

        await message.reply({ 
            body: `${getLang('upscaledFor')} ${action}`, 
            attachment: fs.createReadStream(filePath) 
        }, () => {
            fs.unlinkSync(filePath);
            message.unsend(upscaleNotice.messageID);
        });
    } catch (err) {
        return message.reply(`${getLang('errorDetails')}\n\`\`\`\n${err.stack}\n\`\`\``);
    }
}

async function upscaleImage(imageData, scale = 4) {
    const taskId = '35mgpvmkm2r8ytqchyj0y1rxgpp74f78hAccdrc2019n4rc8d2zxs7nbh69z3pb6g97bc0007rwlbcj3hfn11gzmf83h1gjnfdj0cd738ykfAgr6r479pz09n30fzpg0tc33vkvq6zhj11fbk5mjsrqAq90kn0hxmyAmys3yf0dcz5flrqxq';
    
    const { data: html } = await axios.get("https://www.iloveimg.com/upscale-image");
    const token = html.match(/"toolText":"Upscale","token":"([^"]+)"/)[1];
    const authorization = `Bearer ${token}`;
    const uploadData = new FormData();
    const fileName = `image_${Date.now()}.jpg`;
    
    uploadData.append('name', fileName);
    uploadData.append('chunk', '0');
    uploadData.append('chunks', '1');
    uploadData.append('task', taskId);
    uploadData.append('preview', '1');
    uploadData.append('pdfinfo', '0');
    uploadData.append('pdfforms', '0');
    uploadData.append('pdfresetforms', '0');
    uploadData.append('v', 'web.0');
    uploadData.append('file', imageData, { filename: fileName });

    const uploadConfig = {
      method: 'POST',
      url: 'https://api12g.iloveimg.com/v1/upload',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'sec-ch-ua-platform': '"Android"',
        'authorization': authorization,
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?1',
        'Origin': 'https://www.iloveimg.com',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://www.iloveimg.com/',
        'Accept-Language': 'en,fr;q=0.9,ar;q=0.8',
        ...uploadData.getHeaders()
      },
      data: uploadData
    };

    const uploadResponse = await axios.request(uploadConfig);
    const serverFilename = uploadResponse.data.server_filename;
    
    const upscaleData = new FormData();
    upscaleData.append('task', taskId);
    upscaleData.append('server_filename', serverFilename);
    upscaleData.append('scale', scale.toString());

    const upscaleConfig = {
      method: 'POST',
      url: 'https://api12g.iloveimg.com/v1/upscale',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'sec-ch-ua-platform': '"Android"',
        'Authorization': authorization,
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?1',
        'Origin': 'https://www.iloveimg.com',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://www.iloveimg.com/',
        'Accept-Language': 'en,fr;q=0.9,ar;q=0.8',
        ...upscaleData.getHeaders()
      },
      data: upscaleData,
      responseType: 'arraybuffer'
    };
    
    const upscaleResponse = await axios.request(upscaleConfig);
    const imageBuffer = Buffer.from(upscaleResponse.data);
    return imageBuffer;
}