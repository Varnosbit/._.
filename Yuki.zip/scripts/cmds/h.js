const canvas = require('canvas');
const fs = require('fs');
const path = require('path');
const { createCanvas } = canvas;
const Prism = require('prismjs');
const loadLanguages = require('prismjs/components/');
const { JSDOM } = require('jsdom');
loadLanguages(['javascript']);
module.exports = {
    config: {
        name: "snippets",
        category: "Education",
        author: "Allou Mohamed",
        countDown: 5,
        description: {
            en: "Highlight JS codes.",
            ar: "تسليط الضوء على أكواد جافاسكريبت."
        },
        role: 0,
        aliases: ["h"]
    },
onStart: async function({ args, message }) {
    const code = args.join(" ") || `const BotOwner = "allou mohamed"; // bot owner`;

    if (!isValidSyntax(code)) return message.reply("Your code has syntax issues 🥰");

    const highlightedImagePath = await generateHighlightedCodeImage(code);
    const new_image = await canvas.loadImage(highlightedImagePath);

    const padding = 50;
    const new_width = new_image.width + padding * 2;
    const new_height = new_image.height + padding * 2;

    const new_canvas = canvas.createCanvas(new_width, new_height);
    const new_ctx = new_canvas.getContext('2d');

    const new_gradient = new_ctx.createLinearGradient(0, 0, new_width, new_height);
    new_gradient.addColorStop(0, 'orange');
    new_gradient.addColorStop(1, 'lightcoral');
    new_ctx.fillStyle = new_gradient;
    new_ctx.fillRect(0, 0, new_width, new_height);

    const x = padding;
    const y = padding;

    new_ctx.drawImage(new_image, x, y);

    const new_imagePath = __dirname+'/cache/image.png';
    const out = fs.createWriteStream(new_imagePath);
    const stream = new_canvas.createPNGStream();
    stream.pipe(out);

    out.on('finish', () => {
        message.reply({ attachment: fs.createReadStream(new_imagePath) }, (err) => {
            if (!err) {
                fs.unlinkSync(highlightedImagePath);
                fs.unlinkSync(new_imagePath);
            }
        });
    });
}
};

async function generateHighlightedCodeImage(code) {
    const highlightedCode = Prism.highlight(code, Prism.languages.javascript, 'javascript');
    const { width, height } = calculateDimensions(code);

    const highResScale = 2;
    const canvasInstance = createCanvas(Math.min(width * highResScale, 3840), Math.min(height * highResScale, 2160));
    const ctx = canvasInstance.getContext('2d');
    ctx.scale(highResScale, highResScale);

    drawCodeOnCanvas(ctx, code, highlightedCode, width, height);

    const imagePath = path.join(__dirname, 'cache', 'highlighted_code.png');
    const buffer = canvasInstance.toBuffer('image/png');
    fs.writeFileSync(imagePath, buffer);

    return imagePath;
}

function calculateDimensions(code) {
    const tempCanvas = createCanvas(1, 1);
    const tempCtx = tempCanvas.getContext('2d');
    tempCtx.font = '16px Consolas, monospace';

    const lineHeight = 20;
    const lines = code.split('\n');
    let maxWidth = 0;
    let totalHeight = 0;

    lines.forEach(line => {
        const { width } = tempCtx.measureText(line);
        maxWidth = Math.max(maxWidth, width);
        totalHeight += lineHeight;
    });

    totalHeight += 40;

    return { width: maxWidth + 60, height: totalHeight }; 
}

function drawCodeOnCanvas(ctx, code, highlightedCode, width, height) {
    const lines = code.split('\n');
    const dom = new JSDOM(highlightedCode);
    const { document } = dom.window;

    ctx.fillStyle = 'black'; // Bg
    ctx.fillRect(0, 0, width, height);
    ctx.font = '16px Consolas, monospace';
    ctx.textBaseline = 'top';

    const lineHeight = 20;
    const lineNumberWidth = 30;
    const xOffset = lineNumberWidth + 10;
    let yOffset = 20;

    lines.forEach((line, index) => {
        const y = yOffset;
        const lineNumber = index + 1;

        //lines
        ctx.fillStyle = '#7d7d7d'; 
        ctx.fillText(`${lineNumber} `, 10, y);

        
        const tokens = Prism.tokenize(line, Prism.languages.javascript);
        let x = xOffset;

        tokens.forEach(token => {
            if (typeof token === 'string') {
                ctx.fillStyle = '#d4d4d4'; // default color 
                ctx.fillText(token, x, y);
                x += ctx.measureText(token).width;
            } else {
                ctx.fillStyle = getTokenColor(token.type);
                ctx.fillText(token.content, x, y);
                x += ctx.measureText(token.content).width;
            }
        });

        yOffset += lineHeight;
    });
}

function getTokenColor(type) {
    
    const colors = {
        keyword: '#569cd6', 
        string: '#ce9178',  
        function: '#C200FF', 
        punctuation: '#d4d4d4', 
        operator: '#57AFFF', 
        comment: '#6a9955', 
        variable: '#77C3FE', 
        number: '#80FF00', 
        boolean: '#569cd6' 
    };

    return colors[type] || '#d4d4d4'; // Default .__.
}

function isValidSyntax(code) {
    try {
        new Function(code);
        return true;
    } catch (e) {
        return false;
    }
}