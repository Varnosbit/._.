//1.0.0
exports.config = {
    name: "rules",
    aliases: ["قوانين", "قواعد"],
    version: "16.0.2",
    role: 0,
    author: "Allou Mohamed",
    description: {
      en: "Group Rules Manager.", 
      ar: "قوانين المجموعة."
   },
    category: "group",
    countDown: 5
};

exports.langs = {
    en: {
        invalidCommand: "❌ Invalid command.",
        noRuleText: "❌ Please provide the rule text.",
        ruleAdded: "✅ Rule added successfully!",
        noRules: "📜 No rules set for this group yet.",
        rulesList: "RULES\n_________________________\n%1\n_________________________\n%2",
        ruleDeleted: "✅ Rule #%1 deleted successfully!",
        ruleNotFound: "❌ Rule not found.",
        noRuleNumber: "❌ Please provide rule number.",
        invalidNumber: "❌ Invalid number.",
        onlyAdmins: "❌ Only admins can manage rules.",
        confirmClear: "⚠️ Delete all rules?\n👍 Confirm\n👎 Cancel",
        clearCancelled: "❌ Cancelled.",
        allCleared: "🗑️ All rules removed.",
        ruleUpdated: "✅ Rule #%1 updated.",
        replyWithNumber: "💬 Reply with rule number.",
        replyToEdit: "💬 Reply with: number => new text",
        replyToDelete: "💬 Reply with rule number to delete.",
        provideNewText: "📝 Send new text for rule #%1"
    },
    ar: {
        invalidCommand: "❌ أمر غير صحيح",
        noRuleText: "❌ اكتب نص القانون",
        ruleAdded: "✅ تم إضافة القانون",
        noRules: "📜 لا توجد قوانين",
        rulesList: "قواعد\n_________________________\n%1\n_________________________\n%2",
        ruleDeleted: "✅ تم حذف القانون رقم %1",
        ruleNotFound: "❌ القانون غير موجود",
        noRuleNumber: "❌ اكتب رقم القانون",
        invalidNumber: "❌ رقم غير صالح",
        onlyAdmins: "❌ هذا الأمر للإدمن فقط",
        confirmClear: "⚠️ هل تريد حذف جميع القوانين؟\n👍 تأكيد\n👎 إلغاء",
        clearCancelled: "❌ تم الإلغاء",
        allCleared: "🗑️ تم حذف جميع القوانين",
        ruleUpdated: "✅ تم تعديل القانون رقم %1",
        replyWithNumber: "💬 أرسل رقم القانون",
        replyToEdit: "💬 أرسل: رقم => نص جديد",
        replyToDelete: "💬 أرسل رقم القانون للحذف",
        provideNewText: "📝 اكتب النص الجديد للقانون %1"
    }
};

function centerText(text, width = 25) {
    const pad = Math.max(0, Math.floor((width - text.length) / 2));
    return "\t".repeat(pad) + text;
}

function formatSingleRule(rule, number, lang) {
    const footer = lang === "ar" ? "احترم كي لا تطرد" : "Respect or be removed";
    return (
        (lang === "ar" ? "قواعد" : "RULES") +
        "\n_________________________\n" +
        `${number}. ${rule.text}\n` +
        "_________________________\n" +
        centerText(footer)
    );
}

function normalizeAction(action) {
    if (!action) return "list";
    const a = action.toLowerCase();

    const map = {
        add: ["add", "اضف", "أضف"],
        delete: [
            "delete", "remove",
            "حذف", "احذف", "إحذف", "ازالة", "إزالة",
            "ازل", "شيل", "نحي",
            "حذفكل", "حذفالكل", "شيلها"
        ],
        edit: ["edit", "تعديل", "عدل"],
        list: ["list", "show", "عرض", "قائمة", "اظهر", "أظهر"],
        clear: ["clear", "removeall", "deleteall", "مسح", "مسحكل", "افرغ"]
    };

    for (const key in map)
        if (map[key].includes(a)) return key;

    return "list";
}

exports.onStart = async ({ message, args, threadsData, event, role, getLang }) => {
    const rules = await threadsData.get(event.threadID, "data.rules", []);
    const action = normalizeAction(args[0]);
    const lang = getLang("invalidCommand").includes("أ") ? "ar" : "en";

    if (["add", "delete", "edit", "clear"].includes(action) && role < 1)
        return message.reply(getLang("onlyAdmins"));

    if (action === "add") {
        const text = args.slice(1).join(" ");
        if (!text) return message.reply(getLang("noRuleText"));
        rules.push({ text, createdAt: Date.now() });
        await threadsData.set(event.threadID, rules, "data.rules");
        return message.reply(getLang("ruleAdded"));
    }

    if (action === "list") {
        if (!rules.length) return message.reply(getLang("noRules"));
        const list = rules.map((r, i) => `${i + 1}. ${r.text}`).join("\n");
        return message.reply(
            getLang("rulesList", list, centerText(lang === "ar" ? "احترم كي لا تطرد" : "Respect or be removed"))
        );
    }

    if (action === "delete") {
        if (!args[1]) {
            const m = await message.reply(getLang("replyToDelete"));
            return global.GoatBot.onReply.set(m.messageID, {
                commandName: exports.config.name,
                action: "deleteRule",
                author: event.senderID
            });
        }
        const num = parseInt(args[1]);
        if (!rules[num - 1]) return message.reply(getLang("invalidNumber"));
        rules.splice(num - 1, 1);
        await threadsData.set(event.threadID, rules, "data.rules");
        return message.reply(getLang("ruleDeleted", num));
    }

    if (action === "edit") {
        const input = args.slice(1).join(" ");
        if (!input.includes("=>")) return message.reply(getLang("replyToEdit"));
        const [n, txt] = input.split("=>").map(t => t.trim());
        const num = parseInt(n);
        if (!rules[num - 1]) return message.reply(getLang("invalidNumber"));
        rules[num - 1].text = txt;
        await threadsData.set(event.threadID, rules, "data.rules");
        return message.reply(getLang("ruleUpdated", num));
    }

    if (action === "clear") {
        const m = await message.reply(getLang("confirmClear"));
        return global.GoatBot.onReaction.set(m.messageID, {
            commandName: exports.config.name,
            author: event.senderID
        });
    }
};

exports.onReply = async ({ event, Reply, threadsData, message, role, getLang }) => {
    if (role < 1) return message.reply(getLang("onlyAdmins"));
    const rules = await threadsData.get(event.threadID, "data.rules", []);
    const num = parseInt(event.body);
    if (!rules[num - 1]) return message.reply(getLang("invalidNumber"));
    rules.splice(num - 1, 1);
    await threadsData.set(event.threadID, rules, "data.rules");
    message.reply(getLang("ruleDeleted", num));
};

exports.onReaction = async ({ event, threadsData, message, role, getLang }) => {
    if (role < 1) return;
    if (event.reaction === "👍") {
        await threadsData.set(event.threadID, [], "data.rules");
        return message.reply(getLang("allCleared"));
    }
    if (event.reaction === "👎") {
        return message.reply(getLang("clearCancelled"));
    }
};