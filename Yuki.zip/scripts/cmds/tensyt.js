const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
  config: {
    name: "download",
    aliases: ["downloader", "megadl"],
    version: "2.3",
    author: "tanvir",
    countDown: 5,
    role: 0,
    longDescription: "Download videos or audios from various sources. Supports additional parameters for file size, format, and cookies.",
    category: "media",
    guide: {
      en: {
        body: `{pn} [URL] [optional parameters]\n\n
  # examples:
     • {pn} https://example.com/video --fs 100 --type audio --c cookies.txt\n
     • {pn} https://example.com/video --maxsize 200 --format video\n
     • {pn} https://example.com/video"\n\n
  # params:
     • URL: The video or audio URL to download.\n
     • --fs or --maxsize: Specify maximum file size in MB (optional).\n
     • --type or --format: Specify download type as 'video' or 'audio' (optional).\n
     • --c or --cookie: Path to a cookie file to include in the request (optional).`
      }
    }
  },

  onStart: async function({ message, args, event, threadsData, role }) {
    const vuri = args.find(arg => /^https?:\/\//.test(arg));
    const params = pArgs(args);

    if (args[0] === 'chat' && (args[1] === 'on' || args[1] === 'off') || args[0] === 'on' || args[0] === 'off') {
      if (role >= 1) {
        const choice = args[0] === 'on' || args[1] === 'on';
        await threadsData.set(event.threadID, { data: { autoDownload: choice } });
        return message.reply(`Auto-download has been turned ${choice ? 'on' : 'off'} for this group.`);
      } else {
        return message.reply("You do not have permission to change auto-download settings.");
      }
    }

    if (!vuri) {
      return message.reply("Please provide a valid URL to download.");
    } else {
      message.reaction("⏳", event.messageID);
      await download({ vuri, params, message, event });
    }
  },

  onChat: async function({ event, message, threadsData }) {
    const x = await threadsData.get(event.threadID);
    if (!x.data.autoDownload || x.data.autoDownload === false || event.senderID === global.botID) return;

    try {
      const urlRegx = /https:\/\/[^\s]+/;
      const match = event.body.match(urlRegx);
      if (match) {
        const prefix = await global.utils.getPrefix(event.threadID);
        if (event.body.startsWith(prefix)) return;

        const vuri = match[0];
        message.reaction("⏳", event.messageID);
        const params = {};
        await download({ vuri, params, message, event });
      }
    } catch (e) {
      message.reaction("", event.messageID);
      console.error("onChat Err:", e);
    }
  }
};

async function download({ vuri, params, message, event }) {
  try {
    const reqBody = {
      url: vuri,
      ...(params.format && { format: params.format }),
      ...(params.filesize && { filesize: params.filesize }),
      ...(params.cookies && { cookies: params.cookies })
    };

    const res = await axios.post('https://app.only-fans.club/megatron/cosmic/download', reqBody);
    const data = res.data;

    message.reply({
      body: `• ${data.title}\n• Duration: ${data.duration}\n• Upload Date: ${data.upload_date || "--"}\n• Source: ${data.source}\n\n• Stream: ${data.url}`,
      attachment: await global.utils.getStreamFromUrl(data.url)
    });

    message.reaction("✅", event.messageID);
  } catch (e) {
    message.reaction("❌", event.messageID);
    console.error("Download Err:", e.res?.data || e.message);
  }
}

function pArgs(args) {
  const params = {};
  args.forEach((arg, i) => {
    if (arg.startsWith("--")) {
      const key = arg.slice(2).toLowerCase();
      const value = args[i + 1];

      switch (key) {
        case "maxsize":
        case "ms":
        case "fs":
          if (!isNaN(Number(value))) params.filesize = Number(value);
          break;

        case "type":
        case "format":
        case "media":
        case "f":
          if (["video", "audio"].includes(value.toLowerCase())) {
            params.format = value.toLowerCase();
          }
          break;

        case "cookie":
        case "cookies":
        case "c":
          const cookiePath = path.join(process.cwd(), value);
          if (fs.existsSync(cookiePath)) {
            params.cookies = fs.readFileSync(cookiePath, 'utf-8');
          }
          break;

        default:
          break;
      }
    }
  });
  return params;
}