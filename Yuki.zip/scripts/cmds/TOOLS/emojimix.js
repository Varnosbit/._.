const axios = require('axios');

module.exports = {
    config: {
        name: "emojimix",
        category: "media",
        author: "Allou Mohamed & tanvir",
        countDown: 5,
        description: {
            en: "Emoji mix.",
            ar: "دمج الإيموجيات."
        },
        role: 0,
        aliases: ["دمج", "emoix", "emox"]
    },
    onStart: async function({ message, args }) {
        async function emojiMix(emojis) {
            // Updated emoji regex to support more emojis
            const emojiArray = emojis.match(/[\p{Emoji_Presentation}\u200d\uFE0F]/gu);

            if (emojiArray && emojiArray.length === 2) {
                const e1 = encodeURIComponent(emojiArray[0]);
                const e2 = encodeURIComponent(emojiArray[1]);
                const url = `https://tenor.googleapis.com/v2/featured?key=AIzaSyACvEq5cnT7AcHpDdj64SE3TJZRhW-iHuo&client_key=emoji_kitchen_funbox&q=${e1}_${e2}&collection=emoji_kitchen_v6&contentfilter=high`;

                try {
                    const response = await axios.get(url);
                    return response.data;
                } catch (error) {
                    console.error(error);
                    throw new Error('Failed to fetch emoji mix.');
                }
            } else {
                throw new Error('Please provide exactly two emojis.');
            }
        }

        const input = args.join(" ").trim();
        const cleanedInput = input.replace(/\s+/g, ''); // Remove spaces to handle both cases

        // Check if the cleanedInput contains exactly 2 emojis
        const emojiArray = cleanedInput.match(/[\p{Emoji_Presentation}\u200d\uFE0F]/gu);
        
        if (emojiArray && emojiArray.length === 2) {
            try {
                const mix = await emojiMix(cleanedInput);
                if (mix.results && mix.results.length > 0 && mix.results[0].media_formats && mix.results[0].media_formats.png_transparent && mix.results[0].media_formats.png_transparent.url) {
                    
                    await message.stream(input, mix.results[0].media_formats.png_transparent.url);
                } else {
                    message.reply("No image available for the provided emojis.");
                }
            } catch (error) {
                message.reply(error.message);
            }
        } else {
            message.reply("Usage: emox 🥰 🌝 (provide exactly two emojis, either space-separated or not).");
        }
    }
};