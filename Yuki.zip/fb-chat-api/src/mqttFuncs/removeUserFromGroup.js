'use strict';

const { generateOfflineThreadingID } = require('../../utils');

function isCallable(fn) {
  return typeof fn === 'function';
}

function isValidContactID(contactID) {
  return typeof contactID === 'string' && contactID.trim().length > 0;
}

function isValidThreadID(threadID) {
  return typeof threadID === 'string' && threadID.trim().length > 0;
}

module.exports = function (defaultFuncs, api, ctx) {
  return async function removeMember(contactID, threadID, callback) {
    if (!ctx.mqttClient) {
      const err = new Error('Not connected to MQTT');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    if (!isValidContactID(contactID)) {
      const err = new Error('Invalid contactID: it should be a non-empty string');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    if (!isValidThreadID(threadID)) {
      const err = new Error('Invalid threadID: it should be a non-empty string');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    ctx.wsReqNumber += 1;
    ctx.wsTaskNumber += 1;

    const label = "140";
    const queueName = "remove_participant_v2";

    const taskPayload = {
      thread_id: threadID,
      contact_id: contactID,
      sync_group: 1,
    };

    const payload = JSON.stringify(taskPayload);
    const version = "9305733849522974";
    const epoch = parseInt(generateOfflineThreadingID());

    const task = {
      failure_count: null,
      label: label,
      payload: payload,
      queue_name: queueName,
      task_id: ctx.wsTaskNumber,
    };

    const content = {
      app_id: "2220391788200892",
      payload: JSON.stringify({
        tasks: [task],
        epoch_id: epoch,
        version_id: version,
      }),
      request_id: ctx.wsReqNumber,
      type: 3,
    };

    ctx.mqttClient.publish("/ls_req", JSON.stringify(content), { qos: 1, retain: false });

    const defaultCallback = (err, result) => {
      if (err) {
        return err;
      } else {
        return result;
      }
    };

    if (isCallable(callback)) {
      return callback(null, {
        status: 'sent',
        contactID,
        threadID,
        request_id: ctx.wsReqNumber,
      });
    } else {
      return defaultCallback(null, {
        status: 'sent',
        contactID,
        threadID,
        request_id: ctx.wsReqNumber,
      });
    }
  };
};
