const FormData = require("form-data");
const axios = require("axios");

module.exports = {
 config: {
 name: "plens",
 aliases: ["لانس"],
 author: "Allou Mohamed",
 version: "1.1.0",
 role: 2,
 countDown: 80,
 description: {
 en: "Find similar images using Pinterest Lens",
 ar: "البحث عن صور مشابهة باستخدام Pinterest Lens"
 },
 category: "search"
 },

 langs: {
 en: {
 noReply: "❌ Please reply to an image.",
 processing: "🔍 Searching for similar images...",
 error: "❌ An error occurred while processing the image."
 },
 ar: {
 noReply: "❌ يرجى الرد على صورة.",
 processing: "🔍 جارٍ البحث عن صور مشابهة...",
 error: "❌ حدث خطأ أثناء معالجة الصورة."
 }
 },

 onStart: async function ({ message, event, args, getLang }) {
 try {
 const attachment =
 event.messageReply?.attachments?.[0];

 if (!attachment?.url) {
 return message.reply(getLang("noReply"));
 }

 const limit = Number(args[0]) > 0 ? String(args[0]) : "5";

 message.reply(getLang("processing"));

 const imageUrls = await pinterestLens(attachment.url, limit);

 const streams = await Promise.all(
 imageUrls.map(url => utils.getStreamFromUrl(url))
 );

 return message.reply({ attachment: streams });

 } catch (err) {
 console.error("[PLENS ERROR]", err);
 return message.reply(getLang("error"));
 }
 }
};

async function pinterestLens(imageUrl, pageSize = "5") {
 const imageBuffer = await axios.get(imageUrl, {
 responseType: "arraybuffer"
 }).then(res => res.data);

 const formData = new FormData();
 formData.append("camera_type", "0");
 formData.append("source_type", "1");
 formData.append("video_autoplay_disabled", "1");
 formData.append(
 "fields",
 "pin.{id,description,created_at},pin.image_large_url"
 );
 formData.append("page_size", pageSize);
 formData.append("image", imageBuffer, {
 filename: "camera.jpg",
 contentType: "image/jpeg"
 });

 const headers = {
 ...formData.getHeaders(),
 authorization:
 "Bearer MTQzMTU5NDo5MzEzMzA1MzUzNDk5NTE5NDk6OTIyMzM3MjAzNjg1NDc3NTgwNzoxfDE2OTU5NTc5Mzc6MC0tN2M4M2IzNGI3MzdjNDg0YmM2ZjZhZjM3ZTFmODlmMWM=",
 "user-agent": "Pinterest for Android/11.29.2"
 };

 const { data } = await axios.post(
 "https://api.pinterest.com/v3/visual_search/lens/search/",
 formData,
 { headers }
 );

 return (
 data?.data
 ?.map(item => item.image_large_url)
 .filter(Boolean) || []
 );
}