const numberslst = {};

module.exports = {
  config: {
    name: 'nums',
    aliases: ["numbers"],
    author: 'allou mohamed',
    version: '1.2.3',
    role: 0,
    category: 'games',
    guide: '{pn}',
    description: 'Guess the number game 🎯'
  },

  onStart: async function ({ api, event }) {
    const threadID = event.threadID;
    if (numberslst[threadID]) {
      return api.sendMessageMqtt("⚠ A game is already in progress. Finish it first before starting a new one!", threadID, event.messageID);
    }

    const targetNumber = utils.randomNumber(1, 100);

    numberslst[threadID] = {
      targetNumber,
      players: {},
      startTime: Date.now()
    };

    api.sendMessageMqtt(
      `🎯 Number Guessing Game Started!\n🤔 Guess a number between 1 and 100!\n\nIf I react with ⬆ Send a higher number. If ⬇ Send a lower number.\nFirst player to guess the number wins! 🏆\n\n⚠ You can only guess **once every 5 seconds**, so think carefully!`,
      threadID,
      event.messageID
    );
  },

  onChat: async function ({ api, event, usersData }) {
    const threadID = event.threadID;
    const senderID = event.senderID;
    if (!numberslst[threadID]) return;

    const game = numberslst[threadID];

    if (!game.players[senderID]) {
      game.players[senderID] = { attempts: 0, lastGuessTime: 0 };
    }

    const currentTime = Date.now();
    if (currentTime - game.players[senderID].lastGuessTime < 5000) {
      return //api.sendMessageMqtt("⏳ Please wait 5 seconds before guessing again!", threadID, event.messageID);
    }

    const guessedNumber = parseInt(event.body);
    if (isNaN(guessedNumber)) return;

    game.players[senderID].attempts++;
    game.players[senderID].lastGuessTime = currentTime;

    if (guessedNumber > game.targetNumber) {
      api.setMessageReactionMqtt('⬇', event.messageID, event.threadID);
    } else if (guessedNumber < game.targetNumber) {
      api.setMessageReactionMqtt('⬆', event.messageID, event.threadID);
    } else {
      const name = await usersData.getName(senderID);
      const timeTaken = ((Date.now() - game.startTime) / 1000).toFixed(1);
      const attempts = game.players[senderID].attempts;

      let reward, comment;
      if (attempts <= 5) {
        reward = 1000;
        comment = "🔥 Amazing! You guessed it super fast!";
      } else if (attempts <= 10) {
        reward = 500;
        comment = "🎯 Good job! But you can do better!";
      } else {
        reward = 200;
        comment = "⏳ That took a while! Try improving next time.";
      }

      api.setMessageReactionMqtt('🥳', event.messageID, event.threadID);
      api.sendMessageMqtt(
        `🎉 ${name} wins!\n💵 Prize: ${reward}\n🤞 Attempts: ${attempts}\n⏱ Time Taken: ${timeTaken} sec\n📌 Comment: ${comment}`,
        threadID
      );

      await usersData.addMoney(senderID, reward);
      delete numberslst[threadID]; 
    }
  }
};