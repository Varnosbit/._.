const axios = require('axios');

class Ai {
  constructor() {
    this.chats = new Map(); 
  }

  async NewChat(uid) {
    const res = await axios.post(
      'https://app.chipp.ai/api/chat-history/chat-sessions-for-user',
      '',
      {
        params: {
          appNameId: 'Simo-62428',
          whereTheChatIsBeingViewed: 'BUILDER'
        },
        headers: this.Headers()
      }
    );
    const chat = { cid: res.data.id, msgs: [] };
    this.chats.set(uid, chat);
    return chat;
  }

  async Msg(uid, text) {
    if (text === "clear") {
      this.chats.delete(uid);
      return "Chat Deleted";
    }

    let chat = this.chats.get(uid);
    if (!chat) chat = await this.NewChat(uid);

    chat.msgs.push({ role: "user", content: text });

    try {
      const res = await axios.post("https://app.chipp.ai/api/chat", {
        messages: chat.msgs,
        chatSessionId: chat.cid
      }, { headers: this.Headers() });

      const msg = this.ExtractMessage(res.data);
      chat.msgs.push({ role: "assistant", content: msg });
      return { Text: msg };
    } catch (err) {
      console.log(err);
      return { Text: "🐦 نام عندي مشاكل" };
    }
  }

  ExtractMessage(raw) {
    const lines = raw.split('\n');
    const message = lines
      .filter(line => line.trim().startsWith('0:'))
      .map(line => {
        const match = line.match(/0:"(.*)"/);
        return match ? match[1] : '';
      })
      .join('')
      .replace(/\\n/g, '\n')
      .trim();

    if (message) return message;

    const toolLine = lines.find(line => line.trim().startsWith('a:'));
    if (toolLine) {
      try {
        const json = JSON.parse(toolLine.slice(2));
        const results = json.result?.organic;
        if (Array.isArray(results)) {
          return results.map(r => `- ${r.title}\n  ${r.snippet}\n  ${r.link}`).join('\n\n');
        }
      } catch (err) {
        return '⚠️ JSON parsing error.';
      }
    }

    return '⚠️ لا توجد رسالة قابلة للاستخلاص.';
  }

  Headers() {
    return {
      authority: 'app.chipp.ai',
      accept: '*/*',
      'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
      'content-type': 'application/json',
      origin: 'https://app.chipp.ai',
      referer: 'https://app.chipp.ai/app_builder/62428/build',
      'user-agent': 'Mozilla/5.0 (Linux; Android 10)',
    };
  }
}

const AI = new Ai();

module.exports = {
  config: {
    name: "سيمو",
    category: "ai",
    role: 0,
    countDown: 40,
    description: "تكلم مع سيمو 😈 ._.",
    version: "@latest",
    by: "Allou Mohamed"
  },

  onStart: async function ({ event, args, message, commandName }) {
    if (!args || args.length === 0) return;

    const id = event.senderID;
    const question = args.join(" ");

    const res = await AI.Msg(id, question);
    const reply = await message.reply(res.Text);
    global.GoatBot.onReply.set(reply.messageID, {
      commandName,
      author: id
    });
  },

  onReply: async function ({ event, message, args, Reply, commandName }) {
    if (event.senderID !== Reply.author) return;

    const question = args.join(" ");
    const res = await AI.Msg(event.senderID, question);
    const reply = await message.reply(res.Text);
    global.GoatBot.onReply.set(reply.messageID, {
      commandName,
      author: event.senderID
    });
  }
};