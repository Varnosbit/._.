exports.config = {
 name: "dob",
 aliases: ["كم.عشت", "عمري"],
 author: "Allou Mohamed",
 version: "2.1.1",
 role: 0,
 shortDescription: "حساب العمر مع كشف ذكي لصيغة التاريخ وتذكير مؤثر بالوقت",
};

exports.onStart = async function ({ message, args }) {
 const input = args.join(" ").trim();
 if (!input)
 return message.reply("❌ أدخل تاريخ ميلادك مثل: 27-06-2006 أو 2006-06-27");

 const match = input.match(
 /^(\d{1,4})[\/-](\d{1,2})[\/-](\d{1,4})(?:\s+(\d{1,2}):(\d{2}))?$/
 );

 if (!match)
 return message.reply("❌ صيغة التاريخ غير مفهومة");

 let [, a, b, c, h = 0, min = 0] = match;
 a = Number(a);
 b = Number(b);
 c = Number(c);

 let day, month, year;

 // كشف ذكي: الرقم من 4 خانات هو السنة
 if (a >= 1000) {
 year = a;
 month = b;
 day = c;
 } else if (c >= 1000) {
 year = c;
 month = b;
 day = a;
 } else {
 return message.reply("❌ لا يمكن تحديد السنة بوضوح");
 }

 const dob = new Date(year, month - 1, day, Number(h), Number(min));
 if (isNaN(dob.getTime()))
 return message.reply("❌ تاريخ غير صالح");

 const now = new Date();
 if (dob >= now)
 return message.reply("❌ تاريخ الميلاد في المستقبل؟!");

 const diffMs = now - dob;
 const days = Math.floor(diffMs / 86400000);
 const seconds = Math.floor(diffMs / 1000);

 const years =
 now.getFullYear() -
 dob.getFullYear() -
 (now.getMonth() < dob.getMonth() ||
 (now.getMonth() === dob.getMonth() && now.getDate() < dob.getDate())
 ? 1
 : 0);

 const expectedLife = 50 + Math.floor(Math.random() * 26);
 const remainingYears = Math.max(0, expectedLife - years);
 const remainingSeconds = remainingYears * 31536000;

 const format = (n) =>
 n >= 1e9
 ? Math.floor(n / 1e9) + " مليار"
 : n >= 1e6
 ? Math.floor(n / 1e6) + " مليون"
 : n >= 1e3
 ? Math.floor(n / 1e3) + " ألف"
 : n.toString();

 const text =
 "أنت عشت إلى هذه اللحظة حوالي " +
 days +
 " يومًا أي ما يقارب " +
 years +
 " سنة، وهذا يعني أنك استهلكت ما يقارب " +
 format(seconds) +
 " ثانية من عمرك دون أن تشعر، قال الله تعالى: ﴿كُلُّ نَفْسٍ ذَائِقَةُ الْمَوْتِ﴾، وقال سبحانه: ﴿اقْتَرَبَ لِلنَّاسِ حِسَابُهُمْ وَهُمْ فِي غَفْلَةٍ مُعْرِضُونَ﴾، ولو افترضنا افتراضًا مخيفًا أن عمرك الكلي سيكون فقط " +
 expectedLife +
 " سنة فقد بقي لك تقريبًا " +
 remainingYears +
 " سنة أي ما يعادل " +
 format(remainingSeconds) +
 " ثانية فقط، وكل ثانية تمر لا تعود، وتذكّر أن أول ما يُسأل عنه العبد يوم القيامة الصلاة، فقم الآن ولا تؤجل قبل أن يأتي وقت تتمنى فيه سجدة ولا تُعطى.";

 return message.reply(text);
};