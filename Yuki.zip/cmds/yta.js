const { URLSearchParams } = require('url');
const fs = require("fs");

async function ytdl(url, t, sh, title) {
  t = t || "audio";

  const data = new URLSearchParams();
  data.append('url', url);

  const options = {
    method: 'POST',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
      'Content-Type': 'application/x-www-form-urlencoded',
      'sec-ch-ua-platform': '"Windows"',
      'x-requested-with': 'XMLHttpRequest',
      'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'sec-ch-ua-mobile': '?0',
      'origin': 'https://ytdown.to',
      'sec-fetch-site': 'same-origin',
      'sec-fetch-mode': 'cors',
      'sec-fetch-dest': 'empty',
      'referer': 'https://ytdown.to/fr2/',
      'accept-language': 'en,fr;q=0.9,ar;q=0.8',
      'priority': 'u=1, i',
      'Cookie': 'PHPSESSID=f4kkbnde3j901fhv26pc1mk0aq; _ga=GA1.1.2086193311.1762027164; _ga_2K69M9RN1B=GS2.1.s1762027164$o1$g1$t1762027888$j60$l0$h0'
    },
    body: data
  };

  const resA = await fetch('https://ytdown.to/proxy.php', options);
  const jsonA = await resA.json();

  const baseMedia = jsonA.api.mediaItems[0];
  const [h, m, s] = baseMedia.mediaDuration.split(":").map(Number);
  const duration = h * 3600 + m * 60 + s;

  const q = t === "audio"
    ? "audio"
    : duration < 120
    ? "1080"
    : duration < 200
    ? "720"
    : "480";

  const qr = new RegExp(q, "g");

  const targetMedia = jsonA.api.mediaItems.find(
    x => qr.test(x?.mediaRes || "") || x.type.toLowerCase() === t
  );

  const dataB = new URLSearchParams();
  dataB.append('url', targetMedia.mediaUrl);

  const optionsB = {
    method: 'POST',
    headers: options.headers,
    body: dataB
  };

  const resB = await fetch('https://ytdown.to/proxy.php', optionsB);
  const jsonB = await resB.json();

  const fileName = jsonB.api.fileName;

  return sh.send({ body:"▶️ | "+title,
    attachment: await utils.getStreamFromUrl(jsonB.api.fileUrl, fileName)
  });
}
const yts = require("yt-search");

exports.config = {
    name: 'ytb',
    description: 'Download YouTube videos as MP3 or MP4 or get video information',
    role: 0,
    category: 'Media',
    version: '1.4.1',
    guide: `Usage: {pn} [-a|-v|info] <url or search query>
Examples:
{pn} shape of you
{pn} -a shape of you
{pn} -v despacito
{pn} info https://youtube.com/...
{pn} info despacito
Cooldown: 3 minutes.`,
    countDown: 180
};

exports.onStart = async ({ message, args, commandName, event }) => {
    if (!args.length) return message.reply("❌ Please provide a URL or search query. Usage: ytb [-a|-v|info] <query>");

    let type = 'audio', query, isInfo = false;

    const firstArg = args[0].toLowerCase();
    if (['-a', '-v', 'info', '-i', 'video', 'audio'].includes(firstArg)) {
        if (firstArg === '-v' || firstArg === 'video') type = 'video';
        else if (firstArg === '-a' || firstArg === 'audio') type = 'audio';
        else isInfo = true;
        query = args.slice(1).join(" ");
    } else {
        query = args.join(" ");
    }

    if (!query) return message.reply("❌ Please provide a URL or search query after the format.");

    const ytUrlRegex = /^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//i;

    if (ytUrlRegex.test(query)) {
        if (isInfo) return getVideoInfo({ message, url: query });
        return ytdl(query, type, message);
    }

    try {
        const res = await yts(query);
        if (!res.videos.length) return message.reply("❌ No results found.");

        let filteredVideos = res.videos;

        if (isInfo) {
            filteredVideos = res.videos;
        } else if (type === 'video') {
            filteredVideos = res.videos.filter(v => (v.duration.seconds || 0) <= 492);
            if (!filteredVideos.length) return message.reply("❌ No videos under 8 minutes.");
        } else {
            filteredVideos = res.videos.filter(v => (v.duration.seconds || 0) <= 1116);
            if (!filteredVideos.length) return message.reply("❌ No videos under 18 minutes.");
        }

        const topVideos = filteredVideos.slice(0, 6);

        const resText = isInfo
            ? "Select a video to get information:\n\n" +
              topVideos.map((v, i) => `${i + 1}. ${v.title} (${v.timestamp})`).join("\n\n")
            : "🎥 Suggested videos:\n\n" +
              topVideos.map((v, i) => `${i + 1}. ${v.title} (${v.timestamp})`).join("\n\n");

        const imageUrls = topVideos.map(v => v.image);
        const videoUrls = topVideos.map(v => v.url);
        const videoTitles = topVideos.map(v => v.title);

        const s = await message.stream(resText, imageUrls);

        if (s.messageID) {
            global.YamiBot.onReply.set(s.messageID, {
                commandName,
                videoUrls,
                au: event.senderID,
                type,
                videoTitles,
                mid_1: s.messageID,
                isInfo
            });
        }
    } catch (error) {
        return message.reply(`❌ Search failed: ${error.message}`);
    }
};

exports.onReply = async ({ message, args, commandName, event, Reply }) => {
    const { videoUrls, au, type, videoTitles, mid_1, isInfo } = Reply;
    if (event.senderID !== au) return;

    const selection = parseInt(args[0]);
    if (isNaN(selection) || selection < 1 || selection > videoUrls.length)
        return message.reply("❌ Invalid selection.");

    const url = videoUrls[selection - 1];
    const title = videoTitles[selection - 1];

    message.unsend(mid_1);

    if (isInfo) return getVideoInfo({ message, url });
    return ytdl(url, type, message, title);
};

async function getVideoInfo({ message, url }) {
    try {
        const id = getVideoID(url);
        const info = await yts({ videoId: id });
        if (!info) return message.reply("❌ Could not fetch video information.");

        const data = `
📌 Title: ${info.title}
👤 Channel: ${info.author.name}
⏱️ Duration: ${info.timestamp}
👁️ Views: ${info.views.toLocaleString()}
📅 Uploaded: ${info.ago}
🔗 ${url}
        `.trim();

        return message.reply(data);
    } catch {
        return message.reply("❌ Failed to retrieve information.");
    }
}

function getVideoID(url) {
    const match = url.match(/(?:v=|youtu\.be\/)([A-Za-z0-9_\-]+)/);
    return match ? match[1] : null;
}