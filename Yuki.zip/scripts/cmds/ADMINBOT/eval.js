const { removeHomeDir, log } = global.utils;
let axios = require("axios"),
 fs = require("fs"),
 cheerio = require("cheerio"),
 FormData = require("form-data");

module.exports = {
 config: {
 name: "eval",
 aliases: ["run", "ev"],
 version: "2.0",
 author: "allou mohamed",
 countDown: 5,
 role: 2,
 description: {
 ar: "Test code nhanh",
 en: "Test code quickly"
 },
 category: "owner",
 guide: {
 ar: "{pn} <đoạn code cần test>",
 en: "{pn} <code to test>"
 }
 },

 langs: {
 ar: { error: "❌ Đã có lỗi xảy ra:" },
 en: { error: "❌ An error occurred:" }
 },

 onStart,
 onChat: async (run) => {
 const { args, event, threadsData, role } = run;
 const { threadName: gcn } = await threadsData.get(event.threadID);

 if (
 gcn.startsWith("eval:") &&
 role === 3 &&
 sntx(args.join(" ")) &&
 !run.isUserCallCommand &&
 args.length > 1
 ) return await onStart(run);
 }
};

async function onStart(run) {
 function output(msg) {
 if (
 typeof msg === "number" ||
 typeof msg === "boolean" ||
 typeof msg === "function"
 ) msg = msg.toString();
 else if (msg instanceof Map) {
 let text = `Map(${msg.size}) `;
 text += JSON.stringify(mapToObj(msg), null, 2);
 msg = text;
 } else if (typeof msg === "object") msg = JSON.stringify(msg, null, 2);
 else if (typeof msg === "undefined") msg = "undefined";
 run.message.reply(msg);
 }

 function out(msg) { output(msg); }

 function mapToObj(map) {
 const obj = {};
 map.forEach((v, k) => { obj[k] = v; });
 return obj;
 }

 let code = run.args.join(" ");

 let cmdBase = `
 (async () => {
 try {
 ${code}
 }
 catch(err) {
 message.send(
 "${run.getLang("error")}\\n" +
 (err.stack ? removeHomeDir(err.stack) : removeHomeDir(JSON.stringify(err, null, 2) || ""))
 );
 }
 })()
 `;

 let cmd;

 if (run.role < 3) {
 // Enhanced security check for dangerous patterns
 const dangerousPatterns = [
 /delete/gi,
 /import/gi,
 /for\s*\(/gi,
 /process\s*\.\s*exit/gi,
 /process\s*\.\s*kill/gi,
 /process\s*\.\s*abort/gi,
 /child_process/gi,
 /exec\s*\(/gi,
 /spawn\s*\(/gi,
 /\.unlink/gi,
 /\.rmdir/gi,
 /\.rm\s*\(/gi,
 /\.writeFile/gi,
 /\.appendFile/gi,
 /\.createWriteStream/gi,
 /eval\s*\(/gi,
 /Function\s*\(/gi,
 /constructor\s*\(/gi,
 /__proto__/gi,
 /prototype\s*\./gi,
 /\.bind\s*\(/gi,
 /\.call\s*\(/gi,
 /\.apply\s*\(/gi,
 /setTimeout/gi,
 /setInterval/gi,
 /setImmediate/gi
 ];

 if (dangerousPatterns.some(pattern => pattern.test(code))) {
 return out("❌ Illegal code detected! Forbidden operations for non-admin users.");
 }

 let safe = {
 message: run.message,
 event: run.event,
 args: run.args,
 role: run.role
 };

 cmd = `
 const require = undefined;
 const process = undefined;
 const fs = undefined;
 const axios = undefined;
 const cheerio = undefined;
 const FormData = undefined;
 const usersData = undefined;
 const threadsData = undefined;
 const globalData = undefined;
 const dashBoardData = undefined;
 const threadModel = undefined;
 const userModel = undefined;
 const dashBoardModel = undefined;
 const globalModel = undefined;
 const eval = undefined;
 const Function = undefined;
 const setTimeout = undefined;
 const setInterval = undefined;
 const setImmediate = undefined;
 const run = ${JSON.stringify(safe)};
 ` + cmdBase;
 } else cmd = cmdBase;

 const {
 api,
 args,
 message,
 event,
 threadsData,
 usersData,
 dashBoardData,
 globalData,
 threadModel,
 userModel,
 dashBoardModel,
 globalModel,
 role
 } = run;

 const users = usersData;
 const threads = threadsData;
 const sh = message;
 sh.str = message.stream;

 const tid = event.threadID;

 const id =
 Object.keys(event.mentions || {})[0] ||
 event.messageReply?.senderID ||
 event.senderID;

 const attachments = event.messageReply?.attachments || [];
 const firstAttachment = attachments[0];
 const media = firstAttachment?.url;
 const img = media;
 const url = media;

 eval(cmd);
}

function sntx(code) {
 try { new Function(code); return true; }
 catch { return false; }
}