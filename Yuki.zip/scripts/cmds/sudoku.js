const { randomString, getTime, convertTime } = global.utils;
const { createCanvas } = require('canvas');

// Difficulty settings
const difficulties = {
	easy: { name: "Easy", cellsToRemove: 35, rewardPoints: 3, timeLimit: 1800 }, // 30 min
	medium: { name: "Medium", cellsToRemove: 45, rewardPoints: 5, timeLimit: 2700 }, // 45 min
	hard: { name: "Hard", cellsToRemove: 55, rewardPoints: 8, timeLimit: 3600 }, // 60 min
	expert: { name: "Expert", cellsToRemove: 65, rewardPoints: 12, timeLimit: 5400 } // 90 min
};

module.exports = {
	config: {
		name: "sudoku",
		aliases: ["sudo"],
		version: "1.0",
		author: "Claude",
		countDown: 5,
		role: 0,
		description: {
			en: "Sudoku number puzzle game with multiple difficulty levels"
		},
		category: "game",
		guide: {
			en: "  {pn} [difficulty]: Start a new Sudoku game"
				+ "\n    Difficulties: easy, medium, hard, expert (default: easy)"
				+ "\n    Example: {pn} medium"
				+ "\n"
				+ "\n   How to play:"
				+ "\n    Reply with: row col number (e.g., '1 5 7' to put 7 in row 1, column 5)"
				+ "\n    Use 'hint' for a helpful clue"
				+ "\n    Use 'check' to validate current solution"
				+ "\n    Use 'solve' to see the complete solution (ends game)"
				+ "\n"
				+ "\n   Rules: Fill the 9x9 grid so that:"
				+ "\n    - Each row contains digits 1-9"
				+ "\n    - Each column contains digits 1-9" 
				+ "\n    - Each 3x3 box contains digits 1-9"
				+ "\n"
				+ "\n   {pn} rank [page]: View leaderboard"
				+ "\n   {pn} stats [user]: View player statistics"
				+ "\n   {pn} reset: Reset rankings (admin only)"
		}
	},

	langs: {
		en: {
			leaderboard: "SUDOKU MASTERS:\n%1",
			pageInfo: "Page %1/%2",
			noScore: "No one has solved a puzzle yet! Be the first master!",
			noPermissionReset: "You don't have permission to reset rankings.",
			notFoundUser: "User ID %1 not found in rankings.",
			playerStats: "SUDOKU STATISTICS:\nPlayer: %1\nTotal Score: %2 points\nPuzzles Solved: %3\nAverage Time: %4\nBest Time: %5\nFavorite Difficulty: %6\nSuccess Rate: %7%\n\nDifficulty Breakdown:\n%8",
			difficultyStats: "  %1: %2 solved (avg: %3)",
			resetSuccess: "Rankings reset successfully! Fresh start for everyone!",
			invalidDifficulty: "Invalid difficulty! Choose: easy, medium, hard, or expert",
			gameCreated: "SUDOKU PUZZLE CREATED!\nDifficulty: %1\nReward: %2 points\nTime Limit: %3\n\nFill the grid with numbers 1-9!\nReply with: row col number (e.g., '1 5 7')",
			invalidMove: "Invalid format! Use: row col number (e.g., '1 5 7')",
			invalidPosition: "Position must be between 1-9 for both row and column!",
			invalidNumber: "Number must be between 1-9!",
			cellNotEmpty: "Cell already filled! Choose an empty cell.",
			invalidPlacement: "Invalid move! This number violates Sudoku rules.",
			moveSuccess: "Good move! Number %1 placed at row %2, column %3.",
			puzzleComplete: "CONGRATULATIONS! PUZZLE SOLVED!\nTime: %1\nPoints Earned: %2\nDifficulty: %3\n\nYou're a Sudoku master!",
			gameTimeout: "Time's up! Better luck next time!\nDifficulty: %1\nTime played: %2",
			hintUsed: "HINT: Try placing %1 in row %2, column %3\n(This is a safe move that follows Sudoku rules)",
			noHintAvailable: "No obvious hints available. Keep analyzing the puzzle!",
			checkResult: "PUZZLE CHECK:\nCorrect placements: %1/81\nEmpty cells: %2\nConflicts found: %3\n\nKeep going! You're doing great!",
			solutionRevealed: "SOLUTION REVEALED!\nThe complete puzzle is shown above.\nTime played: %1\nDifficulty: %2\n\nBetter luck next time!"
		}
	},

	onStart: async function ({ message, event, getLang, commandName, args, globalData, usersData, role }) {
		if (args[0] === "rank") {
			const rankings = await globalData.get("sudokuRankings", "data", []);
			if (!rankings.length) {
				return message.reply(getLang("noScore"));
			}

			const page = parseInt(args[1]) || 1;
			const maxPerPage = 15;
			const startIndex = (page - 1) * maxPerPage;
			const endIndex = page * maxPerPage;

			const rankedPlayers = await Promise.all(
				rankings.slice(startIndex, endIndex).map(async (player, index) => {
					const userName = await usersData.getName(player.id);
					const totalAttempts = player.completed + player.failed;
					const successRate = totalAttempts > 0 ? ((player.completed / totalAttempts) * 100).toFixed(1) : 0;
					const globalRank = startIndex + index + 1;
					const avgTime = player.totalTime > 0 ? convertTime(Math.floor(player.totalTime / player.completed)) : "N/A";
					
					return `${globalRank}. ${userName}\n   ${player.points} pts | ${player.completed} solved | ${successRate}% | avg: ${avgTime}`;
				})
			);

			const totalPages = Math.ceil(rankings.length / maxPerPage);
			const leaderboardText = rankedPlayers.join("\n\n");
			
			return message.reply(
				getLang("leaderboard", leaderboardText) + 
				"\n\n" + 
				getLang("pageInfo", page, totalPages)
			);
		}

		if (args[0] === "stats") {
			const rankings = await globalData.get("sudokuRankings", "data", []);
			let targetID = event.senderID;
			
			if (Object.keys(event.mentions).length) {
				targetID = Object.keys(event.mentions)[0];
			} else if (event.messageReply) {
				targetID = event.messageReply.senderID;
			} else if (!isNaN(args[1])) {
				targetID = args[1];
			}

			const playerData = rankings.find(p => p.id == targetID);
			if (!playerData) {
				return message.reply(getLang("notFoundUser", targetID));
			}

			const userName = await usersData.getName(targetID);
			const totalAttempts = playerData.completed + playerData.failed;
			const successRate = totalAttempts > 0 ? ((playerData.completed / totalAttempts) * 100).toFixed(1) : 0;
			const avgTime = playerData.completed > 0 ? convertTime(Math.floor(playerData.totalTime / playerData.completed)) : "N/A";
			const bestTime = playerData.bestTime ? convertTime(playerData.bestTime) : "N/A";
			
			// Find favorite difficulty
			const diffCounts = playerData.difficultyStats || {};
			const favDiff = Object.keys(diffCounts).reduce((a, b) => diffCounts[a] > diffCounts[b] ? a : b, "None");
			
			// Difficulty breakdown
			const diffBreakdown = Object.entries(diffCounts)
				.map(([diff, count]) => {
					const avgTimeForDiff = playerData.difficultyTimes && playerData.difficultyTimes[diff] 
						? convertTime(Math.floor(playerData.difficultyTimes[diff] / count))
						: "N/A";
					return getLang("difficultyStats", diff, count, avgTimeForDiff);
				})
				.join("\n") || "  No games completed yet";

			return message.reply(
				getLang("playerStats", 
					userName, 
					playerData.points, 
					playerData.completed, 
					avgTime,
					bestTime,
					favDiff,
					successRate,
					diffBreakdown
				)
			);
		}

		if (args[0] === "reset") {
			if (role < 2) {
				return message.reply(getLang("noPermissionReset"));
			}
			await globalData.set("sudokuRankings", [], "data");
			return message.reply(getLang("resetSuccess"));
		}

		// Create new game
		const difficulty = args[0] && difficulties[args[0].toLowerCase()] 
			? args[0].toLowerCase() 
			: 'easy';
		
		if (!difficulties[difficulty]) {
			return message.reply(getLang("invalidDifficulty"));
		}

		// Generate puzzle
		const { puzzle, solution } = generateSudokuPuzzle(difficulties[difficulty].cellsToRemove);
		
		const gameData = {
			puzzle: JSON.parse(JSON.stringify(puzzle)),
			solution,
			originalPuzzle: JSON.parse(JSON.stringify(puzzle)),
			difficulty,
			timeStart: getTime("x"),
			timeLimit: difficulties[difficulty].timeLimit,
			isFinished: false,
			hintsUsed: 0,
			author: event.senderID
		};

		const gameImage = createSudokuImage(gameData);
		const diffInfo = difficulties[difficulty];
		const timeText = convertTime(diffInfo.timeLimit);
		
		const introText = getLang("gameCreated", diffInfo.name, diffInfo.rewardPoints, timeText);
		
		message.reply(introText, (err, info) => {
			if (!err) {
				message.reply({
					attachment: gameImage
				}, (err2, info2) => {
					if (!err2) {
						global.GoatBot.onReply.set(info2.messageID, {
							commandName,
							messageID: info2.messageID,
							author: event.senderID,
							gameData
						});
					}
				});
			}
		});
	},

	onReply: async ({ message, Reply, event, getLang, globalData, usersData }) => {
		const { gameData } = Reply;
		
		if (event.senderID !== Reply.author || gameData.isFinished) {
			return;
		}

		// Check time limit
		const timeElapsed = getTime("x") - gameData.timeStart;
		if (timeElapsed > gameData.timeLimit) {
			gameData.isFinished = true;
			await updatePlayerStats(event.senderID, gameData, false, timeElapsed, globalData);
			
			const gameImage = createSudokuImage(gameData);
			const timeText = convertTime(timeElapsed);
			
			message.reply({
				body: getLang("gameTimeout", difficulties[gameData.difficulty].name, timeText),
				attachment: gameImage
			});
			
			global.GoatBot.onReply.delete(Reply.messageID);
			return;
		}

		const input = event.body.trim().toLowerCase();
		
		// Handle special commands
		if (input === 'hint') {
			const hint = getHint(gameData.puzzle, gameData.solution);
			if (hint) {
				gameData.hintsUsed++;
				return message.reply(getLang("hintUsed", hint.number, hint.row, hint.col));
			} else {
				return message.reply(getLang("noHintAvailable"));
			}
		}
		
		if (input === 'check') {
			const checkResult = checkPuzzle(gameData.puzzle);
			return message.reply(getLang("checkResult", checkResult.correct, checkResult.empty, checkResult.conflicts));
		}
		
		if (input === 'solve') {
			gameData.isFinished = true;
			gameData.puzzle = JSON.parse(JSON.stringify(gameData.solution));
			
			const gameImage = createSudokuImage(gameData);
			const timeText = convertTime(timeElapsed);
			
			message.reply({
				body: getLang("solutionRevealed", timeText, difficulties[gameData.difficulty].name),
				attachment: gameImage
			});
			
			global.GoatBot.onReply.delete(Reply.messageID);
			return;
		}

		// Parse move input
		const parts = input.split(' ');
		if (parts.length !== 3) {
			return message.reply(getLang("invalidMove"));
		}

		const row = parseInt(parts[0]) - 1;
		const col = parseInt(parts[1]) - 1;
		const num = parseInt(parts[2]);

		// Validate input
		if (row < 0 || row > 8 || col < 0 || col > 8) {
			return message.reply(getLang("invalidPosition"));
		}
		
		if (num < 1 || num > 9) {
			return message.reply(getLang("invalidNumber"));
		}

		// Check if cell is empty in original puzzle
		if (gameData.originalPuzzle[row][col] !== 0) {
			return message.reply(getLang("cellNotEmpty"));
		}

		// Check if move is valid
		if (!isValidMove(gameData.puzzle, row, col, num)) {
			return message.reply(getLang("invalidPlacement"));
		}

		// Make the move
		gameData.puzzle[row][col] = num;
		
		// Check if puzzle is complete
		const isComplete = isPuzzleComplete(gameData.puzzle);
		
		if (isComplete) {
			gameData.isFinished = true;
			await updatePlayerStats(event.senderID, gameData, true, timeElapsed, globalData);
			
			const gameImage = createSudokuImage(gameData);
			const timeText = convertTime(timeElapsed);
			const points = difficulties[gameData.difficulty].rewardPoints;
			
			message.reply({
				body: getLang("puzzleComplete", timeText, points, difficulties[gameData.difficulty].name),
				attachment: gameImage
			});
			
			global.GoatBot.onReply.delete(Reply.messageID);
		} else {
			// Continue game
			const gameImage = createSudokuImage(gameData);
			
			message.reply({
				body: getLang("moveSuccess", num, row + 1, col + 1),
				attachment: gameImage
			}, (err, info) => {
				if (!err) {
					global.GoatBot.onReply.delete(Reply.messageID);
					global.GoatBot.onReply.set(info.messageID, {
						commandName: "sudoku",
						messageID: info.messageID,
						author: Reply.author,
						gameData
					});
				}
			});
		}
	}
};

// Sudoku generation and solving functions
function generateSudokuPuzzle(cellsToRemove) {
	// Start with a complete valid grid
	const solution = generateCompleteGrid();
	
	// Create puzzle by removing cells
	const puzzle = JSON.parse(JSON.stringify(solution));
	const positions = [];
	
	// Create array of all positions
	for (let i = 0; i < 9; i++) {
		for (let j = 0; j < 9; j++) {
			positions.push([i, j]);
		}
	}
	
	// Shuffle positions
	for (let i = positions.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[positions[i], positions[j]] = [positions[j], positions[i]];
	}
	
	// Remove cells
	for (let i = 0; i < cellsToRemove && i < positions.length; i++) {
		const [row, col] = positions[i];
		puzzle[row][col] = 0;
	}
	
	return { puzzle, solution };
}

function generateCompleteGrid() {
	const grid = Array(9).fill().map(() => Array(9).fill(0));
	
	// Fill diagonal 3x3 boxes first
	for (let i = 0; i < 9; i += 3) {
		fillBox(grid, i, i);
	}
	
	// Fill remaining cells
	solveSudoku(grid);
	
	return grid;
}

function fillBox(grid, row, col) {
	const nums = [1, 2, 3, 4, 5, 6, 7, 8, 9];
	
	// Shuffle numbers
	for (let i = nums.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[nums[i], nums[j]] = [nums[j], nums[i]];
	}
	
	let idx = 0;
	for (let i = 0; i < 3; i++) {
		for (let j = 0; j < 3; j++) {
			grid[row + i][col + j] = nums[idx++];
		}
	}
}

function solveSudoku(grid) {
	for (let row = 0; row < 9; row++) {
		for (let col = 0; col < 9; col++) {
			if (grid[row][col] === 0) {
				const nums = [1, 2, 3, 4, 5, 6, 7, 8, 9];
				
				// Shuffle for randomness
				for (let i = nums.length - 1; i > 0; i--) {
					const j = Math.floor(Math.random() * (i + 1));
					[nums[i], nums[j]] = [nums[j], nums[i]];
				}
				
				for (const num of nums) {
					if (isValidMove(grid, row, col, num)) {
						grid[row][col] = num;
						if (solveSudoku(grid)) {
							return true;
						}
						grid[row][col] = 0;
					}
				}
				return false;
			}
		}
	}
	return true;
}

function isValidMove(grid, row, col, num) {
	// Check row
	for (let x = 0; x < 9; x++) {
		if (grid[row][x] === num) return false;
	}
	
	// Check column
	for (let x = 0; x < 9; x++) {
		if (grid[x][col] === num) return false;
	}
	
	// Check 3x3 box
	const startRow = row - row % 3;
	const startCol = col - col % 3;
	for (let i = 0; i < 3; i++) {
		for (let j = 0; j < 3; j++) {
			if (grid[i + startRow][j + startCol] === num) return false;
		}
	}
	
	return true;
}

function isPuzzleComplete(grid) {
	for (let i = 0; i < 9; i++) {
		for (let j = 0; j < 9; j++) {
			if (grid[i][j] === 0) return false;
		}
	}
	return true;
}

function getHint(puzzle, solution) {
	const emptyCells = [];
	
	for (let i = 0; i < 9; i++) {
		for (let j = 0; j < 9; j++) {
			if (puzzle[i][j] === 0) {
				emptyCells.push({row: i + 1, col: j + 1, number: solution[i][j]});
			}
		}
	}
	
	if (emptyCells.length === 0) return null;
	
	// Return random empty cell
	return emptyCells[Math.floor(Math.random() * emptyCells.length)];
}

function checkPuzzle(puzzle) {
	let correct = 0;
	let empty = 0;
	let conflicts = 0;
	
	for (let i = 0; i < 9; i++) {
		for (let j = 0; j < 9; j++) {
			if (puzzle[i][j] === 0) {
				empty++;
			} else {
				correct++;
				// Check for conflicts
				const num = puzzle[i][j];
				puzzle[i][j] = 0; // Temporarily remove to check
				if (!isValidMove(puzzle, i, j, num)) {
					conflicts++;
				}
				puzzle[i][j] = num; // Restore
			}
		}
	}
	
	return { correct, empty, conflicts };
}

async function updatePlayerStats(playerID, gameData, isWin, timeSpent, globalData) {
	const rankings = await globalData.get("sudokuRankings", "data", []);
	let playerIndex = rankings.findIndex(p => p.id === playerID);
	
	if (playerIndex === -1) {
		// New player
		const newPlayer = {
			id: playerID,
			points: 0,
			completed: 0,
			failed: 0,
			totalTime: 0,
			bestTime: null,
			difficultyStats: {},
			difficultyTimes: {}
		};
		rankings.push(newPlayer);
		playerIndex = rankings.length - 1;
	}
	
	const player = rankings[playerIndex];
	const difficulty = gameData.difficulty;
	
	if (isWin) {
		player.completed++;
		player.points += difficulties[difficulty].rewardPoints;
		player.totalTime += timeSpent;
		
		if (!player.bestTime || timeSpent < player.bestTime) {
			player.bestTime = timeSpent;
		}
		
		// Update difficulty stats
		player.difficultyStats[difficulty] = (player.difficultyStats[difficulty] || 0) + 1;
		player.difficultyTimes[difficulty] = (player.difficultyTimes[difficulty] || 0) + timeSpent;
	} else {
		player.failed++;
	}
	
	// Sort by points
	rankings.sort((a, b) => b.points - a.points);
	
	await globalData.set("sudokuRankings", rankings, "data");
}

function createSudokuImage(gameData) {
	const cellSize = 60;
	const gridSize = cellSize * 9;
	const padding = 40;
	const headerHeight = 100;
	
	const canvasWidth = gridSize + (padding * 2);
	const canvasHeight = gridSize + (padding * 2) + headerHeight;
	
	const canvas = createCanvas(canvasWidth, canvasHeight);
	const ctx = canvas.getContext('2d');
	
	// Background
	ctx.fillStyle = '#f8f9fa';
	ctx.fillRect(0, 0, canvasWidth, canvasHeight);
	
	// Header
	ctx.fillStyle = '#212529';
	ctx.font = 'bold 28px Arial';
	ctx.textAlign = 'center';
	ctx.fillText('SUDOKU', canvasWidth / 2, 35);
	
	ctx.font = '16px Arial';
	ctx.fillStyle = '#6c757d';
	const diffName = difficulties[gameData.difficulty].name;
	const timeElapsed = getTime("x") - gameData.timeStart;
	const timeText = convertTime(timeElapsed);
	ctx.fillText(`${diffName} | Time: ${timeText}`, canvasWidth / 2, 60);
	
	if (gameData.hintsUsed > 0) {
		ctx.fillText(`Hints used: ${gameData.hintsUsed}`, canvasWidth / 2, 80);
	}
	
	// Draw grid
	const startX = padding;
	const startY = headerHeight + padding;
	
	// Draw cells
	for (let row = 0; row < 9; row++) {
		for (let col = 0; col < 9; col++) {
			const x = startX + col * cellSize;
			const y = startY + row * cellSize;
			
			// Cell background
			const isOriginal = gameData.originalPuzzle[row][col] !== 0;
			ctx.fillStyle = isOriginal ? '#e9ecef' : '#ffffff';
			ctx.fillRect(x, y, cellSize, cellSize);
			
			// Cell border
			ctx.strokeStyle = '#dee2e6';
			ctx.lineWidth = 1;
			ctx.strokeRect(x, y, cellSize, cellSize);
			
			// Number
			const num = gameData.puzzle[row][col];
			if (num !== 0) {
				ctx.fillStyle = isOriginal ? '#212529' : '#0d6efd';
				ctx.font = isOriginal ? 'bold 24px Arial' : '24px Arial';
				ctx.textAlign = 'center';
				ctx.textBaseline = 'middle';
				ctx.fillText(num.toString(), x + cellSize / 2, y + cellSize / 2);
			}
		}
	}
	
	// Draw thick borders for 3x3 boxes
	ctx.strokeStyle = '#212529';
	ctx.lineWidth = 3;
	
	// Vertical lines
	for (let i = 0; i <= 3; i++) {
		const x = startX + i * cellSize * 3;
		ctx.beginPath();
		ctx.moveTo(x, startY);
		ctx.lineTo(x, startY + gridSize);
		ctx.stroke();
	}
	
	// Horizontal lines
	for (let i = 0; i <= 3; i++) {
		const y = startY + i * cellSize * 3;
		ctx.beginPath();
		ctx.moveTo(startX, y);
		ctx.lineTo(startX + gridSize, y);
		ctx.stroke();
	}
	
	// Victory overlay
	if (gameData.isFinished && isPuzzleComplete(gameData.puzzle)) {
		ctx.fillStyle = 'rgba(40, 167, 69, 0.9)';
		ctx.fillRect(0, 0, canvasWidth, canvasHeight);
		
		ctx.fillStyle = '#ffffff';
		ctx.font = 'bold 36px Arial';
		ctx.textAlign = 'center';
		ctx.fillText('SOLVED!', canvasWidth / 2, canvasHeight / 2);
		
		ctx.font = '20px Arial';
		ctx.fillText('Congratulations!', canvasWidth / 2, canvasHeight / 2 + 40);
	}
	
	const stream = canvas.createPNGStream();
	stream.path = `sudoku_${randomString(5)}.png`;
	return stream;
}