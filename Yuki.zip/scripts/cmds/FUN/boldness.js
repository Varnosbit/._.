exports.config = {
 name: "تحدي",
 aliases: ["صراحة"],
 version: "2.5.0",
 role: 0,
 guide: {
 en: "{pn} tag question",
 ar: "{pn} منشن أو رد + سؤال التحدي"
 },
 desc: {
 en: "Challenge game with witnesses, exchange and leaderboard",
 ar: "لعبة تحدي بنظام شهود + صرف + ترتيب"
 }
};

const tasks = {};
const onePt = 100;
const ACCEPT_TIMEOUT = 20000;

exports.onStart = async ({ args, event, message, usersData, commandName }) => {
 try {
 const sub = args[0]?.toLowerCase();

 /* ========= LEADERBOARD ========= */
 const leaderboardCommands = ["lb", "leaderboard", "الأفضل", "الافضل", "top", "توب"];
 if (leaderboardCommands.includes(sub)) {
 const all = await usersData.getAll();
 const list = all
 .map(u => ({ id: u.userID, stars: u.data?.boldness?.stars || 0 }))
 .filter(u => u.stars > 0)
 .sort((a, b) => b.stars - a.stars)
 .slice(0, 10);

 if (!list.length) return message.reply("🌟 لا يوجد ترتيب بعد");

 let text = "🏆 ترتيب الأساطير:\n\n";
 for (let i = 0; i < list.length; i++) {
 const name = await usersData.getName(list[i].id);
 const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "⭐";
 text += `${medal} ${i + 1}. ${name} • ${list[i].stars} نجمة\n`;
 }
 return message.reply(text);
 }

 /* ========= EXCHANGE / صرف ========= */
 if (sub === "exchange" || sub === "صرف") {
 const id = event.senderID;
 const points = await usersData.get(id, "data.boldness.points") || 0;
 const toDo = parseInt(args[1]);

 if (!points) return message.reply("❌ ما عندك نقاط");

 if (toDo) {
 if (toDo > points) return message.reply("❌ نقاطك غير كافية");
 const money = toDo * onePt;
 await usersData.set(id, points - toDo, "data.boldness.points");
 await usersData.addMoney(id, money);
 return message.reply(`✅ تم الصرف\n💎 ${toDo} نقطة → ${money} 💰`);
 }

 return message.reply(
 `💰 رصيدك: ${points} نقطة\n📝 رد بعدد النقاط`,
 (err, info) => {
 if (!err && info) {
 YamiBot.onReply.set(info.messageID, {
 commandName,
 do_: "exch",
 author: id
 });
 }
 }
 );
 }

 /* ========= CHALLENGE ========= */
 const id = Object.keys(event.mentions).length
 ? Object.keys(event.mentions)[0]
 : event.messageReply?.senderID;

 if (!id) return;
 if (id === event.senderID) return message.reply("❌ لا يمكنك تحدي نفسك");

 const question = args.join(" ").trim();
 if (!question) return message.reply("❓ يجب كتابة سؤال التحدي");

 if (!tasks[event.threadID]) tasks[event.threadID] = {};
 if (tasks[event.threadID][id]) {
 return message.reply("⏳ هذا الشخص لديه تحدي نشط");
 }

 const name = await usersData.getName(id);

 const challengeMsg = await message.reply({
 body: `🎯 تحدي جديد!\n\n👤 ${name}\n❓ ${question}\n\n✅ أي رياكشن للموافقة\n❌ ❌ للرفض\n👀 شاهدين لإنهاء التحدي`,
 mentions: [{ tag: name, id }]
 });

 const timeout = setTimeout(() => {
 if (tasks[event.threadID]?.[id] && !tasks[event.threadID][id].accepted) {
 delete tasks[event.threadID][id];
 YamiBot.onReaction.delete(challengeMsg.messageID);
 message.reply("⌛ تم إلغاء التحدي تلقائياً");
 }
 }, ACCEPT_TIMEOUT);

 tasks[event.threadID][id] = {
 challengeof: id,
 challenger: event.senderID,
 witnesses: [],
 witnessCount: 0,
 accepted: false,
 completed: false,
 messageID: challengeMsg.messageID,
 timeout
 };

 YamiBot.onReaction.set(challengeMsg.messageID, {
 commandName,
 threadID: event.threadID,
 target: id
 });

 } catch (e) {
 console.error(e);
 message.reply("❌ حدث خطأ");
 }
};

exports.onReaction = async ({ event, message, usersData, Reaction }) => {
 try {
 const task = tasks[Reaction.threadID]?.[Reaction.target];
 if (!task || task.completed) return;

 if (event.userID === task.challengeof && !task.accepted) {
 if (event.reaction === "❌") {
 clearTimeout(task.timeout);
 delete tasks[Reaction.threadID][Reaction.target];
 YamiBot.onReaction.delete(event.messageID);
 return message.reply("❌ تم رفض التحدي");
 }
 task.accepted = true;
 clearTimeout(task.timeout);
 return;
 }

 if (!task.accepted) return;

 if (
 event.userID !== task.challengeof &&
 !task.witnesses.includes(event.userID)
 ) {
 task.witnesses.push(event.userID);
 task.witnessCount += YamiBot.config.adminBot.includes(event.userID) ? 2 : 1;
 }

 if (task.witnessCount >= 2) {
 task.completed = true;

 const pts = await usersData.get(task.challengeof, "data.boldness.points") || 0;
 const stars = await usersData.get(task.challengeof, "data.boldness.stars") || 0;

 await usersData.set(task.challengeof, pts + 1, "data.boldness.points");
 await usersData.set(task.challengeof, stars + 1, "data.boldness.stars");

 const name = await usersData.getName(task.challengeof);

 delete tasks[Reaction.threadID][Reaction.target];
 YamiBot.onReaction.delete(event.messageID);

 message.reply({
 body: `🎊 تم إنجاز التحدي!\n👤 ${name}\n⭐ +1 نجمة | 💎 +1 نقطة`,
 mentions: [{ tag: name, id: task.challengeof }]
 });
 }

 } catch (e) {
 console.error(e);
 }
};

exports.onReply = async ({ event, message, usersData, Reply }) => {
 try {
 if (Reply.commandName !== "تحدي" || Reply.do_ !== "exch") return;
 if (event.senderID !== Reply.author) return;

 const toDo = parseInt(event.body);
 if (!toDo || toDo <= 0) return message.reply("❌ رقم غير صالح");

 const points = await usersData.get(event.senderID, "data.boldness.points") || 0;
 if (toDo > points) return message.reply("❌ نقاطك غير كافية");

 const money = toDo * onePt;
 await usersData.set(event.senderID, points - toDo, "data.boldness.points");
 await usersData.addMoney(event.senderID, money);

 YamiBot.onReply.delete(event.messageReply.messageID);

 message.reply(`✅ تم الصرف\n💎 ${toDo} نقطة → ${money} 💰`);
 } catch (e) {
 console.error(e);
 }
};