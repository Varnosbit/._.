const Config = require('./Config');
const Utils = require('./Utils');
const Variables = require('./Variables');
const Database = require('./Database');

async function startDayPhase(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  game.phase = "day";
  game.votes = {};
  game.voteLocked = {};
  
  const playersList = await Utils.listPlayers(game, usersData);
  const msg = `${Utils.formatPhaseMessage("day", game.day)}\n\n____________________________\n\n👥 الأحياء:\n____________________________\n\n${playersList}\n\n____________________________\n\n💬 ناقشوا وحللوا المعلومات!\n🕵️ من المشبوه في نظركم?\n\n____________________________\n\n${Utils.formatGameStatus(game)}\n\n____________________________\n\n⏱️ ${Config.gameSettings.dayDurationMs / 1000} ثانية للنقاش!`;
  
  await mqtt.sendMessage(msg, game.main);
  dayPhaseTimer(mqtt, gameID, usersData);
}

function dayPhaseTimer(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  const timer1 = setTimeout(async () => {
    if (game.phase === "day") {
      await mqtt.sendMessage(`⏰ تبقى ${Config.gameSettings.dayReminderMs / 1000} ثانية للنقاش! 💬`, game.main);
    }
  }, Config.gameSettings.dayDurationMs - Config.gameSettings.dayReminderMs);
  
  const timer2 = setTimeout(() => {
    if (game.phase === "day") {
      startVoting(mqtt, gameID, usersData);
    }
  }, Config.gameSettings.dayDurationMs);
  
  Variables.addTimer(gameID, timer1);
  Variables.addTimer(gameID, timer2);
}

async function startVoting(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  game.phase = "voting";
  game.votes = {};
  game.voteLocked = {};
  
  await mqtt.sendMessage(
    `${Utils.formatPhaseMessage("voting", game.day)}\n\n____________________________\n\n⚖️ حان وقت العدالة!\n🎯 اختاروا بحكمة!\n\n⏱️ ${Config.gameSettings.votingDurationMs / 1000} ثانية للتصويت!`,
    game.main
  );
  
  for (const p of Variables.alive(game)) {
    if (p.blackmailed) {
      await Utils.sendToPlayerOrRoom(mqtt, p, `🤫 تم ابتزازك!\n____________________________\n🚫 لا يمكنك التصويت اليوم!\n😔 الصمت إجباري`);
      continue;
    }
    
    const playersList = await Utils.listPlayers(game, usersData, false);
    let msg = `🗳️ التصويت - اليوم ${game.day}\n____________________________\n\n⚖️ اختر رقم اللاعب:\n${playersList}\n____________________________\n\n💡 أو اكتب: تخطي`;
    
    if (Database.hasPurchase(p.userID, "vote_power")) {
      msg += `\n⚡ لديك قوة تصويت! (+1 صوت)`;
    }
    
    msg += `\n\n⚠️ فكر جيداً! 🧠`;
    
    try {
      let messageID;
      const playerName = await usersData.getName(p.userID);
      
      if (Config.InboxMode) {
        const result = await mqtt.sendMessage(msg, p.userID);
        messageID = result.messageID;
      } else {
        if (p.groupID) {
          try {
            const result = await mqtt.sendMessage(msg, p.groupID);
            messageID = result.messageID;
          } catch (groupError) {
            console.error(`[MAFIA42] Failed to send voting to group ${p.groupID}, falling back to inbox:`, groupError);
            await mqtt.sendMessage(`⚠️ خطأ في إرسال رسالة تصويت للاعب ${playerName}`, game.main);
            const result = await mqtt.sendMessage(msg, p.userID);
            messageID = result.messageID;
          }
        } else {
          console.error(`[MAFIA42] Player ${p.userID} has no groupID for voting, sending to inbox`);
          await mqtt.sendMessage(`⚠️ اللاعب ${playerName} ليس لديه غرفة خاصة، تم الإرسال للإنبوكس`, game.main);
          const result = await mqtt.sendMessage(msg, p.userID);
          messageID = result.messageID;
        }
      }
      
      if (messageID) {
        global.YamiBot.onReply.set(messageID, {
          commandName: game.commandName,
          gameID: game.id,
          playerID: p.userID,
          type: "voting"
        });
      } else {
        console.error(`[MAFIA42] No messageID returned for voting player ${p.userID}`);
        await mqtt.sendMessage(`❌ خطأ: لم يتم تسجيل استماع التصويت للاعب ${playerName}`, game.main);
      }
    } catch (error) {
      console.error(`[MAFIA42] Critical error sending vote message to ${p.userID}:`, error);
      const playerName = await usersData.getName(p.userID);
      await mqtt.sendMessage(`❌ خطأ حرج: فشل إرسال رسالة تصويت للاعب ${playerName}`, game.main);
    }
  }
  
  votingTimer(mqtt, gameID, usersData);
}

function votingTimer(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  const timer1 = setTimeout(async () => {
    if (game.phase === "voting") {
      await mqtt.sendMessage(`⏰ تبقى ${Config.gameSettings.votingReminderMs / 1000} ثانية للتصويت! 🗳️`, game.main);
    }
  }, Config.gameSettings.votingDurationMs - Config.gameSettings.votingReminderMs);
  
  const timer2 = setTimeout(() => {
    if (game.phase === "voting") {
      resolveVotes(mqtt, gameID, usersData);
    }
  }, Config.gameSettings.votingDurationMs);
  
  Variables.addTimer(gameID, timer1);
  Variables.addTimer(gameID, timer2);
}

async function handleVote(Reply, event, mqtt, usersData) {
  const game = Variables.getGame(Reply.gameID);
  if (!game || game.phase !== "voting") return;
  
  const voter = game.players[Reply.playerID];
  if (!voter || !voter.alive || voter.blackmailed) return;
  
  if (game.voteLocked[voter.userID]) {
    return Utils.sendToPlayerOrRoom(mqtt, voter, "🔒 لقد صوّتت بالفعل!\n____________________________\n⚠️ لا يمكن التغيير");
  }
  
  const input = event.body.trim();
  
  if (input === "تخطي" || input.toLowerCase() === "skip") {
    game.votes[voter.userID] = "skip";
    game.voteLocked[voter.userID] = true;
    const voterName = await usersData.getName(voter.userID);
    await mqtt.sendMessage(`⏭️ ${voterName} صوّت للتخطي`, game.main);
    return Utils.sendToPlayerOrRoom(mqtt, voter, "✅ اخترت التخطي\n____________________________\n⏭️ لا إقصاء اليوم");
  }
  
  const targetIndex = parseInt(input);
  if (isNaN(targetIndex)) {
    return Utils.sendToPlayerOrRoom(mqtt, voter, "❌ رد برقم صحيح أو: تخطي 🔢");
  }
  
  const target = Variables.getPlayerByIndex(game, targetIndex);
  if (!target) {
    return Utils.sendToPlayerOrRoom(mqtt, voter, "❌ رقم خاطئ! تحقق من القائمة 📋");
  }
  
  if (target.userID === voter.userID) {
    return Utils.sendToPlayerOrRoom(mqtt, voter, "⚠️ لا يمكنك التصويت لنفسك! 🚫\n____________________________\n😅 اختر شخصاً آخر");
  }
  
  game.votes[voter.userID] = target.userID;
  game.voteLocked[voter.userID] = true;
  
  const targetName = await usersData.getName(target.userID);
  const voterName = await usersData.getName(voter.userID);
  await mqtt.sendMessage(`🗳️ ¦ تم التصويت لإقصاء ${targetName}`, game.main);
  return Utils.sendToPlayerOrRoom(mqtt, voter, `✅ صوّتت لإقصاء ${targetName}\n____________________________\n🔒 تم تسجيل صوتك!`);
}

async function resolveVotes(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  const voteCounts = {};
  const voteWeights = {};
  
  for (const [voterID, targetID] of Object.entries(game.votes)) {
    if (targetID === "skip") continue;
    
    const voter = game.players[voterID];
    if (!voter || !voter.alive) continue;
    
    let voteWeight = 1;
    if (voter.role === "mayor" && game.mayorRevealed) {
      voteWeight = 3;
    }
    if (Database.hasPurchase(voterID, "vote_power")) {
      voteWeight += 1;
      Database.removePurchaseFromInventory(voterID, "vote_power");
    }
    
    voteCounts[targetID] = (voteCounts[targetID] || 0) + voteWeight;
    if (voteWeight > 1) {
      voteWeights[voterID] = voteWeight;
    }
  }
  
  let maxVotes = 0;
  let candidates = [];
  for (const [targetID, count] of Object.entries(voteCounts)) {
    if (count > maxVotes) {
      maxVotes = count;
      candidates = [targetID];
    } else if (count === maxVotes) {
      candidates.push(targetID);
    }
  }
  
  let msg = `📊 نتائج التصويت 📊\n____________________________\n\n`;
  
  if (Object.keys(voteWeights).length > 0) {
    msg += `⚡ قوة التصويت:\n`;
    for (const [voterID, weight] of Object.entries(voteWeights)) {
      const voterName = await usersData.getName(voterID);
      msg += `• ${voterName}: ${weight} أصوات\n`;
    }
    msg += `\n____________________________\n\n`;
  }
  
  const sortedVotes = Object.entries(voteCounts).sort((a, b) => b[1] - a[1]);
  for (const [targetID, count] of sortedVotes) {
    const target = game.players[targetID];
    const targetName = await usersData.getName(target.userID);
    msg += `🎯 ${targetName}: ${count} ${count === 1 ? 'صوت' : 'أصوات'}\n`;
  }
  
  msg += `\n____________________________\n\n`;
  
  let executed = null;
  let executedTargetID = null;
  
  if (candidates.length === 0 || maxVotes === 0) {
    msg += `⏭️ لا إقصاء اليوم!\n😌 الجميع نجا`;
  } else if (candidates.length === 1) {
    executedTargetID = candidates[0];
    executed = game.players[executedTargetID];
    const roleData = Config.ROLES[executed.role];
    const executedName = await usersData.getName(executed.userID);
    
    if (executed.role === "jester") {
      executed.alive = false;
      msg += `🎭 تم إقصاء: ${executedName}\n\n🤡 كان مهرجاً!\n🎉 فاز بتحقيق هدفه!\n😂 ضحك على الجميع!`;
      await Utils.sendToPlayerOrRoom(mqtt, executed, `🎉 فزت! 🤡\n____________________________\n✅ تم التصويت عليك!\n😂 هدفك تحقق!\n🎭 الفوز بالخسارة!`);
      await mqtt.sendMessage(msg, game.main);
      await Utils.revealRoleInMainChat(mqtt, game, executed.userID, usersData, "مُقصى");
      const Functions = require('./Functions');
      return Functions.handleGameEnd(mqtt, game, { ended: true, winner: "neutral", specialPlayer: executed }, usersData);
    }
    
    executed.alive = false;
    executed.lynched = true;
    msg += `☠️ تم إقصاء: ${executedName}`;
    Database.incrementStat(executed.userID, "deaths");
    
    for (const [voterID, targetID] of Object.entries(game.votes)) {
      if (targetID === "skip") continue;
      const isCorrect = targetID === executedTargetID && Utils.isMafiaRole(executed.role);
      Database.recordVote(voterID, isCorrect);
    }
    
    const executioner = Object.values(game.players).find(p => 
      p.role === "executioner" && 
      p.executionerTarget === executed.userID &&
      p.alive
    );
    
    if (executioner) {
      msg += `\n\n🪓 كان هدف الجلاد!\n🎉 فاز الجلاد!\n🎯 خطة محكمة!`;
      await Utils.sendToPlayerOrRoom(mqtt, executioner, `🎉 فزت! 🪓\n____________________________\n✅ تم إقصاء هدفك!\n🎯 خطة نجحت!\n🏆 انتصار محكم!`);
      await mqtt.sendMessage(msg, game.main);
      await Utils.revealRoleInMainChat(mqtt, game, executed.userID, usersData, "مُقصى");
      const Functions = require('./Functions');
      return Functions.handleGameEnd(mqtt, game, { ended: true, winner: "neutral", specialPlayer: executioner }, usersData);
    }
  } else {
    const tiedNames = [];
    for (const id of candidates) {
      const name = await usersData.getName(game.players[id].userID);
      tiedNames.push(name);
    }
    msg += `⚖️ تعادل!\n${tiedNames.join(" و ")}\n\n⏭️ لا إقصاء!\n🤔 قرار صعب`;
  }
  
  await mqtt.sendMessage(msg, game.main);
  
  if (executed) {
    const roleData = Config.ROLES[executed.role];
    await Utils.sendToPlayerOrRoom(mqtt, executed, `☠️ تم إقصاؤك!\n____________________________\n${roleData.emoji} ${roleData.name}\n📝 ${roleData.desc}`);
    await Utils.revealRoleInMainChat(mqtt, game, executed.userID, usersData, "مُقصى");
  }
  
  const endResult = Utils.checkGameEnd(game);
  if (endResult.ended) {
    const Functions = require('./Functions');
    return Functions.handleGameEnd(mqtt, game, endResult, usersData);
  }
  
  setTimeout(() => {
    const Night = require('./Night');
    Night.startNightPhase(mqtt, gameID, usersData);
  }, Config.gameSettings.phaseTransitionDelayMs);
}

module.exports = {
  startDayPhase,
  dayPhaseTimer,
  startVoting,
  votingTimer,
  handleVote,
  resolveVotes
};
