exports.config = {
 name: "ping",
 author: "Allou",
 version: "1.0.0",
 usage: "ping",
 countDown: 5,
 role: 0,
 description: {
 ar: "فحص سرعة استجابة البوت",
 en: "Check bot response speed"
 },
 guide: {
 ar: "اكتب بينغ لمعرفة سرعة الاستجابة",
 en: "Type ping to check latency"
 },
 aliases: [
 "بينغ",
 "ping",
 "latency"
 ]
};

exports.langs = {
 ar: {
 pong: "التأخير %1 جزء من الثانية ⌛",
 ping: "جاري التحقق من التأخر ⏳..."
 },
 en: {
 pong: "Pong! %1ms ⌛",
 ping: "pinging... ⏳"
 }
};

exports.onStart = async function ({ message, getLang }) {
 const start = Date.now();
 await message.send(getLang("ping"));
 const latency = Date.now() - start;

 message.reply(
 getLang("pong", latency)
 );
};