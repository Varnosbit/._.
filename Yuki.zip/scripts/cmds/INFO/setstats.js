const heKnowUsage = [];

module.exports = {
    config: {
        name: "status_set",
        aliases: ["setstatus", "statusupdate", "setstat"],
        version: "1.0",
        author: "allouMohamed",
        countDown: 5,
        role: 0,
        description: {
            en: "Update your status with options for avatar, cover, name, or achievements",
            ar: "تحديث حالتك مع خيارات لتغيير الصورة الشخصية، الغلاف، الاسم أو الإنجازات"
        },
        category: "general",
        guide: {
            en: "{pn} avatar <reply to image>: Change your avatar"
                + "\n   {pn} cover <reply to image>: Change your cover"
                + "\n   {pn} name <new name>: Change your name"
                + "\n   {pn} achievement <achievement text>: Set your achievement",
            ar: "   {pn} avatar <الرد على صورة>: تغيير الصورة الشخصية"
                + "\n   {pn} cover <الرد على صورة>: تغيير الغلاف"
                + "\n   {pn} name <الاسم الجديد>: تغيير الاسم"
                + "\n   {pn} achievement <نص الإنجاز>: تحديد الإنجاز"
        }
    },
    onStart: async function({ event, message, role, args, commandName, prefix, usersData }) {
        const id = event.senderID;
       /* const isImage = event?.messageReply?.attachments?.[0]?.url
            ? event?.messageReply?.attachments?.[0]?.url
            : /^https?:\/\/[^\s]+$/i.test(args.join(' ')) 
            ? args.join(' ') 
            : null;*/
        const isImage = event?.messageReply?.attachments?.[0]?.url
            ? event?.messageReply?.attachments?.[0]?.url
            : /^https?:\/\/[^\s]+$/i.test(args.slice(1).join(' ')) 
            ? args.slice(1).join(' ') 
            : null;
        const update = async (newData, key, r) => {
            try {
                await helpers.setP(usersData, id, newData, key);
                if (r == false) return;
                message.reaction("✅", event.messageID);
                return;
            } catch(e) {
                message.reply(e.message);
                message.reaction("❌", event.messageID);
                return;
            }
        };
        let key;
        let newData;

        switch (args[0]) {
            case 'avatar':
            case 'avt':
            case 'profile':
            case 'p':
            case 'a':
            case 'pfp': 
            case 'pic': 
            case 'dp': 
            case 'icon':
                key = 'avatar';
                if (!isImage) return message.reaction("❌", event.messageID);
                try {
                    const url = await helpers.YamiBB(isImage);
                    const finalurl = url.stream;
                    newData = finalurl;
                } catch(e) {
                    return message.reaction("❌", event.messageID);
                }
                return await update(newData, key);
                break;
            case 'cover':
            case 'c':
            case 'bg':
            case 'background':
            case 'banner':
            case 'header':
            case 'wallpaper':
                key = 'cover';
                if (!isImage) return message.reaction("❌", event.messageID);
                try {
                    const url = await helpers.YamiBB(isImage);
                    const finalurl = url.stream;
                    newData = finalurl;
                } catch(e) {
                    return message.reaction("❌", event.messageID);
                }
                return await update(newData, key);
                break;
            case 'name':
            case 'n':
            case 'fullname':
            case 'realname':
            case 'identity':
            case 'title':
                key = "name";
                const newName = args.slice(1).join(" ").length < 14 
                    ? args.slice(1).join(" ") 
                    : args.slice(1).join(" ").substring(0, 14);
                newData = newName;
                return await update(newData, key);
                break;
            case 'username':
            case 'usn':
            case 'handle':
            case 'user':
            case 'alias':
            case 'nickname':
                if (!args[1] || !args[2]) return;
                key = "nickname";
                const isValidHex = (color) => /^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/.test(color);
                const colorHex = isValidHex(args[1]) ? args[1] : null;
                if (!colorHex) return message.reaction("❌", event.messageID);
                const newNickName = args.slice(2).join(" ").length < 14 
                    ? args.slice(2).join(" ") 
                    : args.slice(2).join(" ").substring(0, 14);
                newData = { txt: newNickName, clr: colorHex };
                return await update(newData, key);
                break;
            case 'tag':
                if (role < 3) return;
                if (!args[1]) return;
                key = "tag";
                const newTag = args.slice(1).join(" ").length < 14 
                    ? args.slice(1).join(" ") 
                    : args.slice(1).join(" ").substring(0, 7);
                newData = newTag;
                return await update(newData, key);
                break;
            case 'TrustFactor':
            case 'tf':
                if (role < 3) return;
                key = "TrustFactor";
                newData = args[1];
                return await update(newData, key);
                break;
            case 'achievement':
            case 'ach':
                key = "achievement";
                if (role < 3) return;
                const parameters = args.slice(1).join(' ');
                const color = parameters.match(/--colors\s([^\s]+)/g)?.map(color => color.split(' ')[1]) || [];
               // const text = parameters.match(/--text\s([^\s]+)/)?.[1] || '';
                const text = parameters.match(/--text\s([^--]+)/)?.[1].trim() || '';
                newData = { name: text, color: color };
                return await update(newData, key);
                break;
            case "flag":
                key = "flag";
                const info = getCountryInfo(args[1]);
                if (!info) return message.reaction("❌", event.messageID);
                newData = info.Image;
                await update(newData, key);
                const n = info.name;
                const k = "flagname";
                return await update(n, k, false);
                break;
            default:
    if (heKnowUsage.includes(id)) return;
    heKnowUsage.push(id);
    return message.send(`
        Usage for ${commandName}:
        ${prefix}${commandName} avatar <reply to image or provide url>: Change your avatar
        ${prefix}${commandName} cover <reply to image or provide url>: Change your cover
        ${prefix}${commandName} name <new name>: Change your name
        ${prefix}${commandName} achievement <achievement text>: Set your achievement
        ${prefix}${commandName} username <nickname> <color>: Set your nickname with a color
        ${prefix}${commandName} tag <tag>: Set your custom tag
        ${prefix}${commandName} TrustFactor <factor>: Set your trust factor
        ${prefix}${commandName} flag <country code>: Set your country flag
        
        More info: 
        ${prefix}${commandName} <command> [arguments]
    `);
    break;
        }
    }
};

function getCountryInfo(code) {
  const countries = {
    af: "Afghanistan",
    al: "Albania",
    dz: "Algeria",
    as: "American Samoa",
    ad: "Andorra",
    ao: "Angola",
    ai: "Anguilla",
    ag: "Antigua and Barbuda",
    ar: "Argentina",
    am: "Armenia",
    aw: "Aruba",
    au: "Australia",
    at: "Austria",
    az: "Azerbaijan",
    bs: "Bahamas",
    bh: "Bahrain",
    bd: "Bangladesh",
    bb: "Barbados",
    by: "Belarus",
    be: "Belgium",
    bz: "Belize",
    bj: "Benin",
    bm: "Bermuda",
    bt: "Bhutan",
    bo: "Bolivia",
    ba: "Bosnia and Herzegovina",
    bw: "Botswana",
    br: "Brazil",
    io: "British Indian Ocean Territory",
    bn: "Brunei",
    bg: "Bulgaria",
    bf: "Burkina Faso",
    bi: "Burundi",
    cv: "Cabo Verde",
    kh: "Cambodia",
    cm: "Cameroon",
    ca: "Canada",
    ky: "Cayman Islands",
    cf: "Central African Republic",
    td: "Chad",
    cl: "Chile",
    cn: "China",
    co: "Colombia",
    km: "Comoros",
    cg: "Congo",
    cd: "Congo (Democratic Republic)",
    ck: "Cook Islands",
    cr: "Costa Rica",
    ci: "Côte d'Ivoire",
    hr: "Croatia",
    cu: "Cuba",
    cy: "Cyprus",
    cz: "Czech Republic",
    dk: "Denmark",
    dj: "Djibouti",
    dm: "Dominica",
    do: "Dominican Republic",
    ec: "Ecuador",
    eg: "Egypt",
    sv: "El Salvador",
    gq: "Equatorial Guinea",
    er: "Eritrea",
    ee: "Estonia",
    et: "Ethiopia",
    fk: "Falkland Islands",
    fo: "Faroe Islands",
    fj: "Fiji",
    fi: "Finland",
    fr: "France",
    gf: "French Guiana",
    pf: "French Polynesia",
    ga: "Gabon",
    gm: "Gambia",
    ge: "Georgia",
    de: "Germany",
    gh: "Ghana",
    gi: "Gibraltar",
    gr: "Greece",
    gl: "Greenland",
    gd: "Grenada",
    gp: "Guadeloupe",
    gu: "Guam",
    gt: "Guatemala",
    gg: "Guernsey",
    gn: "Guinea",
    gw: "Guinea-Bissau",
    gy: "Guyana",
    ht: "Haiti",
    va: "Vatican City",
    hn: "Honduras",
    hk: "Hong Kong",
    hu: "Hungary",
    is: "Iceland",
    in: "India",
    id: "Indonesia",
    ir: "Iran",
    iq: "Iraq",
    ie: "Ireland",
    il: "Israel",
    it: "Italy",
    jm: "Jamaica",
    jp: "Japan",
    je: "Jersey",
    jo: "Jordan",
    kz: "Kazakhstan",
    ke: "Kenya",
    kir: "Kiribati",
    kw: "Kuwait",
    kg: "Kyrgyzstan",
    la: "Laos",
    lv: "Latvia",
    lb: "Lebanon",
    ls: "Lesotho",
    lr: "Liberia",
    ly: "Libya",
    li: "Liechtenstein",
    lt: "Lithuania",
    lu: "Luxembourg",
    mo: "Macau",
    mk: "North Macedonia",
    mg: "Madagascar",
    mw: "Malawi",
    my: "Malaysia",
    mv: "Maldives",
    ml: "Mali",
    mt: "Malta",
    mh: "Marshall Islands",
    mq: "Martinique",
    mr: "Mauritania",
    mu: "Mauritius",
    yt: "Mayotte",
    mx: "Mexico",
    fm: "Micronesia",
    md: "Moldova",
    mc: "Monaco",
    mn: "Mongolia",
    me: "Montenegro",
    ms: "Montserrat",
    ma: "Morocco",
    mz: "Mozambique",
    mm: "Myanmar",
    na: "Namibia",
    nr: "Nauru",
    np: "Nepal",
    nl: "Netherlands",
    nc: "New Caledonia",
    nz: "New Zealand",
    ni: "Nicaragua",
    ne: "Niger",
    ng: "Nigeria",
    nu: "Niue",
    nf: "Norfolk Island",
    kp: "North Korea",
    mp: "Northern Mariana Islands",
    no: "Norway",
    om: "Oman",
    pk: "Pakistan",
    pw: "Palau",
    pa: "Panama",
    pg: "Papua New Guinea",
    py: "Paraguay",
    pe: "Peru",
    ph: "Philippines",
    pn: "Pitcairn Islands",
    pl: "Poland",
    pt: "Portugal",
    pr: "Puerto Rico",
    qa: "Qatar",
    ro: "Romania",
    ru: "Russia",
    rw: "Rwanda",
    re: "Réunion",
    bl: "Saint Barthélemy",
    sh: "Saint Helena",
    kn: "Saint Kitts and Nevis",
    lc: "Saint Lucia",
    mf: "Saint Martin",
    pm: "Saint Pierre and Miquelon",
    vc: "Saint Vincent and the Grenadines",
    ws: "Samoa",
    sa: "Saudi Arabia",
    sn: "Senegal",
    rs: "Serbia",
    sc: "Seychelles",
    sl: "Sierra Leone",
    sg: "Singapore",
    sx: "Sint Maarten",
    sk: "Slovakia",
    si: "Slovenia",
    sb: "Solomon Islands",
    so: "Somalia",
    za: "South Africa",
    kr: "South Korea",
    ss: "South Sudan",
    es: "Spain",
    lk: "Sri Lanka",
    sd: "Sudan",
    sr: "Suriname",
    sj: "Svalbard and Jan Mayen",
    sz: "Swaziland",
    se: "Sweden",
    ch: "Switzerland",
    sy: "Syria",
    tw: "Taiwan",
    tj: "Tajikistan",
    tz: "Tanzania",
    th: "Thailand",
    tg: "Togo",
    tk: "Tokelau",
    to: "Tonga",
    tt: "Trinidad and Tobago",
    tn: "Tunisia",
    tr: "Turkey",
    tm: "Turkmenistan",
    tc: "Turks and Caicos Islands",
    tv: "Tuvalu",
    ug: "Uganda",
    ua: "Ukraine",
    ae: "United Arab Emirates",
    gb: "United Kingdom",
    us: "United States",
    uy: "Uruguay",
    uz: "Uzbekistan",
    vu: "Vanuatu",
    ve: "Venezuela",
    vn: "Vietnam",
    wf: "Wallis and Futuna",
    eh: "Western Sahara",
    ye: "Yemen",
    zm: "Zambia",
    zw: "Zimbabwe",
    ps: "Palestine"
  };
  if (!countries[code]) return null;
  return {
    name: countries[code],
    Image: `https://flagcdn.com/h240/${code}.png`,
  };
}
