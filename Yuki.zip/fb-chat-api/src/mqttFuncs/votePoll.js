const utils = require("../../utils.js");

module.exports = (c, t, ctx) => {
  function votePoll(threadID, pollID, optionIDs, callback) {
    return new Promise((resolve, reject) => {
      if (!threadID) {
        const err = new Error("Missing parameter: threadID");
        if (callback) callback(err);
        return reject(err);
      }
      if (!pollID) {
        const err = new Error("Missing parameter: pollID");
        if (callback) callback(err);
        return reject(err);
      }
      if (!optionIDs || (Array.isArray(optionIDs) && optionIDs.length === 0)) {
        const err = new Error("Missing parameter: optionIDs");
        if (callback) callback(err);
        return reject(err);
      }

      if (typeof threadID === "number") threadID = String(threadID);
      if (typeof pollID === "number") pollID = String(pollID);
      if (!Array.isArray(optionIDs)) optionIDs = [String(optionIDs)];
      else optionIDs = optionIDs.map(o => String(o));

      const reqNum = ++ctx.wsReqNumber;
      const taskNum = ++ctx.wsTaskNumber;

      const taskPayload = {
        thread_key: threadID,
        poll_id: pollID,
        added_options: [],
        selected_options: optionIDs,
        sync_group: 1,
      };

      const task = {
        failure_count: null,
        label: "164", // poll update label
        payload: JSON.stringify(taskPayload),
        queue_name: "poll_update",
        task_id: taskNum,
      };

      const content = {
        app_id: "772021112871879",
        payload: JSON.stringify({
          epoch_id: parseInt(utils.generateOfflineThreadingID()),
          tasks: [task],
          version_id: "31485834987728002",
        }),
        pwa_version: "1",
        request_id: reqNum,
        type: 3,
      };

      const onResponse = (topic, message) => {
        if (topic === "/ls_resp") {
          let jsonMsg;
          try {
            jsonMsg = JSON.parse(message.toString());
            jsonMsg.payload = JSON.parse(jsonMsg.payload);
          } catch (err) {
            cleanup();
            if (callback) callback(err);
            return reject(err);
          }

          if (jsonMsg.request_id === reqNum) {
            const steps = jsonMsg.payload.step || [];
            const errRegex = /(error|warn)/i;
            let errorText = null;

            for (const s of steps) {
              try {
                const str = JSON.stringify(s);
                if (errRegex.test(str)) {
                  const match = str.match(/"([^"]*error[^"]*|[^"]*warn[^"]*)"/i);
                  if (match) errorText = match[1];
                }
              } catch {}
            }

            if (errorText) {
              const err = {
                message:
                  errorText +
                  ", possible causes: invalid threadID/pollID, bot not in thread, permissions issue, or account restrictions.",
              };
              cleanup();
              if (callback) callback(err);
              return reject(err);
            }
          }
        }

        if (topic !== "/t_ms") return;
        let parsed;
        try {
          parsed = JSON.parse(message.toString());
        } catch (err) {
          cleanup();
          if (callback) callback(err);
          return reject(err);
        }

        const deltas = parsed.deltas || [];
        for (const d of deltas) {
          if (d.type === "group_poll" && d.untypedData?.event_type === "vote_add") {
            cleanup();
            if (callback) callback(null, d);
            return resolve(d);
          }
        }
      };

      const cleanup = () => {
        ctx.mqttClient.removeListener("message", onResponse);
      };

      ctx.mqttClient.on("message", onResponse);
      ctx.mqttClient.publish("/ls_req", JSON.stringify(content), { qos: 1, retain: false });
    });
  }

  return votePoll;
};
