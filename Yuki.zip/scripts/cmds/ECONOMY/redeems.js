//1.0.0
const fs = require("fs");
const path = require("path");

const REDEEM_PATH = path.join(process.cwd(), "database", "data", "redeems.json");
if (!fs.existsSync(REDEEM_PATH)) fs.writeFileSync(REDEEM_PATH, "{}");

function loadRedeems() {
  return JSON.parse(fs.readFileSync(REDEEM_PATH, "utf8"));
}

function saveRedeems(data) {
  fs.writeFileSync(REDEEM_PATH, JSON.stringify(data, null, 2));
}

function generateCode(format = "xxx-xxxx-xx-x-xxxxx") {
  return format.replace(/[x]/g, () => Math.floor(Math.random() * 10));
}

function isExpired(createdAt) {
  return Date.now() - createdAt >= 2 * 60 * 60 * 1000; // 2 hours
}

module.exports = {
  config: {
    name: "redeem",
    aliases: ["rd"],
    version: "2.1.2",
    author: "allou mohamed",
    role: 0,
    cooldown: 5,
    description: "Redeem a code to get money or exp",
    category: "economy"
  },

  onStart: async ({ message, event, args, role, usersData }) => {
    const senderID = event.senderID;
    let redeems = loadRedeems();

    // Cleanup expired codes
    for (const code in redeems) {
      if (isExpired(redeems[code].createdAt)) {
        delete redeems[code];
      }
    }
    saveRedeems(redeems);

    // Admin: Create code
    if ((args[0] === "create" || args[0] === "c") && role >= 3) {
      const type = args[1];
      const amount = parseInt(args[2], 10);
      const maxUses = parseInt(args[3], 10) || 1;

      if (!["money", "exp"].includes(type) || isNaN(amount)) {
        return message.reply(
          "#%bdredeem%:\nUsage: /redeem create <money|exp> <amount> [maxUses]"
        );
      }

      const code = generateCode();
      redeems[code] = {
        type,
        amount,
        maxUses,
        usedBy: [],
        createdAt: Date.now()
      };

      saveRedeems(redeems);

      return message.reply(
        `#%bdredeem%:\nCode: %bd${code}%\nType: %bd${type}%\nAmount: %bd${amount}%\nMax Uses: %bd${maxUses}%\n\nUse /redeem ${code}`
      );
    }

    // User: Redeem code
    const code = args[0]?.trim();
    if (!code || !redeems[code])
      return message.reply("#%bdredeem%:\nInvalid or expired code.");

    const redeem = redeems[code];

    if (redeem.usedBy.includes(senderID))
      return message.reply("#%bdredeem%:\nYou already used this code.");

    if (redeem.usedBy.length >= redeem.maxUses) {
      delete redeems[code];
      saveRedeems(redeems);
      return message.reply("#%bdredeem%:\nThis code has reached its usage limit.");
    }

    const { type, amount } = redeem;

    if (type === "money") {
      await usersData.addMoney(senderID, amount);
    } else if (type === "exp") {
      const currentExp = await usersData.get(senderID, "exp");
      await usersData.set(senderID, currentExp + amount, "exp");
    }

    redeem.usedBy.push(senderID);
    if (redeem.usedBy.length >= redeem.maxUses) delete redeems[code];

    saveRedeems(redeems);

    return message.reply(
      `#%bdredeem%:\nYou received %bd${amount}% ${type === "money" ? "coins" : "exp"}!`
    );
  }
};