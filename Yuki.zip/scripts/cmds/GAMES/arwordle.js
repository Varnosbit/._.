const { createCanvas, registerFont } = require("canvas");
const https = require("https");
const fs = require("fs-extra");
const path = require("path");

const FONT_URL = "https://alfont.com/wp-content/fonts/naskh-arabic-fonts//alfont_com_Alyamama-ExtraBold.ttf";
const FONT_DIR = path.join(process.cwd()+"/scripts/cmds", "canvas", "fonts");
const FONT_PATH = path.join(FONT_DIR, "Alyamama-ExtraBold.ttf");
const DATA_PATH = path.join(process.cwd()+"/database", 'data', 'wordle.json');

fs.mkdirSync(FONT_DIR, { recursive: true });

const words = [
  "فم",
  "اب",
  "ام",
  "أخ",
  "جد",
  "عم",
  "سن",
  "يد",
  "دم",
  "خط",
  "حب",
  "فن",
  "هل",
  "تم",
  "كم",
  "هم",
  "سم",
  "قم",
  "أم",
  "أب",
  "ثم",
  "هن",
  "رب",
  "بن",
  "جن",
  "من",
  "لو",
  "كف",
  "قف",
  "قط",
  "حي",
  "شر",
  "أو",
  "لا",
  "ما",
  "في",
  "إن",
  "قد",
  "أن",
  "كل",
  "عن",
  "به",
  "لك",
  "له",
  "هي",
  "نم",
  "غد",
  "بيت",
  "قلم",
  "باب",
  "كتب",
  "ولد",
  "بنت",
  "عين",
  "عنب",
  "أخت",
  "جدة",
  "عمة",
  "خال",
  "ابن",
  "طفل",
  "رجل",
  "جار",
  "رأس",
  "شعر",
  "وجه",
  "أذن",
  "أنف",
  "كتف",
  "صدر",
  "بطن",
  "ظهر",
  "قدم",
  "قلب",
  "عظم",
  "خبز",
  "أرز",
  "لحم",
  "سمك",
  "بيض",
  "جبن",
  "زيت",
  "سكر",
  "ملح",
  "ماء",
  "شاي",
  "بصل",
  "ثوم",
  "عسل",
  "شمس",
  "قمر",
  "أرض",
  "بحر",
  "نهر",
  "جبل",
  "عشب",
  "مطر",
  "ثلج",
  "ريح",
  "رعد",
  "برق",
  "صيف",
  "طقس",
  "ضوء",
  "كلب",
  "قطة",
  "جمل",
  "أسد",
  "نمر",
  "فيل",
  "قرد",
  "فأر",
  "صقر",
  "نسر",
  "بطة",
  "وطن",
  "قصر",
  "بنك",
  "سوق",
  "جسر",
  "نفق",
  "غرف",
  "فرن",
  "صحن",
  "كوب",
  "مشط",
  "وقت",
  "يوم",
  "شهر",
  "سنة",
  "قرن",
  "فجر",
  "عصر",
  "ليل",
  "أمس",
  "رقم",
  "صفر",
  "ستة",
  "مئة",
  "ألف",
  "أول",
  "نصف",
  "لون",
  "بني",
  "فضي",
  "شكل",
  "ذهب",
  "جاء",
  "أكل",
  "شرب",
  "نام",
  "قرأ",
  "سمع",
  "رأى",
  "مشى",
  "جرى",
  "لعب",
  "عمل",
  "درس",
  "فهم",
  "عرف",
  "سأل",
  "فتح",
  "باع",
  "أخذ",
  "كره",
  "ضحك",
  "بكى",
  "طبخ",
  "غسل",
  "فكر",
  "جيد",
  "سيء",
  "سهل",
  "صعب",
  "غني",
  "قوي",
  "حار",
  "ذكي",
  "غبي",
  "ضيق",
  "موت",
  "حرب",
  "علم",
  "دين",
  "حلم",
  "أمل",
  "فشل",
  "نور",
  "سور",
  "حصن",
  "صنم",
  "ربو",
  "قطر",
  "خطر",
  "حبل",
  "شاب",
  "حبر",
  "خير",
  "حوت",
  "طير",
  "تين",
  "نخل",
  "ورد",
  "موز",
  "تمر",
  "سطح",
  "سلم",
  "سقف",
  "قصة",
  "اسم",
  "لقب",
  "صوت",
  "رسم",
  "نحت",
  "حجم",
  "وزن",
  "طول",
  "عرض",
  "صحة",
  "أدب",
  "كتاب",
  "مكتب",
  "قطار",
  "شباك",
  "موزة",
  "تفاح",
  "مطعم",
  "هاتف",
  "مطار",
  "منزل",
  "شارع",
  "خالة",
  "ابنة",
  "صديق",
  "زميل",
  "طالب",
  "طبيب",
  "ممرض",
  "مدير",
  "موظف",
  "فنان",
  "كاتب",
  "لسان",
  "رقبة",
  "ذراع",
  "إصبع",
  "دجاج",
  "حليب",
  "فلفل",
  "عصير",
  "قهوة",
  "خيار",
  "بطيخ",
  "مربى",
  "زبدة",
  "حساء",
  "سلطة",
  "نجمة",
  "سماء",
  "وادي",
  "غابة",
  "شجرة",
  "زهرة",
  "سحاب",
  "شتاء",
  "ربيع",
  "خريف",
  "ظلام",
  "فضاء",
  "حصان",
  "حمار",
  "بقرة",
  "خروف",
  "ماعز",
  "أرنب",
  "طائر",
  "نحلة",
  "نملة",
  "ضفدع",
  "قرية",
  "دولة",
  "قلعة",
  "متحف",
  "مسرح",
  "فندق",
  "مركز",
  "دكان",
  "مصنع",
  "ملعب",
  "مسبح",
  "مسجد",
  "معبد",
  "رصيف",
  "محطة",
  "حدود",
  "شاطئ",
  "سرير",
  "كرسي",
  "مرآة",
  "شوكة",
  "سكين",
  "وعاء",
  "ساعة",
  "صورة",
  "قميص",
  "معطف",
  "حذاء",
  "جورب",
  "قبعة",
  "وشاح",
  "قفاز",
  "حزام",
  "خاتم",
  "سوار",
  "مظلة",
  "صباح",
  "مساء",
  "غداً",
  "الآن",
  "واحد",
  "خمسة",
  "سبعة",
  "تسعة",
  "عشرة",
  "أخير",
  "أبيض",
  "أسود",
  "أحمر",
  "أزرق",
  "أخضر",
  "أصفر",
  "وردي",
  "ذهبي",
  "مربع",
  "مثلث",
  "تكلم",
  "أجاب",
  "أغلق",
  "أعطى",
  "ساعد",
  "سافر",
  "كبير",
  "صغير",
  "طويل",
  "قصير",
  "جديد",
  "قديم",
  "جميل",
  "قبيح",
  "فقير",
  "ضعيف",
  "سريع",
  "بطيء",
  "بارد",
  "نظيف",
  "متسخ",
  "سعيد",
  "حزين",
  "غاضب",
  "مريض",
  "واسع",
  "حياة",
  "سلام",
  "حرية",
  "خيال",
  "نجاح",
  "مدرس",
  "نهار",
  "ليلة",
  "ثمرة",
  "خضار",
  "جبنة",
  "رمان",
  "زبيب",
  "بلدة",
  "مطبخ",
  "غرفة",
  "حمام",
  "شرفة",
  "جدار",
  "باحة",
  "فكرة",
  "كلمة",
  "جملة",
  "صفحة",
  "دفتر",
  "شركة",
  "مجلة",
  "موقع",
  "بريد",
  "فيلم",
  "ماضي",
  "حاضر",
  "بيئة",
  "علوم",
  "فنون",
  "بحوث",
  "حلول",
  "آراء",
  "صحية",
  "فنية",
  "مرحبا",
  "سيارة",
  "طائرة",
  "مدرسة",
  "حديقة",
  "مفتاح",
  "طماطم",
  "جامعة",
  "حاسوب",
  "مكتبة",
  "بستان",
  "امرأة",
  "أستاذ",
  "مهندس",
  "فواكه",
  "بطاطس",
  "ليمون",
  "صحراء",
  "حرارة",
  "برودة",
  "حمامة",
  "دجاجة",
  "فراشة",
  "ذبابة",
  "بعوضة",
  "ثعبان",
  "تمساح",
  "مدينة",
  "عاصمة",
  "سينما",
  "كنيسة",
  "ميناء",
  "جزيرة",
  "خزانة",
  "طاولة",
  "أريكة",
  "سجادة",
  "ستارة",
  "مصباح",
  "ثلاجة",
  "غسالة",
  "ملعقة",
  "منشفة",
  "صابون",
  "وسادة",
  "فستان",
  "تنورة",
  "حقيبة",
  "محفظة",
  "قلادة",
  "ملابس",
  "ثانية",
  "دقيقة",
  "أسبوع",
  "اليوم",
  "أبداً",
  "اثنان",
  "ثلاثة",
  "أربعة",
  "مليون",
  "رمادي",
  "دائرة",
  "اشترى",
  "عدالة",
  "قانون",
  "سياسة",
  "ثقافة",
  "حقيقة",
  "نهاية",
  "نافذة",
  "فاكهة",
  "سفينة",
  "ميدان",
  "منطقة",
  "صالون",
  "أرضية",
  "كراسة",
  "رواية",
  "مؤسسة",
  "منظمة",
  "حكومة",
  "جريدة",
  "صحيفة",
  "تلفاز",
  "إذاعة",
  "تطبيق",
  "رسالة",
  "عنوان",
  "فيديو",
  "أغنية",
  "مسلسل",
  "تاريخ",
  "تعليم",
  "طبيعة",
  "رياضة",
  "صحيات",
  "فنيات",
  "تجارب",
  "نتائج",
  "مشاكل",
  "قضايا",
  "أفكار",
  "بيئية",
  "علمية",
  "أدبية",
  "نحتية",
  "بحثية",
  "برتقال",
  "مستشفى",
  "صيدلية",
  "مستقبل",
  "اقتصاد",
  "خضروات",
  "فراولة",
  "عنكبوت",
  "سلحفاة",
  "بطانية",
  "بنطلون",
  "نظارات",
  "دائماً",
  "ثمانية",
  "بنفسجي",
  "مستطيل",
  "استيقظ",
  "محافظة",
  "مجموعة",
  "إنترنت",
  "برنامج",
  "موسيقى",
  "مسرحية",
  "معلومة",
  "اجتماع",
  "بيئيات",
  "علميات",
  "أدبيات",
  "نحتيات",
  "قراءات",
  "دراسات",
  "توصيات",
  "سياسية",
  "ثقافية",
  "طبيعية",
  "رياضية",
  "رسومية",
  "كتابية",
  "قرائية",
  "دراسية",
  "حلولية",
  "قضائية",
  "آرائية",
  "تلفزيون",
  "استقلال",
  "مواصلات",
  "معلومات",
  "مسؤولية",
  "أحياناً",
  "برتقالي",
  "جمهورية",
  "اتصالات",
  "جغرافيا",
  "سياسيات",
  "ثقافيات",
  "طبيعيات",
  "رياضيات",
  "مسرحيات",
  "رسوميات",
  "كتابيات",
  "مقترحات",
  "موضوعات",
  "تعليمية",
  "جغرافية",
  "تاريخية",
  "موسيقية",
  "تجريبية",
  "نتائجية",
  "مشاكلية",
  "أفكارية",
  "تعليميات",
  "جغرافيات",
  "تاريخيات",
  "موسيقيات",
  "اقتصادية",
  "اجتماعية",
  "سينمائية",
  "توصياتية",
  "تكنولوجيا",
  "ديمقراطية",
  "اقتصاديات",
  "اجتماعيات",
  "سينمائيات",
  "استنتاجات",
  "معلوماتية",
  "تكنولوجية",
  "اتصالاتية",
  "إلكترونية",
  "استنتاجية",
  "مقترحاتية",
  "موضوعاتية",
  "تطبيقاتية",
  "برمجياتية",
  "إلكترونيات"
];

const lightTheme = {
  bg: "#ffffff",
  tile: "#ffffff",
  border: "#d3d6da",
  borderEmpty: "#878a8c",
  text: "#000000",
  correct: "#6aaa64",
  present: "#c9b458",
  absent: "#787c7e",
  textOnColor: "#ffffff",
  headerText: "#000000",
  messageText: "#ffffff"
};

const darkTheme = {
  bg: "#121213",
  tile: "#121213",
  border: "#3a3a3c",
  borderEmpty: "#565758",
  text: "#ffffff",
  correct: "#538d4e",
  present: "#b59f3b",
  absent: "#3a3a3c",
  textOnColor: "#ffffff",
  headerText: "#ffffff",
  messageText: "#ffffff"
};

const modes = {
  easy: {
    minLength: 2,
    maxLength: 5,
    maxAttempts: 8,
    label: "سهل"
  },
  medium: {
    minLength: 6,
    maxLength: 8,
    maxAttempts: 6,
    label: "متوسط"
  },
  hard: {
    minLength: 9,
    maxLength: 20,
    maxAttempts: 5,
    label: "صعب"
  }
};

const connectableLetters = [
  'ب', 'ت', 'ث', 'ن', 'ي', 'ل', 'ج', 'ح', 'خ',
  'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف',
  'ق', 'ك', 'م', 'ه', 'ى'
];

const addTatweel = (char, position, length, prevChar) => {
  if (!connectableLetters.includes(char)) return char;
  
  if (length === 1) return char;
  
  // Check if previous character is connectable
  const prevConnectable = prevChar && connectableLetters.includes(prevChar);
  
  if (position === 0) {
    // First letter - only add after
    return char + 'ـ';
  } else if (position === length - 1) {
    // Last letter - only add before if previous is connectable
    return prevConnectable ? 'ـ' + char : char;
  } else {
    // Middle letter
    if (prevConnectable) {
      // Previous is connectable - add before and after
      return 'ـ' + char + 'ـ';
    } else {
      // Previous is not connectable - only add after
      return char + 'ـ';
    }
  }
};

const formatWord = (text) => {
  const chars = [...text];
  return chars.map((char, i) => {
    const prevChar = i > 0 ? chars[i - 1] : null;
    return addTatweel(char, i, chars.length, prevChar);
  }).join('');
};

const getWordsByLength = (len) => words.filter(w => [...w].length === len);

const getModeByLength = (len) => {
  if (len >= 2 && len <= 5) return 'easy';
  if (len >= 6 && len <= 8) return 'medium';
  if (len >= 9) return 'hard';
  return 'medium';
};

const pickWord = (len) => {
  const list = getWordsByLength(len);
  if (list.length === 0) return null;
  return list[Math.floor(Math.random() * list.length)];
};

const evaluateGuess = (guess, target) => {
  const g = [...guess];
  const t = [...target];
  const result = new Array(g.length).fill("absent");
  const targetCounts = {};
  
  t.forEach(c => targetCounts[c] = (targetCounts[c] || 0) + 1);
  
  g.forEach((c, i) => {
    if (c === t[i]) {
      result[i] = "correct";
      targetCounts[c]--;
    }
  });
  
  g.forEach((c, i) => {
    if (result[i] === "absent" && targetCounts[c] > 0) {
      result[i] = "present";
      targetCounts[c]--;
    }
  });
  
  return result;
};

const checkWin = (guess, target) => {
  return guess === target;
};

const checkLose = (guesses, maxAttempts) => {
  return guesses.length >= maxAttempts;
};

const drawRoundedRect = (ctx, x, y, width, height, radius) => {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
};

const winMessages = [
  "عبقري!",
  "رائع جداً!",
  "ممتاز!",
  "أحسنت!",
  "جيد جداً!",
  "جيد!"
];

const drawBoard = async ({ target, guesses, mode, gameOver, won, darkMode = true }) => {
  const modeConfig = modes[mode];
  const theme = darkMode ? darkTheme : lightTheme;
  const size = [...target].length;
  const rows = modeConfig.maxAttempts;
  
  let cell = 64;
  let fontSize = 34;
  let headerFontSize = 40;
  
  if (size > 8) {
    cell = 52;
    fontSize = 28;
    headerFontSize = 34;
  } else if (size > 6) {
    cell = 58;
    fontSize = 30;
    headerFontSize = 36;
  }
  
  const gap = 5;
  const padding = 30;
  const headerHeight = 100;
  const bottomPadding = 50;
  
  const w = Math.max(480, size * cell + (size - 1) * gap + padding * 2 + 40);
  const h = rows * cell + (rows - 1) * gap + padding * 2 + headerHeight + bottomPadding;

  const canvas = createCanvas(w, h);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = theme.bg;
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = theme.headerText;
  ctx.font = `bold ${headerFontSize}px "AlyamamaExtraBold"`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(`لعبة الكلمات`, w / 2, 40);
  
  ctx.font = '18px "AlyamamaExtraBold"';
  ctx.fillStyle = theme.borderEmpty;
  ctx.fillText(`${modeConfig.label} • ${size} أحرف • ${modeConfig.maxAttempts} محاولات`, w / 2, 75);

  const gridWidth = size * cell + (size - 1) * gap;
  const gridStartX = (w - gridWidth) / 2;
  const gridStartY = headerHeight + padding;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < size; c++) {
      const x = gridStartX + (size - 1 - c) * (cell + gap);
      const y = gridStartY + r * (cell + gap);
      
      const hasGuess = r < guesses.length;
      const guess = hasGuess ? guesses[r] : "";
      const guessChars = [...guess];
      const hasChar = hasGuess && c < guessChars.length;
      
      ctx.save();
      
      if (hasGuess && hasChar) {
        const evals = evaluateGuess(guess, target);
        drawRoundedRect(ctx, x, y, cell, cell, 2);
        ctx.fillStyle = theme[evals[c]];
        ctx.fill();
        
        const prevChar = c > 0 ? guessChars[c - 1] : null;
        const displayChar = addTatweel(guessChars[c], c, guessChars.length, prevChar);
        ctx.fillStyle = theme.textOnColor;
        ctx.font = `bold ${fontSize}px "AlyamamaExtraBold"`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(displayChar, x + cell / 2, y + cell / 2);
      } else {
        drawRoundedRect(ctx, x, y, cell, cell, 2);
        ctx.fillStyle = theme.tile;
        ctx.fill();
        ctx.strokeStyle = r === guesses.length ? theme.borderEmpty : theme.border;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      
      ctx.restore();
    }
  }

  if (gameOver) {
    const gridCenterX = w / 2;
    const gridCenterY = gridStartY + (rows * cell + (rows - 1) * gap) / 2;
    
    ctx.save();
    ctx.translate(gridCenterX, gridCenterY);
    ctx.rotate(-3 * Math.PI / 180);
    
    if (won) {
      const messageIndex = Math.min(guesses.length - 1, winMessages.length - 1);
      const message = winMessages[messageIndex];
      
      ctx.fillStyle = theme.correct;
      ctx.globalAlpha = 0.95;
      ctx.font = `bold 48px "AlyamamaExtraBold"`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 20;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 4;
      ctx.fillText(message, 0, 0);
    } else {
      ctx.fillStyle = theme.absent;
      ctx.globalAlpha = 0.9;
      ctx.font = `bold 36px "AlyamamaExtraBold"`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 20;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 4;
      ctx.fillText(`${formatWord(target)}`, 0, 0);
    }
    
    ctx.restore();
  }

  if (!gameOver) {
    const remaining = modeConfig.maxAttempts - guesses.length;
    ctx.fillStyle = theme.borderEmpty;
    ctx.font = '18px "AlyamamaExtraBold"';
    ctx.textAlign = "center";
    ctx.fillText(`المحاولات المتبقية: ${remaining}`, w / 2, h - 25);
  }

  const stream = canvas.createPNGStream();
  stream.path = 'wordle.png';
  return stream;
};

module.exports = {
  config: {
    name: "arwordle",
    aliases: ["كلمات", "حزر"],
    version: "1.0",
    author: "YamiBotDad alu",
    countDown: 3,
    role: 0,
    description: "لعبة الكلمات العربية - حزر الكلمة",
    category: "game",
    guide: "{pn} [2-20] - ابدأ لعبة بعدد الأحرف"
  },

  onStart: async function ({ message, event, args, usersData, commandName, api }) {
    try {
      registerFont(FONT_PATH, { family: "AlyamamaExtraBold" });
      
      const sid = event.senderID;
      const length = parseInt(args[0]);

      await loadData();

      if (!length || isNaN(length) || length < 2 || length > 20) {
        return message.reply("❌ أدخل عدد الأحرف (2-20)\nمثال: wordle 5");
      }

      const availableWords = getWordsByLength(length);
      if (availableWords.length === 0) {
        return message.reply(`❌ لا توجد كلمات بطول ${length} أحرف!\nجرب: 2-5 (سهل) | 6-8 (متوسط) | 9+ (صعب)`);
      }

      if (global.wordleData.games[sid]?.a) {
        return message.reply("❌ لديك لعبة نشطة!\nأكمل اللعبة أو انتظر 5 دقائق");
      }

      const target = pickWord(length);
      if (!target) return message.reply("❌ خطأ في اختيار الكلمة!");

      const mode = getModeByLength(length);
      const modeConfig = modes[mode];

      const gd = {
        target,
        guesses: [],
        mode,
        gameOver: false,
        won: false,
        a: true,
        darkMode: true,
        tid: event.threadID,
        pid: sid,
        startTime: Date.now()
      };

      global.wordleData.games[sid] = gd;
      await saveData();

      const timeoutId = setTimeout(async () => {
        await loadData();
        const g = global.wordleData.games[sid];
        if (g && g.a && g.target === target) {
          delete global.wordleData.games[sid];
          await saveData();
        }
      }, 300000*3);
      
      gd.timeoutId = timeoutId;
      await saveData();

      const img = await drawBoard(gd);
      const pn = await getName(sid, usersData);
      
      const { messageID } = await message.reply({ 
        body: `🎮 لعبة جديدة!\n👤 ${pn}\n📊 ${modeConfig.label}\n🔤 ${length} أحرف\n🎯 ${modeConfig.maxAttempts} محاولات\n\n💡 أرسل كلمتك للتخمين`, 
        attachment: img 
      });

      global.GoatBot.onReply.set(messageID, {
        commandName,
        messageID,
        author: sid,
        target: gd.target,
        mode: gd.mode
      });

    } catch (err) {
      console.error("Wordle Start:", err);
      message.reply("❌ خطأ في بدء اللعبة");
    }
  },

  onReply: async function ({ message, Reply, event, usersData, api, commandName }) {
    try {
      registerFont(FONT_PATH, { family: "AlyamamaExtraBold" });

      const { author, target, mode } = Reply;
      const sid = event.senderID;

      if (sid !== author) return;

      await loadData();
      const gd = global.wordleData.games[sid];

      if (!gd || !gd.a) return message.reply("❌ اللعبة منتهية أو غير موجودة!");

      const guess = event.body.trim();
      const guessChars = [...guess];
      const targetChars = [...target];

      if (guessChars.length !== targetChars.length) {
        return message.reply(`❌ الكلمة يجب أن تكون ${targetChars.length} أحرف!`);
      }

      gd.guesses.push(guess);
      await saveData();

      const won = checkWin(guess, target);
      const lost = checkLose(gd.guesses, modes[mode].maxAttempts);

      if (won) {
        gd.a = false;
        gd.gameOver = true;
        gd.won = true;
        
        // Clear the timeout
        if (gd.timeoutId) {
          clearTimeout(gd.timeoutId);
        }
        
        await saveData();

        const wr = 500;
        await usersData.addMoney(sid, wr);
        
        const img = await drawBoard(gd);
        delete global.wordleData.games[sid];
        await saveData();
        
        return message.reply({ 
          body: `🎉 فزت في ${gd.guesses.length} محاولة!\n💰 جائزة: ${wr}$`, 
          attachment: img 
        });
      } else if (lost) {
        gd.a = false;
        gd.gameOver = true;
        gd.won = false;
        
        // Clear the timeout
        if (gd.timeoutId) {
          clearTimeout(gd.timeoutId);
        }
        
        await saveData();

        const img = await drawBoard(gd);
        delete global.wordleData.games[sid];
        await saveData();
        
        return message.reply({ 
          body: `😔 خسرت!\n📖 الكلمة: ${target}`, 
          attachment: img 
        });
      } else {
        const img = await drawBoard(gd);
        const remaining = modes[mode].maxAttempts - gd.guesses.length;
        
        const { messageID } = await message.reply({ 
          body: `⏳ حاول مرة أخرى!\n🔢 محاولات متبقية: ${remaining}\n\n💡 أرسل كلمتك`, 
          attachment: img 
        });

        global.GoatBot.onReply.set(messageID, {
          commandName,
          messageID,
          author: sid,
          target: gd.target,
          mode: gd.mode
        });
      }

    } catch (err) {
      console.error("Wordle Reply:", err);
      message.reply("❌ خطأ في معالجة التخمين");
    }
  }
};

async function loadData() {
  try {
    await fs.ensureDir(path.dirname(DATA_PATH));
    if (await fs.pathExists(DATA_PATH)) {
      const data = await fs.readJson(DATA_PATH);
      global.wordleData = data;
    } else {
      global.wordleData = { games: {} };
    }
  } catch (err) {
    global.wordleData = { games: {} };
  }
}

async function saveData() {
  try {
    await fs.ensureDir(path.dirname(DATA_PATH));
    await fs.writeJson(DATA_PATH, global.wordleData);
  } catch (err) {
    console.error("Save data error:", err);
  }
}

async function getName(uid, u) {
  try {
    const ud = await u.get(uid);
    return ud.name || "Unknown";
  } catch {
    return "Unknown";
  }
}
