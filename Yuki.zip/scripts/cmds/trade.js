module.exports = {
    config: {
        name: "تداول",
        aliases: ["trade", "استثمار", "invest"],
        version: "1.0",
        author: "AllouMohamed",
        countDown: 5,
        role: 0,
        description: {
            ar: "قم بتداول العملات الافتراضية مع احتمالية الربح أو الخسارة",
            en: "Trade virtual currencies with a chance of profit or loss"
        },
        category: "economy",
        guide: {
            ar: "{pn} <المبلغ> - استثمر مبلغًا معينًا في التداول",
            en: "{pn} <amount> - Invest a certain amount in trading"
        },
        ar: true
    },

    langs: {
        ar: {
            invalidAmount: "❌ المبلغ غير صالح! يجب أن يكون رقمًا أكبر من 0.",
            notEnoughMoney: "❌ لا تملك ما يكفي من المال لإتمام الصفقة!",
            tradeResult: "📊 نتيجة التداول: %1\n💰 رصيدك الجديد: %2 دينار",
            winBig: "🎉 ربح كبير! ×2.5",
            winSmall: "💵 ربح متوسط! ×1.5",
            draw: "⚖️ تعادل! لم تخسر شيئًا",
            loseSmall: "😓 خسرت 50% من المبلغ!",
            bankrupt: "💀 إفلاس! خسرت كل شيء!"
        },
        en: {
            invalidAmount: "❌ Invalid amount! It must be a number greater than 0.",
            notEnoughMoney: "❌ You don't have enough money to complete the trade!",
            tradeResult: "📊 Trade result: %1\n💰 Your new balance: %2 coins",
            winBig: "🎉 Huge win! ×2.5",
            winSmall: "💵 Moderate win! ×1.5",
            draw: "⚖️ Draw! You didn't lose anything",
            loseSmall: "😓 You lost 50% of the amount!",
            bankrupt: "💀 Bankrupt! You lost everything!"
        }
    },

    formatMoney: function (num) {
        if (num >= Number.MAX_SAFE_INTEGER) return "∞"; 
        const units = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"];
        let unitIndex = 0;
        while (num >= 1000 && unitIndex < units.length - 1) {
            num /= 1000;
            unitIndex++;
        }
        return num.toFixed(2) + units[unitIndex];
    },

    onStart: async function ({ message, usersData, event, args, getLang }) {
        let amount = parseInt(args[0]);

        if (isNaN(amount) || amount <= 0) {
            return message.reply(getLang("invalidAmount"));
        }

        const userData = await usersData.get(event.senderID) || { money: 0 };

        if (userData.money < amount) {
            return message.reply(getLang("notEnoughMoney"));
        }

        const outcomes = [
            { text: getLang("winBig"), multiplier: 2.5, chance: 10 },
            { text: getLang("winSmall"), multiplier: 1.5, chance: 20 },
            { text: getLang("draw"), multiplier: 1.0, chance: 30 },
            { text: getLang("loseSmall"), multiplier: 0.5, chance: 25 },
            { text: getLang("bankrupt"), multiplier: 0, chance: 15 }
        ];

        let tempValue = Math.random() * 100;
        let chosenOutcome = outcomes.find(outcome => (tempValue -= outcome.chance) < 0);

        const newBalance = Math.floor(userData.money - amount + (amount * chosenOutcome.multiplier));
        await usersData.set(event.senderID, newBalance, "money");

        return message.reply(getLang("tradeResult", chosenOutcome.text, this.formatMoney(newBalance)));
    }
};
