const moment = require('moment');
const { createCanvas, loadImage } = require('canvas');

function generateTransactionID() {
    const timestamp = Date.now().toString(36);
    const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `IKYU-${timestamp}-${randomPart}`;
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function calculateInterest(principal, rate, timeInDays) {
    if (!principal || principal <= 0 || timeInDays <= 0) return 0;
    const dailyRate = rate / 100;
    const compoundInterest = Math.floor(principal * Math.pow(1 + dailyRate, timeInDays) - principal);
    return Math.max(0, compoundInterest);
}

function calculateLoanPenalty(loanAmount, daysOverdue) {
    if (daysOverdue <= 0) return 0;
    const penaltyRate = 0.05;
    return Math.floor(loanAmount * penaltyRate * daysOverdue);
}

const BANK_CONFIG = {
    INTEREST_RATE: 2.5,
    MIN_DEPOSIT: 100,
    MIN_WITHDRAWAL: 50,
    MAX_LOAN_RATIO: 0.8,
    LOAN_INTEREST_RATE: 5,
    LOAN_DURATION_DAYS: 7,
    MAX_HISTORY_ENTRIES: 15,
    WORK_COOLDOWN: 3600000,
    DAILY_BONUS_COOLDOWN: 86400000,
    CRIME_COOLDOWN: 7200000,
    SLOT_BET_MIN: 100,
    SLOT_BET_MAX: 10000,
    ACCOUNT_LEVELS: {
        BRONZE: { min: 0, max: 50000, bonus: 1.0 },
        SILVER: { min: 50001, max: 200000, bonus: 1.2 },
        GOLD: { min: 200001, max: 500000, bonus: 1.5 },
        PLATINUM: { min: 500001, max: Infinity, bonus: 2.0 }
    },
    STOCKS: {
        AAPL: { name: 'Apple Inc.', basePrice: 150, volatility: 0.05 },
        GOOGL: { name: 'Alphabet Inc.', basePrice: 120, volatility: 0.06 },
        TSLA: { name: 'Tesla Inc.', basePrice: 200, volatility: 0.12 },
        AMZN: { name: 'Amazon.com Inc.', basePrice: 130, volatility: 0.07 },
        MSFT: { name: 'Microsoft Corp.', basePrice: 300, volatility: 0.04 },
        META: { name: 'Meta Platforms', basePrice: 280, volatility: 0.08 },
        NVDA: { name: 'NVIDIA Corp.', basePrice: 400, volatility: 0.10 }
    }
};

const WORK_JOBS = [
    { name: 'مبرمج', min: 500, max: 1500, nameEn: 'Programmer' },
    { name: 'طبيب', min: 800, max: 2000, nameEn: 'Doctor' },
    { name: 'مهندس', min: 600, max: 1800, nameEn: 'Engineer' },
    { name: 'معلم', min: 400, max: 1200, nameEn: 'Teacher' },
    { name: 'طباخ', min: 300, max: 1000, nameEn: 'Chef' },
    { name: 'سائق', min: 250, max: 800, nameEn: 'Driver' },
    { name: 'فنان', min: 350, max: 1100, nameEn: 'Artist' },
    { name: 'موسيقي', min: 400, max: 1300, nameEn: 'Musician' }
];

const CRIME_SCENARIOS = [
    { 
        name: 'سرقة بنك', 
        success: 0.3, 
        reward: { min: 5000, max: 15000 }, 
        penalty: { min: 3000, max: 8000 },
        nameEn: 'Bank Robbery'
    },
    { 
        name: 'سرقة سيارة', 
        success: 0.5, 
        reward: { min: 2000, max: 8000 }, 
        penalty: { min: 1500, max: 5000 },
        nameEn: 'Car Theft'
    },
    { 
        name: 'اختراق نظام', 
        success: 0.4, 
        reward: { min: 3000, max: 10000 }, 
        penalty: { min: 2000, max: 6000 },
        nameEn: 'System Hacking'
    },
    { 
        name: 'سطو على متجر', 
        success: 0.6, 
        reward: { min: 1000, max: 5000 }, 
        penalty: { min: 800, max: 3000 },
        nameEn: 'Store Robbery'
    }
];

exports.config = {
    name: "bank",
    aliases: ["تخزين", "بنك", "banking"],
    by: "Allou Mohamed - Enhanced v4.0 Visual",
    version: "4.0.2",
    countDown: 5,
    role: 0,
    category: "Economy",
    guide: {
        usage: "Required",
        params: "amount, @user",
        syntax:
            "bank view | bank deposit [amount] | bank withdraw [amount]\n" +
            "bank loan [amount] | bank repay [amount] | bank history\n" +
            "bank leaderboard | bank transfer [amount] [@user]\n" +
            "bank work | bank daily | bank crime | bank slots [bet]\n" +
            "bank portfolio | bank stocks | bank buy [symbol] [shares]\n" +
            "bank sell [symbol] [shares] | bank card [theme]"
    }
};

exports.onStart = async (params) => {
    const { args, message, event, usersData } = params;
    const action = args[0]?.toLowerCase();

    try {
        await initializeBankData(event.senderID, usersData);

        switch (action) {
            case 'deposit':
            case 'إيداع':
                await handleDeposit(params);
                break;
            case 'withdraw':
            case 'سحب':
                await handleWithdraw(params);
                break;
            case 'info':
            case 'عرض':
            case 'balance':
            case 'view':
                await showAccountInfo(params);
                break;
            case 'loan':
            case 'قرض':
                await handleLoan(params);
                break;
            case 'repay':
            case 'سداد':
                await handleLoanRepayment(params);
                break;
            case 'history':
            case 'تاريخ':
                await showTransactionHistory(params);
                break;
            case 'leaderboard':
            case 'الأغنى':
            case 'top':
                await showLeaderboard(params);
                break;
            case 'transfer':
            case 'تحويل':
                await handleTransfer(params);
                break;
            case 'work':
            case 'عمل':
                await handleWork(params);
                break;
            case 'daily':
            case 'يومي':
                await handleDaily(params);
                break;
            case 'crime':
            case 'جريمة':
                await handleCrime(params);
                break;
            case 'slots':
            case 'سلوت':
                await handleSlots(params);
                break;
            case 'portfolio':
            case 'محفظة':
                await showPortfolio(params);
                break;
            case 'stocks':
            case 'أسهم':
                await showStocks(params);
                break;
            case 'buy':
            case 'شراء':
                await handleBuyStock(params);
                break;
            case 'sell':
            case 'بيع':
                await handleSellStock(params);
                break;
            case 'card':
            case 'بطاقة':
                await handleCard(params);
                break;
            case 'help':
            case 'مساعدة':
                await showHelp(params);
                break;
            default:
                await showAccountInfo(params);
                break;
        }
    } catch (error) {
        console.error('Bank system error:', error);
        return message.reply("حدث خطأ في النظام البنكي. حاول مرة أخرى.");
    }
};

exports.onReply = async ({ commandName, message, api, usersData, role, args, event, Reply }) => {
    const { author, timestamp } = Reply;
    if (author !== event.senderID) return;

    if (Date.now() - timestamp > 180000) {
        return message.reply("انتهت صلاحية هذه الرسالة. حاول مجددًا.");
    }

    try {
        const userMoney = await usersData.getMoney(event.senderID);
        const bankData = await getBankData(event.senderID, usersData);
        const replyText = event.body?.toLowerCase().trim();

        switch (Reply?.action) {
            case 'depositAll':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeDepositAll(event.senderID, userMoney, bankData, usersData, message);
                } else {
                    return message.reply("تم إلغاء العملية.");
                }
                break;
            case 'withdrawAll':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeWithdrawAll(event.senderID, bankData, usersData, message);
                } else {
                    return message.reply("تم إلغاء العملية.");
                }
                break;
            case 'confirmLoan':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeLoan(event.senderID, Reply.amount, bankData, usersData, message);
                } else {
                    return message.reply("تم إلغاء طلب القرض.");
                }
                break;
            case 'confirmBuy':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeBuyStock(event.senderID, Reply.symbol, Reply.shares, Reply.price, bankData, usersData, message);
                } else {
                    return message.reply("تم إلغاء عملية الشراء.");
                }
                break;
            case 'confirmSell':
                if (replyText === 'نعم' || replyText === 'yes') {
                    await executeSellStock(event.senderID, Reply.symbol, Reply.shares, Reply.price, bankData, usersData, message);
                } else {
                    return message.reply("تم إلغاء عملية البيع.");
                }
                break;
        }
    } catch (error) {
        console.error('Bank reply error:', error);
        return message.reply("حدث خطأ أثناء معالجة الرد.");
    }
};

async function initializeBankData(userID, usersData) {
    const bankData = await usersData.get(userID, "bank");
    if (!bankData || !bankData.loan) {
        const initialData = {
            balance: 0,
            loan: {
                amount: 0,
                dueDate: null,
                interestRate: BANK_CONFIG.LOAN_INTEREST_RATE
            },
            lastInterestCalculation: null,
            history: [],
            accountLevel: 'BRONZE',
            totalEarned: 0,
            totalDeposited: 0,
            totalWithdrawn: 0,
            lastWork: 0,
            lastDaily: 0,
            lastCrime: 0,
            workStreak: 0,
            dailyStreak: 0,
            portfolio: {},
            totalInvested: 0,
            totalProfit: 0,
            createdAt: Date.now()
        };
        await usersData.set(userID, initialData, "bank");
    }
}

async function getBankData(userID, usersData) {
    await initializeBankData(userID, usersData);
    return await usersData.get(userID, "bank");
}

function getAccountLevel(balance) {
    for (const [level, config] of Object.entries(BANK_CONFIG.ACCOUNT_LEVELS)) {
        if (balance >= config.min && balance <= config.max) {
            return level;
        }
    }
    return 'BRONZE';
}

function addTransactionToHistory(bankData, type, amount, details = '') {
    const transaction = {
        type,
        amount,
        details,
        date: moment().format('HH:mm:ss DD/MM/YYYY'),
        id: generateTransactionID()
    };
    
    bankData.history.unshift(transaction);
    if (bankData.history.length > BANK_CONFIG.MAX_HISTORY_ENTRIES) {
        bankData.history = bankData.history.slice(0, BANK_CONFIG.MAX_HISTORY_ENTRIES);
    }
}

async function handleDeposit({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const userMoney = await usersData.getMoney(event.senderID);
    const bankData = await getBankData(event.senderID, usersData);

    if (!amount || amount < BANK_CONFIG.MIN_DEPOSIT) {
        const { messageID } = await message.reply(
            `الحد الأدنى للإيداع هو ${formatNumber(BANK_CONFIG.MIN_DEPOSIT)}\n` +
            `رصيدك الحالي: ${formatNumber(userMoney)}\n` +
            `للقيام بإيداع كل رصيدك، رد بـ 'نعم'`
        );
        
        const Reply = {
            commandName: 'bank',
            action: "depositAll",
            author: event.senderID,
            timestamp: Date.now()
        };
        global.YamiBot.onReply.set(messageID, Reply);
        return;
    }

    if (amount > userMoney) {
        return message.reply(`رصيدك غير كافي!\nرصيدك الحالي: ${formatNumber(userMoney)}`);
    }

    await executeDeposit(event.senderID, amount, bankData, usersData, message);
}

async function executeDeposit(userID, amount, bankData, usersData, message) {
    await usersData.subtractMoney(userID, amount);
    bankData.balance += amount;
    bankData.totalDeposited += amount;
    
    if (!bankData.lastInterestCalculation) {
        bankData.lastInterestCalculation = Date.now();
    }
    
    const newLevel = getAccountLevel(bankData.balance);
    const levelChanged = newLevel !== bankData.accountLevel;
    bankData.accountLevel = newLevel;
    
    addTransactionToHistory(bankData, 'إيداع', amount, `إيداع مبلغ ${formatNumber(amount)}`);
    
    await usersData.set(userID, bankData, "bank");
    
    const canvas = await drawDepositReceipt(amount, bankData, await usersData.getMoney(userID), levelChanged);
    const stream = canvas.createPNGStream();
    stream.path = 'deposit_receipt.png';
    
    return message.send({
        body: levelChanged ? `تهانينا! تم ترقية حسابك إلى مستوى ${newLevel}!` : '',
        attachment: stream
    });
}

async function executeDepositAll(userID, amount, bankData, usersData, message) {
    if (amount < BANK_CONFIG.MIN_DEPOSIT) {
        return message.reply(`يجب أن يكون لديك على الأقل ${formatNumber(BANK_CONFIG.MIN_DEPOSIT)} لإيداع كل الرصيد.`);
    }
    
    await executeDeposit(userID, amount, bankData, usersData, message);
}

async function handleWithdraw({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const bankData = await getBankData(event.senderID, usersData);

    if (!amount || amount < BANK_CONFIG.MIN_WITHDRAWAL) {
        const { messageID } = await message.reply(
            `الحد الأدنى للسحب هو ${formatNumber(BANK_CONFIG.MIN_WITHDRAWAL)}\n` +
            `رصيدك البنكي: ${formatNumber(bankData.balance)}\n` +
            `لسحب كل رصيدك البنكي، رد بـ 'نعم'`
        );
        
        const Reply = {
            commandName: 'bank',
            action: "withdrawAll",
            author: event.senderID,
            timestamp: Date.now()
        };
        global.YamiBot.onReply.set(messageID, Reply);
        return;
    }

    if (amount > bankData.balance) {
        return message.reply(`رصيدك البنكي غير كافي!\nرصيدك البنكي: ${formatNumber(bankData.balance)}`);
    }

    await executeWithdraw(event.senderID, amount, bankData, usersData, message);
}

async function executeWithdraw(userID, amount, bankData, usersData, message) {
    const interest = calculateAccumulatedInterest(bankData);
    
    await usersData.addMoney(userID, amount + interest);
    bankData.balance -= amount;
    bankData.totalWithdrawn += amount;
    bankData.totalEarned += interest;
    bankData.lastInterestCalculation = Date.now();
    
    addTransactionToHistory(bankData, 'سحب', amount, `سحب مبلغ ${formatNumber(amount)} + فوائد ${formatNumber(interest)}`);
    
    await usersData.set(userID, bankData, "bank");
    
    const canvas = await drawWithdrawReceipt(amount, interest, bankData, await usersData.getMoney(userID));
    const stream = canvas.createPNGStream();
    stream.path = 'withdraw_receipt.png';
    
    return message.send({
        attachment: stream
    });
}

async function executeWithdrawAll(userID, bankData, usersData, message) {
    if (bankData.balance <= 0) {
        return message.reply("لا يوجد رصيد للسحب!");
    }
    
    await executeWithdraw(userID, bankData.balance, bankData, usersData, message);
}

function calculateAccumulatedInterest(bankData) {
    if (!bankData.lastInterestCalculation || bankData.balance <= 0) return 0;
    
    const daysSinceLastCalculation = moment().diff(moment(bankData.lastInterestCalculation), 'days', true);
    const levelBonus = BANK_CONFIG.ACCOUNT_LEVELS[bankData.accountLevel]?.bonus || 1.0;
    const effectiveRate = BANK_CONFIG.INTEREST_RATE * levelBonus;
    
    return calculateInterest(bankData.balance, effectiveRate, daysSinceLastCalculation);
}

async function handleTransfer({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const targetUserMention = args[2];
    
    if (!amount || amount <= 0) {
        return message.reply("أدخل مبلغ التحويل\nمثال: بنك تحويل 1000 @المستخدم");
    }
    
    if (!targetUserMention || !targetUserMention.includes('@')) {
        return message.reply("قم بمنشن المستخدم المراد التحويل إليه\nمثال: بنك تحويل 1000 @المستخدم");
    }
    
    const targetUserID = targetUserMention.replace('@', '');
    
    if (targetUserID === event.senderID) {
        return message.reply("لا يمكنك تحويل المال لنفسك!");
    }
    
    const senderBankData = await getBankData(event.senderID, usersData);
    const transferFee = Math.max(100, Math.floor(amount * 0.02));
    const totalDeduction = amount + transferFee;
    
    if (senderBankData.balance < totalDeduction) {
        return message.reply(
            `رصيدك البنكي غير كافي!\n` +
            `مبلغ التحويل: ${formatNumber(amount)}\n` +
            `رسوم التحويل: ${formatNumber(transferFee)}\n` +
            `المطلوب: ${formatNumber(totalDeduction)}\n` +
            `رصيدك البنكي: ${formatNumber(senderBankData.balance)}`
        );
    }
    
    try {
        const targetBankData = await getBankData(targetUserID, usersData);
        const senderData = await usersData.get(event.senderID);
        const targetData = await usersData.get(targetUserID);
        
        senderBankData.balance -= totalDeduction;
        targetBankData.balance += amount;
        
        addTransactionToHistory(senderBankData, 'تحويل صادر', totalDeduction, `تحويل ${formatNumber(amount)} + رسوم ${formatNumber(transferFee)}`);
        addTransactionToHistory(targetBankData, 'تحويل وارد', amount, `استلام تحويل ${formatNumber(amount)}`);
        
        await usersData.set(event.senderID, senderBankData, "bank");
        await usersData.set(targetUserID, targetBankData, "bank");
        
        const canvas = await drawTransferReceipt(
            amount, 
            transferFee, 
            senderData.name || 'User', 
            targetData.name || 'User',
            senderBankData.balance
        );
        const stream = canvas.createPNGStream();
        stream.path = 'transfer_receipt.png';
        
        return message.send({
            attachment: stream
        });
        
    } catch (error) {
        return message.reply("المستخدم المحدد غير موجود أو لم يفعل النظام البنكي بعد.");
    }
}

async function showAccountInfo({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    const userMoney = await usersData.getMoney(event.senderID);
    const userData = await usersData.get(event.senderID);
    const interest = calculateAccumulatedInterest(bankData);
    
    let portfolioValue = 0;
    if (bankData.portfolio) {
        for (const [symbol, holding] of Object.entries(bankData.portfolio)) {
            const currentPrice = getStockPrice(symbol);
            portfolioValue += holding.shares * currentPrice;
        }
    }
    
    let loanInfo = null;
    if (bankData?.loan?.amount > 0) {
        const daysOverdue = moment().diff(moment(bankData.loan.dueDate), 'days');
        const penalty = calculateLoanPenalty(bankData.loan.amount, Math.max(0, daysOverdue));
        const totalOwed = bankData.loan.amount + penalty;
        
        loanInfo = {
            amount: totalOwed,
            daysOverdue: Math.max(0, daysOverdue),
            penalty: penalty
        };
    }
    
    const levelBonus = BANK_CONFIG.ACCOUNT_LEVELS[bankData.accountLevel]?.bonus || 1.0;
    const effectiveRate = BANK_CONFIG.INTEREST_RATE * levelBonus;
    const totalWealth = bankData.balance + userMoney + portfolioValue;
    
    const canvas = await drawAccountInfoCard(
        userData.name || 'YamiBank User',
        bankData.balance,
        userMoney,
        portfolioValue,
        totalWealth,
        interest,
        effectiveRate,
        bankData.accountLevel,
        loanInfo,
        bankData
    );
    
    const stream = canvas.createPNGStream();
    stream.path = 'account_info.png';
    
    return message.send({
        body: 'معلومات حسابك البنكي',
        attachment: stream
    });
}

async function showTransactionHistory({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    
    if (!bankData.history || bankData.history.length === 0) {
        return message.reply("لا توجد معاملات سابقة في حسابك البنكي.");
    }
    
    const canvas = await drawTransactionHistory(bankData.history.slice(0, 10));
    const stream = canvas.createPNGStream();
    stream.path = 'transaction_history.png';
    
    return message.send({
        body: 'سجل المعاملات البنكية',
        attachment: stream
    });
}

async function handleLoan({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const bankData = await getBankData(event.senderID, usersData);
    
    if (bankData?.loan?.amount > 0) {
        const daysOverdue = moment().diff(moment(bankData.loan.dueDate), 'days');
        const penalty = calculateLoanPenalty(bankData.loan.amount, Math.max(0, daysOverdue));
        const totalOwed = bankData.loan.amount + penalty;
        
        return message.reply(
            `لديك قرض مستحق بالفعل!\n` +
            `مبلغ القرض: ${formatNumber(bankData.loan.amount)}\n` +
            `الغرامة: ${formatNumber(penalty)}\n` +
            `المبلغ الإجمالي: ${formatNumber(totalOwed)}\n` +
            `تاريخ الاستحقاق: ${moment(bankData.loan.dueDate).format('DD/MM/YYYY')}\n` +
            `استخدم "بنك سداد ${totalOwed}" لسداد القرض`
        );
    }
    
    const maxLoanAmount = Math.floor(bankData.balance * BANK_CONFIG.MAX_LOAN_RATIO);
    
    if (!amount || amount <= 0) {
        return message.reply(
            `أدخل مبلغ القرض المطلوب\n` +
            `الحد الأقصى للقرض: ${formatNumber(maxLoanAmount)}\n` +
            `معدل الفائدة: ${BANK_CONFIG.LOAN_INTEREST_RATE}% يومياً\n` +
            `مدة السداد: ${BANK_CONFIG.LOAN_DURATION_DAYS} أيام`
        );
    }
    
    if (amount > maxLoanAmount) {
        return message.reply(
            `لا يمكنك اقتراض أكثر من ${formatNumber(maxLoanAmount)}\n` +
            `قم بزيادة رصيدك البنكي للحصول على قروض أكبر`
        );
    }
    
    const interestAmount = Math.floor(amount * (BANK_CONFIG.LOAN_INTEREST_RATE / 100) * BANK_CONFIG.LOAN_DURATION_DAYS);
    const totalRepayment = amount + interestAmount;
    const dueDate = moment().add(BANK_CONFIG.LOAN_DURATION_DAYS, 'days');
    
    const { messageID } = await message.reply(
        `تفاصيل القرض:\n` +
        `مبلغ القرض: ${formatNumber(amount)}\n` +
        `الفوائد: ${formatNumber(interestAmount)}\n` +
        `إجمالي السداد: ${formatNumber(totalRepayment)}\n` +
        `تاريخ الاستحقاق: ${dueDate.format('DD/MM/YYYY HH:mm')}\n` +
        `غرامة التأخير: 5% يومياً\n\n` +
        `هل توافق على شروط القرض؟ رد بـ 'نعم' للموافقة`
    );
    
    const Reply = {
        commandName: 'bank',
        action: "confirmLoan",
        amount: amount,
        author: event.senderID,
        timestamp: Date.now()
    };
    global.YamiBot.onReply.set(messageID, Reply);
}

async function executeLoan(userID, amount, bankData, usersData, message) {
    const dueDate = moment().add(BANK_CONFIG.LOAN_DURATION_DAYS, 'days');
    
    await usersData.addMoney(userID, amount);
    
    bankData.loan = {
        amount: amount,
        originalAmount: amount,
        dueDate: dueDate.toISOString(),
        interestRate: BANK_CONFIG.LOAN_INTEREST_RATE,
        takenAt: Date.now()
    };
    
    addTransactionToHistory(bankData, 'قرض', amount, `قرض بمبلغ ${formatNumber(amount)} - استحقاق ${dueDate.format('DD/MM/YYYY')}`);
    
    await usersData.set(userID, bankData, "bank");
    
    const canvas = await drawLoanReceipt(amount, dueDate, await usersData.getMoney(userID));
    const stream = canvas.createPNGStream();
    stream.path = 'loan_receipt.png';
    
    return message.send({
        body: 'تذكر: غرامة 5% يومياً عند التأخير!',
        attachment: stream
    });
}

async function handleLoanRepayment({ args, message, usersData, event }) {
    const amount = parseInt(args[1]) || 0;
    const bankData = await getBankData(event.senderID, usersData);
    const userMoney = await usersData.getMoney(event.senderID);
    
    if (bankData?.loan?.amount <= 0) {
        return message.reply("ليس لديك أي قروض مستحقة!");
    }
    
    const daysOverdue = moment().diff(moment(bankData.loan.dueDate), 'days');
    const penalty = calculateLoanPenalty(bankData.loan.amount, Math.max(0, daysOverdue));
    const totalOwed = bankData.loan.amount + penalty;
    
    if (!amount || amount <= 0) {
        return message.reply(
            `أدخل مبلغ السداد\n` +
            `مبلغ القرض الأصلي: ${formatNumber(bankData.loan.amount)}\n` +
            `الغرامة: ${formatNumber(penalty)}\n` +
            `المبلغ الإجمالي المطلوب: ${formatNumber(totalOwed)}\n` +
            `رصيدك الحالي: ${formatNumber(userMoney)}`
        );
    }
    
    if (amount > userMoney) {
        return message.reply(`رصيدك غير كافي للسداد!\nرصيدك الحالي: ${formatNumber(userMoney)}`);
    }
    
    await usersData.subtractMoney(event.senderID, amount);
    
    const remainingDebt = Math.max(0, totalOwed - amount);
    
    if (remainingDebt <= 0) {
        const overpayment = amount - totalOwed;
        if (overpayment > 0) {
            await usersData.addMoney(event.senderID, overpayment);
        }
        
        bankData.loan = { amount: 0, dueDate: null, interestRate: 0 };
        addTransactionToHistory(bankData, 'سداد', totalOwed, `سداد كامل للقرض + غرامة ${formatNumber(penalty)}`);
        
        await usersData.set(event.senderID, bankData, "bank");
        
        const canvas = await drawRepaymentReceipt(totalOwed, 0, true, await usersData.getMoney(event.senderID));
        const stream = canvas.createPNGStream();
        stream.path = 'repayment_receipt.png';
        
        return message.send({
            body: overpayment > 0 ? `المبلغ الإضافي المسترد: ${formatNumber(overpayment)}` : 'تم سداد القرض بالكامل!',
            attachment: stream
        });
    } else {
        bankData.loan.amount = remainingDebt;
        addTransactionToHistory(bankData, 'سداد جزئي', amount, `سداد جزئي - متبقي ${formatNumber(remainingDebt)}`);
        
        await usersData.set(event.senderID, bankData, "bank");
        
        const canvas = await drawRepaymentReceipt(amount, remainingDebt, false, await usersData.getMoney(event.senderID));
        const stream = canvas.createPNGStream();
        stream.path = 'repayment_receipt.png';
        
        return message.send({
            attachment: stream
        });
    }
}

async function handleWork({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    const now = Date.now();
    
    if (bankData.lastWork && (now - bankData.lastWork) < BANK_CONFIG.WORK_COOLDOWN) {
        const timeLeft = BANK_CONFIG.WORK_COOLDOWN - (now - bankData.lastWork);
        const minutesLeft = Math.ceil(timeLeft / 60000);
        return message.reply(
            `يجب الانتظار ${minutesLeft} دقيقة قبل العمل مرة أخرى!\n` +
            `جرب أوامر أخرى: بنك يومي، بنك سلوت، بنك أسهم`
        );
    }
    
    const job = WORK_JOBS[Math.floor(Math.random() * WORK_JOBS.length)];
    const earnings = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;
    
    const streakBonus = Math.floor(earnings * (bankData.workStreak || 0) * 0.05);
    const totalEarnings = earnings + streakBonus;
    
    await usersData.addMoney(event.senderID, totalEarnings);
    
    bankData.lastWork = now;
    const lastWorkDate = bankData.lastWork ? moment(bankData.lastWork) : null;
    const isNextDay = lastWorkDate && moment().diff(lastWorkDate, 'days') === 1;
    
    if (isNextDay) {
        bankData.workStreak = (bankData.workStreak || 0) + 1;
    } else if (!lastWorkDate || moment().diff(lastWorkDate, 'days') > 1) {
        bankData.workStreak = 1;
    }
    
    bankData.totalEarned += totalEarnings;
    addTransactionToHistory(bankData, 'عمل', totalEarnings, `عملت كـ${job.name}`);
    
    await usersData.set(event.senderID, bankData, "bank");
    
    const canvas = await drawWorkReceipt(job.nameEn, earnings, streakBonus, totalEarnings, bankData.workStreak, await usersData.getMoney(event.senderID));
    const stream = canvas.createPNGStream();
    stream.path = 'work_receipt.png';
    
    return message.send({
        attachment: stream
    });
}

async function handleDaily({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    const now = Date.now();
    
    if (bankData.lastDaily && (now - bankData.lastDaily) < BANK_CONFIG.DAILY_BONUS_COOLDOWN) {
        const timeLeft = BANK_CONFIG.DAILY_BONUS_COOLDOWN - (now - bankData.lastDaily);
        const hoursLeft = Math.ceil(timeLeft / 3600000);
        return message.reply(
            `يمكنك الحصول على المكافأة اليومية بعد ${hoursLeft} ساعة!\n` +
            `جرب: بنك عمل، بنك جريمة، بنك سلوت`
        );
    }
    
    const baseReward = 1000;
    const streakBonus = (bankData.dailyStreak || 0) * 200;
    const levelBonus = Math.floor(baseReward * (BANK_CONFIG.ACCOUNT_LEVELS[bankData.accountLevel]?.bonus || 1.0));
    const totalReward = baseReward + streakBonus + levelBonus;
    
    await usersData.addMoney(event.senderID, totalReward);
    
    bankData.lastDaily = now;
    const lastDailyDate = bankData.lastDaily ? moment(bankData.lastDaily) : null;
    const isNextDay = lastDailyDate && moment().diff(lastDailyDate, 'days') === 1;
    
    if (isNextDay) {
        bankData.dailyStreak = (bankData.dailyStreak || 0) + 1;
    } else if (!lastDailyDate || moment().diff(lastDailyDate, 'days') > 1) {
        bankData.dailyStreak = 1;
    }
    
    bankData.totalEarned += totalReward;
    addTransactionToHistory(bankData, 'مكافأة يومية', totalReward, `مكافأة يومية - يوم ${bankData.dailyStreak}`);
    
    await usersData.set(event.senderID, bankData, "bank");
    
    const canvas = await drawDailyBonusReceipt(baseReward, streakBonus, levelBonus, totalReward, bankData.dailyStreak, await usersData.getMoney(event.senderID));
    const stream = canvas.createPNGStream();
    stream.path = 'daily_bonus.png';
    
    return message.send({
        attachment: stream
    });
}

async function handleCrime({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    const now = Date.now();
    
    if (bankData.lastCrime && (now - bankData.lastCrime) < BANK_CONFIG.CRIME_COOLDOWN) {
        const timeLeft = BANK_CONFIG.CRIME_COOLDOWN - (now - bankData.lastCrime);
        const minutesLeft = Math.ceil(timeLeft / 60000);
        return message.reply(
            `الشرطة تراقبك! انتظر ${minutesLeft} دقيقة\n` +
            `جرب أوامر قانونية: بنك عمل، بنك يومي`
        );
    }
    
    const crime = CRIME_SCENARIOS[Math.floor(Math.random() * CRIME_SCENARIOS.length)];
    const success = Math.random() < crime.success;
    
    if (success) {
        const earnings = Math.floor(Math.random() * (crime.reward.max - crime.reward.min + 1)) + crime.reward.min;
        await usersData.addMoney(event.senderID, earnings);
        
        bankData.lastCrime = now;
        bankData.totalEarned += earnings;
        addTransactionToHistory(bankData, 'جريمة ناجحة', earnings, crime.name);
        
        await usersData.set(event.senderID, bankData, "bank");
        
        const canvas = await drawCrimeReceipt(crime.nameEn, earnings, true, await usersData.getMoney(event.senderID));
        const stream = canvas.createPNGStream();
        stream.path = 'crime_success.png';
        
        return message.send({
            attachment: stream
        });
    } else {
        const penalty = Math.floor(Math.random() * (crime.penalty.max - crime.penalty.min + 1)) + crime.penalty.min;
        const userMoney = await usersData.getMoney(event.senderID);
        const actualPenalty = Math.min(penalty, userMoney);
        
        if (actualPenalty > 0) {
            await usersData.subtractMoney(event.senderID, actualPenalty);
        }
        
        bankData.lastCrime = now;
        addTransactionToHistory(bankData, 'جريمة فاشلة', actualPenalty, crime.name);
        
        await usersData.set(event.senderID, bankData, "bank");
        
        const canvas = await drawCrimeReceipt(crime.nameEn, actualPenalty, false, await usersData.getMoney(event.senderID));
        const stream = canvas.createPNGStream();
        stream.path = 'crime_failed.png';
        
        return message.send({
            attachment: stream
        });
    }
}

async function handleSlots({ args, message, usersData, event }) {
    const bet = parseInt(args[1]) || 0;
    const userMoney = await usersData.getMoney(event.senderID);
    
    if (!bet || bet < BANK_CONFIG.SLOT_BET_MIN) {
        return message.reply(
            `الحد الأدنى للرهان: ${formatNumber(BANK_CONFIG.SLOT_BET_MIN)}\n` +
            `الحد الأقصى: ${formatNumber(BANK_CONFIG.SLOT_BET_MAX)}\n` +
            `رصيدك: ${formatNumber(userMoney)}\n` +
            `مثال: بنك سلوت 500`
        );
    }
    
    if (bet > BANK_CONFIG.SLOT_BET_MAX) {
        return message.reply(`الحد الأقصى للرهان هو ${formatNumber(BANK_CONFIG.SLOT_BET_MAX)}!`);
    }
    
    if (bet > userMoney) {
        return message.reply(`رصيدك غير كافي!\nرصيدك: ${formatNumber(userMoney)}`);
    }
    
    const symbols = ['CHERRY', 'LEMON', 'ORANGE', 'GRAPE', 'DIAMOND', 'SEVEN'];
    const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
    const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
    const slot3 = symbols[Math.floor(Math.random() * symbols.length)];
    
    const bankData = await getBankData(event.senderID, usersData);
    let winnings = 0;
    let result = "";
    let multiplier = 0;
    
    if (slot1 === slot2 && slot2 === slot3) {
        if (slot1 === 'DIAMOND') {
            winnings = bet * 10;
            result = "JACKPOT";
            multiplier = 10;
        } else if (slot1 === 'SEVEN') {
            winnings = bet * 7;
            result = "LUCKY SEVEN";
            multiplier = 7;
        } else {
            winnings = bet * 5;
            result = "BIG WIN";
            multiplier = 5;
        }
    } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
        winnings = bet * 2;
        result = "SMALL WIN";
        multiplier = 2;
    } else {
        winnings = -bet;
        result = "LOST";
        multiplier = 0;
    }
    
    if (winnings > 0) {
        await usersData.addMoney(event.senderID, winnings);
        bankData.totalEarned += winnings;
        addTransactionToHistory(bankData, 'سلوت - فوز', winnings, result);
    } else {
        await usersData.subtractMoney(event.senderID, bet);
        addTransactionToHistory(bankData, 'سلوت - خسارة', bet, result);
    }
    
    await usersData.set(event.senderID, bankData, "bank");
    
    const canvas = await drawSlotsReceipt(slot1, slot2, slot3, bet, winnings, result, multiplier, await usersData.getMoney(event.senderID));
    const stream = canvas.createPNGStream();
    stream.path = 'slots_result.png';
    
    return message.send({
        attachment: stream
    });
}

function getStockPrice(symbol) {
    const stock = BANK_CONFIG.STOCKS[symbol];
    if (!stock) return 0;
    
    const seed = Math.floor(Date.now() / 300000);
    const random = Math.sin(seed * symbol.charCodeAt(0)) * 10000;
    const change = (random - Math.floor(random)) * 2 - 1;
    const price = stock.basePrice * (1 + change * stock.volatility);
    
    return Math.floor(price * 100) / 100;
}

function getStockChange(symbol) {
    const currentPrice = getStockPrice(symbol);
    const basePrice = BANK_CONFIG.STOCKS[symbol].basePrice;
    const change = currentPrice - basePrice;
    const changePercent = (change / basePrice) * 100;
    
    return {
        current: currentPrice,
        change: change,
        changePercent: changePercent
    };
}

async function showStocks({ message }) {
    const canvas = await drawStocksCard();
    const stream = canvas.createPNGStream();
    stream.path = 'stocks_list.png';
    
    return message.send({
        body: 'استخدم "بنك شراء [الرمز] [العدد]" للشراء\nمثال: بنك شراء AAPL 10',
        attachment: stream
    });
}

async function handleBuyStock({ args, message, usersData, event }) {
    const symbol = args[1]?.toUpperCase();
    const shares = parseInt(args[2]) || 0;
    
    if (!symbol || !BANK_CONFIG.STOCKS[symbol]) {
        return message.reply(
            `رمز السهم غير صحيح!\n` +
            `استخدم "بنك أسهم" لعرض الأسهم المتاحة`
        );
    }
    
    if (!shares || shares <= 0) {
        return message.reply(`أدخل عدد الأسهم المراد شراؤها\nمثال: بنك شراء ${symbol} 10`);
    }
    
    const bankData = await getBankData(event.senderID, usersData);
    const currentPrice = getStockPrice(symbol);
    const totalCost = Math.floor(currentPrice * shares);
    const commission = Math.floor(totalCost * 0.01);
    const totalWithCommission = totalCost + commission;
    
    if (bankData.balance < totalWithCommission) {
        return message.reply(
            `رصيدك البنكي غير كافي!\n` +
            `التكلفة: ${formatNumber(totalCost)}\n` +
            `العمولة (1%): ${formatNumber(commission)}\n` +
            `المطلوب: ${formatNumber(totalWithCommission)}\n` +
            `رصيدك: ${formatNumber(bankData.balance)}`
        );
    }
    
    const stock = BANK_CONFIG.STOCKS[symbol];
    const priceData = getStockChange(symbol);
    
    const { messageID } = await message.reply(
        `تأكيد عملية الشراء\n` +
        `السهم: ${symbol} - ${stock.name}\n` +
        `السعر الحالي: $${formatNumber(currentPrice)}\n` +
        `التغير: ${priceData.changePercent >= 0 ? '+' : ''}${priceData.changePercent.toFixed(2)}%\n` +
        `العدد: ${shares}\n` +
        `التكلفة: ${formatNumber(totalCost)}\n` +
        `العمولة: ${formatNumber(commission)}\n` +
        `المجموع: ${formatNumber(totalWithCommission)}\n\n` +
        `رد بـ 'نعم' للتأكيد`
    );
    
    const Reply = {
        commandName: 'bank',
        action: "confirmBuy",
        symbol: symbol,
        shares: shares,
        price: currentPrice,
        author: event.senderID,
        timestamp: Date.now()
    };
    global.YamiBot.onReply.set(messageID, Reply);
}

async function executeBuyStock(userID, symbol, shares, price, bankData, usersData, message) {
    const totalCost = Math.floor(price * shares);
    const commission = Math.floor(totalCost * 0.01);
    const totalWithCommission = totalCost + commission;
    
    bankData.balance -= totalWithCommission;
    
    if (!bankData.portfolio) {
        bankData.portfolio = {};
    }
    
    if (!bankData.portfolio[symbol]) {
        bankData.portfolio[symbol] = {
            shares: 0,
            avgPrice: 0,
            invested: 0
        };
    }
    
    const holding = bankData.portfolio[symbol];
    const newTotalShares = holding.shares + shares;
    const newTotalInvested = holding.invested + totalCost;
    
    holding.avgPrice = newTotalInvested / newTotalShares;
    holding.shares = newTotalShares;
    holding.invested = newTotalInvested;
    
    bankData.totalInvested = (bankData.totalInvested || 0) + totalWithCommission;
    
    addTransactionToHistory(bankData, 'شراء أسهم', totalWithCommission, `${shares} من ${symbol} @ $${formatNumber(price)}`);
    
    await usersData.set(userID, bankData, "bank");
    
    const canvas = await drawStockBuyReceipt(symbol, shares, price, totalWithCommission, bankData.balance, holding.shares);
    const stream = canvas.createPNGStream();
    stream.path = 'stock_buy.png';
    
    return message.send({
        attachment: stream
    });
}

async function handleSellStock({ args, message, usersData, event }) {
    const symbol = args[1]?.toUpperCase();
    const shares = parseInt(args[2]) || 0;
    
    if (!symbol || !BANK_CONFIG.STOCKS[symbol]) {
        return message.reply(
            `رمز السهم غير صحيح!\n` +
            `استخدم "بنك محفظة" لعرض أسهمك`
        );
    }
    
    const bankData = await getBankData(event.senderID, usersData);
    
    if (!bankData.portfolio || !bankData.portfolio[symbol]) {
        return message.reply(`ليس لديك أسهم من ${symbol}!`);
    }
    
    const holding = bankData.portfolio[symbol];
    
    if (!shares || shares <= 0) {
        return message.reply(
            `أدخل عدد الأسهم المراد بيعها\n` +
            `لديك ${holding.shares} سهم من ${symbol}\n` +
            `مثال: بنك بيع ${symbol} 10`
        );
    }
    
    if (shares > holding.shares) {
        return message.reply(
            `ليس لديك هذا العدد من الأسهم!\n` +
            `أسهمك من ${symbol}: ${holding.shares}`
        );
    }
    
    const currentPrice = getStockPrice(symbol);
    const totalRevenue = Math.floor(currentPrice * shares);
    const commission = Math.floor(totalRevenue * 0.01);
    const totalAfterCommission = totalRevenue - commission;
    
    const costBasis = Math.floor(holding.avgPrice * shares);
    const profit = totalRevenue - costBasis;
    const profitPercent = (profit / costBasis) * 100;
    
    const stock = BANK_CONFIG.STOCKS[symbol];
    
    const { messageID } = await message.reply(
        `تأكيد عملية البيع\n` +
        `السهم: ${symbol} - ${stock.name}\n` +
        `السعر الحالي: $${formatNumber(currentPrice)}\n` +
        `العدد: ${shares}\n` +
        `العائد: ${formatNumber(totalRevenue)}\n` +
        `العمولة: ${formatNumber(commission)}\n` +
        `الصافي: ${formatNumber(totalAfterCommission)}\n\n` +
        `الربح/الخسارة: ${profit >= 0 ? '+' : ''}${formatNumber(profit)} (${profitPercent >= 0 ? '+' : ''}${profitPercent.toFixed(2)}%)\n\n` +
        `رد بـ 'نعم' للتأكيد`
    );
    
    const Reply = {
        commandName: 'bank',
        action: "confirmSell",
        symbol: symbol,
        shares: shares,
        price: currentPrice,
        author: event.senderID,
        timestamp: Date.now()
    };
    global.YamiBot.onReply.set(messageID, Reply);
}

async function executeSellStock(userID, symbol, shares, price, bankData, usersData, message) {
    const totalRevenue = Math.floor(price * shares);
    const commission = Math.floor(totalRevenue * 0.01);
    const totalAfterCommission = totalRevenue - commission;
    
    const holding = bankData.portfolio[symbol];
    const costBasis = Math.floor(holding.avgPrice * shares);
    const profit = totalRevenue - costBasis;
    
    bankData.balance += totalAfterCommission;
    
    holding.shares -= shares;
    holding.invested -= costBasis;
    
    if (holding.shares === 0) {
        delete bankData.portfolio[symbol];
    }
    
    bankData.totalProfit = (bankData.totalProfit || 0) + profit;
    
    addTransactionToHistory(bankData, 'بيع أسهم', totalAfterCommission, `${shares} من ${symbol} @ $${formatNumber(price)} - ربح: ${formatNumber(profit)}`);
    
    await usersData.set(userID, bankData, "bank");
    
    const canvas = await drawStockSellReceipt(symbol, shares, price, totalAfterCommission, profit, bankData.balance);
    const stream = canvas.createPNGStream();
    stream.path = 'stock_sell.png';
    
    return message.send({
        attachment: stream
    });
}

async function showPortfolio({ message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    
    if (!bankData.portfolio || Object.keys(bankData.portfolio).length === 0) {
        return message.reply(
            `محفظتك فارغة!\n` +
            `استخدم "بنك أسهم" لعرض الأسهم المتاحة\n` +
            `ثم "بنك شراء [الرمز] [العدد]" للشراء`
        );
    }
    
    const portfolioData = [];
    let totalValue = 0;
    let totalInvested = 0;
    
    for (const [symbol, holding] of Object.entries(bankData.portfolio)) {
        const currentPrice = getStockPrice(symbol);
        const marketValue = holding.shares * currentPrice;
        const profit = marketValue - holding.invested;
        const profitPercent = (profit / holding.invested) * 100;
        
        totalValue += marketValue;
        totalInvested += holding.invested;
        
        portfolioData.push({
            symbol,
            shares: holding.shares,
            currentPrice,
            avgPrice: holding.avgPrice,
            marketValue,
            invested: holding.invested,
            profit,
            profitPercent
        });
    }
    
    const totalProfit = totalValue - totalInvested;
    const totalProfitPercent = (totalProfit / totalInvested) * 100;
    
    const canvas = await drawPortfolioCard(portfolioData, totalValue, totalInvested, totalProfit, totalProfitPercent, bankData.balance);
    const stream = canvas.createPNGStream();
    stream.path = 'portfolio.png';
    
    return message.send({
        attachment: stream
    });
}

async function showLeaderboard({ message, usersData }) {
    try {
        const allUsers = await usersData.getAll();
        const bankAccounts = [];
        
        for (const [userID, userData] of Object.entries(allUsers)) {
            if (userData.bank && userData.bank.balance > 0) {
                const interest = calculateAccumulatedInterest(userData.bank);
                let portfolioValue = 0;
                
                if (userData.bank.portfolio) {
                    for (const [symbol, holding] of Object.entries(userData.bank.portfolio)) {
                        const currentPrice = getStockPrice(symbol);
                        portfolioValue += holding.shares * currentPrice;
                    }
                }
                
                const totalWealth = userData.bank.balance + interest + portfolioValue;
                
                bankAccounts.push({
                    userID,
                    balance: userData.bank.balance,
                    wealth: totalWealth,
                    level: userData.bank.accountLevel || 'BRONZE',
                    name: userData.name || `User ${userID.slice(-4)}`
                });
            }
        }
        
        if (bankAccounts.length === 0) {
            return message.reply("لا توجد حسابات بنكية نشطة حالياً!");
        }
        
        bankAccounts.sort((a, b) => b.wealth - a.wealth);
        
        const top10 = bankAccounts.slice(0, 10);
        
        const canvas = await drawLeaderboardCard(top10);
        const stream = canvas.createPNGStream();
        stream.path = 'leaderboard.png';
        
        return message.send({
            body: 'قائمة أغنى الحسابات البنكية',
            attachment: stream
        });
        
    } catch (error) {
        console.error('Leaderboard error:', error);
        return message.reply("حدث خطأ أثناء عرض قائمة الأغنياء.");
    }
}

async function handleCard({ args, message, usersData, event }) {
    const bankData = await getBankData(event.senderID, usersData);
    const userData = await usersData.get(event.senderID);
    
    let theme = 'black';
    if (bankData.accountLevel === 'GOLD') theme = 'gold';
    if (bankData.accountLevel === 'PLATINUM') theme = 'platinum';
    
    if (args[1]) {
        const requestedTheme = args[1].toLowerCase();
        if (['black', 'gold', 'platinum'].includes(requestedTheme)) {
            theme = requestedTheme;
        }
    }
    
    const cardNumber = '4532 **** **** ' + Math.floor(1000 + Math.random() * 9000);
    const holderName = (userData.name || 'YUKI MEMBER').toUpperCase().substring(0, 20);
    
    const canvas = await drawBankCard(theme, bankData.accountLevel, bankData.balance, cardNumber, holderName);
    const stream = canvas.createPNGStream();
    stream.path = 'bank_card.png';
    
    return message.send({
        body: `بطاقتك البنكية - مستوى ${bankData.accountLevel}`,
        attachment: stream
    });
}

async function showHelp({ message }) {
    const canvas = await drawHelpCard();
    const stream = canvas.createPNGStream();
    stream.path = 'bank_help.png';
    
    return message.send({
        body: 'دليل النظام البنكي المتطور',
        attachment: stream
    });
}

//B
// Drawing Functions - Part 1

// Utility function to format large numbers with suffixes
function formatNumberWithSuffix(num) {
    const absNum = Math.abs(num);
    if (absNum >= 1000000000) {
        return (num / 1000000000).toFixed(2) + 'B';
    } else if (absNum >= 1000000) {
        return (num / 1000000).toFixed(2) + 'M';
    } else if (absNum >= 1000) {
        return (num / 1000).toFixed(2) + 'K';
    }
    return formatNumber(num);
}

async function drawBankCard(theme, accountLevel, balance, cardNumber, holderName) {
    const width = 1000;
    const height = 630;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const themes = {
        black: {
            bg: ['#0f0f0f', '#1a1a1a'],
            accent: '#ffffff',
            secondary: '#888888',
            glow: 'rgba(255, 255, 255, 0.1)'
        },
        gold: {
            bg: ['#1a1510', '#2a2010'],
            accent: '#ffd700',
            secondary: '#b8860b',
            glow: 'rgba(255, 215, 0, 0.2)'
        },
        platinum: {
            bg: ['#0a0a12', '#15152a'],
            accent: '#e5e4e2',
            secondary: '#9e9e9e',
            glow: 'rgba(229, 228, 226, 0.15)'
        }
    };
    
    const colors = themes[theme] || themes.black;
    
    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, colors.bg[0]);
    gradient.addColorStop(1, colors.bg[1]);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Modern geometric patterns
    ctx.strokeStyle = colors.glow;
    ctx.lineWidth = 1;
    for (let i = 0; i < 20; i++) {
        const x = Math.random() * width;
        const y = Math.random() * height;
        const size = Math.random() * 100 + 50;
        ctx.strokeRect(x, y, size, size);
    }
    
    // Chip
    const chipX = 80;
    const chipY = 200;
    const chipW = 100;
    const chipH = 80;
    
    ctx.fillStyle = colors.secondary;
    ctx.fillRect(chipX, chipY, chipW, chipH);
    
    ctx.fillStyle = colors.bg[0];
    const contactSize = 14;
    const contactSpacing = 20;
    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 4; col++) {
            ctx.fillRect(
                chipX + 10 + col * contactSpacing,
                chipY + 10 + row * contactSpacing,
                contactSize,
                contactSize
            );
        }
    }
    
    // Logo area
    ctx.fillStyle = colors.accent;
    ctx.font = 'bold 48px Arial';
    ctx.fillText('YamiBank', 80, 120);
    
    ctx.font = '20px Arial';
    ctx.fillStyle = colors.secondary;
    ctx.fillText(accountLevel, 80, 150);
    
    // Card number
    ctx.font = 'bold 42px Courier New';
    ctx.fillStyle = colors.accent;
    ctx.fillText(cardNumber, 80, 380);
    
    // Holder info
    ctx.font = '16px Arial';
    ctx.fillStyle = colors.secondary;
    ctx.fillText('CARD HOLDER', 80, 450);
    
    ctx.font = 'bold 24px Arial';
    ctx.fillStyle = colors.accent;
    ctx.fillText(holderName, 80, 490);
    
    // Balance
    ctx.font = '16px Arial';
    ctx.fillStyle = colors.secondary;
    ctx.fillText('BALANCE', width - 350, 450);
    
    ctx.font = 'bold 28px Arial';
    ctx.fillStyle = colors.accent;
    ctx.fillText(`$${formatNumberWithSuffix(balance)}`, width - 350, 490);
    
    // Expiry
    ctx.font = '16px Arial';
    ctx.fillStyle = colors.secondary;
    ctx.fillText('VALID THRU', width - 200, 540);
    
    ctx.font = 'bold 22px Arial';
    ctx.fillStyle = colors.accent;
    const expireDate = moment().add(3, 'years');
    ctx.fillText(expireDate.format('MM/YY'), width - 200, 575);
    
    // Contactless symbol
    ctx.strokeStyle = colors.accent;
    ctx.lineWidth = 3;
    const symbolX = width - 120;
    const symbolY = 200;
    for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.arc(symbolX, symbolY, 15 + i * 10, 0.3, Math.PI - 0.3);
        ctx.stroke();
    }
    
    return canvas;
}

async function drawDepositReceipt(amount, bankData, externalBalance, levelChanged) {
    const width = 800;
    const height = 650;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    // Modern dark background
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Success indicator with glow
    const glowGradient = ctx.createRadialGradient(width / 2, 120, 30, width / 2, 120, 80);
    glowGradient.addColorStop(0, 'rgba(0, 255, 136, 0.3)');
    glowGradient.addColorStop(1, 'rgba(0, 255, 136, 0)');
    ctx.fillStyle = glowGradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#00ff88';
    ctx.beginPath();
    ctx.arc(width / 2, 120, 60, 0, Math.PI * 2);
    ctx.fill();
    
    // Checkmark
    ctx.strokeStyle = '#0a0a0a';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(width / 2 - 25, 120);
    ctx.lineTo(width / 2 - 10, 135);
    ctx.lineTo(width / 2 + 25, 105);
    ctx.stroke();
    
    // Title
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Deposit Successful', width / 2, 240);
    
    // Amount with better spacing
    ctx.font = 'bold 56px Arial';
    ctx.fillStyle = '#00ff88';
    ctx.fillText(`$${formatNumberWithSuffix(amount)}`, width / 2, 320);
    
    // Divider
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, 370);
    ctx.lineTo(width - 100, 370);
    ctx.stroke();
    
    // Details with improved layout
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    const detailsY = 430;
    const lineHeight = 45;
    
    ctx.fillText('Bank Balance:', 100, detailsY);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(bankData.balance)}`, width - 100, detailsY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Wallet Balance:', 100, detailsY + lineHeight);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(externalBalance)}`, width - 100, detailsY + lineHeight);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Account Level:', 100, detailsY + lineHeight * 2);
    ctx.fillStyle = '#ffd700';
    ctx.textAlign = 'right';
    ctx.fillText(bankData.accountLevel, width - 100, detailsY + lineHeight * 2);
    
    if (levelChanged) {
        // Level up badge with glow
        const badgeY = detailsY + lineHeight * 3 + 10;
        ctx.fillStyle = 'rgba(255, 215, 0, 0.15)';
        ctx.fillRect(width / 2 - 120, badgeY - 30, 240, 50);
        
        ctx.fillStyle = '#ffd700';
        ctx.font = 'bold 24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('LEVEL UP!', width / 2, badgeY);
    }
    
    return canvas;
}

async function drawWithdrawReceipt(amount, interest, bankData, externalBalance) {
    const width = 800;
    const height = 650;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#2e1a1a');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Icon with modern design
    const iconY = 110;
    ctx.strokeStyle = '#ff6b9d';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(width / 2 - 40, iconY + 20);
    ctx.lineTo(width / 2, iconY + 60);
    ctx.lineTo(width / 2 + 40, iconY + 20);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(width / 2, iconY);
    ctx.lineTo(width / 2, iconY + 60);
    ctx.stroke();
    
    // Glow effect
    const glowGradient = ctx.createRadialGradient(width / 2, iconY + 30, 20, width / 2, iconY + 30, 70);
    glowGradient.addColorStop(0, 'rgba(255, 107, 157, 0.2)');
    glowGradient.addColorStop(1, 'rgba(255, 107, 157, 0)');
    ctx.fillStyle = glowGradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Withdrawal Complete', width / 2, 220);
    
    ctx.font = 'bold 56px Arial';
    ctx.fillStyle = '#ff6b9d';
    ctx.fillText(`$${formatNumberWithSuffix(amount)}`, width / 2, 300);
    
    if (interest > 0) {
        ctx.font = '22px Arial';
        ctx.fillStyle = '#00ff88';
        ctx.fillText(`+$${formatNumberWithSuffix(interest)} Interest`, width / 2, 340);
    }
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, 390);
    ctx.lineTo(width - 100, 390);
    ctx.stroke();
    
    const detailsY = 450;
    const lineHeight = 45;
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Bank Balance:', 100, detailsY);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(bankData.balance)}`, width - 100, detailsY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Wallet Balance:', 100, detailsY + lineHeight);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(externalBalance)}`, width - 100, detailsY + lineHeight);
    
    return canvas;
}

async function drawTransferReceipt(amount, fee, senderName, receiverName, senderBalance) {
    const width = 800;
    const height = 700;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Transfer Successful', width / 2, 80);
    
    // Modern arrow graphic
    const arrowY = 150;
    ctx.strokeStyle = '#4a9eff';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(width / 2 - 80, arrowY);
    ctx.lineTo(width / 2 + 40, arrowY);
    ctx.lineTo(width / 2 + 20, arrowY - 20);
    ctx.moveTo(width / 2 + 40, arrowY);
    ctx.lineTo(width / 2 + 20, arrowY + 20);
    ctx.stroke();
    
    // Sender/Receiver boxes with better design
    const boxY = 210;
    ctx.fillStyle = 'rgba(74, 158, 255, 0.1)';
    ctx.fillRect(80, boxY, 300, 110);
    
    ctx.fillStyle = 'rgba(0, 255, 136, 0.1)';
    ctx.fillRect(420, boxY, 300, 110);
    
    ctx.font = '16px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('FROM', 100, boxY + 30);
    ctx.fillText('TO', 440, boxY + 30);
    
    ctx.font = 'bold 22px Arial';
    ctx.fillStyle = '#ffffff';
    const maxNameLength = 18;
    const senderDisplay = senderName.length > maxNameLength ? senderName.substring(0, maxNameLength) + '...' : senderName;
    const receiverDisplay = receiverName.length > maxNameLength ? receiverName.substring(0, maxNameLength) + '...' : receiverName;
    
    ctx.fillText(senderDisplay, 100, boxY + 70);
    ctx.fillText(receiverDisplay, 440, boxY + 70);
    
    // Amount with better positioning
    ctx.font = 'bold 56px Arial';
    ctx.fillStyle = '#4a9eff';
    ctx.textAlign = 'center';
    ctx.fillText(`$${formatNumberWithSuffix(amount)}`, width / 2, 420);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, 470);
    ctx.lineTo(width - 100, 470);
    ctx.stroke();
    
    const detailsY = 530;
    const lineHeight = 45;
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Transfer Fee:', 100, detailsY);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(fee)}`, width - 100, detailsY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Remaining Balance:', 100, detailsY + lineHeight);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(senderBalance)}`, width - 100, detailsY + lineHeight);
    
    return canvas;
}

// Drawing Functions - Part 2

async function drawAccountInfoCard(name, bankBalance, walletBalance, portfolioValue, totalWealth, interest, interestRate, accountLevel, loanInfo, bankData) {
    const width = 1000;
    const height = 850;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Header
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Account Overview', width / 2, 70);
    
    ctx.font = '26px Arial';
    ctx.fillStyle = '#ffffff';
    const maxNameLength = 30;
    const displayName = name.length > maxNameLength ? name.substring(0, maxNameLength) + '...' : name;
    ctx.fillText(displayName, width / 2, 110);
    
    // Account level badge with modern design
    const levelColors = {
        BRONZE: '#cd7f32',
        SILVER: '#c0c0c0',
        GOLD: '#ffd700',
        PLATINUM: '#e5e4e2'
    };
    
    const badgeColor = levelColors[accountLevel] || '#cd7f32';
    ctx.fillStyle = badgeColor;
    ctx.fillRect(width / 2 - 90, 130, 180, 45);
    
    // Add subtle glow to badge
    ctx.shadowColor = badgeColor;
    ctx.shadowBlur = 15;
    ctx.fillRect(width / 2 - 90, 130, 180, 45);
    ctx.shadowBlur = 0;
    
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 22px Arial';
    ctx.fillText(accountLevel, width / 2, 160);
    
    // Main balance display with glow
    ctx.fillStyle = 'rgba(0, 255, 136, 0.05)';
    ctx.fillRect(50, 210, width - 100, 130);
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'center';
    ctx.fillText('Total Wealth', width / 2, 245);
    
    ctx.font = 'bold 52px Arial';
    ctx.fillStyle = '#00ff88';
    ctx.fillText(`$${formatNumberWithSuffix(totalWealth)}`, width / 2, 310);
    
    // Details grid with improved spacing
    const gridY = 380;
    const gridHeight = 90;
    const colWidth = (width - 140) / 3;
    
    // Bank Balance
    ctx.fillStyle = 'rgba(74, 158, 255, 0.1)';
    ctx.fillRect(70, gridY, colWidth, gridHeight);
    ctx.fillStyle = '#888888';
    ctx.font = '18px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Bank Balance', 70 + colWidth / 2, gridY + 30);
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 24px Arial';
    ctx.fillText(`$${formatNumberWithSuffix(bankBalance)}`, 70 + colWidth / 2, gridY + 65);
    
    // Wallet Balance
    ctx.fillStyle = 'rgba(255, 107, 157, 0.1)';
    ctx.fillRect(70 + colWidth + 15, gridY, colWidth, gridHeight);
    ctx.fillStyle = '#888888';
    ctx.font = '18px Arial';
    ctx.fillText('Wallet', 70 + colWidth + 15 + colWidth / 2, gridY + 30);
    ctx.fillStyle = '#ff6b9d';
    ctx.font = 'bold 24px Arial';
    ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, 70 + colWidth + 15 + colWidth / 2, gridY + 65);
    
    // Portfolio Value
    ctx.fillStyle = 'rgba(192, 255, 0, 0.1)';
    ctx.fillRect(70 + (colWidth + 15) * 2, gridY, colWidth, gridHeight);
    ctx.fillStyle = '#888888';
    ctx.font = '18px Arial';
    ctx.fillText('Portfolio', 70 + (colWidth + 15) * 2 + colWidth / 2, gridY + 30);
    ctx.fillStyle = '#c0ff00';
    ctx.font = 'bold 24px Arial';
    ctx.fillText(`$${formatNumberWithSuffix(portfolioValue)}`, 70 + (colWidth + 15) * 2 + colWidth / 2, gridY + 65);
    
    // Interest & Stats with better layout
    const statsY = 510;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(70, statsY, width - 140, 220);
    
    ctx.font = '20px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    const leftX = 110;
    const rightX = width / 2 + 60;
    let currentY = statsY + 45;
    const lineSpacing = 50;
    
    ctx.fillText('Accumulated Interest:', leftX, currentY);
    ctx.fillStyle = '#00ff88';
    ctx.fillText(`$${formatNumberWithSuffix(interest)}`, leftX + 250, currentY);
    
    currentY += lineSpacing;
    ctx.fillStyle = '#888888';
    ctx.fillText('Interest Rate:', leftX, currentY);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`${interestRate}% Daily`, leftX + 250, currentY);
    
    currentY += lineSpacing;
    ctx.fillStyle = '#888888';
    ctx.fillText('Work Streak:', leftX, currentY);
    ctx.fillStyle = '#ff9500';
    ctx.fillText(`${bankData.workStreak || 0} Days`, leftX + 250, currentY);
    
    currentY = statsY + 45;
    ctx.fillStyle = '#888888';
    ctx.fillText('Daily Streak:', rightX, currentY);
    ctx.fillStyle = '#ffea00';
    ctx.fillText(`${bankData.dailyStreak || 0} Days`, rightX + 200, currentY);
    
    currentY += lineSpacing;
    ctx.fillStyle = '#888888';
    ctx.fillText('Total Earned:', rightX, currentY);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`$${formatNumberWithSuffix(bankData.totalEarned || 0)}`, rightX + 200, currentY);
    
    currentY += lineSpacing;
    ctx.fillStyle = '#888888';
    ctx.fillText('Member Since:', rightX, currentY);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(moment(bankData.createdAt).format('MM/YYYY'), rightX + 200, currentY);
    
    // Loan warning with modern design
    if (loanInfo) {
        ctx.fillStyle = 'rgba(255, 68, 68, 0.15)';
        ctx.fillRect(70, 760, width - 140, 65);
        ctx.fillStyle = '#ff4444';
        ctx.font = 'bold 22px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(`Outstanding Loan: $${formatNumberWithSuffix(loanInfo.amount)}`, width / 2, 798);
    }
    
    return canvas;
}

async function drawTransactionHistory(transactions) {
    const width = 900;
    const height = 850;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Transaction History', width / 2, 60);
    
    const startY = 130;
    const rowHeight = 70;
    
    transactions.forEach((tx, index) => {
        const y = startY + index * rowHeight;
        
        // Alternating background
        ctx.fillStyle = index % 2 === 0 ? 'rgba(255, 255, 255, 0.03)' : 'rgba(255, 255, 255, 0.06)';
        ctx.fillRect(50, y, width - 100, rowHeight - 5);
        
        // Type with better spacing
        ctx.font = 'bold 20px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'left';
        const typeText = getTransactionTypeEn(tx.type);
        const maxTypeLength = 20;
        const displayType = typeText.length > maxTypeLength ? typeText.substring(0, maxTypeLength) + '...' : typeText;
        ctx.fillText(displayType, 70, y + 30);
        
        // Amount with suffix
        ctx.font = 'bold 24px Arial';
        const isPositive = tx.type.includes('وارد') || tx.type.includes('فوز') || tx.type.includes('عمل') || tx.type.includes('مكافأة') || tx.type.includes('جريمة ناجحة');
        ctx.fillStyle = isPositive ? '#00ff88' : '#ff6b9d';
        ctx.textAlign = 'right';
        ctx.fillText(`${isPositive ? '+' : '-'}$${formatNumberWithSuffix(tx.amount)}`, width - 70, y + 30);
        
        // Date
        ctx.font = '14px Arial';
        ctx.fillStyle = '#888888';
        ctx.textAlign = 'left';
        ctx.fillText(tx.date, 70, y + 55);
    });
    
    return canvas;
}

async function drawLoanReceipt(amount, dueDate, walletBalance) {
    const width = 800;
    const height = 700;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#2e1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#ff9500';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Loan Approved', width / 2, 80);
    
    // Modern icon
    const iconY = 140;
    ctx.strokeStyle = '#ff9500';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(width / 2, iconY + 30, 50, 0, Math.PI * 2);
    ctx.stroke();
    
    // Dollar sign
    ctx.fillStyle = '#ff9500';
    ctx.font = 'bold 48px Arial';
    ctx.fillText('$', width / 2, iconY + 45);
    
    // Amount with better spacing
    ctx.font = 'bold 56px Arial';
    ctx.fillStyle = '#00ff88';
    ctx.fillText(`$${formatNumberWithSuffix(amount)}`, width / 2, 310);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, 360);
    ctx.lineTo(width - 100, 360);
    ctx.stroke();
    
    // Details with improved layout
    const detailsY = 420;
    const lineHeight = 50;
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Due Date:', 100, detailsY);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(dueDate.format('DD/MM/YYYY'), width - 100, detailsY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Interest Rate:', 100, detailsY + lineHeight);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText('5% Daily', width - 100, detailsY + lineHeight);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Current Balance:', 100, detailsY + lineHeight * 2);
    ctx.fillStyle = '#00ff88';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, width - 100, detailsY + lineHeight * 2);
    
    // Warning box with modern design
    ctx.fillStyle = 'rgba(255, 68, 68, 0.15)';
    ctx.fillRect(80, 600, width - 160, 75);
    ctx.fillStyle = '#ff4444';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Late payment penalty: 5% per day', width / 2, 643);
    
    return canvas;
}

async function drawRepaymentReceipt(amountPaid, remainingDebt, fullPaid, walletBalance) {
    const width = 800;
    const height = 650;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a2e1a');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    if (fullPaid) {
        // Success indicator with glow
        const glowGradient = ctx.createRadialGradient(width / 2, 120, 30, width / 2, 120, 80);
        glowGradient.addColorStop(0, 'rgba(0, 255, 136, 0.3)');
        glowGradient.addColorStop(1, 'rgba(0, 255, 136, 0)');
        ctx.fillStyle = glowGradient;
        ctx.fillRect(0, 0, width, height);
        
        ctx.fillStyle = '#00ff88';
        ctx.beginPath();
        ctx.arc(width / 2, 120, 60, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.strokeStyle = '#0a0a0a';
        ctx.lineWidth = 8;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(width / 2 - 25, 120);
        ctx.lineTo(width / 2 - 10, 135);
        ctx.lineTo(width / 2 + 25, 105);
        ctx.stroke();
        
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 42px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Loan Fully Repaid', width / 2, 230);
    } else {
        ctx.fillStyle = '#ffea00';
        ctx.font = 'bold 42px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Partial Payment', width / 2, 120);
    }
    
    ctx.font = 'bold 56px Arial';
    ctx.fillStyle = '#00ff88';
    ctx.fillText(`$${formatNumberWithSuffix(amountPaid)}`, width / 2, fullPaid ? 320 : 220);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, fullPaid ? 370 : 270);
    ctx.lineTo(width - 100, fullPaid ? 370 : 270);
    ctx.stroke();
    
    const detailsY = fullPaid ? 430 : 330;
    const lineHeight = 50;
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    if (!fullPaid) {
        ctx.fillText('Remaining Debt:', 100, detailsY);
        ctx.fillStyle = '#ff9500';
        ctx.textAlign = 'right';
        ctx.fillText(`$${formatNumberWithSuffix(remainingDebt)}`, width - 100, detailsY);
        
        ctx.fillStyle = '#888888';
        ctx.textAlign = 'left';
        ctx.fillText('Wallet Balance:', 100, detailsY + lineHeight);
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'right';
        ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, width - 100, detailsY + lineHeight);
    } else {
        ctx.fillText('Wallet Balance:', 100, detailsY);
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'right';
        ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, width - 100, detailsY);
    }
    
    return canvas;
}

// Drawing Functions - Part 3

async function drawWorkReceipt(jobName, baseEarnings, streakBonus, totalEarnings, streak, walletBalance) {
    const width = 800;
    const height = 700;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Work Completed', width / 2, 80);
    
    ctx.font = '28px Arial';
    ctx.fillStyle = '#ffffff';
    const maxJobLength = 25;
    const displayJob = jobName.length > maxJobLength ? jobName.substring(0, maxJobLength) + '...' : jobName;
    ctx.fillText(displayJob, width / 2, 130);
    
    // Earnings breakdown with improved design
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(100, 180, width - 200, 220);
    
    const breakdownY = 235;
    const lineHeight = 55;
    
    ctx.font = '24px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Base Salary:', 130, breakdownY);
    ctx.fillStyle = '#4a9eff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(baseEarnings)}`, width - 130, breakdownY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Streak Bonus:', 130, breakdownY + lineHeight);
    ctx.fillStyle = '#ff9500';
    ctx.textAlign = 'right';
    ctx.fillText(`+$${formatNumberWithSuffix(streakBonus)}`, width - 130, breakdownY + lineHeight);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(130, breakdownY + lineHeight + 30);
    ctx.lineTo(width - 130, breakdownY + lineHeight + 30);
    ctx.stroke();
    
    ctx.font = 'bold 30px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Total Earned:', 130, breakdownY + lineHeight * 2 + 10);
    ctx.fillStyle = '#00ff88';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(totalEarnings)}`, width - 130, breakdownY + lineHeight * 2 + 10);
    
    // Stats with modern boxes
    const statsY = 460;
    
    ctx.fillStyle = 'rgba(255, 149, 0, 0.1)';
    ctx.fillRect(150, statsY, 250, 90);
    ctx.fillStyle = '#888888';
    ctx.font = '18px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Work Streak', 275, statsY + 35);
    ctx.fillStyle = '#ff9500';
    ctx.font = 'bold 32px Arial';
    ctx.fillText(`${streak} Days`, 275, statsY + 70);
    
    ctx.fillStyle = 'rgba(0, 255, 136, 0.1)';
    ctx.fillRect(420, statsY, 250, 90);
    ctx.fillStyle = '#888888';
    ctx.font = '18px Arial';
    ctx.fillText('Balance', 545, statsY + 35);
    ctx.fillStyle = '#00ff88';
    ctx.font = 'bold 32px Arial';
    ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, 545, statsY + 70);
    
    return canvas;
}

async function drawDailyBonusReceipt(baseReward, streakBonus, levelBonus, totalReward, streak, walletBalance) {
    const width = 800;
    const height = 750;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#2e1a1a');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Modern gift icon
    const iconY = 90;
    ctx.fillStyle = '#ff6b9d';
    ctx.fillRect(width / 2 - 40, iconY, 80, 60);
    ctx.fillRect(width / 2 - 10, iconY - 20, 20, 20);
    ctx.fillStyle = '#ff9500';
    ctx.fillRect(width / 2 - 50, iconY + 30, 100, 10);
    ctx.fillRect(width / 2 - 5, iconY, 10, 60);
    
    ctx.fillStyle = '#ffea00';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Daily Bonus Claimed', width / 2, 210);
    
    // Rewards breakdown with better spacing
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(80, 260, width - 160, 240);
    
    const breakdownY = 315;
    const lineHeight = 55;
    
    ctx.font = '24px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Base Reward:', 110, breakdownY);
    ctx.fillStyle = '#4a9eff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(baseReward)}`, width - 110, breakdownY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Streak Bonus:', 110, breakdownY + lineHeight);
    ctx.fillStyle = '#ff9500';
    ctx.textAlign = 'right';
    ctx.fillText(`+$${formatNumberWithSuffix(streakBonus)}`, width - 110, breakdownY + lineHeight);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Level Bonus:', 110, breakdownY + lineHeight * 2);
    ctx.fillStyle = '#ffd700';
    ctx.textAlign = 'right';
    ctx.fillText(`+$${formatNumberWithSuffix(levelBonus)}`, width - 110, breakdownY + lineHeight * 2);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(110, breakdownY + lineHeight * 2 + 30);
    ctx.lineTo(width - 110, breakdownY + lineHeight * 2 + 30);
    ctx.stroke();
    
    ctx.font = 'bold 34px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Total:', 110, breakdownY + lineHeight * 3 + 5);
    ctx.fillStyle = '#00ff88';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(totalReward)}`, width - 110, breakdownY + lineHeight * 3 + 5);
    
    // Stats with modern design
    const statsY = 560;
    
    ctx.fillStyle = 'rgba(255, 234, 0, 0.1)';
    ctx.fillRect(150, statsY, 250, 90);
    ctx.fillStyle = '#888888';
    ctx.font = '18px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Daily Streak', 275, statsY + 35);
    ctx.fillStyle = '#ffea00';
    ctx.font = 'bold 32px Arial';
    ctx.fillText(`${streak} Days`, 275, statsY + 70);
    
    ctx.fillStyle = 'rgba(0, 255, 136, 0.1)';
    ctx.fillRect(420, statsY, 250, 90);
    ctx.fillStyle = '#888888';
    ctx.font = '18px Arial';
    ctx.fillText('Balance', 545, statsY + 35);
    ctx.fillStyle = '#00ff88';
    ctx.font = 'bold 32px Arial';
    ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, 545, statsY + 70);
    
    return canvas;
}

async function drawCrimeReceipt(crimeName, amount, success, walletBalance) {
    const width = 800;
    const height = 650;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    if (success) {
        gradient.addColorStop(0, '#0a0a0a');
        gradient.addColorStop(1, '#1a2e1a');
    } else {
        gradient.addColorStop(0, '#0a0a0a');
        gradient.addColorStop(1, '#2e1a1a');
    }
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    if (success) {
        ctx.fillStyle = '#00ff88';
        ctx.font = 'bold 42px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Crime Successful', width / 2, 100);
        
        ctx.font = '28px Arial';
        ctx.fillStyle = '#ffffff';
        const maxCrimeLength = 25;
        const displayCrime = crimeName.length > maxCrimeLength ? crimeName.substring(0, maxCrimeLength) + '...' : crimeName;
        ctx.fillText(displayCrime, width / 2, 150);
        
        ctx.font = 'bold 56px Arial';
        ctx.fillStyle = '#00ff88';
        ctx.fillText(`+$${formatNumberWithSuffix(amount)}`, width / 2, 260);
        
        ctx.font = '22px Arial';
        ctx.fillStyle = '#888888';
        ctx.fillText('Loot Acquired', width / 2, 300);
    } else {
        ctx.fillStyle = '#ff4444';
        ctx.font = 'bold 42px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Crime Failed', width / 2, 100);
        
        ctx.font = '28px Arial';
        ctx.fillStyle = '#ffffff';
        const maxCrimeLength = 25;
        const displayCrime = crimeName.length > maxCrimeLength ? crimeName.substring(0, maxCrimeLength) + '...' : crimeName;
        ctx.fillText(displayCrime, width / 2, 150);
        
        ctx.font = 'bold 56px Arial';
        ctx.fillStyle = '#ff4444';
        ctx.fillText(`-$${formatNumberWithSuffix(amount)}`, width / 2, 260);
        
        ctx.font = '22px Arial';
        ctx.fillStyle = '#888888';
        ctx.fillText('Fine Paid', width / 2, 300);
    }
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, 350);
    ctx.lineTo(width - 100, 350);
    ctx.stroke();
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Current Balance:', 100, 420);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, width - 100, 420);
    
    if (!success) {
        ctx.fillStyle = 'rgba(255, 68, 68, 0.15)';
        ctx.fillRect(100, 490, width - 200, 90);
        ctx.fillStyle = '#ff4444';
        ctx.font = 'bold 24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('You were caught!', width / 2, 530);
        ctx.font = '18px Arial';
        ctx.fillText('Crime doesn\'t pay', width / 2, 560);
    }
    
    return canvas;
}

async function drawSlotsReceipt(slot1, slot2, slot3, bet, winnings, result, multiplier, walletBalance) {
    const width = 800;
    const height = 750;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const isWin = winnings > 0;
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    if (isWin) {
        gradient.addColorStop(0, '#0a0a0a');
        gradient.addColorStop(1, '#1a2e1a');
    } else {
        gradient.addColorStop(0, '#0a0a0a');
        gradient.addColorStop(1, '#2e1a1a');
    }
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = isWin ? '#00ff88' : '#ff6b9d';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('SLOT MACHINE', width / 2, 70);
    
    // Slot display with modern design
    const slotY = 140;
    const slotSize = 180;
    const slotSpacing = 20;
    const totalWidth = slotSize * 3 + slotSpacing * 2;
    const startX = (width - totalWidth) / 2;
    
    const slotSymbols = {
        'CHERRY': { color: '#ff4444', text: 'CH' },
        'LEMON': { color: '#ffea00', text: 'LE' },
        'ORANGE': { color: '#ff9500', text: 'OR' },
        'GRAPE': { color: '#9d4edd', text: 'GR' },
        'DIAMOND': { color: '#4a9eff', text: 'DI' },
        'SEVEN': { color: '#ff6b9d', text: '7' }
    };
    
    [slot1, slot2, slot3].forEach((slot, index) => {
        const x = startX + index * (slotSize + slotSpacing);
        
        // Slot background with glow
        ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.fillRect(x, slotY, slotSize, slotSize);
        
        // Border with color
        ctx.strokeStyle = slotSymbols[slot].color;
        ctx.lineWidth = 4;
        ctx.strokeRect(x, slotY, slotSize, slotSize);
        
        // Symbol text
        ctx.fillStyle = slotSymbols[slot].color;
        if (slot === 'SEVEN') {
            ctx.font = 'bold 100px Arial';
            ctx.fillText('7', x + slotSize / 2, slotY + slotSize / 2 + 38);
        } else {
            ctx.font = 'bold 70px Arial';
            ctx.fillText(slotSymbols[slot].text, x + slotSize / 2, slotY + slotSize / 2 + 28);
        }
    });
    
    // Result with better spacing
    ctx.font = 'bold 42px Arial';
    ctx.fillStyle = isWin ? '#00ff88' : '#ff4444';
    ctx.textAlign = 'center';
    ctx.fillText(result, width / 2, 390);
    
    if (multiplier > 0) {
        ctx.font = 'bold 32px Arial';
        ctx.fillStyle = '#ffea00';
        ctx.fillText(`x${multiplier}`, width / 2, 430);
    }
    
    // Bet and winnings
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, 480);
    ctx.lineTo(width - 100, 480);
    ctx.stroke();
    
    const detailsY = 540;
    const lineHeight = 50;
    
    ctx.font = '24px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Bet Amount:', 120, detailsY);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(bet)}`, width - 120, detailsY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText(isWin ? 'Winnings:' : 'Loss:', 120, detailsY + lineHeight);
    ctx.fillStyle = isWin ? '#00ff88' : '#ff4444';
    ctx.textAlign = 'right';
    ctx.fillText(`${isWin ? '+' : '-'}$${formatNumberWithSuffix(Math.abs(winnings))}`, width - 120, detailsY + lineHeight);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Balance:', 120, detailsY + lineHeight * 2);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(walletBalance)}`, width - 120, detailsY + lineHeight * 2);
    
    return canvas;
}

// Drawing Functions - Part 4

async function drawStocksCard() {
    const width = 1000;
    const height = 950;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Stock Market', width / 2, 70);
    
    ctx.font = '20px Arial';
    ctx.fillStyle = '#888888';
    ctx.fillText('Live Market Prices', width / 2, 105);
    
    const startY = 170;
    const rowHeight = 110;
    let currentY = startY;
    
    for (const [symbol, stock] of Object.entries(BANK_CONFIG.STOCKS)) {
        const priceData = getStockChange(symbol);
        const isPositive = priceData.change >= 0;
        
        // Background
        ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
        ctx.fillRect(70, currentY, width - 140, rowHeight - 10);
        
        // Stock symbol and name
        ctx.font = 'bold 32px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'left';
        ctx.fillText(symbol, 110, currentY + 40);
        
        ctx.font = '18px Arial';
        ctx.fillStyle = '#888888';
        const maxStockNameLength = 25;
        const displayStockName = stock.name.length > maxStockNameLength ? stock.name.substring(0, maxStockNameLength) + '...' : stock.name;
        ctx.fillText(displayStockName, 110, currentY + 70);
        
        // Price with suffix
        ctx.font = 'bold 34px Arial';
        ctx.fillStyle = '#4a9eff';
        ctx.textAlign = 'right';
        ctx.fillText(`$${formatNumberWithSuffix(priceData.current)}`, width - 320, currentY + 45);
        
        // Change with better spacing
        ctx.font = 'bold 24px Arial';
        ctx.fillStyle = isPositive ? '#00ff88' : '#ff4444';
        const changeText = `${isPositive ? '+' : ''}${priceData.changePercent.toFixed(2)}%`;
        ctx.fillText(changeText, width - 110, currentY + 50);
        
        // Trend arrow with modern design
        ctx.beginPath();
        if (isPositive) {
            ctx.moveTo(width - 270, currentY + 50);
            ctx.lineTo(width - 250, currentY + 30);
            ctx.lineTo(width - 230, currentY + 50);
        } else {
            ctx.moveTo(width - 270, currentY + 30);
            ctx.lineTo(width - 250, currentY + 50);
            ctx.lineTo(width - 230, currentY + 30);
        }
        ctx.strokeStyle = isPositive ? '#00ff88' : '#ff4444';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.stroke();
        
        currentY += rowHeight;
    }
    
    return canvas;
}

async function drawStockBuyReceipt(symbol, shares, price, totalCost, bankBalance, totalShares) {
    const width = 800;
    const height = 700;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a2e1a');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#00ff88';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Stock Purchase', width / 2, 80);
    
    // Stock info with modern design
    ctx.fillStyle = 'rgba(0, 255, 136, 0.1)';
    ctx.fillRect(100, 140, width - 200, 110);
    
    ctx.font = 'bold 36px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText(symbol, width / 2, 185);
    
    ctx.font = '20px Arial';
    ctx.fillStyle = '#888888';
    const stockName = BANK_CONFIG.STOCKS[symbol]?.name || symbol;
    const maxStockNameLength = 30;
    const displayStockName = stockName.length > maxStockNameLength ? stockName.substring(0, maxStockNameLength) + '...' : stockName;
    ctx.fillText(displayStockName, width / 2, 220);
    
    // Transaction details with better spacing
    const detailsY = 300;
    const lineHeight = 55;
    
    ctx.font = '24px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Shares Purchased:', 120, detailsY);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(shares.toString(), width - 120, detailsY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Price per Share:', 120, detailsY + lineHeight);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(price)}`, width - 120, detailsY + lineHeight);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Total Cost:', 120, detailsY + lineHeight * 2);
    ctx.fillStyle = '#ff6b9d';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(totalCost)}`, width - 120, detailsY + lineHeight * 2);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(120, detailsY + lineHeight * 2 + 30);
    ctx.lineTo(width - 120, detailsY + lineHeight * 2 + 30);
    ctx.stroke();
    
    ctx.font = 'bold 26px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Total Holdings:', 120, detailsY + lineHeight * 3 + 10);
    ctx.fillStyle = '#00ff88';
    ctx.textAlign = 'right';
    ctx.fillText(`${totalShares} shares`, width - 120, detailsY + lineHeight * 3 + 10);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Bank Balance:', 120, detailsY + lineHeight * 4 + 10);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(bankBalance)}`, width - 120, detailsY + lineHeight * 4 + 10);
    
    return canvas;
}

async function drawStockSellReceipt(symbol, shares, price, totalRevenue, profit, bankBalance) {
    const width = 800;
    const height = 750;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const isProfit = profit >= 0;
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    if (isProfit) {
        gradient.addColorStop(0, '#0a0a0a');
        gradient.addColorStop(1, '#1a2e1a');
    } else {
        gradient.addColorStop(0, '#0a0a0a');
        gradient.addColorStop(1, '#2e1a1a');
    }
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = isProfit ? '#00ff88' : '#ff6b9d';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Stock Sale', width / 2, 80);
    
    // Stock info
    ctx.fillStyle = isProfit ? 'rgba(0, 255, 136, 0.1)' : 'rgba(255, 107, 157, 0.1)';
    ctx.fillRect(100, 140, width - 200, 110);
    
    ctx.font = 'bold 36px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText(symbol, width / 2, 185);
    
    ctx.font = '20px Arial';
    ctx.fillStyle = '#888888';
    const stockName = BANK_CONFIG.STOCKS[symbol]?.name || symbol;
    const maxStockNameLength = 30;
    const displayStockName = stockName.length > maxStockNameLength ? stockName.substring(0, maxStockNameLength) + '...' : stockName;
    ctx.fillText(displayStockName, width / 2, 220);
    
    // Transaction details
    const detailsY = 300;
    const lineHeight = 55;
    
    ctx.font = '24px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    
    ctx.fillText('Shares Sold:', 120, detailsY);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(shares.toString(), width - 120, detailsY);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Price per Share:', 120, detailsY + lineHeight);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(price)}`, width - 120, detailsY + lineHeight);
    
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Total Revenue:', 120, detailsY + lineHeight * 2);
    ctx.fillStyle = '#00ff88';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(totalRevenue)}`, width - 120, detailsY + lineHeight * 2);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(120, detailsY + lineHeight * 2 + 30);
    ctx.lineTo(width - 120, detailsY + lineHeight * 2 + 30);
    ctx.stroke();
    
    // Profit/Loss
    ctx.font = 'bold 30px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText(isProfit ? 'Profit:' : 'Loss:', 120, detailsY + lineHeight * 3 + 10);
    ctx.fillStyle = isProfit ? '#00ff88' : '#ff4444';
    ctx.textAlign = 'right';
    ctx.fillText(`${isProfit ? '+' : ''}$${formatNumberWithSuffix(profit)}`, width - 120, detailsY + lineHeight * 3 + 10);
    
    ctx.font = '24px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Bank Balance:', 120, detailsY + lineHeight * 4 + 10);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(bankBalance)}`, width - 120, detailsY + lineHeight * 4 + 10);
    
    return canvas;
}

async function drawPortfolioCard(portfolioData, totalValue, totalInvested, totalProfit, totalProfitPercent, bankBalance) {
    const width = 1000;
    const height = 250 + portfolioData.length * 110 + 100;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Stock Portfolio', width / 2, 70);
    
    // Summary with better layout
    const summaryY = 140;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(70, summaryY, width - 140, 110);
    
    ctx.font = '18px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Total Value', 110, summaryY + 35);
    ctx.fillText('Invested', 370, summaryY + 35);
    ctx.fillText('Profit/Loss', 630, summaryY + 35);
    
    ctx.font = 'bold 26px Arial';
    ctx.fillStyle = '#4a9eff';
    ctx.fillText(`$${formatNumberWithSuffix(totalValue)}`, 110, summaryY + 75);
    
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`$${formatNumberWithSuffix(totalInvested)}`, 370, summaryY + 75);
    
    const isProfit = totalProfit >= 0;
    ctx.fillStyle = isProfit ? '#00ff88' : '#ff4444';
    ctx.fillText(`${isProfit ? '+' : ''}$${formatNumberWithSuffix(totalProfit)}`, 630, summaryY + 75);
    
    ctx.font = '20px Arial';
    ctx.fillText(`(${isProfit ? '+' : ''}${totalProfitPercent.toFixed(2)}%)`, 800, summaryY + 75);
    
    // Holdings with improved design
    let currentY = summaryY + 160;
    
    portfolioData.forEach((holding, index) => {
        ctx.fillStyle = index % 2 === 0 ? 'rgba(255, 255, 255, 0.02)' : 'rgba(255, 255, 255, 0.04)';
        ctx.fillRect(70, currentY, width - 140, 100);
        
        // Symbol
        ctx.font = 'bold 28px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'left';
        ctx.fillText(holding.symbol, 110, currentY + 40);
        
        // Shares
        ctx.font = '16px Arial';
        ctx.fillStyle = '#888888';
        ctx.fillText(`${holding.shares} shares`, 110, currentY + 70);
        
        // Price
        ctx.font = '20px Arial';
        ctx.fillStyle = '#4a9eff';
        ctx.textAlign = 'right';
        ctx.fillText(`$${formatNumberWithSuffix(holding.currentPrice)}`, 420, currentY + 40);
        ctx.font = '14px Arial';
        ctx.fillStyle = '#888888';
        ctx.fillText(`Avg: $${formatNumberWithSuffix(holding.avgPrice)}`, 420, currentY + 65);
        
        // Value
        ctx.font = 'bold 22px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'right';
        ctx.fillText(`$${formatNumberWithSuffix(holding.marketValue)}`, 640, currentY + 50);
        
        // Profit
        const isHoldingProfit = holding.profit >= 0;
        ctx.font = 'bold 24px Arial';
        ctx.fillStyle = isHoldingProfit ? '#00ff88' : '#ff4444';
        ctx.textAlign = 'right';
        ctx.fillText(`${isHoldingProfit ? '+' : ''}$${formatNumberWithSuffix(holding.profit)}`, width - 110, currentY + 40);
        
        ctx.font = '16px Arial';
        ctx.fillText(`${isHoldingProfit ? '+' : ''}${holding.profitPercent.toFixed(2)}%`, width - 110, currentY + 70);
        
        currentY += 110;
    });
    
    // Bank balance
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(70, currentY + 20, width - 140, 75);
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.textAlign = 'left';
    ctx.fillText('Bank Balance:', 110, currentY + 65);
    
    ctx.font = 'bold 28px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.fillText(`$${formatNumberWithSuffix(bankBalance)}`, width - 110, currentY + 65);
    
    return canvas;
}

// Drawing Functions - Part 5 (Final)

async function drawLeaderboardCard(top10) {
    const width = 900;
    const height = 850;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Leaderboard', width / 2, 70);
    
    ctx.font = '22px Arial';
    ctx.fillStyle = '#888888';
    ctx.fillText('Top Wealthy Accounts', width / 2, 110);
    
    const startY = 170;
    const rowHeight = 65;
    
    top10.forEach((account, index) => {
        const y = startY + index * rowHeight;
        
        // Background with special styling for top 3
        ctx.fillStyle = index < 3 ? 'rgba(255, 215, 0, 0.1)' : 'rgba(255, 255, 255, 0.03)';
        ctx.fillRect(70, y, width - 140, rowHeight - 5);
        
        // Rank with medals for top 3
        const rankColors = ['#ffd700', '#c0c0c0', '#cd7f32'];
        ctx.font = 'bold 32px Arial';
        ctx.fillStyle = index < 3 ? rankColors[index] : '#888888';
        ctx.textAlign = 'center';
        ctx.fillText(`${index + 1}`, 120, y + 43);
        
        // Name with truncation
        ctx.font = 'bold 24px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'left';
        const maxNameLength = 18;
        const displayName = account.name.length > maxNameLength ? account.name.substring(0, maxNameLength) + '...' : account.name;
        ctx.fillText(displayName, 180, y + 33);
        
        // Level badge
        const levelColors = {
            BRONZE: '#cd7f32',
            SILVER: '#c0c0c0',
            GOLD: '#ffd700',
            PLATINUM: '#e5e4e2'
        };
        ctx.font = '14px Arial';
        ctx.fillStyle = levelColors[account.level] || '#cd7f32';
        ctx.fillText(account.level, 180, y + 52);
        
        // Wealth with suffix
        ctx.font = 'bold 26px Arial';
        ctx.fillStyle = '#00ff88';
        ctx.textAlign = 'right';
        ctx.fillText(`$${formatNumberWithSuffix(account.wealth)}`, width - 90, y + 43);
    });
    
    return canvas;
}

async function drawHelpCard() {
    const width = 1000;
    const height = 1250;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    ctx.fillStyle = '#4a9eff';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Bank System Guide', width / 2, 70);
    
    const sections = [
        { 
            title: 'Basic Commands', 
            y: 140, 
            commands: [
                'bank view - Account information',
                'bank deposit [amount] - Deposit money',
                'bank withdraw [amount] - Withdraw money',
                'bank transfer [amount] [@user] - Transfer',
                'bank history - Transaction history',
                'bank leaderboard - Top accounts'
            ]
        },
        { 
            title: 'Loans', 
            y: 440, 
            commands: [
                'bank loan [amount] - Request loan (80%)',
                'bank repay [amount] - Repay loan',
                'Interest: 5% daily',
                'Late penalty: 5% per day'
            ]
        },
        { 
            title: 'Earning Money', 
            y: 670, 
            commands: [
                'bank work - Work for salary (1 hour)',
                'bank daily - Daily bonus (24 hours)',
                'bank crime - Try crime (2 hours)',
                'bank slots [bet] - Slot machine'
            ]
        },
        { 
            title: 'Stock Trading', 
            y: 900, 
            commands: [
                'bank stocks - View available stocks',
                'bank buy [symbol] [shares] - Buy stocks',
                'bank sell [symbol] [shares] - Sell stocks',
                'bank portfolio - View portfolio',
                'Trading commission: 1%'
            ]
        }
    ];
    
    sections.forEach(section => {
        const boxHeight = section.commands.length * 38 + 70;
        ctx.fillStyle = 'rgba(74, 158, 255, 0.1)';
        ctx.fillRect(70, section.y, width - 140, boxHeight);
        
        ctx.font = 'bold 28px Arial';
        ctx.fillStyle = '#4a9eff';
        ctx.textAlign = 'left';
        ctx.fillText(section.title, 110, section.y + 45);
        
        ctx.font = '20px Arial';
        ctx.fillStyle = '#ffffff';
        section.commands.forEach((cmd, index) => {
            ctx.fillText(cmd, 110, section.y + 90 + index * 38);
        });
    });
    
    // Account levels footer with modern design
    ctx.fillStyle = 'rgba(255, 215, 0, 0.1)';
    ctx.fillRect(70, 1130, width - 140, 95);
    
    ctx.font = 'bold 24px Arial';
    ctx.fillStyle = '#ffd700';
    ctx.textAlign = 'center';
    ctx.fillText('Account Levels', width / 2, 1165);
    
    ctx.font = '18px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('Bronze: 0-50K | Silver: 50K-200K', width / 2, 1195);
    ctx.fillText('Gold: 200K-500K | Platinum: 500K+', width / 2, 1220);
    
    return canvas;
}

function getTransactionTypeEn(type) {
    const types = {
        'إيداع': 'Deposit',
        'سحب': 'Withdrawal',
        'قرض': 'Loan',
        'سداد': 'Repayment',
        'سداد جزئي': 'Partial Payment',
        'تحويل صادر': 'Transfer Out',
        'تحويل وارد': 'Transfer In',
        'عمل': 'Work',
        'مكافأة يومية': 'Daily Bonus',
        'جريمة ناجحة': 'Crime Success',
        'جريمة فاشلة': 'Crime Failed',
        'سلوت - فوز': 'Slots Win',
        'سلوت - خسارة': 'Slots Loss',
        'شراء أسهم': 'Stock Buy',
        'بيع أسهم': 'Stock Sell'
    };
    return types[type] || type;
}