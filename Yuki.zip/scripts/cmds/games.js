const games = "• حزورة: يرسل لك حزورة\n• لكل جواب صحيح 10 دنانير"
            + "\n• ترتيب: يرسل لك كلمة مبعثرة و الهدف ترتبها.\n• لكل جواب صحيح 5 دنانير."
            + "\n• الأسرع: يرسل لك صورة إيموجي و الهدف إرسال الإيموجي الذي في الصورة"
            + "\n• كل جواب صحيح يزيد لك 10 دنانير."
            + "\n• رصيد: عرض رصيدك في البوت"
            + "\n• رانك: عرض رانكك في البوت"
            + "\n• دفع: تحويل النقود لصديقك"
            + "\n• مغامرة: لعبة مغامرة ستضاف قريبا..";
let title = "👾 الألعاب المتوفرة حاليا:\n-------------\t\t👾\t\t-------------\n"
title += games;
const botAdmin = "fb.me/proarcoder";
title += "\n-------------\t\t👾\t\t-------------\n• المطور: "+botAdmin;
module.exports = {
	config: {
		name: "games",
		aliases: ["الألعاب"],
		version: "1.2",
		author: "allou Mohamed",
		countDown: 5,
		role: 0,
		description: {
			en: "bot Games list",
			ar: "قائمة الألعاب الموجودة في البوت."
		},
		category: "info",
		guide: {
			en: "{pn}",
			ar: "{pn}"
     	}
	},
	onStart: async function({ message }) {
	    message.stream(title, logo());
	},
	onChat: async function({ args, message }) {
	    const reg = new RegExp("الألعاب");
	    const reg2 = new RegExp("الالعاب");
	    const body = args.join(" ");
	    if (reg.test(body) || reg2.test(body)) return message.stream(title, logo());
	}
};

function logo() {
  const images = [
    "https://i.ibb.co/6cz9TZ4z/file-00000000af7451f692ada8e1cadeae5e-conversation-id-67f66176-5a98-8002-a535-91c948dbfbd8-message-i.png",
    "https://i.ibb.co/gFRP0mgT/file-00000000aab051f695c898ff90a65273-conversation-id-67f66176-5a98-8002-a535-91c948dbfbd8-message-i.png"
  ];

  const randomIndex = Math.floor(Math.random() * images.length);
  return images[randomIndex];
}
