const os = require("os");
const canvas = require("canvas");
const fs = require("fs");
const path = require("path");
const disk = require("diskusage");

module.exports = {
    config: {
        name: 'z2',
        author: 'allou mohamed',
        aliases: ["statistics2", "upt2", "dashboard"],
        description: {
            ar: "معلومات البوت و المطور",
            en: "Complete bot analytics dashboard"
        },
        role: 0,
        countDown: 10,
        category: "stats"
    },
    onStart: async function ({ usersData, threadsData, message }) {
        const width = 1800;
        const height = 1200;
        const image = canvas.createCanvas(width, height);
        const ctx = image.getContext("2d");
        
        ctx.antialias = 'subpixel';
        ctx.patternQuality = 'best';
        ctx.quality = 'best';
        
        await createDashboard(ctx, image, usersData, threadsData);

        const imagePath = path.join(__dirname, 'cache', 'dashboard.png');
        const buffer = image.toBuffer('image/png');
        fs.writeFileSync(imagePath, buffer);
        
        message.reply({ attachment: fs.createReadStream(imagePath) }, async () => {
            fs.unlinkSync(imagePath);
        });

        async function createDashboard(ctx, canvas, usersData, threadsData) {
            const W = canvas.width;
            const H = canvas.height;
            
            const bgGradient = ctx.createLinearGradient(0, 0, W, H);
            bgGradient.addColorStop(0, '#0a0a0a');
            bgGradient.addColorStop(0.3, '#1a1a1a');
            bgGradient.addColorStop(0.7, '#2a2a2a');
            bgGradient.addColorStop(1, '#0f0f0f');
            ctx.fillStyle = bgGradient;
            ctx.fillRect(0, 0, W, H);

            addPattern(ctx, W, H);
            
            const padding = 60;
            const containerX = padding;
            const containerY = padding;
            const containerW = W - (padding * 2);
            const containerH = H - (padding * 2);
            
            drawContainer(ctx, containerX, containerY, containerW, containerH);
            
            const headerH = containerH * 0.12;
            await drawHeader(ctx, containerX, containerY, containerW, headerH);
            
            const statsY = containerY + headerH + 20;
            const statsH = containerH * 0.45;
            await drawAllStats(ctx, containerX, statsY, containerW, statsH, usersData, threadsData);
            
            const chartsY = statsY + statsH + 20;
            const chartsH = containerH * 0.35;
            await drawCharts(ctx, containerX, chartsY, containerW, chartsH);
            
            const footerY = containerY + containerH - 30;
            drawFooter(ctx, containerX, footerY, containerW);
        }

        function addPattern(ctx, width, height) {
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.02)';
            ctx.lineWidth = 1;
            
            for (let x = 0; x < width; x += 100) {
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x, height);
                ctx.stroke();
            }
            
            for (let y = 0; y < height; y += 100) {
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(width, y);
                ctx.stroke();
            }
            
            addAccents(ctx, width, height);
        }

        function addAccents(ctx, width, height) {
            const color = '#4a90e2';
            const size = 3;
            const length = 50;
            
            ctx.strokeStyle = color;
            ctx.lineWidth = size;
            
            [[60, 60], [width - 60, 60], [60, height - 60], [width - 60, height - 60]].forEach(([x, y]) => {
                ctx.beginPath();
                if (x === 60 && y === 60) {
                    ctx.moveTo(x, y + length);
                    ctx.lineTo(x, y);
                    ctx.lineTo(x + length, y);
                } else if (x === width - 60 && y === 60) {
                    ctx.moveTo(x - length, y);
                    ctx.lineTo(x, y);
                    ctx.lineTo(x, y + length);
                } else if (x === 60 && y === height - 60) {
                    ctx.moveTo(x, y - length);
                    ctx.lineTo(x, y);
                    ctx.lineTo(x + length, y);
                } else {
                    ctx.moveTo(x - length, y);
                    ctx.lineTo(x, y);
                    ctx.lineTo(x, y - length);
                }
                ctx.stroke();
            });
        }

        function drawContainer(ctx, x, y, width, height) {
            ctx.save();
            
            ctx.fillStyle = 'rgba(20, 20, 20, 0.95)';
            drawRoundedRect(ctx, x, y, width, height, 20);
            ctx.fill();
            
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
            ctx.lineWidth = 2;
            ctx.stroke();
            
            ctx.restore();
        }

        async function drawHeader(ctx, x, y, width, height) {
            ctx.save();
            
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 64px sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            
            const titleY = y + (height * 0.45);
            ctx.fillText('YUKI BOT II', x + 40, titleY);
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
            ctx.font = '28px sans-serif';
            const subtitleY = titleY + 45;
            ctx.fillText('Complete Analytics Dashboard', x + 40, subtitleY);
            
            ctx.textAlign = 'right';
            ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
            ctx.font = '22px sans-serif';
            
            const rightX = x + width - 40;
            ctx.fillText(getCurrentTime(), rightX, titleY - 25);
            
            const packageJsonPath = path.join('package.json');
            let version = '1.0.0';
            try {
                const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
                version = packageJson.version;
            } catch (e) {}
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
            ctx.font = '20px sans-serif';
            ctx.fillText(`Version ${version}`, rightX, titleY + 25);
            
            ctx.restore();
        }

        async function drawAllStats(ctx, x, y, width, height, usersData, threadsData) {
            const allUsers = await usersData.getAll();
            const allGroups = await threadsData.getAll();
            
            const bannedUsers = allUsers.filter(u => u.banned?.status);
            const maleUsers = allUsers.filter(u => u.gender === 2);
            const femaleUsers = allUsers.filter(u => u.gender === 1);
            const otherGender = allUsers.filter(u => u.gender !== 1 && u.gender !== 2);
            const activeUsers = allUsers.filter(u => !u.banned?.status);
            const premiumUsers = allUsers.filter(u => u.data?.premium);
            const verifiedUsers = allUsers.filter(u => u.data?.verified);
            
            const bannedGroups = allGroups.filter(g => g.banned?.status);
            const approvedGroups = allGroups.filter(g => g.data?.approved);
            const disapprovedGroups = allGroups.filter(g => g.data?.approved === false);
            const activeGroups = allGroups.filter(g => !g.banned?.status);
            const privateGroups = allGroups.filter(g => g.data?.type === 'private');
            const publicGroups = allGroups.filter(g => g.data?.type === 'public');
            
            const cardWidth = 220;
            const cardHeight = 110;
            const cardsPerRow = 6;
            const cardSpacing = 30;
            const totalWidth = (cardWidth * cardsPerRow) + (cardSpacing * (cardsPerRow - 1));
            const startX = x + (width - totalWidth) / 2;
            
            const stats = [
                { title: 'Total Users', value: formatNumber(allUsers.length), letter: 'U', color: '#4a90e2' },
                { title: 'Active Users', value: formatNumber(activeUsers.length), letter: 'A', color: '#5cb85c' },
                { title: 'Banned Users', value: formatNumber(bannedUsers.length), letter: 'B', color: '#d9534f' },
                { title: 'Male Users', value: formatNumber(maleUsers.length), letter: 'M', color: '#5bc0de' },
                { title: 'Female Users', value: formatNumber(femaleUsers.length), letter: 'F', color: '#e91e63' },
                { title: 'Other Gender', value: formatNumber(otherGender.length), letter: 'O', color: '#9c27b0' },
                
                { title: 'Premium Users', value: formatNumber(premiumUsers.length), letter: 'P', color: '#ff9800' },
                { title: 'Verified Users', value: formatNumber(verifiedUsers.length), letter: 'V', color: '#4caf50' },
                { title: 'Total Groups', value: formatNumber(allGroups.length), letter: 'G', color: '#2196f3' },
                { title: 'Active Groups', value: formatNumber(activeGroups.length), letter: 'C', color: '#00bcd4' },
                { title: 'Banned Groups', value: formatNumber(bannedGroups.length), letter: 'X', color: '#f44336' },
                { title: 'Approved Groups', value: formatNumber(approvedGroups.length), letter: 'R', color: '#8bc34a' },
                
                { title: 'Disapproved', value: formatNumber(disapprovedGroups.length), letter: 'D', color: '#ff5722' },
                { title: 'Private Groups', value: formatNumber(privateGroups.length), letter: 'S', color: '#795548' },
                { title: 'Public Groups', value: formatNumber(publicGroups.length), letter: 'L', color: '#607d8b' },
                { title: 'Bot Uptime', value: formatUptime(), letter: 'T', color: '#9b59b6' },
                { title: 'Node.js Version', value: 'v20.16.0', letter: 'N', color: '#2ecc71' },
                { title: 'Platform', value: os.platform().toUpperCase(), letter: 'W', color: '#34495e' }
            ];

            stats.forEach((stat, index) => {
                const row = Math.floor(index / cardsPerRow);
                const col = index % cardsPerRow;
                stat.x = startX + col * (cardWidth + cardSpacing);
                stat.y = y + 20 + row * (cardHeight + 25);
                drawStatCard(ctx, stat, cardWidth, cardHeight);
            });
        }

        function drawStatCard(ctx, card, width, height) {
            ctx.save();
            
            const gradient = ctx.createLinearGradient(card.x, card.y, card.x, card.y + height);
            gradient.addColorStop(0, 'rgba(40, 40, 40, 0.9)');
            gradient.addColorStop(1, 'rgba(20, 20, 20, 0.9)');
            ctx.fillStyle = gradient;
            drawRoundedRect(ctx, card.x, card.y, width, height, 12);
            ctx.fill();
            
            ctx.strokeStyle = card.color;
            ctx.lineWidth = 2;
            ctx.stroke();
            
            const iconX = card.x + 20;
            const iconY = card.y + 25;
            drawIcon(ctx, card.letter, iconX, iconY, 35, card.color);
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
            ctx.font = '14px sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.fillText(card.title, card.x + 70, card.y + 20);
            
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 24px sans-serif';
            ctx.fillText(card.value, card.x + 70, card.y + 40);
            
            ctx.strokeStyle = card.color;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(card.x + 70, card.y + 75);
            ctx.lineTo(card.x + width - 15, card.y + 75);
            ctx.stroke();
            
            ctx.restore();
        }

        function drawIcon(ctx, letter, x, y, size, color) {
            ctx.save();
            
            ctx.fillStyle = color + '20';
            ctx.beginPath();
            ctx.arc(x + size/2, y + size/2, size/2, 0, Math.PI * 2);
            ctx.fill();
            
            ctx.strokeStyle = color;
            ctx.lineWidth = 2;
            ctx.stroke();
            
            ctx.fillStyle = color;
            ctx.font = `bold ${size * 0.55}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(letter, x + size/2, y + size/2);
            
            ctx.restore();
        }

        async function drawCharts(ctx, x, y, width, height) {
            ctx.save();
            
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 32px sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.fillText('System Performance Analytics', x + 40, y);
            
            const chartY = y + 60;
            const chartHeight = height - 80;
            const chartWidth = (width - 160) / 3;
            
            const { totalMemory, freeMemory } = ram();
            const diskUsage = getDiskUsage();
            const cpuData = generateCPUData();
            
            const ramUsage = ((totalMemory - freeMemory) / totalMemory) * 100;
            const diskUsagePercent = ((diskUsage.totalSpace - diskUsage.freeSpace) / diskUsage.totalSpace) * 100;
            
            drawCircularChart(ctx, x + 40, chartY, chartWidth, chartHeight, ramUsage, 'RAM Usage', '#4a90e2');
            drawCircularChart(ctx, x + 40 + chartWidth + 40, chartY, chartWidth, chartHeight, diskUsagePercent, 'Storage Usage', '#5cb85c');
            drawLineChart(ctx, x + 40 + (chartWidth + 40) * 2, chartY, chartWidth, chartHeight, cpuData, 'CPU Load History', '#f0ad4e');
            
            ctx.restore();
        }

        function drawCircularChart(ctx, x, y, width, height, percentage, title, color) {
            ctx.save();
            
            const centerX = x + width / 2;
            const centerY = y + height / 2;
            const radius = Math.min(width, height) * 0.3;
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
            ctx.font = 'bold 18px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(title, centerX, y + 20);
            
            ctx.lineWidth = 12;
            ctx.lineCap = 'round';
            
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
            ctx.stroke();
            
            const angle = (percentage / 100) * Math.PI * 2 - Math.PI / 2;
            ctx.strokeStyle = color;
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, -Math.PI / 2, angle);
            ctx.stroke();
            
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 24px sans-serif';
            ctx.fillText(`${Math.round(percentage)}%`, centerX, centerY + 5);
            
            ctx.font = '14px sans-serif';
            ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
            ctx.fillText(getUsageDescription(percentage), centerX, centerY + 30);
            
            ctx.restore();
        }

        function drawLineChart(ctx, x, y, width, height, data, title, color) {
            ctx.save();
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
            ctx.font = 'bold 18px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(title, x + width / 2, y + 20);
            
            const chartX = x + 20;
            const chartY = y + 50;
            const chartWidth = width - 40;
            const chartHeight = height - 100;
            
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
            ctx.lineWidth = 1;
            for (let i = 0; i <= 4; i++) {
                const lineY = chartY + (chartHeight / 4) * i;
                ctx.beginPath();
                ctx.moveTo(chartX, lineY);
                ctx.lineTo(chartX + chartWidth, lineY);
                ctx.stroke();
            }
            
            const stepX = chartWidth / (data.length - 1);
            const maxValue = Math.max(...data);
            const minValue = Math.min(...data);
            const range = maxValue - minValue || 1;
            
            ctx.strokeStyle = color;
            ctx.lineWidth = 3;
            ctx.beginPath();
            
            data.forEach((value, index) => {
                const x_pos = chartX + index * stepX;
                const y_pos = chartY + chartHeight - ((value - minValue) / range) * chartHeight;
                
                if (index === 0) {
                    ctx.moveTo(x_pos, y_pos);
                } else {
                    ctx.lineTo(x_pos, y_pos);
                }
            });
            
            ctx.stroke();
            
            data.forEach((value, index) => {
                const x_pos = chartX + index * stepX;
                const y_pos = chartY + chartHeight - ((value - minValue) / range) * chartHeight;
                
                ctx.fillStyle = color;
                ctx.beginPath();
                ctx.arc(x_pos, y_pos, 4, 0, Math.PI * 2);
                ctx.fill();
            });
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(`Max: ${maxValue.toFixed(1)}%`, chartX, chartY - 10);
            ctx.textAlign = 'right';
            ctx.fillText(`Current: ${data[data.length - 1].toFixed(1)}%`, chartX + chartWidth, chartY - 10);
            
            ctx.restore();
        }

        function getUsageDescription(percentage) {
            if (percentage < 30) return 'Optimal';
            if (percentage < 60) return 'Good';
            if (percentage < 80) return 'High';
            return 'Critical';
        }

        function generateCPUData() {
            const data = [];
            let baseValue = 30;
            for (let i = 0; i < 20; i++) {
                baseValue += (Math.random() - 0.5) * 10;
                baseValue = Math.max(10, Math.min(90, baseValue));
                data.push(baseValue);
            }
            return data;
        }

        function drawFooter(ctx, x, y, width) {
            ctx.save();
            
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(x + 40, y);
            ctx.lineTo(x + width - 40, y);
            ctx.stroke();
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
            ctx.font = '16px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'top';
            ctx.fillText('© 2024 Allou Mohamed - Yuki Bot Analytics', 
                        x + width/2, y + 10);
            
            ctx.restore();
        }

        function drawRoundedRect(ctx, x, y, width, height, radius) {
            ctx.beginPath();
            ctx.moveTo(x + radius, y);
            ctx.lineTo(x + width - radius, y);
            ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
            ctx.lineTo(x + width, y + height - radius);
            ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
            ctx.lineTo(x + radius, y + height);
            ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
            ctx.lineTo(x, y + radius);
            ctx.quadraticCurveTo(x, y, x + radius, y);
            ctx.closePath();
        }

        function formatNumber(num) {
            if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
            if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
            return num.toString();
        }

        function formatUptime() {
            const uptimeInSeconds = process.uptime();
            const days = Math.floor(uptimeInSeconds / (24 * 60 * 60));
            const hours = Math.floor((uptimeInSeconds % (24 * 60 * 60)) / (60 * 60));
            const minutes = Math.floor((uptimeInSeconds % (60 * 60)) / 60);
            
            if (days > 0) return `${days}d ${hours}h`;
            if (hours > 0) return `${hours}h ${minutes}m`;
            return `${minutes}m`;
        }

        function getCurrentTime() {
            const algeriaOffset = 1;
            const now = new Date();
            const utc = now.getTime() + now.getTimezoneOffset() * 60000;
            const algeriaTime = new Date(utc + (3600000 * algeriaOffset));

            const options = {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            };
            
            return algeriaTime.toLocaleString('en-GB', options) + ' GMT+1';
        }

        function ram() {
            return {
                totalMemory: os.totalmem(),
                freeMemory: os.freemem()
            };
        }

        function getDiskUsage() {
            try {
                const diskPath = os.platform() === 'win32' ? 'C:' : '/';
                const { total, free } = disk.checkSync(diskPath);
                return { freeSpace: free, totalSpace: total };
            } catch (error) {
                return { freeSpace: 0, totalSpace: 1 };
            }
        }
    }
};
