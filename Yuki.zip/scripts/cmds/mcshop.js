const ITEMS_PER_PAGE = 30;
const MAX_PURCHASE_QUANTITY = 64;
const items_ = require('../../minecraft/items.js');

function FN(id) {
  const sliced = id.split("minecraft:")[1] || id;
  return sliced.replaceAll("_", "");
}

const items = Array.from(
  new Map(items_.map(obj => [obj.id, { ...obj, name: FN(obj.id) }])).values()
);

exports.config = {
  name: "mcshop",
  version: "@latest",
  by: "Allou Mohamed",
  countDown: 10,
  role: 0,
  category: ["Games", "ألعاب"],
  desc: "Minecraft server shop."
};

exports.onStart = async ({ message, args, event, commandName, usersData }) => {
  let searchTerm = null;
  let page = 1;

  if (args.length > 0) {
    const a0 = args[0].toLowerCase();
    if (!isNaN(a0)) {
      page = parseInt(a0, 10);
    } else {
      searchTerm = args[0];
      if (args.length > 1) {
        const a1 = args[1].toLowerCase();
        if (!isNaN(a1)) {
          page = parseInt(a1, 10);
        } else if (a1 === 'page' && args[2]) {
          page = parseInt(args[2], 10) || 1;
        }
      }
    }
  }

  let filtered = items;
  if (searchTerm) {
    const terms = searchTerm.toLowerCase().split(/\s+/);
    filtered = items.filter(it =>
      terms.every(term =>
        it.name.toLowerCase().includes(term) ||
        it.id.toLowerCase().includes(term)
      )
    );
    if (filtered.length === 0) {
      return message.reply(`❌ No items found matching “${searchTerm}”.`);
    }
  }

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  if (page < 1 || page > totalPages) {
    return message.reply(`❌ Invalid page. Please pick between 1 and ${totalPages}.`);
  }

  const startIdx = (page - 1) * ITEMS_PER_PAGE;
  const pageItems = filtered.slice(startIdx, startIdx + ITEMS_PER_PAGE);
  const userMoney = await usersData.getMoney(event.senderID);

  const header = helpers.boldify(`🛒 Shop${searchTerm ? ` (search: ${searchTerm})` : ''}`) + ` — Page ${page}/${totalPages}\n💰 Balance: ${userMoney} $\n\n`;
  const body = pageItems.map((it, i) =>
    `${i + 1}. ${it.name} — ${it.price} $`
  ).join('\n');
  const footer = `\n\n➡️ To navigate: \`/shop ${searchTerm ?? ''} [page]\`\n➡️ To buy: reply with the item index.`;

  const shopMsg = await message.reply(header + body + footer);

  global.YukiBot.onReply.set(shopMsg.messageID, {
    commandName,
    author: event.senderID,
    action: 'shop_select',
    searchTerm,
    page,
    filtered
  });
};

exports.onReply = async ({ Reply, message, usersData, event, commandName, args }) => {
  const { author, action, searchTerm, page: replyPage, filtered, itemIndex } = Reply;
  const { senderID } = event;
  if (senderID !== author) return;

  switch (action) {
    case 'shop_select': {
      const idx = parseInt(args[0], 10);
      if (isNaN(idx) || idx < 1 || idx > ITEMS_PER_PAGE) {
        return message.reply("❌ Invalid selection; please pick a number from the list.");
      }

      const startIdx = (replyPage - 1) * ITEMS_PER_PAGE;
      const item = filtered[startIdx + idx - 1];
      if (!item) {
        return message.reply("❌ Item not found — perhaps the page changed?");
      }

      const prompt = await message.reply(`You chose ${helpers.boldify(item.name)} (${item.price} $ each). How many would you like to buy? (max ${MAX_PURCHASE_QUANTITY})`);
      global.YukiBot.onReply.set(prompt.messageID, {
        commandName,
        author: senderID,
        action: 'confirm_shop',
        item,
      });
      break;
    }

    case 'confirm_shop': {
      const quantity = parseInt(args[0], 10);
      if (isNaN(quantity)) return message.reply("❌ Please enter a valid number.");
      if (quantity < 1) return message.reply("❌ You must buy at least one.");
      if (quantity > MAX_PURCHASE_QUANTITY) return message.reply(`❌ Max allowed per purchase is ${MAX_PURCHASE_QUANTITY}.`);

      const { item } = Reply;
      if (!item) return message.reply("❌ Item not found.");

      const totalPrice = item.price * quantity;
      const userMoney = await usersData.getMoney(senderID);
      if (totalPrice > userMoney) {
        return message.reply("❌ You don't have enough money.");
      }

      const mcData = await usersData.get(senderID, "data.minecraft");
      if (!mcData || (!mcData.name && !mcData.id)) {
        return message.reply("❌ You haven't linked your Minecraft account.");
      }

      if (!Array.isArray(mcData.runCmdOnJoin)) {
        mcData.runCmdOnJoin = [];
      }

      mcData.runCmdOnJoin.push(`/give @s ${item.id} ${quantity}`);
      await usersData.set(senderID, mcData, "data.minecraft");
      await usersData.subtractMoney(senderID, totalPrice);
      return message.reply(`✅ Purchase successful! You’ll receive ${quantity}×${helpers.boldify(item.name)} when you join the server.`);
    }

    default:
      return;
  }
};