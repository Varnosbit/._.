const fs = require("fs");
const path = require("path");
const axios = require("axios");
const FormData = require("form-data");

const config = {
  name: "anime",
  version: "2.1.0",
  role: 2,
  author: "Allou Mohamed",
  description: "Identify anime name and info from an image.",
  category: "Media",
  guide: "Reply to an anime screenshot with: anime",
  countDown: 10,
};

async function onStart({message, event}) {
  const attachment = event?.messageReply?.attachments?.[0];
  if (!attachment || attachment.type !== "photo") return message.reply("📷 Please reply to an anime image to identify it.");

  const imgUrl = attachment.url;
  const cacheDir = path.join(__dirname, "cache");
  const filePath = path.join(cacheDir, await utils.randomString(12));

  await message.reaction("🔍", event.messageID);

  try {
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir);
    const imgBuffer = await axios.get(imgUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(filePath, imgBuffer.data);

    const form = new FormData();
    form.append("image", fs.createReadStream(filePath));

    const { data } = await axios.post("https://api.trace.moe/search?anilistInfo=2", form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
       //'Accept-Encoding': 'gzip, deflate, br, zstd',
       'sec-ch-ua-platform': '"Android"',
       'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
       'sec-ch-ua-mobile': '?1',
       'origin': 'https://trace.moe',
       'sec-fetch-site': 'same-site',
       'sec-fetch-mode': 'cors',
       'sec-fetch-dest': 'empty',
       'accept-language': 'en,fr;q=0.9,ar;q=0.8',
       'priority': 'u=1, i'
      },
    });

    if (!data.result || data.result.length === 0) {
      await message.reaction("❌", event.messageID);
      fs.unlinkSync(filePath);
      return message.reply("❌ No anime found matching this image.");
    }

    const result = data.result[0];
    const anime = result.anilist;

    const body =
      `🎌 **Anime Identified Successfully!**\n\n` +
      `📺 Title: ${anime.title.romaji || anime.title.english || anime.title.native}\n` +
      (anime.title.english ? `🌐 English: ${anime.title.english}\n` : "") +
      (anime.title.native ? `🈶 Japanese: ${anime.title.native}\n` : "") +
      (anime.format ? `🎞️ Format: ${anime.format}\n` : "") +
      (anime.episodes ? `📆 Episodes: ${anime.episodes}\n` : "") +
      (anime.status ? `📡 Status: ${anime.status}\n` : "") +
      (anime.siteUrl ? `🔗 AniList: ${anime.siteUrl}\n` : "") +
      `\n🎯 Similarity: ${(result.similarity * 100).toFixed(2)}%`;

    const previewStream = await utils.getStreamFromUrl(anime.coverImage?.large || result.image);

    await message.reaction("✅", event.messageID);
    return message.reply({ body, attachment: previewStream }, () => {
      try {
        fs.unlinkSync(filePath);
      } catch {}
    });
  } catch (error) {
    console.error("Anime detection error:", error.response?.data || error.message);
    await message.reaction("⚠️", event.messageID);
    try {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    } catch {}
    return message.reply("⚠️ An error occurred while analyzing the image. Please try again later.\n>"+error.message);
  }
}

module.exports = { config, onStart };
