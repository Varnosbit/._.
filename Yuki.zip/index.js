//1.0.4
const { spawn } = require("child_process");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const log = require("./logger/log.js");

const USERNAME = "alloumohamed";
const REPO = "Yuki";
const GITHUB_TOKEN = "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";

function drawProgressBar(current, total, label = "") {
  const barLength = 50;
  const percentage = Math.floor((current / total) * 100);
  const filledLength = Math.floor((current / total) * barLength);
  
  const gradientColors = [
    '\x1b[38;5;201m',
    '\x1b[38;5;200m',
    '\x1b[38;5;199m',
    '\x1b[38;5;198m',
    '\x1b[38;5;165m',
    '\x1b[38;5;164m',
    '\x1b[38;5;129m',
    '\x1b[38;5;93m',
    '\x1b[38;5;57m',
    '\x1b[38;5;21m'
  ];
  
  let bar = '';
  for (let i = 0; i < barLength; i++) {
    if (i < filledLength) {
      const colorIndex = Math.floor((i / barLength) * gradientColors.length);
      bar += gradientColors[colorIndex] + '█';
    } else {
      bar += '\x1b[38;5;240m░';
    }
  }
  
  readline.clearLine(process.stdout, 0);
  readline.cursorTo(process.stdout, 0);
  
  const truncatedLabel = label.length > 30 ? label.substring(0, 27) + "..." : label;
  process.stdout.write(`  ${bar}\x1b[0m \x1b[1m${percentage}%\x1b[0m \x1b[90m|\x1b[0m ${truncatedLabel}`);
  
  if (current === total) {
    process.stdout.write('\n');
  }
}

async function getAllFoldersAndFiles(basePath = "") {
  const url = `https://api.github.com/repos/${USERNAME}/${REPO}/contents/${basePath}`;
  try {
    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3+json"
      },
      timeout: 10000
    });
    
    let allFiles = [];
    
    for (const item of response.data) {
      if (item.type === "file" && item.name.endsWith('.js')) {
        allFiles.push({
          name: item.name,
          path: item.path,
          download_url: item.download_url,
          folder: basePath
        });
      } else if (item.type === "dir") {
        const subFiles = await getAllFoldersAndFiles(item.path);
        allFiles = allFiles.concat(subFiles);
      }
    }
    
    return allFiles;
  } catch (err) {
    if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
      log.error("GitHub API timeout - check your connection");
    } else {
      log.error(`Failed to fetch repository: ${err.response?.data?.message || err.message}`);
    }
    return [];
  }
}

async function downloadGitHubFile(downloadUrl, localPath) {
  try {
    const response = await axios.get(downloadUrl, {
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3+json"
      },
      timeout: 15000
    });
    
    const dir = path.dirname(localPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(localPath, response.data);
    return true;
  } catch (err) {
    log.error(`Download failed for ${localPath}: ${err.message}`);
    return false;
  }
}

function extractVersionFromFile(filePath) {
  try {
    if (!fs.existsSync(filePath)) return null;
    const content = fs.readFileSync(filePath, 'utf8');
    
    const firstLineMatch = content.match(/^\/\/\s*(\d+\.\d+\.\d+)/);
    if (firstLineMatch) return firstLineMatch[1];
    
    const configMatch = content.match(/config\s*:\s*\{[^}]*version\s*:\s*['"']([^'"']+)['"'][^}]*\}/s);
    if (configMatch) return configMatch[1];
    
    const versionMatch = content.match(/version\s*:\s*['"']([^'"']+)['"']/);
    return versionMatch ? versionMatch[1] : null;
  } catch {
    return null;
  }
}

async function extractVersionFromGitHub(downloadUrl) {
  try {
    const response = await axios.get(downloadUrl, {
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3+json"
      },
      timeout: 10000
    });
    const content = response.data;
    
    const firstLineMatch = content.match(/^\/\/\s*(\d+\.\d+\.\d+)/);
    if (firstLineMatch) return firstLineMatch[1];
    
    const configMatch = content.match(/config\s*:\s*\{[^}]*version\s*:\s*['"']([^'"']+)['"'][^}]*\}/s);
    if (configMatch) return configMatch[1];
    
    const versionMatch = content.match(/version\s*:\s*['"']([^'"']+)['"']/);
    return versionMatch ? versionMatch[1] : null;
  } catch {
    return null;
  }
}

function versionsAreDifferent(version1, version2) {
  const normalize = v => {
    if (!v) return "0.0";
    return String(v).trim() || "0.0";
  };

  const v1 = normalize(version1).split('.').map(n => parseInt(n, 10) || 0);
  const v2 = normalize(version2).split('.').map(n => parseInt(n, 10) || 0);

  const maxLen = Math.max(v1.length, v2.length);

  for (let i = 0; i < maxLen; i++) {
    const a = v1[i] || 0;
    const b = v2[i] || 0;
    if (a !== b) return true;
  }

  return false;
}

async function syncAllFilesFromGitHub() {
  log.info("syncing GitHub..");
  if (!GITHUB_TOKEN) {
    log.error("GITHUB_TOKEN not found in environment variables");
    return false;
  }
  
  const allFiles = await getAllFoldersAndFiles();
  
  if (allFiles.length === 0) {
    log.warn("No JavaScript files found in GitHub repository");
    return false;
  }

  let downloaded = [];
  let updated = [];
  let skipped = [];
  let failed = [];
  let processed = 0;

  for (const githubFile of allFiles) {
    // FIX: Map directly to project root, not into a 'scripts' subfolder
    const localFilePath = path.join(process.cwd(), githubFile.path);
    const localExists = fs.existsSync(localFilePath);

    let shouldDownload = false;
    let actionType = "download";

    if (localExists) {
      const localVersion = extractVersionFromFile(localFilePath);
      const githubVersion = await extractVersionFromGitHub(githubFile.download_url);
      
      if (versionsAreDifferent(localVersion, githubVersion)) {
        shouldDownload = true;
        actionType = "update";
      } else {
        skipped.push(githubFile.path);
      }
    } else {
      shouldDownload = true;
      actionType = "download";
    }

    if (shouldDownload) {
      const success = await downloadGitHubFile(githubFile.download_url, localFilePath);
      if (success) {
        if (actionType === "update") {
          updated.push(githubFile.path);
        } else {
          downloaded.push(githubFile.path);
        }
      } else {
        failed.push(githubFile.path);
      }
    }
    
    processed++;
    drawProgressBar(processed, allFiles.length, githubFile.name);
  }

  console.log("\n\x1b[36m  ╔════════════════════════════════════════════════╗\x1b[0m");
  console.log("\x1b[36m  ║           📊 Sync Summary Results           ║\x1b[0m");
  console.log("\x1b[36m  ╚════════════════════════════════════════════════╝\x1b[0m");
  console.log(`  \x1b[32m✓ Downloaded:\x1b[0m \x1b[1m${downloaded.length}\x1b[0m file${downloaded.length !== 1 ? 's' : ''}`);
  console.log(`  \x1b[33m↻ Updated:\x1b[0m    \x1b[1m${updated.length}\x1b[0m file${updated.length !== 1 ? 's' : ''}`);
  console.log(`  \x1b[90m- Skipped:\x1b[0m    \x1b[1m${skipped.length}\x1b[0m file${skipped.length !== 1 ? 's' : ''}`);
  
  if (failed.length > 0) {
    console.log(`  \x1b[31m✗ Failed:\x1b[0m     \x1b[1m${failed.length}\x1b[0m file${failed.length !== 1 ? 's' : ''}`);
  }
  
  console.log("\x1b[36m  ════════════════════════════════════════════════\x1b[0m\n");
  
  return true;
}

async function pushToGit(filePath) {
  const localPath = path.resolve(process.cwd(), filePath);
  
  if (!fs.existsSync(localPath)) {
    return `❌ File not found: ${filePath}`;
  }
  
  try {
    const content = fs.readFileSync(localPath, "utf8");
    const base64Content = Buffer.from(content).toString("base64");

    const remotePath = filePath;
    const url = `https://api.github.com/repos/${USERNAME}/${REPO}/contents/${remotePath}`;

    let sha;
    try {
      const { data } = await axios.get(url, {
        headers: { Authorization: `Bearer ${GITHUB_TOKEN}` },
        timeout: 10000
      });
      sha = data.sha;
    } catch (err) {
      if (err.response?.status !== 404) throw err;
    }

    await axios.put(
      url,
      {
        message: `${sha ? "Update" : "Add"} ${remotePath}`,
        content: base64Content,
        sha: sha || undefined
      },
      {
        headers: { Authorization: `Bearer ${GITHUB_TOKEN}` },
        timeout: 15000
      }
    );

    return `✅ ${sha ? "Updated" : "Added"}: ${remotePath}`;
  } catch (err) {
    return `❌ Push failed: ${err.response?.data?.message || err.message}`;
  }
}

function startProject() {
  log.info("Starting Yuki bot...");
  
  const child = spawn("node", ["--no-deprecation", "--async-stack-traces", "Yuki.js"], {
    cwd: __dirname,
    stdio: "inherit",
    shell: true
  });

  child.on("close", (code) => {
    if (code === 2) {
      log.info("Restarting Project...");
      startProject();
    } else if (code !== 0) {
      log.error(`Process exited with code ${code}`);
    }
  });

  child.on("error", (err) => {
    log.error(`Failed to start process: ${err.message}`);
  });
}

async function initialize() {
  try {
    const syncSuccess = await syncAllFilesFromGitHub();
    
    if (syncSuccess) {
      log.success("GitHub sync completed successfully");
    } else {
      log.warn("GitHub sync completed with warnings");
    }
    
    startProject();
  } catch (err) {
    log.error(`Initialization failed: ${err.message}`);
    log.warn("Starting project without sync...");
    startProject();
  }
}

initialize();