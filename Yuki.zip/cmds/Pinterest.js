const axios = require('axios');
const qs = require('qs');
const { createCanvas, loadImage } = require('canvas');
const https = require('https');

const headers = {
  "accept": "application/json, text/javascript, */*; q=0.01",
  "accept-language": "en-US,en;q=0.9",
  "content-type": "application/x-www-form-urlencoded",
  "x-app-version": "d3189d8",
  "x-csrftoken": "8b3109af64f08fd976af53a4db0f94467",
  "x-pinterest-appstate": "active",
  "x-pinterest-pws-handler": "www/ideas.js",
  "x-requested-with": "XMLHttpRequest",
  "x-pinterest-source-url": "/ideas/",
  "referer": "https://fr.pinterest.com/",
  "cookie": "csrftoken=8b3109af64f08fd976af53a4db0f94467;",
  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123.0.0.0 Safari/537.36"
};

async function fetchPinterestImages(query, bookmark = "") {
  const options = {
    options: {
      query,
      //bookmarks: bookmark ? [bookmark] : []
      etslf: 25901,
  fields: 'explorearticle.cover_images[474x,236x,280x280],pin.images[736x,236x],board.images[150x150],user.explicitly_followed_by_me,pin.story_pin_data_id,pin.story_pin_data(),explorearticle.dominant_colors,board.id,pin.domain,user.last_name,pincarouseldata.id,user.is_partner,pin.is_eligible_for_brand_catalog,pin.tracking_params,pin.promoter(),pin.aggregated_pin_data(),video.duration,user.partner(),pincarouselslot.details,pin.source_interest(),pin.promoted_android_deep_link,pin.ad_match_reason,explorearticle.type,pincarouseldata.carousel_slots,pin.is_repin,pin.is_video,board.collaborator_invites_enabled,pin.is_native,pincarouselslot.rich_metadata,board.category,user.show_creator_profile,pin.category,user.id,pin.link,pin.requires_advertiser_attribution,pin.is_cpc_ad,pin.pinner(),aggregatedpindata.is_shop_the_look,pin.grid_title,aggregatedpindata.aggregated_stats,board.privacy,pin.id,pin.comment_count,pin.is_full_width,pin.promoted_is_removable,pin.native_creator(),pin.type,pin.dark_profile_link,pin.done_by_me,aggregatedpindata.comment_count,board.archived_by_me_at,user.custom_gender,explorearticle.subtitle,aggregatedpindata.did_it_data,board.name,pin.promoted_is_max_video,pin.via_pinner,explorearticle.show_cover,pin.image_crop,pincarouseldata.index,pin.dominant_color,pincarouselslot.images[345x,750x],aggregatedpindata.pin_tags,pin.is_eligible_for_web_closeup,pincarouselslot.title,pin.ad_destination_url,board.created_at,pin.image_signature,explorearticle.curator(),explorearticle.title,board.followed_by_me,user.full_name,pin.videos(),aggregatedpindata.pin_tags_chips,pin.closeup_description,board.owner(),user.is_default_image,pincarouselslot.id,user.first_name,explorearticle.video_cover_pin(),storypindata.page_count,pincarouselslot.domain,pin.created_at,pincarouselslot.link,user.type,board.type,aggregatedpindata.id,board.url,pin.description,pin.board(),pin.is_promoted,pin.cacheable_id,pin.carousel_data(),board.should_show_board_activity,explorearticle.content_type,user.verified_identity,explorearticle.story_category,board.image_cover_url,pin.shopping_flags,pin.embed(),pin.is_downstream_promotion,board.section_count,user.gender,pin.recommendation_reason,aggregatedpindata.is_stela,video.video_list[V_HLSV4],user.image_medium_url,user.username,pincarouselslot.ad_destination_url,explorearticle.id,video.id,board.pin_count,pin.rich_summary()',
  eq: query,
  dynamic_grid_stories: 6,
  page_size: 200,
  asterix: true,
  commerce_only: false,
  filters: '',
  rs: 'autocomplete',
  'term_meta[0]': `${query}|autocomplete|0`
    },
    context: {}
  };

  const body = qs.stringify({
    data: JSON.stringify(options),
    _: Date.now()
  });

  try {
    const res = await axios.post("https://www.pinterest.com/resource/BaseSearchResource/get/", body, { headers });
    const resource = res.data.resource_response;
    const nextBookmark = resource.bookmark || null;
    const results = [];

    for (const result of resource.data.results) {
      if (result.type === "story") continue;
      const images = result.images || {};
      results.push({
        url: result.link || `https://www.pinterest.com/pin/${result.id}/`,
        title: result.title || result.grid_title || "",
        content: result.rich_summary?.display_description || "",
        img_src: images["736x"]?.url || "",
        thumbnail_src: images["236x"]?.url || "",
        source: result.rich_summary?.site_name || ""
      });
    }

    return { results, nextBookmark };
  } catch (err) {
    console.error("Fetch failed:", err.response?.data || err.message);
    return { results: [], nextBookmark: null };
  }
}

class PinterestSearchUI {
  constructor(q, imageUrls) {
    this.imageUrls = imageUrls;
    this.canvasWidth = 2160;
    this.canvasHeight = 3840;
    this.padding = 15;
    this.headerHeight = 200;
    this.footerHeight = 120;
    this.imageWidth = 420;
    this.cornerRadius = 20;
    this.backgroundImageUrl = "https://i.imgur.com/kdVEbkA.jpeg";
    this.searchIconUrl = "https://i.imgur.com/GPvQGy6.png";
    this.columns = 5;
    this.q = q;
    this.imageSpacing = 12;
    this.calculateDynamicValues();
    this.imageCache = new Map();
    this.paginationCache = new Map();
  }

  calculateDynamicValues() {
    this.availableHeight = this.canvasHeight - this.headerHeight - this.footerHeight - (this.padding * 2);
    this.columnWidth = (this.canvasWidth - (this.padding * (this.columns + 1))) / this.columns;
    this.imageWidth = this.columnWidth - this.imageSpacing;
  }

  async downloadImage(url) {
    return new Promise((resolve, reject) => {
      https.get(url, (response) => {
        const chunks = [];
        response.on('data', (chunk) => chunks.push(chunk));
        response.on('end', () => {
          const buffer = Buffer.concat(chunks);
          resolve(buffer);
        });
        response.on('error', reject);
      }).on('error', reject);
    });
  }

  async loadImageFromUrl(url) {
    if (this.imageCache.has(url)) {
      return this.imageCache.get(url);
    }
    
    try {
      const buffer = await this.downloadImage(url);
      const image = await loadImage(buffer);
      this.imageCache.set(url, image);
      return image;
    } catch (error) {
      this.imageCache.set(url, null);
      return null;
    }
  }

  drawRoundedRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  calculateImageHeight(originalWidth, originalHeight) {
    const aspectRatio = originalWidth / originalHeight;
    return Math.round(this.imageWidth / aspectRatio);
  }

  async calculateOptimalLayout() {
    if (this.paginationCache.has('layout')) {
      return this.paginationCache.get('layout');
    }

    const pages = [];
    let currentIndex = 0;

    while (currentIndex < this.imageUrls.length) {
      const pageLayout = await this.calculatePageLayout(currentIndex);
      pages.push(pageLayout);
      currentIndex += pageLayout.images.length;
    }

    this.paginationCache.set('layout', pages);
    return pages;
  }

  async calculatePageLayout(startIndex) {
    const startY = this.headerHeight + this.padding;
    const columnHeights = new Array(this.columns).fill(startY);
    const maxAllowedBottom = this.canvasHeight - this.footerHeight - this.padding;
    const images = [];
    let currentIndex = startIndex;

    while (currentIndex < this.imageUrls.length) {
      const imageUrl = this.imageUrls[currentIndex];
      const img = await this.loadImageFromUrl(imageUrl);
      
      if (!img) {
        currentIndex++;
        continue;
      }

      const imageHeight = this.calculateImageHeight(img.width, img.height);
      let bestColumn = 0;
      let minHeight = columnHeights[0];

      for (let col = 1; col < this.columns; col++) {
        if (columnHeights[col] < minHeight) {
          minHeight = columnHeights[col];
          bestColumn = col;
        }
      }

      const imageBottom = minHeight + imageHeight + this.imageSpacing;
      
      if (imageBottom > maxAllowedBottom && images.length > 0) {
        break;
      }

      const x = this.padding + bestColumn * (this.columnWidth + this.padding);
      const y = minHeight;

      images.push({
        url: imageUrl,
        x,
        y,
        width: this.imageWidth,
        height: imageHeight,
        originalWidth: img.width,
        originalHeight: img.height,
        index: currentIndex
      });

      columnHeights[bestColumn] = y + imageHeight + this.imageSpacing;
      currentIndex++;

      if (images.length >= 50) break;
    }

    return { images, pageNumber: Math.floor(startIndex / 50) + 1 };
  }

  async generateSearchResults(page = 1) {
    const canvas = createCanvas(this.canvasWidth, this.canvasHeight);
    const ctx = canvas.getContext('2d');
    
    ctx.quality = 'best';
    ctx.patternQuality = 'best';
    ctx.textDrawingMode = 'glyph';
    ctx.antialias = 'subpixel';

    await this.drawBackground(ctx);
    await this.drawHeader(ctx);

    const layouts = await this.calculateOptimalLayout();
    const currentLayout = layouts[page - 1];
    
    if (!currentLayout) {
      return canvas;
    }

    for (let i = 0; i < currentLayout.images.length; i++) {
      const imgData = currentLayout.images[i];
      const img = await this.loadImageFromUrl(imgData.url);
      
      if (img) {
        await this.drawImageItem(ctx, img, imgData.x, imgData.y, imgData.width, imgData.height, 
                                imgData.index + 1, imgData.originalWidth, imgData.originalHeight);
      }
    }

    this.drawFooter(ctx, page, layouts.length);
    return canvas;
  }

  async drawBackground(ctx) {
    try {
      const backgroundImg = await this.loadImageFromUrl(this.backgroundImageUrl);
      
      if (backgroundImg) {
        ctx.drawImage(backgroundImg, 0, 0, this.canvasWidth, this.canvasHeight);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
        ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
      } else {
        const gradient = ctx.createLinearGradient(0, 0, this.canvasWidth, this.canvasHeight);
        gradient.addColorStop(0, '#1a2847');
        gradient.addColorStop(0.5, '#2d4a6b');
        gradient.addColorStop(1, '#3f5f7f');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
      }
    } catch (error) {
      const gradient = ctx.createLinearGradient(0, 0, this.canvasWidth, this.canvasHeight);
      gradient.addColorStop(0, '#1a2847');
      gradient.addColorStop(0.5, '#2d4a6b');
      gradient.addColorStop(1, '#3f5f7f');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
    }
  }

  drawTextWithShadow(ctx, text, x, y, shadowColor = 'rgba(255, 255, 255, 0.3)', shadowBlur = 4) {
    ctx.save();
    ctx.shadowColor = shadowColor;
    ctx.shadowBlur = shadowBlur;
    ctx.shadowOffsetX = 1;
    ctx.shadowOffsetY = 1;
    ctx.fillText(text, x, y);
    ctx.restore();
  }

  async drawHeader(ctx) {
    const Icon = await this.loadImageFromUrl(this.searchIconUrl);
    if (Icon) ctx.drawImage(Icon, 45, 25, 180, 180);
    
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 68px Arial';
    this.drawTextWithShadow(ctx, "Pinterest Searcher", 220, 110);

    ctx.font = 'bold 38px Arial';
    ctx.fillStyle = '#e8e8e8';
    this.drawTextWithShadow(ctx, `Search results of "${this.q}", Showing ${this.imageUrls.length} images.`, 220, 165);
  }

  async drawImageItem(ctx, img, x, y, displayWidth, displayHeight, number, originalWidth, originalHeight) {
    ctx.save();
    
    this.drawRoundedRect(ctx, x, y, displayWidth, displayHeight, this.cornerRadius);
    ctx.clip();
    
    ctx.drawImage(img, x, y, displayWidth, displayHeight);
    
    ctx.restore();

    const badgeWidth = 75;
    const badgeHeight = 42;
    const badgeX = x + 12;
    const badgeY = y + 12;
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
    this.drawRoundedRect(ctx, badgeX, badgeY, badgeWidth, badgeHeight, 8);
    ctx.fill();
    
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px Arial';
    ctx.textAlign = 'center';
    this.drawTextWithShadow(ctx, `#${number}`, badgeX + badgeWidth/2, badgeY + badgeHeight/2 + 9, 'rgba(255, 255, 255, 0.4)', 2);

    const counterText = `${number}/${this.imageUrls.length}`;
    ctx.font = 'bold 24px Arial';
    const counterMetrics = ctx.measureText(counterText);
    const counterBadgeWidth = counterMetrics.width + 26;
    const counterBadgeHeight = 38;
    const counterBadgeX = x + displayWidth - counterBadgeWidth - 12;
    const counterBadgeY = y + 12;
    
    ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
    this.drawRoundedRect(ctx, counterBadgeX, counterBadgeY, counterBadgeWidth, counterBadgeHeight, 8);
    ctx.fill();
    
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    this.drawTextWithShadow(ctx, counterText, counterBadgeX + counterBadgeWidth/2, counterBadgeY + counterBadgeHeight/2 + 8, 'rgba(255, 255, 255, 0.6)', 1);

    const dimensions = `${originalWidth} x ${originalHeight}`;
    ctx.font = 'bold 24px Arial';
    const textMetrics = ctx.measureText(dimensions);
    const dimBadgeWidth = textMetrics.width + 26;
    const dimBadgeHeight = 38;
    const dimBadgeX = x + displayWidth - dimBadgeWidth - 12;
    const dimBadgeY = y + displayHeight - dimBadgeHeight - 12;
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
    this.drawRoundedRect(ctx, dimBadgeX, dimBadgeY, dimBadgeWidth, dimBadgeHeight, 8);
    ctx.fill();
    
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    this.drawTextWithShadow(ctx, dimensions, dimBadgeX + dimBadgeWidth/2, dimBadgeY + dimBadgeHeight/2 + 8, 'rgba(255, 255, 255, 0.4)', 2);
    ctx.textAlign = 'left';
  }

  drawFooter(ctx, currentPage, totalPages) {
    const footerY = this.canvasHeight - 75;
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 44px Arial';
    ctx.textAlign = 'center';
    this.drawTextWithShadow(ctx, `YamiBot - Page ${currentPage}/${totalPages}`, this.canvasWidth/2, footerY + 25);
    ctx.textAlign = 'left';
  }

  async getTotalPages() {
    const layouts = await this.calculateOptimalLayout();
    return layouts.length;
  }

  async getPageInfo(page) {
    const layouts = await this.calculateOptimalLayout();
    return layouts[page - 1] || null;
  }
}

exports.config = {
  name: "pinterest",
  version: "@beta-1.2",
  role: 0,
  description: "Pinterest image search 🔍.",
  countDown: 30,
  category: "images",
  guide: "{pn} <search query> - Search Pinterest images\nReply with:\n- 'next' for next page\n- 'prev' for previous page\n- Numbers (1-9) to download specific images",
  aliases: ["pin"]
};

exports.onStart = async function({ message, args, commandName, event }) {
  const q = args.join(" ");
  
  if (!q) {
    return message.send("❌ Please provide a search query!\nUsage: pinterest <search term>");
  }

  try {
    message.reaction("⏳", event.messageID);
    
    //let bookmark = "";
    const allResults = await fetchPinterestImages(q);
   console.log(allResults.results);
    /*for (let i = 0; i < 4; i++) {
      const { results, nextBookmark } = await fetchPinterestImages(q, bookmark);
      allResults.push(...results);
      if (!nextBookmark) break;
      bookmark = nextBookmark;
      
      await new Promise(resolve => setTimeout(resolve, 100));
    }*/

    if (allResults.results.length === 0) {
      return message.send("❌ No images found for your search query.");
    }

    const URLS = allResults.results.map(r => r.img_src).filter(url => url && url.trim() !== "");
    
    if (URLS.length === 0) {
      return message.send("❌ No valid image URLs found.");
    }

    const generator = new PinterestSearchUI(q, URLS);
    const totalPages = await generator.getTotalPages();
    const pagesToSend = Math.min(10, totalPages);
    
    const attachment = [];
    
    for (let page = 1; page <= pagesToSend; page++) {
      const canvas = await generator.generateSearchResults(page);
      const stream = canvas.createPNGStream();
      stream.path = `pin_${page}.png`;
      attachment.push(stream);
    }
    message.reaction("✅", event.messageID);
    message.send({ attachment }, (error, info) => {
      if (error) {
        console.error("Canvas error:", error);
        return message.send("❌ Failed to generate search results image.");
      }
      
      global.YamiBot.onReply.set(info.messageID, {
        commandName,
        messageID: info.messageID,
        URLS,
        query: q,
        currentPage: 1,
        totalPages,
        author: event.senderID
      });
    });
    
  } catch (error) {
    console.error("Pinterest search error:", error);
    message.send("❌ An error occurred while searching Pinterest images.");
  }
};

exports.onReply = async function({ message, args, event, Reply }) {
  const { commandName, messageID, URLS, query, currentPage, totalPages, author } = Reply;
  
  if (author !== event.senderID) {
    return message.send("❌ Only the person who initiated the search can interact with it.");
  }

  const input = args.join(" ").toLowerCase().trim();

  try {
    if (input === "next") {
      const nextPage = currentPage + 3;
      
      if (nextPage > totalPages) {
        return message.send("❌ No more pages available!");
      }
      
      const generator = new PinterestSearchUI(query, URLS);
      const pagesToSend = Math.min(3, totalPages - nextPage + 1);
      const attachment = [];
      
      for (let page = nextPage; page < nextPage + pagesToSend; page++) {
        const canvas = await generator.generateSearchResults(page);
        const stream = canvas.createPNGStream();
        stream.path = `pin_${page}.png`;
        attachment.push(stream);
      }
      
      message.send({ attachment }, (error, info) => {
        if (error) {
          console.error("Canvas error:", error);
          return message.send("❌ Failed to generate next pages.");
        }
        
        global.YamiBot.onReply.set(info.messageID, {
          commandName,
          messageID: info.messageID,
          URLS,
          query,
          currentPage: nextPage,
          totalPages,
          author: event.senderID
        });
      });
      
    } else if (input === "prev" || input === "previous") {
      const prevPage = currentPage - 3;
      
      if (prevPage < 1) {
        return message.send("❌ You're already at the beginning!");
      }
      
      const generator = new PinterestSearchUI(query, URLS);
      const attachment = [];
      
      for (let page = prevPage; page < prevPage + 3 && page <= totalPages; page++) {
        const canvas = await generator.generateSearchResults(page);
        const stream = canvas.createPNGStream();
        stream.path = `pin_${page}.png`;
        attachment.push(stream);
      }
      
      message.send({ attachment }, (error, info) => {
        if (error) {
          console.error("Canvas error:", error);
          return message.send("❌ Failed to generate previous pages.");
        }
        
        global.YamiBot.onReply.set(info.messageID, {
          commandName,
          messageID: info.messageID,
          URLS,
          query,
          currentPage: prevPage,
          totalPages,
          author: event.senderID
        });
      });
      
    } else {
      const numbers = args.map(arg => {
        const num = parseInt(arg);
        return isNaN(num) ? null : num;
      }).filter(num => num !== null && num > 0 && num <= URLS.length);
      
      if (numbers.length === 0) {
        return message.send("❌ Please provide valid image numbers or use 'next'/'prev' for navigation.\nExample: 1 3 5 (to select images 1, 3, and 5)");
      }
      
      if (numbers.length > 9) {
        return message.send("❌ You can only select up to 9 images at once!");
      }
      
      const selectedURLs = numbers.map(num => URLS[num - 1]).filter(url => url);
      
      if (selectedURLs.length === 0) {
        return message.send("❌ No valid images found for the selected numbers.");
      }
      
      message.send(`📤 Sending ${selectedURLs.length} selected image(s)...`);
     
      return message.stream(selectedURLs);
    }
    
  } catch (error) {
    console.error("Reply handler error:", error);
    message.send("❌ An error occurred while processing your request.");
  }
};