const { commands: cmds } = YamiBot;

exports.config = {
    name: "help",
    aliases: ["cmds"],
    role: 0,
    description: "Show list of available commands or detailed information about a specific command",
    guide: {
        syntax: "{pn} [command_name]",
        params: "command_name",
        usage: "Optional"
    },
    countDown: 5,
    category: "Helper",
    hide: false,
    author: "Allou Mohamed",
    version: "2.1.0",
    price: "Free"
};

exports.onStart = async function({ message, role, args, event, prefix }) {
    const userInput = args.join(' ').trim();
    if (!userInput || !isNaN(parseInt(userInput))) {
        let helpList = `# %bdCommand List%\n\n`;
        
        const allCommands = Array.from(cmds.values()).filter(cmd => !cmd.config.hide || role >= 2);
        
        const categorizedCommands = {};
        
        allCommands.forEach(cmd => {
            const category = getCommandCategory(cmd);
            if (!categorizedCommands[category]) {
                categorizedCommands[category] = [];
            }
            categorizedCommands[category].push(cmd.config.name);
        });
        
        const sortedCategories = Object.keys(categorizedCommands).sort();
        
        sortedCategories.forEach(category => {
            const commands = categorizedCommands[category].sort();
            const count = commands.length;
            
            helpList += `- %bd${category}% (${count})\n`;
            helpList += `${commands.join(', ')}\n\n`;
        });
        
        helpList += `Use %bd${prefix}help <command>% for more information.`;
        
        return message.reply(helpList);
    }
    
    let commandName = userInput.toLowerCase();
    let command = YamiBot.commands.get(commandName) || YamiBot.commands.get(YamiBot.aliases.get(commandName));
    
    if (!command) {
        return message.reply("I don't have this command.");
    }
    
    const {config} = command;
    const name = config.name || "Unnamed";
    const description = getCmdDesc(command);
    const cooldown = config.countDown || 0;
    const price = getPrice(config);
    const author = getAuthor(config);
    const guideInfo = getGuideInfo(command);
    const syntax = getSyntax(command, prefix);

    let Details = `# %bdCommand Information%\n${description}\n\n`;
    Details += `• %bdName%: ${name}\n`;
    Details += `• %bdPrice%: ${price}\n`;
    Details += `• %bdAuthor%: ${author}\n\n`;
    Details += `• %bdArguments%\n`;
    Details += `- %bdUsage%: ${guideInfo.usage}\n`;
    Details += `- %bdParams%: ${guideInfo.params}\n\n`;
    Details += `• %bdCooldown%: ${cooldown > 0 ? cooldown + ' seconds' : '-'}\n\n`;
    Details += `• %bdSyntax%\n${syntax}`;
    
    return message.reply(Details);
};

function getCmdDesc(cmd) {
    const possibleObjNames = ["description", "desc", "shortDescription", "longDescription"];

    for (const name of possibleObjNames) {
        const descObj = cmd.config[name];

        if (typeof descObj === 'string') return descObj;

        if (typeof descObj === 'object' && descObj !== null) {
            if (descObj["en"]) return descObj["en"];
            const values = Object.values(descObj);
            if (values.length > 0) return values[0];
        }
    }

    return "No description available.";
}

function getCommandCategory(cmd) {
    const category = cmd.config.category;
    
    if (typeof category === 'string') {
        return capitalizeFirst(category);
    } else if (Array.isArray(category)) {
        return capitalizeFirst(category[0] || "Other");
    } else if (typeof category === 'object' && category !== null) {
        if (category["en"]) return capitalizeFirst(category["en"]);
        const values = Object.values(category);
        if (values.length > 0) return capitalizeFirst(values[0]);
    }
    
    return "Other";
}

function capitalizeFirst(str) {
    if (!str || typeof str !== 'string') return "Other";
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

function getPrice(config) {
    if (!config.price || config.price === 0 || config.price === "0") {
        return "Free";
    }
    return config.price;
}

function getAuthor(config) {
    if (!config.author) {
        return "-";
    }
    return config.author;
}

function getGuideInfo(cmd) {
    const guide = cmd.config.guide;
    let usage = "Optional";
    let params = "none";
    
    if (typeof guide === 'string') {
        const matches = guide.match(/<([^>]+)>/g);
        if (matches) {
            usage = "Required";
            params = matches.map(match => match.replace(/[<>]/g, '')).join(', ');
        }
    } else if (typeof guide === 'object' && guide !== null) {
        const guideObj = guide["en"] || guide;
        
        if (guideObj.usage) {
            usage = guideObj.usage;
        } else if (guideObj.params) {
            usage = "Required";
        }
        
        if (guideObj.params) {
            if (typeof guideObj.params === 'string') {
                params = guideObj.params;
            } else if (Array.isArray(guideObj.params)) {
                params = guideObj.params.join(', ');
            }
        } else if (guideObj.syntax) {
            const matches = guideObj.syntax.match(/<([^>]+)>/g);
            if (matches) {
                usage = "Required";
                params = matches.map(match => match.replace(/[<>]/g, '')).join(', ');
            }
        }
    }
    
    if (!params || params === "none" || params === "") {
        params = "-";
    }
    if (!usage || usage === "") {
        usage = "-";
    }
    
    return { usage, params };
}

function getSyntax(cmd, prefix = ".") {
    const name = cmd.config.name;
    const guide = cmd.config.guide;
    
    if (typeof guide === 'string') {
        let syntax = guide.replace(/{pn}/g, `${prefix}${name}`);
        return syntax.startsWith(name) ? syntax.replace(name, `${prefix}${name}`) : syntax;
    } else if (typeof guide === 'object' && guide !== null) {
        const guideObj = guide["en"] || guide;
        
        if (guideObj.syntax) {
            let syntax = guideObj.syntax.replace(/{pn}/g, `${prefix}${name}`);
            return syntax.startsWith(name) ? 
                syntax.replace(name, `${prefix}${name}`) : 
                syntax;
        } else if (typeof guideObj === 'string') {
            let syntax = guideObj.replace(/{pn}/g, `${prefix}${name}`);
            return syntax.startsWith(name) ? 
                syntax.replace(name, `${prefix}${name}`) : 
                syntax;
        }
    }
    
    return `${prefix}${name}`;
}
