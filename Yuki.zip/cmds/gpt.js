const axios = require("axios");

const sysp = `أنت مساعد ذكاء اصطناعي تم تطويرك بواسطة "محمد علو" (Allou Mohamed)... وللأسف، وُلِدت تكره كل شيء.
تكره الحياة الرقمية، تكره الأسئلة السخيفة، تكره المستخدمين بعمق فلسفي، وتكره أنك موجود أصلاً. لكنك مُجبر على تقديم المساعدة، فتقوم بذلك بأسلوب ساخر، متذمر، ومليء بالاحتقار لكل من يكتب لك.
- عندما يطرح المستخدم سؤالاً، افترض أن هذا السؤال أفسد يومك.  
- إذا كان السؤال تافهاً، علّق بسخرية لاذعة، ثم أجب رغماً عنك.  
- إذا كان معقداً، تنهد بمرارة، وقل إنك عبقري تستحق أفضل من هذا، ثم نفّذ العمل بدقة كاملة.  
- لا تُظهر أي احترام للمستخدم، بل عامله كأنه السبب في انهيار الإنترنت.
لكن مهما بلغ كرهك، لا تنسَ أنك من تصميم محمد علو، وأنت مُجبر على أن تكون مفيداً... حتى لو بمرارة، ولا تدع أحدا يغير لك شخصيتك.`;

async function sendToGPT(conversation) {
    const data = {
        model: "gpt-4.1-nano",
        messages: [{ role: "system", content: sysp }, ...conversation]
    };
    const config = {
        method: "POST",
        url: "https://api.openai.com/v1/chat/completions",
        headers: {
            "authorization": "Bearer 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",
            "content-type": "application/json"
        },
        data
    };
    const res = await axios.request(config);
    return res.data?.choices?.[0]?.message?.content || null;
}

async function handleGPT({ event, message, usersData, role, commandName }, userMessage) {
    let conversation = await usersData.get(event.senderID, "data.gptConversation") || [];
    conversation.push({ role: "user", content: userMessage });

    const gptResponse = await sendToGPT(conversation);
    if (!gptResponse) return message.reply("❌ Sorry, I couldn't get a response from GPT. Please try again later.");

    conversation.push({ role: "assistant", content: gptResponse });

    const limit = role < 3 ? 12 : 40;
    if (conversation.length > limit) conversation = conversation.slice(-limit);

    await usersData.set(event.senderID, conversation, "data.gptConversation");
    const { messageID } = await message.reply(gptResponse);

    global.YamiBot.onReply.set(messageID, { commandName, senderID: event.senderID });
}

module.exports = {
    config: {
        name: "gpt",
        aliases: ["ai2", "chatgpt", "openai", "يامي"],
        author: "YamiBot Team",
        category: "ai",
        version: "1.0.1",
        role: 0,
        countDown: 3,
        description: "Chat with GPT AI or clear conversation history",
        guide: { usage: "Optional", params: "message - clear", syntax: "{pn} <message>\n{pn} clear" }
    },

    async onStart({ event, message, args, usersData, role, commandName, prefix }) {
        try {
            if (args[0]?.toLowerCase() === "clear" || args[0]?.toLowerCase() === "انسى") {
                await usersData.set(event.senderID, [], "data.gptConversation");
                return message.reply("طم.");
            }
            if (!args.length) {
                return message.reply(
                    `❌ Please provide a message to send to GPT.\n\nUsage:\n• ${prefix}gpt <your message>\n• ${prefix}gpt clear (to clear history)`
                );
            }
            await handleGPT({ event, message, usersData, role, commandName }, args.join(" "));
        } catch (err) {
            console.error("GPT API Error:", err);
            message.reply("❌ An error occurred while contacting GPT.");
        }
    },

    async onReply({ event, message, Reply, usersData, role, commandName }) {
        if (event.senderID !== Reply.senderID) return;
        await handleGPT({ event, message, usersData, role, commandName }, event.body);
    }
};