const fs = require("fs");
const path = require("path");
const Config = require('./Config');

const DB_PATH = path.join(process.cwd(), "database", "data", "database.json");

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initialDB = {
      playerStats: {},
      shopPurchases: {},
      playerRooms: {},
      playerInRoom: {},
      exchangeRate: Config.exchangeRate
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialDB, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

let DB = loadDB();

function getDB() {
  return DB;
}

function reloadDB() {
  DB = loadDB();
  return DB;
}

function getPlayerRoom(userID) {
  if (!DB.playerRooms) DB.playerRooms = {};
  return DB.playerRooms[userID] || null;
}

function savePlayerRoom(userID, groupID) {
  if (!DB.playerRooms) DB.playerRooms = {};
  DB.playerRooms[userID] = groupID;
  if (!DB.playerInRoom) DB.playerInRoom = {};
  DB.playerInRoom[userID] = groupID;
  saveDB(DB);
}

function removePlayerFromRoom(userID) {
  if (!DB.playerInRoom) DB.playerInRoom = {};
  delete DB.playerInRoom[userID];
  if (DB.playerRooms) {
    delete DB.playerRooms[userID];
  }
  saveDB(DB);
}

function clearAllPlayerRooms() {
  DB.playerInRoom = {};
  saveDB(DB);
}

function initPlayerStats(userID) {
  if (!DB.playerStats) DB.playerStats = {};
  if (!DB.playerStats[userID]) {
    DB.playerStats[userID] = {
      gamesPlayed: 0,
      wins: 0,
      losses: 0,
      kills: 0,
      deaths: 0,
      correctVotes: 0,
      wrongVotes: 0,
      survivalRate: 0,
      winRate: 0,
      money: 0,
      points: 0,
      successfulSkills: 0,
      failedSkills: 0,
      teamKills: 0
    };
  }
  return DB.playerStats[userID];
}

function updatePlayerStats(userID, updates) {
  const stats = initPlayerStats(userID);
  Object.assign(stats, updates);
  if (stats.gamesPlayed > 0) {
    stats.winRate = ((stats.wins / stats.gamesPlayed) * 100).toFixed(1);
    stats.survivalRate = (((stats.gamesPlayed - stats.deaths) / stats.gamesPlayed) * 100).toFixed(1);
  }
  saveDB(DB);
  return stats;
}

function incrementStat(userID, statName, value = 1) {
  const stats = initPlayerStats(userID);
  stats[statName] = (stats[statName] || 0) + value;
  updatePlayerStats(userID, stats);
  return stats[statName];
}

function awardPlayer(userID, money, points, reason, usersData) {
  const stats = initPlayerStats(userID);
  stats.money += money;
  stats.points += points;
  if (money > 0 && usersData) {
    usersData.addMoney(userID, money);
  }
  saveDB(DB);
  return { money, points, reason };
}

function getPlayerPurchases(userID) {
  if (!DB.shopPurchases) DB.shopPurchases = {};
  if (!DB.shopPurchases[userID]) {
    DB.shopPurchases[userID] = {};
  }
  return DB.shopPurchases[userID];
}

function addPurchaseToInventory(userID, itemKey) {
  const purchases = getPlayerPurchases(userID);
  if (!purchases[itemKey]) {
    purchases[itemKey] = { count: 0 };
  }
  purchases[itemKey].count++;
  saveDB(DB);
}

function removePurchaseFromInventory(userID, itemKey) {
  const purchases = getPlayerPurchases(userID);
  if (purchases[itemKey] && purchases[itemKey].count > 0) {
    purchases[itemKey].count--;
    if (purchases[itemKey].count === 0) {
      delete purchases[itemKey];
    }
    saveDB(DB);
    return true;
  }
  return false;
}

function hasPurchase(userID, itemKey) {
  const purchases = getPlayerPurchases(userID);
  return purchases[itemKey] && purchases[itemKey].count > 0;
}

function getPurchaseCount(userID, itemKey) {
  const purchases = getPlayerPurchases(userID);
  return purchases[itemKey] ? purchases[itemKey].count : 0;
}

function getAllPlayerStats() {
  if (!DB.playerStats) return {};
  return DB.playerStats;
}

function getPlayerStats(userID) {
  return initPlayerStats(userID);
}

function deductMoney(userID, amount) {
  const stats = initPlayerStats(userID);
  if (stats.money < amount) {
    return false;
  }
  stats.money -= amount;
  saveDB(DB);
  return true;
}

function addMoney(userID, amount) {
  const stats = initPlayerStats(userID);
  stats.money += amount;
  saveDB(DB);
  return stats.money;
}

function exchangePoints(userID, points) {
  const stats = initPlayerStats(userID);
  if (stats.points < points) {
    return { success: false, reason: "insufficient_points" };
  }
  
  const money = Math.floor(points / DB.exchangeRate);
  if (money < 1) {
    return { success: false, reason: "below_minimum" };
  }
  
  const actualPoints = money * DB.exchangeRate;
  stats.points -= actualPoints;
  stats.money += money;
  saveDB(DB);
  
  return { 
    success: true, 
    money, 
    pointsUsed: actualPoints,
    remainingPoints: stats.points,
    remainingMoney: stats.money
  };
}

function recordVote(userID, isCorrect) {
  const stats = initPlayerStats(userID);
  if (isCorrect) {
    stats.correctVotes++;
  } else {
    stats.wrongVotes++;
  }
  saveDB(DB);
}

function recordKill(killerID, victimID, isTeamKill = false) {
  const killerStats = initPlayerStats(killerID);
  const victimStats = initPlayerStats(victimID);
  
  if (isTeamKill) {
    killerStats.teamKills++;
    killerStats.failedSkills++;
  } else {
    killerStats.kills++;
    killerStats.successfulSkills++;
  }
  
  victimStats.deaths++;
  saveDB(DB);
  
  return { killerStats, victimStats };
}

function recordSkillUse(userID, success) {
  const stats = initPlayerStats(userID);
  if (success) {
    stats.successfulSkills++;
  } else {
    stats.failedSkills++;
  }
  saveDB(DB);
}

function recordGameResult(userID, won, survived) {
  const stats = initPlayerStats(userID);
  stats.gamesPlayed++;
  
  if (won) {
    stats.wins++;
  } else {
    stats.losses++;
  }
  
  if (!survived) {
    stats.deaths++;
  }
  
  updatePlayerStats(userID, stats);
  return stats;
}

function getTopPlayers(limit = 10) {
  const allStats = getAllPlayerStats();
  const entries = Object.entries(allStats).map(([id, stats]) => ({
    userID: id,
    ...stats
  }));
  
  return entries
    .sort((a, b) => {
      const scoreA = (a.wins * 15) + (a.kills * 8) + (a.correctVotes * 5) - (a.wrongVotes * 3);
      const scoreB = (b.wins * 15) + (b.kills * 8) + (b.correctVotes * 5) - (b.wrongVotes * 3);
      return scoreB - scoreA;
    })
    .slice(0, limit);
}

function resetPlayerStats(userID) {
  if (!DB.playerStats) DB.playerStats = {};
  DB.playerStats[userID] = {
    gamesPlayed: 0,
    wins: 0,
    losses: 0,
    kills: 0,
    deaths: 0,
    correctVotes: 0,
    wrongVotes: 0,
    survivalRate: 0,
    winRate: 0,
    money: DB.playerStats[userID]?.money || 0,
    points: DB.playerStats[userID]?.points || 0,
    successfulSkills: 0,
    failedSkills: 0,
    teamKills: 0
  };
  saveDB(DB);
  return DB.playerStats[userID];
}

function clearInventory(userID) {
  if (!DB.shopPurchases) DB.shopPurchases = {};
  DB.shopPurchases[userID] = {};
  saveDB(DB);
}

function getExchangeRate() {
  return DB.exchangeRate || Config.exchangeRate;
}

function setExchangeRate(rate) {
  DB.exchangeRate = rate;
  saveDB(DB);
}

module.exports = {
  loadDB,
  saveDB,
  getDB,
  reloadDB,
  getPlayerRoom,
  savePlayerRoom,
  removePlayerFromRoom,
  clearAllPlayerRooms,
  initPlayerStats,
  updatePlayerStats,
  incrementStat,
  awardPlayer,
  getPlayerPurchases,
  addPurchaseToInventory,
  removePurchaseFromInventory,
  hasPurchase,
  getPurchaseCount,
  getAllPlayerStats,
  getPlayerStats,
  deductMoney,
  addMoney,
  exchangePoints,
  recordVote,
  recordKill,
  recordSkillUse,
  recordGameResult,
  getTopPlayers,
  resetPlayerStats,
  clearInventory,
  getExchangeRate,
  setExchangeRate
};
