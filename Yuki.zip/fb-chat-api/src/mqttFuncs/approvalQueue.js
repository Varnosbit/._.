'use strict';

const { generateOfflineThreadingID } = require('../../utils');

module.exports = function (defaultFuncs, api, ctx) {
  /**
   * Approve or deny a pending member request in a thread
   * @param {string|number} threadID - Conversation ID
   * @param {Array<string|number>} contactIDs - Array of user IDs to approve/deny
   * @param {boolean} accepted - true = approve, false = deny
   * @param {function} [callback] - Optional callback(err)
   */
  return function approvalQueue(threadID, contactIDs, accepted = true, callback) {
    // ✅ Connection check
    if (!ctx.mqttClient) {
      throw new Error('Not connected to MQTT');
    }

    // ✅ Param checks
    if (!threadID || (typeof threadID !== 'string' && typeof threadID !== 'number')) {
      throw new TypeError('approvalQueue: threadID must be a string or number');
    }

    if (!Array.isArray(contactIDs) || contactIDs.length === 0) {
      throw new TypeError('approvalQueue: contactIDs must be a non-empty array of IDs');
    }

    if (typeof accepted !== 'boolean') {
      throw new TypeError('approvalQueue: accepted must be a boolean');
    }

    if (callback && typeof callback !== 'function') {
      throw new TypeError('approvalQueue: callback must be a function if provided');
    }

    ctx.wsReqNumber += 1;
    let taskNumber = ++ctx.wsTaskNumber;

    const taskPayload = {
      thread_key: threadID,
      contact_ids: contactIDs,
      accepted: accepted ? 1 : 0,
    };

    const task = {
      failure_count: null,
      label: '27', // Messenger internal op code for approval requests
      payload: JSON.stringify(taskPayload),
      queue_name: 'respond_to_admin_approval_request',
      task_id: taskNumber,
    };

    const content = {
      app_id: '772021112871879',
      payload: JSON.stringify({
        epoch_id: parseInt(generateOfflineThreadingID()),
        tasks: [task],
        version_id: '31485834987728002',
      }),
      pwa_version: '1',
      request_id: ctx.wsReqNumber,
      type: 3,
    };

    try {
      ctx.mqttClient.publish(
        '/ls_req',
        JSON.stringify(content),
        { qos: 1, retain: false },
        callback || (() => {})
      );
    } catch (err) {
      if (callback) callback(err);
      else throw err;
    }
  };
};
