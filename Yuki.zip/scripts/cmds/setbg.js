const {
    YukiBB
} = global.helpers;
module.exports = {
    config: {
        name: "setcov",
        aliases: ["كوفر", "bg", "سيتكوفر"],
        role: 0,
        description: {
            en: "Change cover photo",
            ar: "تغيير صورة الغلاف."
        },
        category: "Status",
        countDown: 10
    },
    onStart: async function({
        message, event, usersData
    }) {
        const id = event.senderID;
        const image = event?.messageReply?.attachments[0]?.url;
        if (!image) {
            await helpers.setP(usersData, id, "cover");
            message.reply("Your cover photo has been successfully changed to the default image.");
            return;
        }
        const z = "cover";
        const upload = await YukiBB(image);
        const x = upload.stream;
        await helpers.setP(usersData, id, x, z);
        message.reply("Your cover photo has been successfully changed.");
    }
};