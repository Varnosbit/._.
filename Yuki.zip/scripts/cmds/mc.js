const mcs = require('node-mcstatus');
const axios = require("axios");

if (!global.minecraft) {
    global.minecraft = new Map();
}
exports.config = {
    name: "mc",
    aliases: ["ماينكرافت"],
    version: "@latest",
    by: "Allou Mohamed",
    countDown: 10,
    role: 0,
    category: ["Games", "ألعاب"]
};

exports.onStart = async ({ message, args, usersData, event, globalData, role }) => {
    let { host, port } = await globalData.get("minecraft", "data.server", {
        host: "ArabCraftServer.aternos.me",
        port: 59870
    });

    if (args.length > 0) {
        
        if (args[0] === "stop") {
            if (role < 3) return;
            potato("stop").then(s => {
                if (s == 200) {
                    message.reply(helpers.boldify("⛔ I turned off the server."));
                } else {
                    message.reply(helpers.boldify("⚠️ Server returned unknown status.")+"\n#XRGV07");
                }
            });
            return;
        }
        
        if (args[0] === "update") {
            const [host,port] = args[1].split(":");
            await globalData.set("minecraft", {host, port}, "data.server");
            return message.reply("d.o.n.e\n\t\t\t☝️😊");
        }
        if (args[0] === "link") {
            const key = args[1].trim();
            const data = global.minecraft.get(key);
            if (!data) return message.reply("الرمز غير صالح. يرجى التأكد من نسخ الرمز الصحيح من دردشة السيرفر:\nاكتب +link في شات السيرفر للحصول على الرمز. لا تشاركه مع أي أحد.");
            await usersData.set(event.senderID, data, "data.minecraft");
            global.minecraft.delete(key);
            return message.reply(`${data.name} تم ربطك بالمسنجر بنجاح.`);
        }

        const input = args.join(" ").trim();
        const [inputHost, inputPortStr] = input.split(":");
        if (inputHost) host = inputHost.trim();
        if (inputPortStr && /^\d+$/.test(inputPortStr)) port = parseInt(inputPortStr.trim());
    }

    try {
        const res = await mcs.statusBedrock(host, port);

        if (!res || !res.online) {
            potato("start").then(s => {
                if (s == 200) {
                    message.reply(helpers.boldify("✅ I turned on the server. wait 2 minutes and join."));
                } else {
                    message.reply(helpers.boldify("⚠️ Server returned unknown status.")+"\n#XRGV07");
                }
            });
            return;
        }

        const bold = helpers.boldify;
        const motd = res.motd?.clean.split("\n")[0] || "No MOTD available";

        const serverInfo = `${bold("# Minecraft Server Status")}

- ${bold("Gamemode")}: ${res.gamemode}
- ${bold("Edition")}: ${res.edition}
- ${bold("Version")}: ${res.version.name} (Protocol ${res.version.protocol})

- ${bold("Players")}: ${res.players.online} / ${res.players.max}
- ${bold("MOTD")}: ${motd}

- ${bold("IP Address")}: ${host}
- ${bold("Port")}: ${res.port}
- ${bold("Online players")}: http://193.149.164.168:5505/onLinePlayers
- ${bold("Download Minecraft")}: https://mcpedl.org/uploads_files/28-03-2025/minecraft-1-21-71.apk
`;

        return message.reply(serverInfo);
    } catch (error) {
        console.error("Minecraft status error:", error);
        return message.reply(helpers.boldify("⚠️ Failed to retrieve server status. Please verify the IP and port."));
    }
};

async function potato(power) {
  try {
    const MAIN = (await axios.get(`https://raw.githubusercontent.com/Tanvir0999/stuffs/main/raw/addresses.json`)).data.main;
    const response = await axios.post(`${MAIN}/homo/potato/server`, { power });
    return response.status;
  } catch (error) {
    throw new Error(error);
  }
}