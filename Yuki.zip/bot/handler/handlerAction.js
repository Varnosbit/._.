class EventListener {
	constructor() {
		this.listeners = new Map();
	}

	add(key, conditionFunc, resultFunc, timeoutMs = 600000) {
		if (!key || typeof key !== 'string') {
			throw new Error("Invalid key for EventListener.");
		}

		if (typeof conditionFunc !== 'function' || typeof resultFunc !== 'function') {
			throw new Error("Both conditionFunc and resultFunc must be functions.");
		}

		if (conditionFunc.constructor.name !== 'AsyncFunction') {
			const original = conditionFunc;
			conditionFunc = async (...args) => original(...args);
		}
		if (resultFunc.constructor.name !== 'AsyncFunction') {
			const original = resultFunc;
			resultFunc = async (...args) => original(...args);
		}

		const existing = this.listeners.get(key);
		if (existing?.timeout) clearTimeout(existing.timeout);

		const timeout = setTimeout(() => {
			this.listeners.delete(key);
			console.warn(`Listener [${key}] expired after ${timeoutMs}ms.`);
		}, timeoutMs);

		this.listeners.set(key, {
			conditionFunc,
			resultFunc,
			timeout
		});
	}

	async triggerAll(params) {
		for (const [key, listener] of this.listeners) {
			const { conditionFunc, resultFunc, timeout } = listener;

			try {
				const shouldTrigger = await conditionFunc(params);
				if (shouldTrigger) {
					await resultFunc(params);
					clearTimeout(timeout);
					this.listeners.delete(key);
				}
			} catch (err) {
				console.error(`EventListener error on key "${key}":`, err);
				clearTimeout(timeout);
				this.listeners.delete(key);
			}
		}
	}

	clear(key) {
		if (!this.listeners.has(key)) return false;
		const { timeout } = this.listeners.get(key);
		if (timeout) clearTimeout(timeout);
		this.listeners.delete(key);
		return true;
	}

	clearAll() {
		for (const [key, listener] of this.listeners) {
			clearTimeout(listener.timeout);
		}
		this.listeners.clear();
	}
}

global.onListen = new EventListener();
const createFuncMessage = global.utils.message;
const handlerCheckDB = require("./handlerCheckData.js");

module.exports = (api, threadModel, userModel, dashBoardModel, globalModel, usersData, threadsData, dashBoardData, globalData, mqtt) => {
    const handlerEvents = require(process.env.NODE_ENV == 'development' ? "./handlerEvents.dev.js" : "./handlerEvents.js")(api, threadModel, userModel, dashBoardModel, globalModel, usersData, threadsData, dashBoardData, globalData, mqtt);

    return async function (event) {
        if (
            global.YamiBot.config.antiInbox == true &&
            (event.senderID == event.threadID || event.userID == event.senderID || event.isGroup == false) &&
            (event.senderID || event.userID || event.isGroup == false)
        )
            return;

        const message = createFuncMessage(api, event, mqtt);//may soon '&'

        await handlerCheckDB(usersData, threadsData, event);
        const handlerChat = await handlerEvents(event, message);
        if (!handlerChat)
            return;

        const {
            onAnyEvent, onFirstChat, onStart, onChat,
            onReply, onEvent, handlerEvent, onReaction,
            typ, presence, read_receipt
        } = handlerChat;

        const Params = {
            api,
            threadModel,
            userModel,
            dashBoardModel,
            globalModel,
            usersData,
            threadsData,
            dashBoardData,
            globalData,
            event,
            message,
            mqtt
        };

        global.onListen.triggerAll(Params);
        onAnyEvent();
        switch (event.type) {
            case "message":
            case "message_reply":
            case "message_unsend":
                onFirstChat();
                onChat();
                onStart();
                onReply();
                break;
            case "event":
                handlerEvent();
                onEvent();
                break;
            case "message_reaction":
                onReaction();
                break;
            case "typ":
                typ();
                break;
            case "presence":
                presence();
                break;
            case "read_receipt":
                read_receipt();
                break;
            default:
                break;
        }
    };
};
