const axios = require("axios");
const {
  FormData,
  Blob
} = require("formdata-node");

class GeminiChat {
  constructor() {
    this.chatUrl = "https://ai.jaze.top/api/auth/gemini";
    this.headers = {
      accept: "*/*",
      "accept-language": "id-ID,id;q=0.9",
      cookie: "i18n_redirected=zh",
      origin: "https://ai.jaze.top",
      priority: "u=1, i",
      referer: "https://ai.jaze.top/?session=1",
      "sec-ch-ua": '"Chromium";v="131", "Not_A Brand";v="24", "Microsoft Edge Simulate";v="131", "Lemur";v="131"',
      "sec-ch-ua-mobile": "?1",
      "sec-ch-ua-platform": '"Android"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    };
  }
  async chat({
    prompt,
    imageUrl = "",
    model = "gemini-1.5-flash",
    system = "",
    messages = []
  }) {
    try {
      console.log("[1] Menyiapkan FormData...");
      const form = new FormData();
      form.append("model", model);
      console.log("[2] Menambahkan model:", model);
      const finalMessages = messages.length ? messages : [system ? {
        role: "system",
        content: system
      } : {
        role: "system",
        content: "You are ChatGPT, a large language model trained by OpenAI. Follow the user's instructions carefully. Respond using markdown."
      }, {
        role: "user",
        content: prompt
      }];
      form.append("messages", JSON.stringify(finalMessages));
      console.log("[3] Menambahkan pesan:", finalMessages);
      if (imageUrl) {
        try {
          console.log("[4] Mengunduh gambar:", imageUrl);
          const {
            data: buffer,
            headers: resHeaders
          } = await axios.get(imageUrl, {
            responseType: "arraybuffer"
          });
          const mimeType = resHeaders["content-type"] || "image/webp";
          const blob = new Blob([buffer], {
            type: mimeType
          });
          form.append("files", blob, "image.webp");
          console.log("[5] Gambar ditambahkan ke FormData.");
        } catch (imgErr) {
          console.warn("[Gagal unduh gambar]", imgErr.message);
        }
      }
      console.log("[6] Mengirim permintaan ke Gemini...");
      const res = await axios.post(this.chatUrl, form, {
        headers: {
          ...this.headers,
          ...form.headers
        }
      });
      console.log("[7] Respons diterima.");
      return res.data;
    } catch (err) {
      console.error("[chat error]", err.message);
      return null;
    }
  }
}

exports.config = {
    name: "gemini",
    role: 2,
    category: "Ai",
    countDown: 15,
    author: "Allou Mohamed",
    desc: "chat with Gemini"
};

const sessions = {};
exports.onStart = async function ({ message, args, event, commandName }) {
  const { senderID } = event;
  const userMessage = args.join(" ").trim();

  if (!userMessage) {
    return message.reply("Please enter a message.");
  }

  if (["clear", "reset"].includes(userMessage.toLowerCase())) {
    delete sessions[senderID];
    return message.reply("Conversation has been cleared.");
  }

  if (!sessions[senderID]) {
    sessions[senderID] = [
      {
        role: "system",
        content: "You are a helpful assistant powered by Gemini. Respond clearly and concisely."
      }
    ];
  }

  sessions[senderID].push({
    role: "user",
    content: userMessage
  });

  if (sessions[senderID].length > 11) {
    sessions[senderID] = [sessions[senderID][0], ...sessions[senderID].slice(-10)];
  }

  const imageUrl = event.messageReply?.attachments?.[0]?.url;

  try {
    const gemini = new GeminiChat();
    const response = await gemini.chat({
      messages: sessions[senderID],
      imageUrl
    });

    if (!response) {
      return message.reply("No response received from Gemini.");
    }

    sessions[senderID].push({
      role: "assistant",
      content: response
    });

    const alu = await message.reply(response);
    YukiBot.onReply.set(alu.messageID, {commandName,a:senderID});
  } catch (error) {
    console.error("Gemini error:", error.message);
    message.reply("An error occurred while processing your request.");
  }
};

exports.onReply = async function ({ message, args, event, commandName, Reply }) {
  const { senderID } = event;
  if (Reply.a!=senderID)return;
  const userMessage = args.join(" ").trim();

  if (!userMessage) {
    return message.reply("Please enter a message.");
  }

  if (["clear", "reset"].includes(userMessage.toLowerCase())) {
    delete sessions[senderID];
    return message.reply("Conversation has been cleared.");
  }

  if (!sessions[senderID]) {
    sessions[senderID] = [
      {
        role: "system",
        content: "You are a helpful assistant powered by Gemini. Respond clearly and concisely."
      }
    ];
  }

  sessions[senderID].push({
    role: "user",
    content: userMessage
  });

  if (sessions[senderID].length > 11) {
    sessions[senderID] = [sessions[senderID][0], ...sessions[senderID].slice(-10)];
  }

  const imageUrl = event.messageReply?.attachments?.[0]?.url;

  try {
    const gemini = new GeminiChat();
    const response = await gemini.chat({
      messages: sessions[senderID],
      imageUrl
    });

    if (!response) {
      return message.reply("No response received from Gemini.");
    }

    sessions[senderID].push({
      role: "assistant",
      content: response
    });

    const alu = await message.reply(response);
    YukiBot.onReply.set(alu.messageID, {commandName,a:senderID});
  } catch (error) {
    console.error("Gemini error:", error.message);
    message.reply("An error occurred while processing your request.");
  }
};
