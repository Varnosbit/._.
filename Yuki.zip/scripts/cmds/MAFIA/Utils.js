const crypto = require("crypto");
const Config = require('./Config');

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function secureRandom(min, max) {
  const range = max - min;
  const randomBytes = crypto.randomBytes(4);
  const randomValue = randomBytes.readUInt32BE(0);
  return min + (randomValue % (range + 1));
}

function secureShuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = secureRandom(0, i);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function getRandomElement(array) {
  return array[secureRandom(0, array.length - 1)];
}

function getRoleDistribution(playerCount) {
  const roles = [];
  const mafiaCount = Math.max(1, Math.floor(playerCount / 3.5));
  
  if (mafiaCount === 1) {
    roles.push(secureRandom(0, 1) === 0 ? "mafia" : "godfather");
  } else {
    roles.push("godfather");
    for (let i = 1; i < mafiaCount; i++) {
      roles.push("mafia");
    }
    if (playerCount >= 8) {
      const helpers = ["consigliere", "framer", "janitor", "blackmailer"];
      const helper = getRandomElement(helpers);
      roles[roles.length - 1] = helper;
    }
  }
  
  const guaranteedRoles = [];
  guaranteedRoles.push(secureRandom(0, 1) === 0 ? "cop" : "sheriff");
  guaranteedRoles.push("doctor");
  if (playerCount >= 7) {
    guaranteedRoles.push("vigilante");
  }
  roles.push(...guaranteedRoles);
  
  const specialRoles = [
    "bodyguard", "veteran", "lookout", "tracker", "escort", "transporter",
    "mayor", "spy", "crusader", "retributionist", "trapper", "psychic",
    "medium", "vampire_hunter"
  ];
  
  const neutralRoles = [
    "jester", "executioner", "witch", "survivor", "arsonist",
    "serial_killer", "werewolf", "amnesiac"
  ];
  
  if (playerCount >= 9) {
    roles.push("vampire");
  }
  
  const availableSpecials = secureShuffle(specialRoles);
  const availableNeutrals = secureShuffle(neutralRoles);
  
  while (roles.length < playerCount) {
    const rand = secureRandom(0, 100);
    if (rand < 20 && availableNeutrals.length > 0) {
      roles.push(availableNeutrals.pop());
    } else if (availableSpecials.length > 0) {
      roles.push(availableSpecials.pop());
    } else {
      roles.push("citizen");
    }
  }
  return secureShuffle(roles);
}

async function listPlayers(game, usersData, showStatus = true) {
  const Variables = require('./Variables');
  const players = Variables.alive(game);
  const list = [];
  for (let i = 0; i < players.length; i++) {
    const p = players[i];
    const name = await usersData.getName(p.userID);
    let line = `${i + 1}. ${name}`;
    if (showStatus) {
      const statuses = [];
      if (p.blackmailed) statuses.push("🥺 مبتز");
      if (p.roleblocked) statuses.push("💤 يلهو");
      if (p.protected) statuses.push("🛡️ محمي");
      if (statuses.length > 0) {
        line += ` ${statuses.join(" ")}`;
      }
    }
    list.push(line);
  }
  return list.join("\n");
}

async function listPlayersWithRoles(game, usersData) {
  const list = [];
  const players = Object.values(game.players);
  for (let i = 0; i < players.length; i++) {
    const p = players[i];
    const name = await usersData.getName(p.userID);
    const status = p.alive ? "حي 🥰" : "ميت ☠️";
    const roleData = Config.ROLES[p.role];
    let displayRole = `${roleData.emoji} ${roleData.name}`;
    if (p.convertedToVampire) {
      displayRole += " 🧛 (مصاص دماء)";
    }
    list.push(`${i + 1}. ${name} ${status} - ${displayRole}`);
  }
  return list.join("\n");
}

function formatGameStatus(game) {
  const Variables = require('./Variables');
  const alive_count = Variables.alive(game).length;
  const mafia_count = Variables.aliveMafia(game).length;
  const citizen_count = Variables.aliveCitizen(game).length;
  const neutral_count = Variables.aliveNeutral(game).length;
  let status = `📊 حالة اللعبة
____________________________

👥 أحياء: ${alive_count}
🔴 مافيا: ${mafia_count}
🔵 مواطنون: ${citizen_count}`;
  if (neutral_count > 0) {
    status += `\n⚪ محايدون: ${neutral_count}`;
  }
  status += `\n📅 اليوم: ${game.day}`;
  return status;
}

function formatPhaseMessage(phase, day) {
  const messages = Config.messages;
  if (phase === "night") return messages.nightPhase(day);
  if (phase === "day") return messages.dayPhase(day);
  if (phase === "voting") return messages.votingPhase(day);
  return "";
}

async function createGameReport(game, winner, usersData) {
  let report = `🎭 انتهت اللعبة! 🎭
____________________________

`;
  if (winner === "mafia") {
    report += `🕴️ فريق المافيا انتصر! 🔪\n🌑 سيطروا على المدينة بالخوف\n\n`;
  } else if (winner === "citizen") {
    report += `🥰 فريق المواطنين انتصر! 👮\n☀️ عاد الأمان للمدينة\n\n`;
  } else if (winner === "neutral") {
    report += `⚪ فوز محايد مثير! 🎯\n🎭 حقق هدفه الخاص\n\n`;
  } else if (winner === "vampire") {
    report += `👀 مصاصو الدماء انتصروا! 🧛\n🌙 سيطروا على المدينة بالظلام\n\n`;
  } else if (winner === "cancelled") {
    report += `❌ تم إلغاء اللعبة\n\n`;
  }
  report += `📜 الأدوار الكاملة:
____________________________

`;
  report += await listPlayersWithRoles(game, usersData);
  report += `\n\n____________________________`;
  report += `\n📅 إجمالي الأيام: ${game.day}`;
  report += `\n⏱️ المدة: ${Math.floor((Date.now() - game.createdAt) / 60000)} دقيقة`;
  return report;
}

function checkGameEnd(game) {
  const Variables = require('./Variables');
  const alivePlayers = Variables.alive(game);
  const mafia = Variables.aliveMafia(game);
  const citizen = Variables.aliveCitizen(game);
  const neutral = Variables.aliveNeutral(game);
  const vampires = Variables.aliveVampires(game);
  
  if (alivePlayers.length === 0) {
    return { ended: true, winner: "draw" };
  }
  
  if (vampires.length >= alivePlayers.length / 2 && vampires.length > 0) {
    return { ended: true, winner: "vampire" };
  }
  
  if (mafia.length >= citizen.length + neutral.length - vampires.length && mafia.length > 0) {
    return { ended: true, winner: "mafia" };
  }
  
  if (mafia.length === 0 && vampires.length === 0) {
    const sk = alivePlayers.find(p => p.role === "serial_killer");
    const ww = alivePlayers.find(p => p.role === "werewolf");
    const arson = alivePlayers.find(p => p.role === "arsonist");
    if (alivePlayers.length === 1 && (sk || ww || arson)) {
      return { ended: true, winner: "neutral", specialPlayer: sk || ww || arson };
    }
    return { ended: true, winner: "citizen" };
  }
  
  return { ended: false };
}

async function sendToPlayerOrRoom(mqtt, player, message) {
  if (Config.InboxMode) {
    return await mqtt.sendMessage(message, player.userID);
  } else {
    if (player.groupID) {
      return await mqtt.sendMessage(message, player.groupID);
    } else {
      return await mqtt.sendMessage(message, player.userID);
    }
  }
}

async function sendToAllPlayers(mqtt, game, message, condition = null) {
  const Variables = require('./Variables');
  const players = condition ? Variables.alive(game).filter(condition) : Variables.alive(game);
  
  for (const player of players) {
    try {
      await sendToPlayerOrRoom(mqtt, player, message);
      await sleep(500);
    } catch (error) {
      console.error(`[MAFIA42] Failed to send message to ${player.userID}:`, error);
    }
  }
}

function isMafiaRole(role) {
  const roleData = Config.ROLES[role];
  return roleData && roleData.team === "mafia";
}

function isCitizenRole(role) {
  const roleData = Config.ROLES[role];
  return roleData && roleData.team === "citizen";
}

function isNeutralRole(role) {
  const roleData = Config.ROLES[role];
  return roleData && (roleData.team === "neutral" || roleData.team === "vampire");
}

function canRoleActAtNight(role) {
  const roleData = Config.ROLES[role];
  return roleData && (roleData.night === true || roleData.canKill === true);
}

function getRoleAbility(role) {
  const roleData = Config.ROLES[role];
  return roleData ? roleData.ability : null;
}

function getRolePriority(role) {
  const roleData = Config.ROLES[role];
  return roleData ? (roleData.priority || 0) : 0;
}

function hasRoleAbilityUses(player, ability) {
  if (!player.abilities || !player.abilities[ability]) {
    return false;
  }
  return player.abilities[ability] > 0;
}

function decrementAbilityUse(player, ability) {
  if (player.abilities && player.abilities[ability]) {
    player.abilities[ability]--;
    return player.abilities[ability];
  }
  return 0;
}

function getTeamName(team) {
  const teamNames = {
    "mafia": "🔴 المافيا",
    "citizen": "🔵 المواطنين",
    "neutral": "⚪ المحايدين",
    "vampire": "🟣 مصاصي الدماء"
  };
  return teamNames[team] || team;
}

function generateGameID() {
  return Date.now().toString() + secureRandom(1000, 9999);
}

async function notifyMainChat(mqtt, game, message) {
  try {
    await mqtt.sendMessage(message, game.main);
  } catch (error) {
    console.error(`[MAFIA42] Failed to notify main chat:`, error);
  }
}

async function revealRoleInMainChat(mqtt, game, userID, usersData, reason = "ميت") {
  const player = game.players[userID];
  if (!player) return;
  
  const name = await usersData.getName(userID);
  const roleData = Config.ROLES[player.role];
  
  let message = `💀 ${name} - ${reason}\n`;
  message += `🎭 الدور: ${roleData.emoji} ${roleData.name}\n`;
  message += `📝 ${roleData.desc}`;
  
  await notifyMainChat(mqtt, game, message);
}

function parseActionInput(input) {
  const trimmed = input.trim();
  
  if (trimmed === "نعم" || trimmed.toLowerCase() === "yes") {
    return { type: "confirm" };
  }
  
  if (trimmed === "تخطي" || trimmed.toLowerCase() === "skip") {
    return { type: "skip" };
  }
  
  if (trimmed === "حرق" || trimmed.toLowerCase() === "ignite") {
    return { type: "ignite" };
  }
  
  const parts = trimmed.split(" ");
  if (parts.length === 2) {
    const num1 = parseInt(parts[0]);
    const num2 = parseInt(parts[1]);
    if (!isNaN(num1) && !isNaN(num2)) {
      return { type: "two_targets", target1: num1, target2: num2 };
    }
  }
  
  const num = parseInt(trimmed);
  if (!isNaN(num)) {
    return { type: "single_target", target: num };
  }
  
  return { type: "invalid" };
}

module.exports = {
  sleep,
  secureRandom,
  secureShuffle,
  getRandomElement,
  getRoleDistribution,
  listPlayers,
  listPlayersWithRoles,
  formatGameStatus,
  formatPhaseMessage,
  createGameReport,
  checkGameEnd,
  sendToPlayerOrRoom,
  sendToAllPlayers,
  isMafiaRole,
  isCitizenRole,
  isNeutralRole,
  canRoleActAtNight,
  getRoleAbility,
  getRolePriority,
  hasRoleAbilityUses,
  decrementAbilityUse,
  getTeamName,
  generateGameID,
  notifyMainChat,
  revealRoleInMainChat,
  parseActionInput
};
