const axios = require("axios");
const {
    createCanvas,
    loadImage,
    registerFont
} = require('canvas');
registerFont(__dirname+"/canvas/fonts/Rounded.otf", {family: "rndd"});
global.helpers.StatusCard = StatusCard;
global.helpers.setP = async (usersData, id, x, z) => {
    if (!z) {
        await usersData.deleteKey(id, "data.status." + x);
        return;
    }
    await usersData.set(id, x, "data.status." + z);
    return;
};
module.exports = {
    config: {
        name: "status",
        aliases: ["معلوماتي"],
        version: "1.1.0",
        author: "allou mohamed",
        countDown: 50,
        role: 0,
        shortDescription: {
            en: "status card.",
            ar: "رؤية بطاقة معلوماتك"
        },
        longDescription: {
            ar: "أمر يصمم لك صورة جميلة",
            en: "get status card that has some of your informations in bot"
        },
        category: "Status"
    },

    onStart: async function (MaTeam) {
        await StatusCard(MaTeam);
    }
};

async function StatusCard(params) {
    let deltaNext = 5;
    const expToLevel = (exp, deltaNextLevel = deltaNext) => Math.floor((1 + Math.sqrt(1 + 8 * exp / deltaNextLevel)) / 2);
    const levelToExp = (level, deltaNextLevel = deltaNext) => Math.floor(((Math.pow(level, 2) - level) * deltaNextLevel) / 2);
    const {
        event,
        usersData,
        threadsData,
        message
    } = params;
    const id = Object.keys(event?.mentions || {})[0] || event?.messageReply?.senderID || event.senderID;
    let name = await getP(usersData, id, "name", (await usersData.getName(id)).split(" ")[0]);
    const width = 1282;
    const height = 1080;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    //background
    ctx.fillStyle = "#1F2024";
    ctx.fillRect(0, 0, width, height);
    //load default things
    let profile = await getP(usersData, id, "avatar", await usersData.getAvatarUrl(id));
    let cover = await getP(usersData, id, "cover", "https://i.pinimg.com/736x/b3/65/af/b365af02734efdf8cea73f0eff2f8920.jpg");
    //draw default photos
    await drawCover(ctx, cover, 0, 0, width, 644);
    await drawProfile(ctx, profile, 220, 580, 308, 10, "black");
    //draw shapes
    //slider bar and level texts
    const {
        exp
    } = await usersData.get(id);
    const levelUser = expToLevel(exp, deltaNext);
    const expNextLevel = levelToExp(levelUser + 1, deltaNext) - levelToExp(levelUser, deltaNext);

    const currentExp = expNextLevel - (levelToExp(levelUser + 1, deltaNext) - exp);
    const all = await usersData.getAll();
    await drawRoundedRect(ctx, 414, 676, 94, 114, 6, ["#2FA1FF", "#0071FF"], "⚡︎", true);
    drawSliderBar(ctx, "#0071FF", "#2FA1FF", currentExp, expNextLevel, 520, 736, 690, 10);
    //level
    ctx.textAlign = "left";
    ctx.fillStyle = 'white';
    ctx.font = 'bold 31px sans-serif';
    ctx.fillText(`Level ${levelUser}`, 520, 710);
    //points exp
    ctx.globalAlpha = 0.6;
    ctx.fillStyle = 'white';
    ctx.font = 'bold 20px sans-serif';
    ctx.fillText(`${currentExp.toLocaleString('en-US')} Experience Points`, 520, 770);
    //order for whois '-'
    const ID = ID_(id, all);
    let Y_ = 568;
    let Y__ = 530;
    let tag = await getP(usersData, id, "tag", "User"); //max letters 7
    if (!tag) Y__ = Y_;
    ctx.font = 'bold 45px sans-serif';
    ctx.globalAlpha = 0.2;
    const idText = `#${ID}`;
    const idTextWidth = ctx.measureText(idText).width;
    ctx.fillText(idText, 1182 - idTextWidth/2, Y__);
    //tag :-: @
    if (tag) {
        ctx.font = 'bold 30px sans-serif';
        ctx.globalAlpha = 0.2;
        const tagText = `@${tag || "M"}`;
        const tagTextWidth = ctx.measureText(tagText).width;
        ctx.fillText(tagText, 1182 - tagTextWidth / 2, Y_);
    }
    //name
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = 'white';
    ctx.font = "bold 50px sans-serif";
    ctx.fillText(name, 414, 570);
    ctx.globalAlpha = 1;

    //guild

    //flag
    const nameOfFlag = await getP(usersData, id, "flagname", "Japan");
    const flagUrl = await getP(usersData, id, "flag", "https://flagcdn.com/h240/jp.png");
    await drawFlag(ctx, flagUrl, nameOfFlag);
    //achievement
    let achievement = await getP(usersData, id, "achievement", {
        name: "The New Status",
        color: ["#80FF00", "#B4FF00"]
    });

    if (achievement && achievement.name) await drawAch(ctx, achievement.name, 80, 760, 284, 50, achievement.color);
    //trust factor
    let TFY = 760;
    if (achievement && achievement.name) TFY += 60;
    const TFR = await getP(usersData, id, "TrustFactor", "9/10");
    drawTrustFactor(ctx, TFR);

    //vanity

    //messages, points, money, warns...
    const rectWidth = 255;
    const distance = 14;
    //money
    const money = await usersData.getMoney(id);
    const bal = formatMoney(money);
    await drawRoundedRect(ctx, 414, 805, rectWidth, 75, 6, "#FFA956", bal, false, "https://i.imgur.com/3mM0IU5.png");//https://i.ibb.co/VvXtLt8/status-pro-yen.png

    //messages
    let totamesRank_en;
    const tiddata = await threadsData.get(event.threadID);
    const members = tiddata.members;
    const fin = members.find(user => user.userID == id);
    const totames = fin?.count || 0;
    if (totames >= 3000) {
        totamesRank_en = "Interaction Star";
    } else if (totames >= 2500) {
        totamesRank_en = "Dialogue Creator"
    } else if (totames >= 2000) {
        totamesRank_en = "Outstanding"
    } else if (totames >= 1500) {
        totamesRank_en = "Active";
    } else if (totames >= 1000) {
        totamesRank_en = "Engaged";
    } else if (totames >= 500) {
        totamesRank_en = "Contributor";
    } else if (totames >= 100) {
        totamesRank_en = "Participant";
    } else {
        totamesRank_en = "Observer";
    }
    await drawRoundedRect(ctx, 414 + (rectWidth + distance), 805, rectWidth, 75, 6, "#8370FE", `${totames.toLocaleString('en-US')}`, false, "https://i.imgur.com/5jPXbsW.png");//https://i.ibb.co/bLTcR0s/status-pro-mssh.png
    //rank txt
    let sideRnkTxt = await getP(usersData, id, "nickname", {});
    if (sideRnkTxt && sideRnkTxt.txt) totamesRank_en += " • ";
    ctx.textAlign = "left";
    ctx.globalAlpha = 0.6;
    ctx.fillStyle = 'white';
    ctx.font = "bold 25px sans-serif";
    ctx.fillText(totamesRank_en, 414, 615);
    if (sideRnkTxt && sideRnkTxt.txt) {
        ctx.globalAlpha = 1; let stx = 414+ctx.measureText(totamesRank_en).width; ctx.fillStyle = sideRnkTxt.clr; ctx.fillText(sideRnkTxt.txt, stx, 615)}
    ctx.globalAlpha = 1;
    //:-: order xp
    const expSort = all.sort((a, b) => b.exp - a.exp);
    const ordUs = expSort.findIndex(user => user.userID == id) + 1;
    await drawRoundedRect(ctx, 414 + ((rectWidth + distance) * 2), 805, rectWidth, 75, 6, "#73E79C", `${ordUs.toLocaleString('en-US')}`, false, "https://i.imgur.com/NaTq0iE.png");//https://i.ibb.co/2hN0pfg/status-pro.png
    //exp symbol
    const pointsExp = await usersData.getPoints(id) || 0;
    const skwidth = 188;
    await drawSkills(ctx, 414, 900, skwidth, (75 / 1.6), 4, "#18191C", "#E9B824", symbol = "", `${pointsExp}`, "https://i.imgur.com/LGATVf1.png");//https://i.ibb.co/5nvkQzj/8078601.png
    //retry
    await drawSkills(ctx, 414 + (skwidth + distance), 900, skwidth, (75 / 1.6), 4, "#18191C", "#3081D0", symbol = "", amount = "0", "https://i.imgur.com/aPW9Q6k.png");
    //ludo symbole
    await drawSkills(ctx, 414 + (skwidth + distance) * 2, 900, skwidth, (75 / 1.6), 4, "#18191C", "#3081D0", symbol = "", amount = "0", "https://i.imgur.com/srAdP2N.png");//https://i.ibb.co/j6CBcHW/10115687.png
    //warning
    await drawSkills(ctx, 414 + (skwidth + distance) * 3, 900, skwidth, (75 / 1.6), 4, "#18191C", "#FF5359", symbol = "", amount = "0", "https://i.imgur.com/bqTQDU8.png");//https://i.ibb.co/Lzz785x/Picsart-24-09-07-17-23-27-371.png
   
    //Copyright '-'
    const totalSkillsWidth = (skwidth * 4) + (distance * 3) + 195; // 4 skills with 3 gaps between them
    const copyrightHeight = 85;
    const copyrightY = 900 + (75 / 1.6) + 10; // skills Y + skill height + margin

    await drawYamiCopyRights(
     ctx, 
     "https://i.pinimg.com/736x/1a/bc/e0/1abce0057f69996b32f6ab28984be34b.jpg", 
     315,
     copyrightY, 
     totalSkillsWidth,
     copyrightHeight, 
     0.8,
     0.1, 
     'Yami Bot By @Allou Mohamed'
    );
    //send image
    const stream = canvas.createPNGStream();
    stream.path = `${ID}-status-pro.png`;
    message.reply({
        attachment: stream
    });

    async function drawSkills(ctx, x, y, w, h, r, colorA, colorB, symbol = "", amount = "10", img = null) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;

        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
        ctx.fillStyle = colorA;
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.font = `bold ${Math.min(w, h) * 0.5}px sans-serif`;
        ctx.fillStyle = "white";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        const textWidth = ctx.measureText(amount).width;
        const xPos = (x + w / 2) + 20;
        const yPos = y + h / 2;

        ctx.fillText(amount, xPos, yPos);

        const squareWidth = w * 0.25;
        const squareHeight = h;
        const squareX = x;
        const squareY = y;

        ctx.beginPath();
        ctx.moveTo(squareX + r, squareY);
        ctx.arcTo(squareX, squareY, squareX, squareY + r, r);
        ctx.lineTo(squareX, squareY + squareHeight - r);
        ctx.arcTo(squareX, squareY + squareHeight, squareX + r, squareY + squareHeight, r);
        ctx.lineTo(squareX + squareWidth, squareY + squareHeight);
        ctx.lineTo(squareX + squareWidth, squareY);
        ctx.closePath();
        ctx.fillStyle = colorB;
        ctx.fill();

        if (img) {
            ctx.globalAlpha = 0.8;
            const image = await loadImage(img);
            const imgHeight = squareHeight * 0.8;
            const imgWidth = image.width * (imgHeight / image.height);
            const imgX = squareX + (squareWidth - imgWidth) / 2;
            const imgY = squareY + (squareHeight - imgHeight) / 2;
            ctx.drawImage(image, imgX, imgY, imgWidth, imgHeight);
        } else {
            ctx.font = `bold ${Math.min(squareWidth, squareHeight) * 0.8}px sans-serif`;
            ctx.fillStyle = "white";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(symbol, squareX + squareWidth / 2, squareY + squareHeight / 2);
        }
    }

    async function drawRoundedRect(ctx, x, y, w, h, r, clrs, s = "", strk, img) {
        let image = false;
        let imgW = 0;
        if (img) {
            image = await loadImage(img);
        }

        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;

        if (Array.isArray(clrs)) {
            const gradient = ctx.createLinearGradient(x, y, x + w, y + h);
            const step = 1 / (clrs.length - 1);

            clrs.forEach((color, index) => {
                gradient.addColorStop(index * step, color);
            });

            ctx.fillStyle = gradient;
        } else {
            ctx.fillStyle = clrs;
        }

        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
        ctx.fill();

        if (strk) {
            ctx.font = `bold ${Math.min(w, h) * 0.6}px sans-serif`;
        } else {
            ctx.font = `bold 30px sans-serif`;
        }

        ctx.fillStyle = "white";
        ctx.strokeStyle = "white";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        const xPos = x + w / 2;
        const yPos = y + h / 2;

        if (strk) {
            ctx.lineWidth = 12;
            ctx.strokeText(s, xPos, yPos);
        }

        if (image) {
            const imgH = h * 0.8;
            imgW = image.width * (imgH / image.height);
            const imgX = x + w - imgW - 10;
            const imgY = y + (h - imgH) / 2;
            ctx.globalAlpha = 0.8;
            ctx.drawImage(image, imgX, imgY, imgW, imgH);
        }
        imgW = 0;
        const textMaxWidth = image ? w - imgW - 20: w;
        ctx.globalAlpha = 1;
        ctx.fillText(s, x + textMaxWidth / 2, yPos);
    }

    async function drawCover(ctx, inputImagePath, x, y, coverWidth, coverHeight) {
        const {
            data: imageBuffer
        } = await axios.get(inputImagePath, {
                responseType: 'arraybuffer',
            });
        try {
            const image = await loadImage(imageBuffer);
            const targetBgWidth = 1282;
            const targetBgHeight = 644;
            const imageAspect = image.width / image.height;
            const targetAspect = targetBgWidth / targetBgHeight;

            let sourceX,
            sourceY,
            sourceWidth,
            sourceHeight;

            if (imageAspect > targetAspect) {
                sourceWidth = image.height * targetAspect;
                sourceHeight = image.height;
                sourceX = (image.width - sourceWidth) / 2;
                sourceY = 0;
            } else {
                sourceWidth = image.width;
                sourceHeight = image.width / targetAspect;
                sourceX = 0;
                sourceY = (image.height - sourceHeight) / 2;
            }

            const canvas = createCanvas(targetBgWidth, targetBgHeight);
            const tempCtx = canvas.getContext('2d');

            tempCtx.drawImage(
                image,
                sourceX, sourceY, sourceWidth, sourceHeight,
                0, 0, targetBgWidth, targetBgHeight
            );

            const gradient = tempCtx.createLinearGradient(0, 0, 0, targetBgHeight);
            gradient.addColorStop(0, 'rgba(31, 32, 36, 0.05)');
            gradient.addColorStop(1, 'rgba(31, 32, 36, 1)');
            tempCtx.fillStyle = gradient;
            tempCtx.fillRect(0, 0, targetBgWidth, targetBgHeight);

            ctx.drawImage(
                canvas,
                0, 0, targetBgWidth, targetBgHeight,
                x, y, coverWidth, coverHeight
            );
        } catch (err) {
            console.error('Error loading image:', err);
        }
    }

    async function drawProfile(ctx, imagePath, x, y, size, A, B) {
        const {
            data: imageBuffer
        } = await axios.get(imagePath, {
                responseType: 'arraybuffer',
            });

        const avatar = await loadImage(imageBuffer);
        const imageWidth = avatar.width;
        const imageHeight = avatar.height;

        const squareSize = Math.min(imageWidth, imageHeight);
        const radius = size / 2;

        const startX = (imageWidth - squareSize) / 2;
        const startY = (imageHeight - squareSize) / 2;

        ctx.save();
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.clip();

        ctx.drawImage(
            avatar,
            startX, startY, squareSize, squareSize,
            x - radius, y - radius, size, size
        );

        if (A && B) {
            ctx.lineWidth = A;
            ctx.strokeStyle = B;
            ctx.stroke();
        }

        ctx.restore();
    }
/*
    function drawSliderBar(ctx, colorA, colorB, currentExp, expNextLevel, x, y, width, height) {
        const MAX_WIDTH = 1282;
        const scaleFactor = Math.min(MAX_WIDTH / width, 1);
        const scaledWidth = Math.min(width, MAX_WIDTH);
        const scaledExpNextLevel = expNextLevel * (scaledWidth / width);
        const scaledCurrentExp = currentExp * (scaledWidth / width);
        const percentage = Math.min((scaledCurrentExp / scaledExpNextLevel) * 100, 100);

        const skew = 30;
        const radius = height / 2;

        const gradient = ctx.createLinearGradient(x, y, x + scaledWidth, y);
        gradient.addColorStop(0, colorA);
        gradient.addColorStop(1, colorB);

        ctx.fillStyle = '#353639';
        ctx.beginPath();
        ctx.moveTo(x + skew, y);
        ctx.lineTo(x + scaledWidth, y);
        ctx.arcTo(x + scaledWidth, y + height, x + scaledWidth - skew, y + height, radius);
        ctx.lineTo(x, y + height);
        ctx.arcTo(x, y, x + skew, y, radius);
        ctx.closePath();
        ctx.fill();

        const filledWidth = scaledWidth * (percentage / 100);
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(x + skew, y);
        ctx.lineTo(x + filledWidth, y);
        ctx.arcTo(x + filledWidth, y + height, x + filledWidth - skew, y + height, radius);
        ctx.lineTo(x, y + height);
        ctx.arcTo(x, y, x + skew, y, radius);
        ctx.closePath();
        ctx.fill();

        ctx.lineJoin = "round";
        ctx.lineCap = "round";
    }*/
    
function drawSliderBar(ctx, colorA, colorB, currentExp, expNextLevel, x, y, width, height) {
    const MAX_WIDTH = 1282;
    const scaleFactor = Math.min(MAX_WIDTH / width, 1);
    const scaledWidth = Math.min(width, MAX_WIDTH);
    const scaledExpNextLevel = expNextLevel * (scaledWidth / width);
    const scaledCurrentExp = currentExp * (scaledWidth / width);
    const percentage = Math.min((scaledCurrentExp / scaledExpNextLevel) * 100, 100);

    const skew = 30;
    const radius = height / 2;

    const gradient = ctx.createLinearGradient(x, y, x + scaledWidth, y);
    gradient.addColorStop(0, colorA);
    gradient.addColorStop(1, colorB);

    ctx.fillStyle = '#353639';
    ctx.beginPath();
    ctx.moveTo(x + skew, y);
    ctx.lineTo(x + scaledWidth, y);
    ctx.arcTo(x + scaledWidth, y + height, x + scaledWidth - skew, y + height, radius);
    ctx.lineTo(x, y + height);
    ctx.arcTo(x, y, x + skew, y, radius);
    ctx.closePath();
    ctx.fill();

    const filledWidth = scaledWidth * (percentage / 100);

    ctx.shadowColor = colorB;
    ctx.shadowBlur = 15;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.moveTo(x + skew, y);
    ctx.lineTo(x + filledWidth, y);
    ctx.arcTo(x + filledWidth, y + height, x + filledWidth - skew, y + height, radius);
    ctx.lineTo(x, y + height);
    ctx.arcTo(x, y, x + skew, y, radius);
    ctx.closePath();
    ctx.fill();

    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;

    ctx.lineJoin = "round";
    ctx.lineCap = "round";
}
    
    function ID_(userID, userDataArray) {
        const userIndex = userDataArray.findIndex(user => user.userID === userID);
        if (userIndex !== -1) {

            return userIndex + 1;
        } else {
            return userDataArray.length;
        }
    }

    async function getP(usersData, UID, x, default_) {
        const d = await usersData.get(UID, "data.status");
        if (!d) {
            await usersData.set(UID, {}, "data.status");
            return default_;
        }
        if (d && d[x]) return d[x];
        return default_;
    }

    function formatMoney(amount) {
        const suffixes = ['',
            'k',
            'M',
            'B',
            'T',
            'P',
            'E'];
        const i = Math.floor(Math.log10(Math.abs(amount)) / 3);

        if (amount === 0 || i === 0) return amount.toString();

        const value = (amount / Math.pow(1000, i)).toFixed(2);

        return `${value}${suffixes[i]}`;
    }
/*
    function drawTrustFactor(ctx, data) {
        ctx.fillStyle = '#2A2B2F';
        ctx.fillRect(80, TFY, 284, 50);
        ctx.font = 'bold 20px sans-serif';
        ctx.fillStyle = "white";
        ctx.globalAlpha = 0.8;
        const tText = "Trust Factor";
        const tTextWidth = ctx.measureText(tText).width;
        ctx.fillText(tText, 220 - tTextWidth/2, TFY + 20);
        ctx.globalAlpha = 1;
        const sliderX = 80;
        const sliderY = TFY + 44;
        const sliderWidth = 284;
        const sliderHeight = 5;

        //const data = "50/100";
        const [value,
            max] = data.split('/').map(Number);
        const handleRadius = 7;

        const filledWidth = (value / max) * sliderWidth;
        const handleX = sliderX + filledWidth;
        const handleY = sliderY + (sliderHeight / 2);

        ctx.fillStyle = '#FF5B79';
        ctx.fillRect(sliderX, sliderY, sliderWidth, sliderHeight);

        ctx.fillStyle = '#44F779';
        ctx.fillRect(sliderX, sliderY, filledWidth, sliderHeight);
    }

    async function drawAch(ctx, text, x, y, width, height, colors) {
        const originalFillStyle = ctx.fillStyle;
        const originalFont = ctx.font;
        const originalTextAlign = ctx.textAlign;
        const originalTextBaseline = ctx.textBaseline;
        const originalGlobalAlpha = ctx.globalAlpha;

        const gradient = ctx.createLinearGradient(x, y, x + width, y);
        colors.forEach((color, index) => {
            gradient.addColorStop(index / (colors.length - 1), color);
        });

        ctx.fillStyle = gradient;
        ctx.fillRect(x, y, width, height);

        const greyRectWidth = 278 - 4;
        const greyRectHeight = 44 - 4;
        const greyRectX = x + (width - greyRectWidth) / 2;
        const greyRectY = y + (height - greyRectHeight) / 2;

        ctx.globalAlpha = 0.8;
        ctx.fillStyle = '#2f302f';
        ctx.fillRect(greyRectX, greyRectY, greyRectWidth, greyRectHeight);

        ctx.globalAlpha = 1;
        ctx.font = 'bold 22px sans-serif';
        ctx.fillStyle = gradient;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, x + width / 2, y + height / 2);

        ctx.fillStyle = originalFillStyle;
        ctx.font = originalFont;
        ctx.textAlign = originalTextAlign;
        ctx.textBaseline = originalTextBaseline;
        ctx.globalAlpha = originalGlobalAlpha;
    }*/

    async function drawFlag(ctx, flagUrl, flagName) {
        const x = 414;
        const y = 500;
        const flagWidth = 60;
        const flagHeight = 35;

        ctx.font = "bold 20px sans-serif";
        const name = flagName;
        const nameWidth = ctx.measureText(name).width;
        const nameHeight = 6;
        const cornerRadius = 4;
        const rectWidth = nameWidth + 12;
        const rectHeight = flagHeight - 7;

        ctx.globalAlpha = 0.4;
        ctx.fillStyle = "black";

        ctx.beginPath();
        ctx.moveTo(x + 68 + cornerRadius, y + 6);
        ctx.lineTo(x + 68 + rectWidth - cornerRadius, y + 6);
        ctx.arcTo(x + 68 + rectWidth, y + 6, x + 68 + rectWidth, y + cornerRadius + 6, cornerRadius);
        ctx.lineTo(x + 68 + rectWidth, y + rectHeight - cornerRadius + 6);
        ctx.arcTo(x + 68 + rectWidth, y + rectHeight + 6, x + 68 + rectWidth - cornerRadius, y + rectHeight + 6, cornerRadius);
        ctx.lineTo(x + 68 + cornerRadius, y + rectHeight + 6);
        ctx.arcTo(x + 68, y + rectHeight + 6, x + 68, y + rectHeight - cornerRadius + 6, cornerRadius);
        ctx.lineTo(x + 68, y + cornerRadius + 6);
        ctx.arcTo(x + 68, y + 6, x + 68 + cornerRadius, y + 6, cornerRadius);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = "white";
        ctx.globalAlpha = 0.6;

        const textX = x + 68 + (rectWidth - nameWidth) / 2;
        const textY = y+6 + (rectHeight + nameHeight) / 2 - 4;
        ctx.fillText(name, textX, textY);
        ctx.globalAlpha = 1;
        const flag = await loadImage(flagUrl);
        const reducedWidth = flagWidth * 0.8;
        const reducedHeight = flagHeight * 0.8;
        const offsetX = x + (flagWidth - reducedWidth) / 2 + 2;
        const offsetY = y + (flagHeight - reducedHeight) / 2 + 2;

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(offsetX + cornerRadius, offsetY);
        ctx.arcTo(offsetX + reducedWidth, offsetY, offsetX + reducedWidth, offsetY + reducedHeight, cornerRadius);
        ctx.arcTo(offsetX + reducedWidth, offsetY + reducedHeight, offsetX, offsetY + reducedHeight, cornerRadius);
        ctx.arcTo(offsetX, offsetY + reducedHeight, offsetX, offsetY, cornerRadius);
        ctx.arcTo(offsetX, offsetY, offsetX + reducedWidth, offsetY, cornerRadius);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(flag, offsetX, offsetY, reducedWidth, reducedHeight);

        /*ctx.globalAlpha = 0.4;
        ctx.strokeStyle = "black";
        ctx.lineWidth = 8;
        ctx.stroke();*/

        ctx.globalAlpha = 1;
        ctx.restore();
    }
    /*
    function drawTrustFactor(ctx, data) {
    ctx.fillStyle = '#2A2B2F';
    ctx.beginPath();
    ctx.roundRect(80, TFY, 284, 50, 4);
    ctx.fill();
    
    ctx.font = 'bold 20px sans-serif';
    ctx.fillStyle = "white";
    ctx.globalAlpha = 0.8;
    const tText = "Trust Factor";
    const tTextWidth = ctx.measureText(tText).width;
    ctx.fillText(tText, 220 - tTextWidth/2, TFY + 20);
    ctx.globalAlpha = 1;
    
    const sliderX = 80;
    const sliderY = TFY + 44;
    const sliderWidth = 284;
    const sliderHeight = 5;

    const [value, max] = data.split('/').map(Number);
    const handleRadius = 7;

    const filledWidth = (value / max) * sliderWidth;
    const handleX = sliderX + filledWidth;
    const handleY = sliderY + (sliderHeight / 2);

    ctx.fillStyle = '#FF5B79';
    ctx.beginPath();
    ctx.roundRect(sliderX, sliderY, sliderWidth, sliderHeight, 4);
    ctx.fill();

    ctx.fillStyle = '#44F779';
    ctx.beginPath();
    ctx.roundRect(sliderX, sliderY, filledWidth, sliderHeight, 4);
    ctx.fill();
}*/

function drawTrustFactor(ctx, data) {
    ctx.fillStyle = '#2A2B2F';
    ctx.beginPath();
    ctx.roundRect(80, TFY, 284, 50, 4);
    ctx.fill();

    ctx.font = 'bold 20px sans-serif';
    ctx.fillStyle = 'white';
    ctx.globalAlpha = 0.8;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
/*
    ctx.shadowColor = '#44F779';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
*/
    const tText = "Trust Factor";
    ctx.fillText(tText, 220, TFY + 10);
    ctx.globalAlpha = 1;
/*
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
*/
    const sliderX = 80;
    const sliderY = TFY + 44;
    const sliderWidth = 284;
    const sliderHeight = 5;

    const [value, max] = data.split('/').map(Number);
    const filledWidth = (value / max) * sliderWidth;

    ctx.fillStyle = '#FF5B79';
    ctx.beginPath();
    ctx.roundRect(sliderX, sliderY, sliderWidth, sliderHeight, 4);
    ctx.fill();

    ctx.shadowColor = '#44F779';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;

    ctx.fillStyle = '#44F779';
    ctx.beginPath();
    ctx.roundRect(sliderX, sliderY, filledWidth, sliderHeight, 4);
    ctx.fill();

    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
}
    
async function drawAch(ctx, text, x, y, width, height, colors) {
    const originalFillStyle = ctx.fillStyle;
    const originalFont = ctx.font;
    const originalTextAlign = ctx.textAlign;
    const originalTextBaseline = ctx.textBaseline;
    const originalGlobalAlpha = ctx.globalAlpha;

    const gradient = ctx.createLinearGradient(x, y, x + width, y);
    colors.forEach((color, index) => {
        gradient.addColorStop(index / (colors.length - 1), color);
    });

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.roundRect(x, y, width, height, 4);
    ctx.fill();

    const greyRectWidth = 278 - 2;
    const greyRectHeight = 44 - 2;
    const greyRectX = x + (width - greyRectWidth) / 2;
    const greyRectY = y + (height - greyRectHeight) / 2;

    ctx.globalAlpha = 0.8;
    ctx.fillStyle = '#2f302f';
    ctx.beginPath();
    ctx.roundRect(greyRectX, greyRectY, greyRectWidth, greyRectHeight, 4);
    ctx.fill();

    ctx.globalAlpha = 1;
    ctx.font = 'bold 22px sans-serif';
    ctx.fillStyle = gradient;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, x + width / 2, y + height / 2);

    ctx.fillStyle = originalFillStyle;
    ctx.font = originalFont;
    ctx.textAlign = originalTextAlign;
    ctx.textBaseline = originalTextBaseline;
    ctx.globalAlpha = originalGlobalAlpha;
  }
}

/*
async function drawYamiCopyRights(ctx, imagePath, x, y, w, h, reduce, shadowIntensity = 0.3, text = '') {
    try {
        const img = await loadImage(imagePath);
        const imgW = img.width;
        const imgH = img.height;
        const targetRatio = w / h;
        const imgRatio = imgW / imgH;

        let srcX = 0, srcY = 0, srcW = imgW, srcH = imgH;

        if (imgRatio > targetRatio) {
            srcW = imgH * targetRatio;
            srcX = (imgW - srcW) / 2;
        } else {
            srcH = imgW / targetRatio;
            srcY = (imgH - srcH) / 2;
        }

        const scale = reduce;
        const drawW = w * scale;
        const drawH = h * scale;
        const drawX = x + (w - drawW) / 2;
        const drawY = y + (h - drawH) / 2;

        const cornerRadius = 6;
        
        ctx.save();
        ctx.beginPath();
        ctx.roundRect(drawX, drawY, drawW, drawH, cornerRadius);
        ctx.clip();
        
        ctx.drawImage(img, srcX, srcY, srcW, srcH, drawX, drawY, drawW, drawH);

        if (shadowIntensity > 0) {
            ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(shadowIntensity, 1)})`;
            ctx.fillRect(drawX, drawY, drawW, drawH);
        }
        
        ctx.restore();

        if (text) {
    ctx.fillStyle = 'white';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = 0.8;

    let fontSize = 25;
    ctx.font = `bold ${fontSize}px rndd`;

    let maxWidth = drawW - 20; // 10px padding on each side
    let textWidth = ctx.measureText(text).width;

    // Reduce font size if needed to fit within image
    while (textWidth > maxWidth && fontSize > 10) {
        fontSize -= 1;
        ctx.font = `bold ${fontSize}px rndd`;
        textWidth = ctx.measureText(text).width;
    }

    ctx.fillText(text, drawX + drawW - 10, drawY + drawH / 2); // right aligned with 10px padding
    ctx.globalAlpha = 1;
}
    } catch (error) {
        console.error('Error loading copyright image:', error);
        // Fallback: draw a simple rectangle with text
        const cornerRadius = 6;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.beginPath();
        ctx.roundRect(x, y, w, h, cornerRadius);
        ctx.fill();
        
        if (text) {
            ctx.fillStyle = 'white';
            ctx.font = `bold 25px rndd`;
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            ctx.fillText(text, x + w - 40, y + h / 2);
        }
    }
}
*/

async function drawYamiCopyRights(ctx, imagePath, x, y, w, h, reduce, shadowIntensity = 0.3, text = '') {
    try {
        const img = await loadImage(imagePath);
        const imgW = img.width;
        const imgH = img.height;
        const targetRatio = w / h;
        const imgRatio = imgW / imgH;

        let srcX = 0, srcY = 0, srcW = imgW, srcH = imgH;

        if (imgRatio > targetRatio) {
            srcW = imgH * targetRatio;
            srcX = (imgW - srcW) / 2;
        } else {
            srcH = imgW / targetRatio;
            srcY = (imgH - srcH) / 2;
        }

        const scale = reduce;
        const drawW = w * scale;
        const drawH = h * scale;
        const drawX = x + (w - drawW) / 2;
        const drawY = y + (h - drawH) / 2;

        const cornerRadius = 6;

        ctx.save();
        ctx.beginPath();
        ctx.roundRect(drawX, drawY, drawW, drawH, cornerRadius);
        ctx.clip();

        ctx.drawImage(img, srcX, srcY, srcW, srcH, drawX, drawY, drawW, drawH);

        if (shadowIntensity > 0) {
            ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(shadowIntensity, 1)})`;
            ctx.fillRect(drawX, drawY, drawW, drawH);
        }

        ctx.restore();

        if (text) {
            ctx.fillStyle = 'white';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';

            let fontSize = 25;
            ctx.font = `bold ${fontSize}px rndd`;

            let maxWidth = drawW - 20;
            let textWidth = ctx.measureText(text).width;

            while (textWidth > maxWidth && fontSize > 10) {
                fontSize -= 1;
                ctx.font = `bold ${fontSize}px rndd`;
                textWidth = ctx.measureText(text).width;
            }

            ctx.shadowColor = 'white';
            ctx.shadowBlur = 12;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 0;

            ctx.fillText(text, drawX + drawW - 30, drawY + drawH / 2);

            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
        }
    } catch (error) {
        console.error('Error loading copyright image:', error);
        const cornerRadius = 6;
        ctx.fillStyle = 'white';
        ctx.beginPath();
        ctx.roundRect(x, y, w, h, cornerRadius);
        ctx.fill();

        if (text) {
            ctx.fillStyle = 'white';
            ctx.font = `bold 25px rndd`;
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            ctx.shadowColor = 'white';
            ctx.shadowBlur = 12;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 0;
            ctx.fillText(text, x + w - 40, y + h / 2);
            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
        }
    }
}
