exports.config = {
  name: "omnisell",
  aliases: [],
  version: "1.0",
  author: "Allou Mohamed",
  role: 0,
  category: "game",
  description: "Sell a collected alien for money.",
  guide: {
    syntax: "> omnisell AlienName",
    params: "AlienName: the name of the alien you want to sell",
    usage: "Example: > omnisell XLR8\nYou will sell the alien and receive money in return."
  }
};

exports.onStart = async function ({ message, usersData, args, event }) {
  const senderID = event.senderID;
  const name = args.join(" ")?.trim();
  if (!name) return message.reply("👻 اكتب اسم الفضائي الذي تريد بيعه.");

  let userAliens = await usersData.get(senderID, "data.omnitrex", []);
  const index = userAliens.findIndex(a => a.toLowerCase() === name.toLowerCase());
  if (index === -1) return message.reply("❌ لا تملك هذا الفضائي.");

  userAliens.splice(index, 1);
  await usersData.set(senderID, userAliens, "data.omnitrex");

  const amount = 1000;
  await usersData.addMoney(senderID, amount);
  return message.reply(`💸 تم بيع ${name} مقابل $${amount}.`);
};