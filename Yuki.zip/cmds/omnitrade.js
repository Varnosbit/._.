exports.config = {
  name: "omnitrade",
  aliases: [],
  version: "2.2",
  author: "Allou Mohamed",
  role: 0,
  category: "game",
  description: "Trade aliens with another user (with confirmation).",
  guide: {
    syntax: "> omnitrade YourAlien | TheirAlien",
    params: "YourAlien: the alien you're offering\nTheirAlien: the alien you want",
    usage: "Use while replying to the target user you want to trade with.\nExample: > omnitrade Heatblast | XLR8 (as a reply)"
  }
};

exports.onStart = async function ({ message, usersData, args, event, commandName }) {
  if (!event.messageReply) return message.reply("↩️ يجب الرد على رسالة المستخدم الذي تريد مبادلته.");
  const partnerID = event.messageReply.senderID;
  const senderID = event.senderID;

  if (partnerID === senderID) return message.reply("❌ لا يمكنك التبادل مع نفسك.");

  const text = args.join(" ").split("|").map(s => s.trim());
  if (text.length !== 2) return message.reply("📦 الصيغة: اسم_فضائك | اسم_فضائي_الطرف_الآخر");

  const [myAlien, theirAlien] = text;

  const myAliens = await usersData.get(senderID, "data.omnitrex", []);
  const partnerAliens = await usersData.get(partnerID, "data.omnitrex", []);

  const i1 = myAliens.findIndex(a => a.toLowerCase() === myAlien.toLowerCase());
  const i2 = partnerAliens.findIndex(a => a.toLowerCase() === theirAlien.toLowerCase());

  if (i1 === -1) return message.reply("❌ لا تملك الفضائي الذي تريد تقديمه.");
  if (i2 === -1) return message.reply("❌ المستخدم الآخر لا يملك الفضائي المطلوب.");

  const senderName = await usersData.getName(senderID);
  const partnerName = await usersData.getName(partnerID);

  const reply = await message.send(
    `🔁 طلب تبادل:\n` +
    `👤 ${senderName} يريد أن يبادلك، ${partnerName}:\n\n` +
    `🎁 ${myAlien} مقابل ${theirAlien}\n\n` +
    `✏️ إذا وافقت، أجب بـ "قبول"\n` +
    `❌ إذا رفضت، أجب بـ "رفض"`
  );

  global.YamiBot.onReply.set(reply.messageID, {
    commandName,
    author: senderID,
    partner: partnerID,
    myAlien,
    theirAlien,
    messageID: reply.messageID
  });
};

exports.onReply = async function ({ event, message, usersData, Reply }) {
  const { author, partner, myAlien, theirAlien, messageID } = Reply;

  if (event.senderID !== partner) return;

  const answer = event.body.trim().toLowerCase();
  const authorName = await usersData.getName(author);
  const partnerName = await usersData.getName(partner);

  if (answer === "قبول") {
    let myAliens = await usersData.get(author, "data.omnitrex", []);
    let partnerAliens = await usersData.get(partner, "data.omnitrex", []);

    const i1 = myAliens.findIndex(a => a.toLowerCase() === myAlien.toLowerCase());
    const i2 = partnerAliens.findIndex(a => a.toLowerCase() === theirAlien.toLowerCase());

    if (i1 === -1 || i2 === -1) {
      global.YamiBot.onReply.delete(messageID);
      return message.reply("❌ التبادل فشل. أحدكما لا يملك الفضائي المطلوب بعد الآن.");
    }

    myAliens.splice(i1, 1);
    partnerAliens.splice(i2, 1);
    myAliens.push(theirAlien);
    partnerAliens.push(myAlien);

    await usersData.set(author, myAliens, "data.omnitrex");
    await usersData.set(partner, partnerAliens, "data.omnitrex");

    global.YamiBot.onReply.delete(messageID);
    return message.reply(
      `✅ تمت المبادلة!\n` +
      `🤝 ${authorName} حصل على ${theirAlien}\n` +
      `🤝 ${partnerName} حصل على ${myAlien}`
    );
  }

  if (answer === "رفض") {
    global.YamiBot.onReply.delete(messageID);
    return message.reply(`🚫 ${partnerName} رفض التبادل.`);
  }
};