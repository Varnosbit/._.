const axios = require("axios");

exports.config = {
  name: "fastgen",
  aliases: ["توليد", "fg"], // first alias in Arabic
  role: 0,
  countDown: 15,
  author: "Allou Mohamed",
  desc: {
    en: "Fast generate images",
    ar: "توليد الصور بسرعة"
  },
  version: "2.4"
};

// Language object for getLang
exports.langs = {
  en: {
    noPrompt: "❌ Please provide a prompt to generate the image.",
    failed: "❌ Failed to generate images. Please try again.",
    error: "❌ An error occurred while generating the images.",
    generating: "⏳ Generating %1 images...",
    success: "✅ Successfully generated %1 images."
  },
  ar: {
    noPrompt: "❌ يرجى إدخال نص لإنشاء الصورة.",
    failed: "❌ فشل في إنشاء الصور. حاول مرة أخرى.",
    error: "❌ حدث خطأ أثناء إنشاء الصور.",
    generating: "⏳ جارٍ إنشاء %1 صورة...",
    success: "✅ تم إنشاء %1 صورة بنجاح."
  }
};

exports.onStart = async function ({ message, args, event, getLang }) {
  let userMessage = event.messageReply?.body || args.join(" ").trim();

  if (!userMessage) {
    return message.reply(getLang("noPrompt"));
  }

  let aspectRatio = "16:9", cn = 4;
  const aspectRatioMatch = userMessage.match(/--ar\s*(\d+:\d+)/);
  const cnMatch = userMessage.match(/--cn\s*(\d+)/);

  if (aspectRatioMatch) {
    aspectRatio = aspectRatioMatch[1];
    userMessage = userMessage.replace(/--ar\s*\d+:\d+/, "").trim();
  }

  if (cnMatch) {
    cn = parseInt(cnMatch[1]);
    userMessage = userMessage.replace(/--cn\s*\d+/, "").trim();
  }

  try {
    const imageLinks = [];
    if (cn > 4) message.reaction("⏳", event.messageID);

    for (let i = 0; i < cn; i++) {
      const response = await axios.get(
        `https://www.ai4chat.co/api/image/generate?prompt=${encodeURIComponent(userMessage)}&aspect_ratio=${encodeURIComponent(aspectRatio)}`
      );

      if (response.data.image_link) {
        imageLinks.push(response.data.image_link);
      } else {
        console.error(`Failed to generate image on attempt ${i + 1}`);
      }
    }

    if (imageLinks.length > 0) {
      if (cn > 4) message.reaction("✅", event.messageID);
      message.stream(imageLinks);
    } else {
      message.reply(getLang("failed"));
    }
  } catch (error) {
    console.error("Image generation error:", error.message);
    message.reply(getLang("error"));
  }
};
