const Config = require('./Config');
const Utils = require('./Utils');
const Variables = require('./Variables');
const Database = require('./Database');

async function assignRoles(game, playerCount) {
  const playerIDs = Utils.secureShuffle(Object.keys(game.players));
  const roles = Utils.getRoleDistribution(playerCount);
  
  playerIDs.forEach((id, i) => {
    const role = roles[i];
    game.players[id].role = role;
    const roleData = Config.ROLES[role];
    if (roleData.uses) {
      game.players[id].abilities[roleData.ability] = roleData.uses;
    }
    if (role === "executioner") {
      const others = playerIDs.filter(pid => pid !== id);
      const target = Utils.getRandomElement(others);
      game.players[id].executionerTarget = target;
    }
  });
  
  Variables.assignMafiaKillAbility(game);
}

async function sendRolesToPlayers(mqtt, game, usersData) {
  const mafiaMembers = [];
  const mafiaPlayers = [];
  
  for (const p of Object.values(game.players)) {
    if (Utils.isMafiaRole(p.role)) {
      const name = await usersData.getName(p.userID);
      const roleData = Config.ROLES[p.role];
      mafiaMembers.push(`🔴 ${name} - ${roleData.emoji} ${roleData.name}`);
      mafiaPlayers.push(p);
    }
  }
  
  const mafiaList = mafiaMembers.join("\n");
  
  if (!Config.InboxMode && mafiaPlayers.length > 0) {
    try {
      const mafiaGroupID = Variables.getAvailableGroupID();
      Variables.markGroupIDUsed(mafiaGroupID);
      Variables.setMafiaRoom(game.id, mafiaGroupID);
      game.mafiaGroupID = mafiaGroupID;
      
      for (const mafiaPlayer of mafiaPlayers) {
        await global.YamiBot.fcaApi.addUserToGroup(mafiaPlayer.userID, mafiaGroupID);
        await Utils.sleep(Config.gameSettings.actionDelayMs);
      }
      
      await Utils.sleep(2000);
    } catch (error) {
      console.error("[MAFIA42] Failed to create Mafia room:", error);
    }
  }
  
  for (const p of Object.values(game.players)) {
    const roleData = Config.ROLES[p.role];
    let msg = `${roleData.emoji} دورك في اللعبة ${roleData.emoji}
____________________________

🎭 ${roleData.name} 🎭

📝 ${roleData.desc}

____________________________

`;
    
    if (roleData.team === "mafia") {
      msg += `🔴 فريق المافيا 🔴
____________________________

أعضاء فريقك:
${mafiaList}

💬 ${Config.InboxMode ? "يمكنكم التحدث في الشات الخاص" : "يمكنكم التحدث في غرفة المافيا"}
🤝 تنسقوا مع بعض!
🔪 اقتلوا بحذر وذكاء

____________________________

`;
    } else if (roleData.team === "citizen") {
      msg += `🔵 فريق المواطنين 🔵
____________________________

🎯 الهدف: القضاء على المافيا كلها!
🕵️ استخدم قدراتك بذكاء
🤝 تعاون مع الفريق
⚖️ صوّت بحكمة

____________________________

`;
    } else if (roleData.team === "neutral") {
      msg += `⚪ محايد - هدف خاص ⚪
____________________________

🎯 لديك هدفك الخاص!
🎭 اخف نواياك
🧠 استغل الفريقين
🏆 حقق هدفك للفوز!

____________________________

`;
    } else if (roleData.team === "vampire") {
      msg += `🟣 مصاص دماء 🟣
____________________________

🧛 حول الجميع لمصاصي دماء!
🌙 اصبر واحذر
🎯 السيطرة على نصف المدينة

____________________________

`;
    }
    
    if (roleData.uses && roleData.uses < 10) {
      msg += `⚡ عدد الاستخدامات المحدودة: ${roleData.uses} مرة\n\n____________________________\n\n`;
    }
    
    if (p.role === "executioner" && p.executionerTarget) {
      const targetName = await usersData.getName(p.executionerTarget);
      msg += `🎯 هدفك الخاص: ${targetName}\n🪓 يجب أن يُقصى بالتصويت للفوز!\n\n____________________________\n\n`;
    }
    
    msg += `🔒 رسائلك سرية تماماً\n🎮 استمتع باللعبة\n🍀 حظاً موفقاً!`;
    
    await Utils.sendToPlayerOrRoom(mqtt, p, msg);
    await Utils.sleep(1000);
  }
  
  if (!Config.InboxMode && game.mafiaGroupID) {
    const welcomeMsg = `🔴 غرفة المافيا 🔴
____________________________

👥 الأعضاء:
${mafiaList}

____________________________

💬 يمكنكم التحدث هنا بحرية
🤝 تنسيق الخطط
🔪 اختاروا الأهداف بحكمة

🎯 هدفكم: السيطرة على المدينة!`;
    
    await mqtt.sendMessage(welcomeMsg, game.mafiaGroupID);
  }
}

async function processPendingPlayers(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  const pendingIDs = Object.keys(game.pendingPlayers);
  const playerCount = pendingIDs.length;
  
  if (playerCount < Config.gameSettings.minPlayers) {
    await mqtt.sendMessage(
      `❌ عدد اللاعبين غير كافٍ ❌
____________________________
- تم إلغاء اللعبة لان عددكم ${playerCount} ما يكفي. المرة الجاية تعالو في ${Config.gameSettings.minPlayers} ثم ابدو اللعبة يا 🫏🗿.`, 
      game.main
    );
    Variables.deleteGame(gameID);
    return;
  }
  
  const successful = [];
  const failed = [];
  
  for (const userID of pendingIDs) {
    try {
      let groupID = null;
      
      if (!Config.InboxMode) {
        groupID = Database.getPlayerRoom(userID);
        if (!groupID || Variables.usedGroupIDs.includes(groupID)) {
          groupID = Variables.getAvailableGroupID();
        }
        Variables.markGroupIDUsed(groupID);
        await global.YamiBot.fcaApi.addUserToGroup(userID, groupID);
      }
      
      game.players[userID] = Variables.initPlayer(userID, groupID);
      if (groupID) {
        game.playerGroups[userID] = groupID;
        Database.savePlayerRoom(userID, groupID);
      }
      
      successful.push(userID);
      await Utils.sleep(Config.gameSettings.actionDelayMs);
    } catch (err) {
      console.error(`[MAFIA42] Failed to add ${userID}:`, err);
      failed.push(userID);
      const groupID = game.playerGroups[userID];
      if (groupID) {
        Variables.releaseGroupID(groupID);
      }
    }
  }
  
  game.pendingPlayers = {};
  
  let resultMsg = `✅ نتائج الانضمام ✅
____________________________

`;
  if (successful.length > 0) {
    resultMsg += `✅ تم إدخال ${successful.length} لاعب بنجاح! 🎉\n\n`;
    for (let i = 0; i < Math.min(successful.length, 10); i++) {
      const name = await usersData.getName(successful[i]);
      resultMsg += `${i + 1}. ${name} ✅\n`;
    }
    if (successful.length > 10) {
      resultMsg += `... و ${successful.length - 10} آخرين ✅\n`;
    }
    resultMsg += `\n`;
  }
  
  if (failed.length > 0) {
    resultMsg += `❌ فشل إدخال ${failed.length} لاعب 😔\n\n`;
    for (let i = 0; i < Math.min(failed.length, 5); i++) {
      const name = await usersData.getName(failed[i]);
      resultMsg += `${i + 1}. ${name} ❌\n`;
    }
    if (failed.length > 5) {
      resultMsg += `... و ${failed.length - 5} آخرين ❌\n`;
    }
    resultMsg += `\n⚠️ السبب المحتمل:\n`;
    resultMsg += `• لم يرسلوا طلب صداقة للبوت\n`;
    resultMsg += `• لم يرسلوا رسالة خاصة للبوت\n`;
    resultMsg += `• حظروا البوت من المراسلة\n\n`;
    resultMsg += `💡 تأكدوا من إرسال طلب صداقة ورسالة!`;
  }
  
  await mqtt.sendMessage(resultMsg, game.main);
  
  const finalCount = Object.keys(game.players).length;
  if (finalCount < Config.gameSettings.minPlayers) {
    await mqtt.sendMessage(
      `❌ العدد غير كافٍ بعد الفشل ❌
____________________________
- تم الغاء اللعبة لان احد اللاعبين ال🫏 حط رياكشن بس ما ارسل طلب صداقة و رسالة خاص للبوت 🗿 عددكم ${finalCount} فقط ما يكفي للاسف جيبو ناس فيها مخ احسن من الفشل 🫏.`, 
      game.main
    );
    await cleanup(mqtt, game);
    return;
  }
  
  await Utils.sleep(2000);
  startGame(mqtt, gameID, usersData);
}

async function startGame(mqtt, gameID, usersData) {
  const game = Variables.getGame(gameID);
  if (!game) return;
  
  const playerCount = Object.keys(game.players).length;
  await assignRoles(game, playerCount);
  
  for (const userID of Object.keys(game.players)) {
    Database.initPlayerStats(userID);
  }
  
  await sendRolesToPlayers(mqtt, game, usersData);
  
  const mafiaCount = Variables.aliveMafia(game).length;
  await mqtt.sendMessage(
    Config.messages.gameStart(playerCount, mafiaCount) + `\n\n____________________________\n\n${Utils.formatGameStatus(game)}`,
    game.main
  );
  
  setTimeout(() => {
    const Night = require('./Night');
    Night.startNightPhase(mqtt, gameID, usersData);
  }, 10000);
}

async function cleanup(mqtt, game) {
  game.phase = "ended";
  Variables.clearAllTimers(game.id);
  
  if (!Config.InboxMode) {
    if (game.mafiaGroupID) {
      const mafiaPlayers = Object.values(game.players).filter(p => Utils.isMafiaRole(p.role));
      for (const mafiaPlayer of mafiaPlayers) {
        try {
          await mqtt.removeUserFromGroup(mafiaPlayer.userID, game.mafiaGroupID);
          await Utils.sleep(Config.gameSettings.actionDelayMs);
        } catch (err) {
          console.error(`[MAFIA42] Failed to remove ${mafiaPlayer.userID} from Mafia room:`, err);
        }
      }
      Variables.releaseMafiaRoom(game.id);
    }
    
    for (const [userID, groupID] of Object.entries(game.playerGroups)) {
      try {
        Variables.releaseGroupID(groupID);
        await mqtt.removeUserFromGroup(userID, groupID);
        Database.removePlayerFromRoom(userID);
      } catch (err) {
        console.error(`[MAFIA42] Failed to remove ${userID}:`, err);
      }
      await Utils.sleep(Config.gameSettings.actionDelayMs);
    }
  }
  
  Variables.deleteGame(game.id);
  
  if (global.YamiBot.onReply) {
    for (const [msgID, data] of global.YamiBot.onReply.entries()) {
      if (data.gameID === game.id) {
        global.YamiBot.onReply.delete(msgID);
      }
    }
  }
}

async function handleGameEnd(mqtt, game, endResult, usersData) {
  const { winner, specialPlayer } = endResult;
  let winnerPlayers = [];
  
  if (winner === "mafia") {
    winnerPlayers = Object.values(game.players).filter(p => Utils.isMafiaRole(p.role));
  } else if (winner === "citizen") {
    winnerPlayers = Object.values(game.players).filter(p => Utils.isCitizenRole(p.role));
  } else if (winner === "neutral" && specialPlayer) {
    winnerPlayers = [specialPlayer];
  } else if (winner === "vampire") {
    winnerPlayers = Object.values(game.players).filter(p => 
      Config.ROLES[p.role].team === "vampire" || p.convertedToVampire
    );
  }
  
  const report = await Utils.createGameReport(game, winner, usersData);
  let announcement = report + `\n\n🎁 الجوائز:\n____________________________\n\n`;
  const rewards = [];
  
  for (const player of winnerPlayers) {
    Database.awardPlayer(player.userID, Config.rewards.win.money, Config.rewards.win.points, "فوز", usersData);
    const name = await usersData.getName(player.userID);
    rewards.push(`🏆 ${name}: +${Config.rewards.win.money} 💰 +${Config.rewards.win.points} ⭐`);
    Database.recordGameResult(player.userID, true, player.alive);
  }
  
  const losers = Object.values(game.players).filter(p => 
    !winnerPlayers.some(w => w.userID === p.userID)
  );
  
  for (const player of losers) {
    if (player.alive) {
      Database.awardPlayer(player.userID, Config.rewards.survived.money, Config.rewards.survived.points, "ناجٍ", usersData);
      const name = await usersData.getName(player.userID);
      rewards.push(`💪 ${name}: +${Config.rewards.survived.money} 💰 +${Config.rewards.survived.points} ⭐ (ناجٍ)`);
    }
    Database.recordGameResult(player.userID, false, player.alive);
  }
  
  if (rewards.length > 0) {
    announcement += rewards.slice(0, 12).join("\n");
    if (rewards.length > 12) {
      announcement += `\n... و ${rewards.length - 12} آخرين`;
    }
  }
  
  announcement += `\n\n____________________________\n💡 ${Config.exchangeRate} نقطة = 1 💰\n🛒 زر المتجر!`;
  
  Variables.updateLeaderboard(Database.getAllPlayerStats());
  await mqtt.sendMessage(announcement, game.main);
  await cleanup(mqtt, game);
}

module.exports = {
  assignRoles,
  sendRolesToPlayers,
  processPendingPlayers,
  startGame,
  cleanup,
  handleGameEnd
};
