module.exports = {
  config: {
    name: "quiz",
    aliases: ["حزورة"],
    version: "1.6",
    author: "Allou Mohamed",
    countDown: 15,
    role: 0,
    description: "Hard Arabic quizzes. Win small rewards for correct answers.",
    category: "Owner",
    guide: {
      syntax: "quiz",
      params: "-",
      usage: "-"
    }
  },

  onStart: async function ({ message, event, usersData, args, api }) {
    // Fetch the quiz and its correct answer
    const { quiz, answer, help } = helpers.Quiz();
    const correctAnswer = answer.trim().toLowerCase();
    const regex = new RegExp(correctAnswer);

    // Add listener for this user until they answer correctly
    global.onListen.add(
      event.senderID,
      async ({ event }) => regex.test(event?.body?.trim()?.toLowerCase()),
      async ({ message, usersData, event }) => {
        const reward = 10;
        const userName = await usersData.getName(event.senderID);
        const mentionTag = "@" + userName;

        await usersData.addMoney(event.senderID, reward);
        const newBalance = await usersData.getMoney(event.senderID);

        const replyText = 
          `😁 ${mentionTag}:\n` +
          `✅ جوابك صحيح: ${correctAnswer}\n` +
          `💸 ربحت ${reward} دينار تافه، ورصيدك صار الآن ${newBalance} دينار.`;

        message.reply({
          body: replyText,
          mentions: [{ tag: mentionTag, id: event.senderID }]
        });
      }
    );

    // Send the quiz and a hint
    message.reply(`${quiz}\n🧠 تلميح: ${help}`);
  }
};
