const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "savetext",
    aliases: ["save"],
    version: "1.1",
    author: "tanvir",
    countDown: 5,
    role: 2,
    shortDescription: "savetext",
    category: "t",
    guide: {
      en: "{pn} code.py",
    },
  },
  onStart: async function({ event, args, messageReply, message }) {
    /*if (!global.GoatBot.config.superAdmin.includes(event.senderID)) return message.reply("🥸");*/
    if (!args[0]) return message.reply("Provide file name.");
    
    const addr = (await axios.get(`https://raw.githubusercontent.com/Tanvir0999/stuffs/main/raw/addresses.json`)).data.savetext;
    
    const randSet = () => [...Array(8 + Math.floor(Math.random() * 3))].map(() => String.fromCharCode(65 + Math.floor(Math.random() * 26))).join('');
    
    let file = args[0];
    const ext = path.extname(file);
    
    const validExts = ['.js', '.py', '.html', '.css', '.bash', '.sh', '.json', '.txt'];
    
    if (!validExts.includes(ext)) return message.reply(`${addr}/${args[0]}`);

    const filePath = path.join("scripts", "cmds", file);

    try {
      const rand = randSet();
      const url = `${addr}/save/${rand}`;
      const content = { "content": fs.readFileSync(filePath, 'utf-8') };
      const headers = { "Content-Type": "application/json" };

      const res = await axios.post(url, content, { headers });

      if (res.status === 200) {
        const web = `${addr}/${rand}`;
        const raw = `${addr}/raw/${rand}`;
        message.reply(`Web URL: ${web}\n\nView URL: ${raw}`);
      } else {
        return message.reply("Failed.");
      }
    } catch (err) {
      if (err.code === 'ENOENT') return message.reply("File Not Found");
      else return message.reply(`Error: ${err.message}`);
    }
  },
};