const sucksios = require("axios");
const taktApi = "https://fuckingmj.onrender.com/mj";

module.exports = {
    config: {
        name: "mj",
        author: "takt & allou",
        description: "mj image gen",
        category: "Ai",
        version: "1.0-beta",
        role: 2,
        countDown: 20
    },
    onStart: async (alu_takt) => {
        await MJ(alu_takt);
    },
    onReply: async (alu_takt) => {
        await MJ(alu_takt);
    }
};

async function MJ(alu_takt) {
    const {
        message,
        Reply,
        commandName,
        event,
        args
    } = alu_takt;
    const userID = event.senderID;
    if (Reply && Reply.userID != userID) return;
    if (Reply) {
        const choose = args[0].split(/u/i)[1];
        if (!["1", "2", "3", "4"].includes(choose)) {
            return message.reply("❌ Invalid upscale request.");
        }

        const taktKey = "upscale";

        const getTask = async () => {
            try {
                    const {
                        data
                    } = await sucksios.get(`${taktApi}?id=${Reply.mj.id}&num=${taktKey + choose}`);
                    return message.stream(`✅ Successfully upscaled: U${choose}`, [data.img]);
                } catch (error) {
                return message.reply("❌ Failed to upscale. Please try again later.");
            }
        };
        return await getTask();
    } else {
        const prompt = args.join(" ").length > 0 ? args.join(" "): null;
        if (!prompt) return message.reply("❌ Can't Add Mj Task:\n\n- Invalid Prompt.");
        const addTask = async () => {
            message.reply("⛵ Building request...");
            const {
                data: mj
            } = await sucksios.get(taktApi+"?prompt="+encodeURIComponent(prompt));
            if(mj?.code == "forbidden") return message.reply("❌ Failed to add task:\n\n"+mj.message);
            return message.stream("✅ Midjourney process done.\n- Upscale U1, U2, U3, U4", mj.img, (gay, notgay) => {
                if (gay) return message.reply("❌ Failed to build Request:\n\n"+gay.message);
                global.YukiBot.onReply.set(notgay.messageID, {
                    commandName,
                    userID,
                    mj
                });
            });
        }
        await addTask();
    }
}