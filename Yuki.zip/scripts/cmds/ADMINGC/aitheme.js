//3.0.1
const axios = require('axios');
const { createCanvas, loadImage, registerFont } = require('canvas');

(async () => await registerFont(process.cwd()+'/scripts/cmds/canvas/fonts/HelveticaNeueRoman.otf', { family: 'Helvetica Neue' }))();


function textBubble(options) {
    const {
        text,
        textColor = '#000000',
        font = 'Arial',
        fontSize = 16,
        padding = 10,
        bgColor = '#ffffff',
        borderPx = 0,
        borderColor = '#000000',
        maxTextWidth = 300,
        cornerRadius = 0,
        minBubbleWidth = 0
    } = options;

    const pad = typeof padding === 'object'
        ? { top: padding.top || 0, bottom: padding.bottom || 0, left: padding.left || 0, right: padding.right || 0 }
        : { top: padding, bottom: padding, left: padding, right: padding };

    pad.top *= 1;
    pad.bottom *= 0.1;

    const radius = typeof cornerRadius === 'object'
        ? { tl: cornerRadius.tl || 0, tr: cornerRadius.tr || 0, br: cornerRadius.br || 0, bl: cornerRadius.bl || 0 }
        : { tl: cornerRadius, tr: cornerRadius, br: cornerRadius, bl: cornerRadius };

    const tempCanvas = createCanvas(1, 1);
    const tempCtx = tempCanvas.getContext('2d');
    tempCtx.font = `${fontSize}px ${font}`;
    const trimmedText = text.replace(/\s+$/, '');

    function wrapText(ctx, text, maxWidth) {
        const lines = [];
        const paragraphs = text.split('\n');
        for (const paragraph of paragraphs) {
            if (paragraph.trim() === '') {
                lines.push('');
                continue;
            }
            const words = paragraph.split(' ');
            let currentLine = '';
            for (let i = 0; i < words.length; i++) {
                const word = words[i];
                const wordWidth = ctx.measureText(word).width;
                if (wordWidth > maxWidth) {
                    if (currentLine.trim()) {
                        lines.push(currentLine.trim());
                        currentLine = '';
                    }
                    let remainingWord = word;
                    while (remainingWord.length > 0) {
                        let chunk = '';
                        for (let j = 0; j < remainingWord.length; j++) {
                            const testChunk = remainingWord.substring(0, j + 1);
                            if (ctx.measureText(testChunk).width > maxWidth) {
                                chunk = remainingWord.substring(0, Math.max(1, j));
                                break;
                            }
                            chunk = testChunk;
                        }
                        if (chunk === remainingWord) {
                            lines.push(chunk);
                            remainingWord = '';
                        } else {
                            lines.push(chunk);
                            remainingWord = remainingWord.substring(chunk.length);
                        }
                    }
                } else {
                    const testLine = currentLine ? currentLine + ' ' + word : word;
                    const testWidth = ctx.measureText(testLine).width;
                    if (testWidth > maxWidth && currentLine) {
                        lines.push(currentLine.trim());
                        currentLine = word;
                    } else {
                        currentLine = testLine;
                    }
                }
            }
            if (currentLine.trim()) {
                lines.push(currentLine.trim());
            }
        }
        return lines;
    }

    const lines = wrapText(tempCtx, trimmedText, maxTextWidth);
    const lineHeight = fontSize * 1.2;
    const textHeight = lines.length * lineHeight;

    let maxLineWidth = 0;
    for (const line of lines) {
        const lineWidth = tempCtx.measureText(line).width;
        if (lineWidth > maxLineWidth) maxLineWidth = lineWidth;
    }

    let bubbleWidth = maxLineWidth + pad.left + pad.right + (borderPx * 2);
    if (bubbleWidth < minBubbleWidth) bubbleWidth = minBubbleWidth;
    const bubbleHeight = textHeight + pad.top + pad.bottom + (borderPx * 2);

    const canvas = createCanvas(Math.ceil(bubbleWidth), Math.ceil(bubbleHeight));
    const ctx = canvas.getContext('2d');

    function applyColor(ctx, color, x, y, width, height) {
        if (Array.isArray(color)) {
            if (color.length === 0) return '#000000';
            const isConfigArray = color.some(c => typeof c === 'object' && c.hex);
            if (isConfigArray) {
                const gradient = ctx.createLinearGradient(x, y, x + width, y);
                color.forEach((stop, idx) => {
                    const position = stop.position !== undefined ? stop.position : idx / (color.length - 1);
                    gradient.addColorStop(position, stop.hex);
                });
                return gradient;
            } else {
                const gradient = ctx.createLinearGradient(x, y, x + width, y);
                color.forEach((c, idx) => gradient.addColorStop(idx / (color.length - 1), c));
                return gradient;
            }
        }
        return color;
    }

    function roundedRect(ctx, x, y, width, height, r) {
        ctx.beginPath();
        ctx.moveTo(x + r.tl, y);
        ctx.lineTo(x + width - r.tr, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + r.tr);
        ctx.lineTo(x + width, y + height - r.br);
        ctx.quadraticCurveTo(x + width, y + height, x + width - r.br, y + height);
        ctx.lineTo(x + r.bl, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - r.bl);
        ctx.lineTo(x, y + r.tl);
        ctx.quadraticCurveTo(x, y, x + r.tl, y);
        ctx.closePath();
    }

    ctx.fillStyle = applyColor(ctx, bgColor, 0, 0, bubbleWidth, bubbleHeight);
    roundedRect(ctx, borderPx / 2, borderPx / 2, bubbleWidth - borderPx, bubbleHeight - borderPx, radius);
    ctx.fill();

    if (borderPx > 0) {
        ctx.strokeStyle = applyColor(ctx, borderColor, 0, 0, bubbleWidth, bubbleHeight);
        ctx.lineWidth = borderPx;
        ctx.stroke();
    }

    ctx.font = `${fontSize}px ${font}`;
    ctx.textBaseline = 'top';

    const textX = borderPx + pad.left;
    let textY = borderPx + pad.top - fontSize * 0.15;

    for (const line of lines) {
        ctx.fillStyle = applyColor(ctx, textColor, textX, textY, maxLineWidth, lineHeight);
        ctx.fillText(line, textX, textY);
        textY += lineHeight;
    }

    return canvas.toBuffer('image/png');
}

async function genExample(themeObject) {

    const font = 'Helvetica Neue, sans-serif';
    const imageUrl = themeObject.background_asset?.image?.uri;
    const primary_message_bubble_color = `#${themeObject.gradient_colors?.[0].slice(2) || "0084ff"}`;
    const secondary_message_bubble_color = `#${themeObject.inbound_message_gradient_colors?.[0].slice(2) || "f0f2f5"}`;
    const primary_message_text_color = `#${themeObject.message_text_color?.slice(2) || "ffffff"}`;
    const secondary_message_text_color = `#${themeObject.secondary_text_color?.slice(2) || "000000"}`;
    const tertiary_text_color = `#${themeObject.tertiary_text_color?.slice(2) || "888888"}`;
    const messages = [
        {
            type: "right",
            text: "There are many themes to choose from and they're all a little different.",
            cornerRadius: {
                tl: 56,
                tr: 56,
                br: 10,
                bl: 56,
            },
        },
        {
            type: "right",
            text: "You'll see the messages you send to other people in this color.",
            cornerRadius: {
                tl: 56,
                tr: 10,
                br: 56,
                bl: 56,
            },
        },
        {
            type: "left",
            text: "And messages from your friends will look like this.",
            cornerRadius: {
                tl: 56,
                tr: 56,
                br: 56,
                bl: 56,
            },
        },
        {
            type: "time",
            text: "8:49 PM"
        },
        {
            type: "right",
            text: "Click Select to select this theme.",
            cornerRadius: {
                tl: 56,
                tr: 56,
                br: 56,
                bl: 56,
            },
        }
    ];

    if (!imageUrl) {
        throw new Error('No background image URL found in the object');
    }

    const response = await axios({
        url: imageUrl,
        method: 'GET',
        responseType: 'arraybuffer'
    });

    const imageBuffer = Buffer.from(response.data);
    const img = await loadImage(imageBuffer);

    const targetWidth = 945;
    const targetHeight = 1670;

    const canvas = createCanvas(targetWidth, targetHeight);
    const ctx = canvas.getContext('2d');
    ctx.font = font;

    const sourceWidth = img.width;
    const sourceHeight = img.height;

    const scaleWidth = targetWidth / sourceWidth;
    const scaleHeight = targetHeight / sourceHeight;
    const scale = Math.max(scaleWidth, scaleHeight);

    const scaledWidth = sourceWidth * scale;
    const scaledHeight = sourceHeight * scale;

    const offsetX = (targetWidth - scaledWidth) / 2;
    const offsetY = (targetHeight - scaledHeight) / 2;

    ctx.drawImage(img, offsetX, offsetY, scaledWidth, scaledHeight);
    let currentY = 200;
    for (const message of messages) {
        if (message.type === "time") {
            currentY += 70;
            ctx.font = `36px Helvetica Neue`;
            ctx.fillStyle = tertiary_text_color;
            ctx.textAlign = "center";
            ctx.fillText(message.text, canvas.width / 2, currentY);
            currentY += 50;
            continue;
        }

        const bubbleBuffer = await textBubble({
            text: message.text,
            maxTextWidth: 580,
            fontSize: 42,
            font: "Helvetica Neue",
            padding: 30,
            cornerRadius: message.cornerRadius || 56,
            bgColor: message.type === "right" ? primary_message_bubble_color : secondary_message_bubble_color,
            textColor: message.type === "right" ? primary_message_text_color : secondary_message_text_color,
        });

        const bubbleImage = await loadImage(bubbleBuffer);
        if (message.type === "left") {
            currentY += 30;
        };

        const bubbleX = message.type === "right" ? canvas.width - bubbleImage.width - 30 : 30;
        ctx.drawImage(bubbleImage, bubbleX, currentY);

        currentY += bubbleImage.height + 5;
    }

    const stream = await canvas.createPNGStream();
    stream.path = `${themeObject.accessibility_label}.png`;
    return stream;
}

module.exports = {
    config: {
        name: "aitheme",
        aliases: ["سمة"],
        version: "2.0",
        author: "isai",
        role: 0,
        shortDescription: {
            en: 'Generate AI themes'
        },
        longDescription: {
            en: "Generate multiple AI themes using AI and apply them to your chat",
            ar: "تغيير ثيم الجروب بالذكاء الاصطناعي"
        },
        category: "theme",
        guide: {
            en: "{pn} [prompt] - Generate themes based on your description\nExample: {pn} dark ocean waves",
            ar: "{pn}  برومبت"
        },
    },

    onStart: async function ({ api, event, args, message }) {
        try {
            const prompt = args.join(" ");

            if (!prompt) {
                return message.reply("⚠ Gomen… please provide a theme prompt.\n\nExample: aitheme dark ocean waves");
            }

            const loadingMsg = await message.reply("⟳ Matte… generating AI themes for you.");

            const themes = await api.makeAiTheme(prompt);

            if (!themes || themes.length === 0) {
                await api.editMessage("✗ Zannen… no themes were generated. Please try a different prompt.", loadingMsg.messageID);
                return;
            }

            const themeList = themes.map((theme, index) =>
                `${index + 1}. ${theme.name || theme.accessibility_label || `Theme ${index + 1}`}`
            ).join("\n");

            let attachments = [];
            for (const theme of themes) {
                const example = await genExample(theme);
                attachments.push(example);
                if (theme.alternative_themes?.length) {
                    for (const altTheme of theme.alternative_themes) {
                        const altExample = await genExample(altTheme);
                        attachments.push(altExample);
                    };
                };
            };

            const info = await message.reply({
                body: `★ Mō matasemasen!\n\n${themeList}\n\n→ Reply with a number (1-${themes.length}) to apply the theme to this chat.`,
                attachment: attachments
            });


            await global.GoatBot.onReply.set(info.messageID, {
                commandName: this.config.name,
                messageID: info.messageID,
                author: event.senderID,
                themes,
                threadID: event.threadID,
                loadingMessageID: loadingMsg.messageID,
            });

            await api.editMessage(`✓ Yatta! Successfully generated ${themes.length} theme${themes.length > 1 ? 's' : ''}!`, loadingMsg.messageID);
        } catch (error) {
            console.error("Error in aitheme command:", error);
            message.reply(`✗ Gomen nasai… failed to generate themes.`);
        }
    },

    onReply: async function ({ event, args, Reply, message, api, mqtt }) {
        try {
            const { messageID, themes, author, threadID, loadingMessageID } = Reply;

            if (event.senderID !== author) {
                return message.reply("⚠ Chotto matte… only the person who requested the themes can select one.");
            }

            const choice = parseInt(args[0], 10);

            if (isNaN(choice) || choice < 1 || choice > themes.length) {
                return message.reply(`⚠ Dame… invalid choice. Please reply with a number between 1 and ${themes.length}.`);
            }
            let attachments = [];
            const selectedTheme = themes[choice - 1];
            const themeName = selectedTheme.name || selectedTheme.accessibility_label || `Theme ${choice}`;
            const example = await genExample(selectedTheme);

            attachments.push(example);

            if (selectedTheme.alternative_themes?.length) {
                for (const altTheme of selectedTheme.alternative_themes) {
                    const altExample = await genExample(altTheme);
                    attachments.push(altExample);
                };
            };

            await api.unsendMessage(messageID);
            mqtt.setTheme(threadID, selectedTheme.id);
            await new Promise(resolve => setTimeout(resolve, 5000));
            message.send({
                    body: `✓ Kanpeki! Theme "${themeName}" has been set, Senpai ♡`,
                    attachment: attachments
                });

            global.GoatBot.onReply.delete(messageID);

        } catch (error) {
            console.error("Error in onReply:", error);
            message.reply(`✗ Gomen nasai… an error occurred while applying the theme.`);
        }
    }
};
