const { randomString, getTime, convertTime } = global.utils;
const { createCanvas } = require('canvas');

// Difficulty settings
const difficulties = {
    easy: { name: "Easy", gridSize: 6, colors: 4, timeLimit: 300, pointsPerMatch: 10, shuffleLimit: 3 },
    medium: { name: "Medium", gridSize: 8, colors: 5, timeLimit: 240, pointsPerMatch: 15, shuffleLimit: 2 },
    hard: { name: "Hard", gridSize: 10, colors: 6, timeLimit: 180, pointsPerMatch: 20, shuffleLimit: 1 }
};

// Color palette
const colorPalette = {
    1: { name: "Ruby", hex: "#e63946", glow: "rgba(230, 57, 70, 0.5)" },
    2: { name: "Sapphire", hex: "#1d3557", glow: "rgba(29, 53, 87, 0.5)" },
    3: { name: "Emerald", hex: "#2a9d8f", glow: "rgba(42, 157, 143, 0.5)" },
    4: { name: "Topaz", hex: "#f4a261", glow: "rgba(244, 162, 97, 0.5)" },
    5: { name: "Amethyst", hex: "#7209b7", glow: "rgba(114, 9, 183, 0.5)" },
    6: { name: "Turquoise", hex: "#48cae4", glow: "rgba(72, 202, 228, 0.5)" }
};

module.exports = {
    config: {
        name: "colorclash",
        aliases: ["clash"],
        version: "1.0",
        author: "Grok",
        countDown: 5,
        role: 0,
        description: { en: "A vibrant tile-matching puzzle game" },
        category: "game",
        guide: { en: "  {pn} [difficulty]: Start a game\n  {pn} rank [page]: View leaderboard\n  {pn} stats [user]: View stats\n  {pn} reset: Reset rankings (admin)" }
    },

    langs: {
        en: {
            leaderboard: "COLOR CLASH CHAMPIONS:\n%1",
            pageInfo: "Page %1/%2",
            noScore: "No scores yet!",
            noPermissionReset: "No permission to reset.",
            notFoundUser: "User %1 not found.",
            playerStats: "Stats: %1\nScore: %2\nGames: %3\nBest: %4\nTime: %5\nFav: %6\n\n%7",
            difficultyStats: "  %1: %2 games (avg: %3)",
            resetSuccess: "Rankings reset!",
            invalidDifficulty: "Invalid difficulty!",
            gameCreated: "Started!\nDifficulty: %1\nTime: %2\nShuffles: %3\n\nSwap tiles: row1 col1 row2 col2",
            invalidMove: "Invalid format!",
            invalidPosition: "Invalid positions!",
            noMatch: "No match!",
            moveSuccess: "Cleared %1 tiles for %2 points!\nCombo: x%3 | Total: %4",
            gameOver: "Over!\nScore: %1\nTime: %2\nDifficulty: %3",
            timeOut: "Time's up!\nScore: %1\nDifficulty: %2",
            hintUsed: "Hint: Swap (%1, %2) with (%3, %4)",
            noHintAvailable: "No moves! Try shuffling.",
            shuffleUsed: "Shuffled! %1 left.",
            noShufflesLeft: "No shuffles left!"
        }
    },

    onStart: async function ({ message, event, getLang, args, globalData, usersData, role }) {
        if (args[0] === "rank") {
            const rankings = await globalData.get("colorClashRankings", "data", []);
            if (!rankings.length) return message.reply(getLang("noScore"));

            const page = parseInt(args[1]) || 1;
            const perPage = 10;
            const start = (page - 1) * perPage;
            const end = page * perPage;

            const rankedPlayers = await Promise.all(
                rankings.slice(start, end).map(async (player, i) => {
                    const userName = await usersData.getName(player.id);
                    const avgScore = player.games > 0 ? Math.floor(player.totalScore / player.games) : 0;
                    return `${start + i + 1}. ${userName}\n   ${player.totalScore} points | ${player.games} games | ${avgScore} avg`;
                })
            );
            const totalPages = Math.ceil(rankings.length / perPage);
            return message.reply(getLang("leaderboard", rankedPlayers.join("\n\n")) + "\n\n" + getLang("pageInfo", page, totalPages));
        }

        if (args[0] === "stats") {
            const rankings = await globalData.get("colorClashRankings", "data", []);
            let targetID = event.senderID;
            if (args[1]) targetID = args[1];
            const player = rankings.find(p => p.id == targetID);
            if (!player) return message.reply(getLang("notFoundUser", targetID));

            const userName = await usersData.getName(targetID);
            const avgTime = player.games > 0 ? convertTime(Math.floor(player.totalTime / player.games)) : "N/A";
            const favDiff = Object.keys(player.difficultyStats).reduce((a, b) => player.difficultyStats[a] > player.difficultyStats[b] ? a : b, "none");
            const diffBreakdown = Object.entries(player.difficultyStats)
                .map(([diff, count]) => getLang("difficultyStats", diff, count, Math.floor(player.difficultyScores[diff] / count)))
                .join("\n");

            return message.reply(getLang("playerStats", userName, player.totalScore, player.games, player.bestScore, avgTime, favDiff, diffBreakdown));
        }

        if (args[0] === "reset" && role >= 2) {
            await globalData.set("colorClashRankings", [], "data");
            return message.reply(getLang("resetSuccess"));
        }

        const difficulty = difficulties[args[0]?.toLowerCase()] ? args[0].toLowerCase() : "easy";
        if (!difficulties[difficulty]) return message.reply(getLang("invalidDifficulty"));

        const gameData = {
            grid: generateGrid(difficulties[difficulty].gridSize, difficulties[difficulty].colors),
            score: 0,
            difficulty,
            timeStart: getTime("x"),
            timeLimit: difficulties[difficulty].timeLimit,
            shufflesLeft: difficulties[difficulty].shuffleLimit,
            isFinished: false,
            author: event.senderID,
            combos: 0
        };

        const gameImage = createGameImage(gameData);
        message.reply({
            body: getLang("gameCreated", difficulties[difficulty].name, convertTime(gameData.timeLimit), gameData.shufflesLeft),
            attachment: gameImage
        }, (err, info) => {
            if (!err) {
                global.GoatBot.onReply.set(info.messageID, {
                    commandName: "colorclash",
                    messageID: info.messageID,
                    author: event.senderID,
                    gameData
                });
            }
        });
    },

    onReply: async function ({ message, Reply, event, getLang, globalData }) {
        const { gameData } = Reply;
        if (event.senderID !== gameData.author || gameData.isFinished) return;

        const timeElapsed = getTime("x") - gameData.timeStart;
        if (timeElapsed > gameData.timeLimit) {
            gameData.isFinished = true;
            await updatePlayerStats(event.senderID, gameData, gameData.score, timeElapsed, globalData);
            const gameImage = createGameImage(gameData);
            message.reply({
                body: getLang("timeOut", gameData.score, difficulties[gameData.difficulty].name),
                attachment: gameImage
            });
            global.GoatBot.onReply.delete(Reply.messageID);
            return;
        }

        const input = event.body.trim().toLowerCase();

        if (input === "hint") {
            const move = getValidMove(gameData.grid);
            if (move) return message.reply(getLang("hintUsed", move.r1 + 1, move.c1 + 1, move.r2 + 1, move.c2 + 1));
            return message.reply(getLang("noHintAvailable"));
        }

        if (input === "shuffle") {
            if (gameData.shufflesLeft <= 0) return message.reply(getLang("noShufflesLeft"));
            gameData.grid = shuffleGrid(gameData.grid, difficulties[gameData.difficulty].colors);
            gameData.shufflesLeft--;
            const gameImage = createGameImage(gameData);
            message.reply({
                body: getLang("shuffleUsed", gameData.shufflesLeft),
                attachment: gameImage
            });
            return;
        }

        const parts = input.split(/\s+/);
        if (parts.length !== 4 || parts.some(p => isNaN(p))) return message.reply(getLang("invalidMove"));

        const r1 = parseInt(parts[0]) - 1;
        const c1 = parseInt(parts[1]) - 1;
        const r2 = parseInt(parts[2]) - 1;
        const c2 = parseInt(parts[3]) - 1;

        const gridSize = difficulties[gameData.difficulty].gridSize;
        if (r1 < 0 || r1 >= gridSize || c1 < 0 || c1 >= gridSize || r2 < 0 || r2 >= gridSize || c2 < 0 || c2 >= gridSize || (Math.abs(r1 - r2) + Math.abs(c1 - c2) !== 1)) {
            return message.reply(getLang("invalidPosition"));
        }

        const newGrid = gameData.grid.map(row => [...row]);
        [newGrid[r1][c1], newGrid[r2][c2]] = [newGrid[r2][c2], newGrid[r1][c1]];

        let matches = findMatches(newGrid);
        if (!matches.length) return message.reply(getLang("noMatch"));

        let pointsEarned = 0;
        let tilesCleared = 0;
        let comboCount = 0;
        let tempGrid = newGrid;

        while (matches.length) {
            const currentMatches = matches.reduce((sum, m) => sum + m.length, 0);
            tilesCleared += currentMatches;
            pointsEarned += currentMatches * difficulties[gameData.difficulty].pointsPerMatch * (comboCount + 1);
            comboCount++;
            tempGrid = clearMatches(tempGrid, matches);
            tempGrid = dropTiles(tempGrid);
            matches = findMatches(tempGrid);
        }

        gameData.grid = tempGrid;
        gameData.score += pointsEarned;
        gameData.combos = Math.max(gameData.combos, comboCount);

        const gameImage = createGameImage(gameData);

        if (!hasValidMoves(gameData.grid)) {
            gameData.isFinished = true;
            await updatePlayerStats(event.senderID, gameData, gameData.score, timeElapsed, globalData);
            message.reply({
                body: getLang("gameOver", gameData.score, convertTime(timeElapsed), difficulties[gameData.difficulty].name),
                attachment: gameImage
            });
            global.GoatBot.onReply.delete(Reply.messageID);
        } else {
            message.reply({
                body: getLang("moveSuccess", tilesCleared, pointsEarned, comboCount, gameData.score),
                attachment: gameImage
            }, (err, info) => {
                if (!err) {
                    global.GoatBot.onReply.set(info.messageID, {
                        commandName: "colorclash",
                        messageID: info.messageID,
                        author: gameData.author,
                        gameData
                    });
                }
            });
        }
    }
};

// Helper functions
function generateGrid(size, colors) {
    const grid = Array(size).fill().map(() => Array(size).fill().map(() => Math.floor(Math.random() * colors) + 1));
    while (findMatches(grid).length > 0) {
        grid.forEach(row => row.forEach((_, i) => row[i] = Math.floor(Math.random() * colors) + 1));
    }
    return grid;
}

function findMatches(grid, min = 3) {
    const matches = [];
    const size = grid.length;

    for (let i = 0; i < size; i++) {
        let count = 1;
        for (let j = 1; j < size; j++) {
            if (grid[i][j] === grid[i][j - 1] && grid[i][j] !== 0) {
                count++;
            } else {
                if (count >= min) matches.push(Array.from({ length: count }, (_, k) => [i, j - count + k]));
                count = 1;
            }
        }
        if (count >= min) matches.push(Array.from({ length: count }, (_, k) => [i, size - count + k]));
    }

    for (let j = 0; j < size; j++) {
        let count = 1;
        for (let i = 1; i < size; i++) {
            if (grid[i][j] === grid[i - 1][j] && grid[i][j] !== 0) {
                count++;
            } else {
                if (count >= min) matches.push(Array.from({ length: count }, (_, k) => [i - count + k, j]));
                count = 1;
            }
        }
        if (count >= min) matches.push(Array.from({ length: count }, (_, k) => [size - count + k, j]));
    }
    return matches;
}

function clearMatches(grid, matches) {
    const newGrid = grid.map(row => [...row]);
    for (const match of matches) {
        for (const [r, c] of match) newGrid[r][c] = 0;
    }
    return newGrid;
}

function dropTiles(grid) {
    const size = grid.length;
    const newGrid = Array(size).fill().map(() => Array(size).fill(0));
    for (let j = 0; j < size; j++) {
        let writePos = size - 1;
        for (let i = size - 1; i >= 0; i--) {
            if (grid[i][j] !== 0) newGrid[writePos--][j] = grid[i][j];
        }
    }
    return newGrid;
}

function hasValidMoves(grid) {
    const size = grid.length;
    for (let i = 0; i < size; i++) {
        for (let j = 0; j < size; j++) {
            if (j < size - 1) {
                const tempGrid = grid.map(row => [...row]);
                [tempGrid[i][j], tempGrid[i][j + 1]] = [tempGrid[i][j + 1], tempGrid[i][j]];
                if (findMatches(tempGrid).length > 0) return true;
            }
            if (i < size - 1) {
                const tempGrid = grid.map(row => [...row]);
                [tempGrid[i][j], tempGrid[i + 1][j]] = [tempGrid[i + 1][j], tempGrid[i][j]];
                if (findMatches(tempGrid).length > 0) return true;
            }
        }
    }
    return false;
}

function getValidMove(grid) {
    const size = grid.length;
    for (let i = 0; i < size; i++) {
        for (let j = 0; j < size; j++) {
            if (j < size - 1) {
                const tempGrid = grid.map(row => [...row]);
                [tempGrid[i][j], tempGrid[i][j + 1]] = [tempGrid[i][j + 1], tempGrid[i][j]];
                if (findMatches(tempGrid).length > 0) return { r1: i, c1: j, r2: i, c2: j + 1 };
            }
            if (i < size - 1) {
                const tempGrid = grid.map(row => [...row]);
                [tempGrid[i][j], tempGrid[i + 1][j]] = [tempGrid[i + 1][j], tempGrid[i][j]];
                if (findMatches(tempGrid).length > 0) return { r1: i, c1: j, r2: i + 1, c2: j };
            }
        }
    }
    return null;
}

function shuffleGrid(grid, colors) {
    return generateGrid(grid.length, colors);
}

async function updatePlayerStats(playerID, gameData, score, timeSpent, globalData) {
    const rankings = await globalData.get("colorClashRankings", "data", []);
    let player = rankings.find(p => p.id == playerID);
    if (!player) {
        player = { id: playerID, totalScore: 0, games: 0, bestScore: 0, totalTime: 0, difficultyStats: {}, difficultyScores: {} };
        rankings.push(player);
    }

    player.games++;
    player.totalScore += score;
    player.totalTime += timeSpent;
    player.bestScore = Math.max(player.bestScore, score);
    player.difficultyStats[gameData.difficulty] = (player.difficultyStats[gameData.difficulty] || 0) + 1;
    player.difficultyScores[gameData.difficulty] = (player.difficultyScores[gameData.difficulty] || 0) + score;

    rankings.sort((a, b) => b.totalScore - a.totalScore);
    await globalData.set("colorClashRankings", rankings, "data");
}

function createGameImage(gameData) {
    const cellSize = 50;
    const gridSize = cellSize * difficulties[gameData.difficulty].gridSize;
    const padding = 20;
    const headerHeight = 80;
    const canvas = createCanvas(gridSize + 2 * padding, gridSize + headerHeight + 2 * padding);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#ff9f43';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('COLOR CLASH', canvas.width / 2, padding + 30);

    ctx.font = '16px Arial';
    const timeElapsed = getTime("x") - gameData.timeStart;
    ctx.fillText(`${gameData.difficulty.toUpperCase()} | Score: ${gameData.score} | Time: ${convertTime(timeElapsed)}`, canvas.width / 2, padding + 50);

    const startX = padding;
    const startY = headerHeight + padding;
    for (let i = 0; i < gameData.grid.length; i++) {
        for (let j = 0; j < gameData.grid[i].length; j++) {
            const x = startX + j * cellSize;
            const y = startY + i * cellSize;
            const colorId = gameData.grid[i][j];
            if (colorId > 0) {
                ctx.fillStyle = colorPalette[colorId].hex;
                ctx.fillRect(x, y, cellSize - 2, cellSize - 2);
            }
        }
    }

    const stream = canvas.createPNGStream();
    stream.path = `colorclash_${randomString(5)}.png`;
    return stream;
}
