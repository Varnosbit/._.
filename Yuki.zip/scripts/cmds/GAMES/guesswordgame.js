const { createCanvas } = require('canvas');
const modes = {
  "2": [
    "an",
    "at",
    "be",
    "by",
    "do",
    "go",
    "he",
    "if",
    "in",
    "is",
    "it",
    "me",
    "my",
    "no",
    "on",
    "or",
    "so",
    "to",
    "up",
    "us",
    "we",
    "am",
    "as",
    "of",
    "oh",
    "ok",
    "hi",
    "ye",
    "yo",
    "ox"
  ],
  "3": [
    "cat",
    "dog",
    "bat",
    "hat",
    "sun",
    "run",
    "man",
    "pan",
    "tan",
    "fan",
    "box",
    "fox",
    "mix",
    "fix",
    "zip",
    "hip",
    "lip",
    "sip",
    "tip",
    "pit",
    "bit",
    "sit",
    "fit",
    "kit",
    "net",
    "bet",
    "get",
    "pet",
    "set",
    "jet"
  ],
  "4": [
    "blue",
    "tree",
    "free",
    "wolf",
    "bear",
    "lion",
    "fish",
    "frog",
    "duck",
    "seal",
    "goat",
    "hawk",
    "dove",
    "crow",
    "kiwi",
    "swan",
    "bull",
    "lamb",
    "clam",
    "deer",
    "puma",
    "mole",
    "crab",
    "toad",
    "lynx",
    "wolf",
    "swim",
    "cave",
    "beet",
    "boar"
  ],
  "5": [
    "apple",
    "grape",
    "zebra",
    "sheep",
    "snake",
    "tiger",
    "eagle",
    "whale",
    "horse",
    "robin",
    "flock",
    "pride",
    "viper",
    "koala",
    "moose",
    "skunk",
    "spine",
    "crows",
    "shark",
    "sting",
    "panda",
    "gecko",
    "bison",
    "coral",
    "bunny",
    "worms",
    "camel",
    "rhino",
    "midge",
    "quail"
  ],
  "6": [
    "rabbit",
    "donkey",
    "cougar",
    "falcon",
    "iguana",
    "beetle",
    "monkey",
    "weasel",
    "baboon",
    "coyote",
    "shrimp",
    "parrot",
    "beaver",
    "ferret",
    "gopher",
    "hermit",
    "otters",
    "pigeon",
    "spider",
    "turtle",
    "gerbil",
    "lemurs",
    "dragon",
    "mantis",
    "quagga",
    "badger",
    "darter",
    "pellet",
    "cranes",
    "logger"
  ],
  "7": [
    "jackals",
    "buffalo",
    "dolphin",
    "leopard",
    "cougars",
    "pelican",
    "frigate",
    "antlion",
    "catfish",
    "termite",
    "parrots",
    "anemone",
    "warbler",
    "armored",
    "peacock",
    "skylark",
    "gazelle",
    "caribou",
    "wildcat",
    "giraffe",
    "herring",
    "puffins",
    "cheetah",
    "turtles",
    "wombats",
    "kingdom",
    "bullfin",
    "flytrap",
    "cockles",
    "snapper"
  ],
  "8": [
    "kangaroo",
    "elephant",
    "dinosaur",
    "aardvark",
    "bluebird",
    "chipmunk",
    "anteater",
    "platypus",
    "penguins",
    "buffalos",
    "armadill",
    "starfish",
    "porcupin",
    "albatros",
    "caterpil",
    "tarantul",
    "mosquito",
    "cockatoo",
    "ladybugs",
    "parakeet",
    "sandpipi",
    "raccoons",
    "waterbug",
    "woodpeck",
    "roadrunn",
    "stingray"
  ]
};

function drawRoundedSquare(ctx, x, y, width, height, radius, fillStyle, strokeStyle, lineWidth = 2) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fillStyle = fillStyle;
    ctx.fill();
    ctx.strokeStyle = strokeStyle;
    ctx.lineWidth = lineWidth;
    ctx.stroke();
}

function drawWrappedText(ctx, text, x, y, maxWidth, lineHeight, font, color = '#000', align = 'left') {
    ctx.fillStyle = color;
    ctx.font = font;
    const words = text.split(' ');
    let line = '';
    let lines = [];
    words.forEach((word) => {
        const testLine = line + word + ' ';
        if (ctx.measureText(testLine).width > maxWidth && line.length > 0) {
            lines.push(line.trim());
            line = word + ' ';
        } else {
            line = testLine;
        }
    });
    lines.push(line.trim());
    lines.forEach((line, index) => {
        const textWidth = ctx.measureText(line).width;
        const drawX = align === 'center' ? x - textWidth / 2 : x;
        ctx.fillText(line, drawX, y + index * lineHeight);
    });
    return y + lines.length * lineHeight;
}
function drawLegend(ctx, canvasWidth, canvasHeight) {
    const legendY = canvasHeight - 80;
    const boxSize = 20;
    const spacing = 10;
    const lineHeight = 24;
    const labels = [
        { color: '#4CAF50', text: 'Correct', strokeStyle: '#388E3C' },
        { color: '#FFC107', text: 'Wrong Position', strokeStyle: '#FFA000' },
        { color: '#E0E0E0', text: 'Incorrect', strokeStyle: '#BDBDBD' }
    ];

    const totalLegendWidth = labels.reduce((acc, item) => {
        const textWidth = ctx.measureText(item.text).width;
        return acc + boxSize + spacing + textWidth + spacing;
    }, -spacing);

    let startX = (canvasWidth - (totalLegendWidth/1.8)) / 2;

    labels.forEach((item) => {
        drawRoundedSquare(ctx, startX, legendY, boxSize, boxSize, 5, item.color, item.strokeStyle);
        drawWrappedText(
            ctx,
            item.text,
            startX + boxSize + spacing,
            legendY + boxSize / 2 + 5,
            canvasWidth,
            lineHeight,
            '16px Arial',
            '#000',
            'left'
        );
        startX += boxSize + spacing + ctx.measureText(item.text).width + spacing;
    });
}
/*
function drawGuessTheWordGame(wordMode, guesses, correctWord) {
    const canvasWidth = wordMode * 100 + 100;
    let canvasHeight = guesses.length === 1 ? 150 + guesses.length * 110 + 100 : guesses.length == 0 ? 150 + 1.2 * 110 + 100 : 150 + guesses.length * 110 + 100;
    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#f7f7f7';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    const titleSize = Math.max(30, 50 - wordMode * 5);
    const wrappedTitleY = drawWrappedText(
        ctx,
        'GUESS THE WORD GAME',
        canvasWidth / 2,
        60,
        canvasWidth - 40,
        titleSize + 10,
        `bold ${titleSize}px Arial`,
        '#333',
        'center'
    );

    const correctLetterCountsMap = new Map();
    if (guesses.length === 0) {
        const startY = wrappedTitleY + 20;
        for (let i = 0; i < wordMode; i++) {
            const startX = 50 + i * 100;
            drawRoundedSquare(ctx, startX, startY, 90, 90, 10, '#E0E0E0', '#BDBDBD');
        }
    } else {
    guesses.forEach((guess, rowIndex) => {
        const correctLetterCounts = {}; 
        correctWord.toUpperCase().split('').forEach(letter => {
            correctLetterCounts[letter] = (correctLetterCounts[letter] || 0) + 1;
        });

        const startY = wrappedTitleY + 20 + rowIndex * 110;
        guess.toUpperCase().split('').forEach((letter, letterIndex) => {
            const startX = 50 + letterIndex * 100;
            let fillStyle, strokeStyle;

            if (correctWord[letterIndex].toUpperCase() === letter) {
                fillStyle = '#4CAF50';
                strokeStyle = '#388E3C';
                correctLetterCounts[letter]--;
            } else if (correctWord.toUpperCase().includes(letter) && correctLetterCounts[letter] > 0) {
                fillStyle = '#FFC107';
                strokeStyle = '#FFA000';
                correctLetterCounts[letter]--;
            } else {
                fillStyle = '#E0E0E0';
                strokeStyle = '#BDBDBD';
            }

            drawRoundedSquare(ctx, startX, startY, 90, 90, 10, fillStyle, strokeStyle);
            ctx.fillStyle = '#FFF';
            ctx.font = 'bold 34px Arial';
            const textWidth = ctx.measureText(letter).width;
            ctx.fillText(letter, startX + 45 - textWidth / 2, startY + 55);
        });

        correctLetterCountsMap.set(rowIndex, correctLetterCounts);
     });
    }
    if (guesses.length > 0) {
        drawLegend(ctx, canvasWidth, canvasHeight);
    } else {
        drawWrappedText(
        ctx,
        'REPLY BY FIRST GUESS',
        canvasWidth / 2,
        canvasHeight - 30,
        canvasWidth - 40,
        35,
        `bold 20px Arial`,
        '#333',
        'center'
    );
    }

    const stream = canvas.createPNGStream();
    stream["path"] = "guess_word_game_" + Date.now() + ".png";
    return {
        attachment: stream
    };
}*/
function drawGuessTheWordGame(wordMode, guesses, correctWord) {
    const canvasWidth = wordMode * 100 + 100;
    let canvasHeight = guesses.length === 1 ? 150 + guesses.length * 110 + 100 : guesses.length == 0 ? 150 + 1.2 * 110 + 100 : 150 + guesses.length * 110 + 100;
    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#f7f7f7';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    const titleSize = Math.max(30, 50 - wordMode * 5);
    const wrappedTitleY = drawWrappedText(
        ctx,
        'GUESS THE WORD GAME',
        canvasWidth / 2,
        60,
        canvasWidth - 40,
        titleSize + 10,
        `bold ${titleSize}px Arial`,
        '#333',
        'center'
    );

    if (guesses.length === 0) {
        const startY = wrappedTitleY + 20;
        for (let i = 0; i < wordMode; i++) {
            const startX = 50 + i * 100;
            drawRoundedSquare(ctx, startX, startY, 90, 90, 10, '#E0E0E0', '#BDBDBD');
        }
    } else {
        guesses.forEach((guess, rowIndex) => {
            const correctLetterCounts = {}; 
            correctWord.toUpperCase().split('').forEach(letter => {
                correctLetterCounts[letter] = (correctLetterCounts[letter] || 0) + 1;
            });

            const usedLetters = {};

            const startY = wrappedTitleY + 20 + rowIndex * 110;
            const guessArray = guess.toUpperCase().split('');

            guessArray.forEach((letter, letterIndex) => {
                if (correctWord[letterIndex].toUpperCase() === letter) {
                    correctLetterCounts[letter]--;
                }
            });

            guessArray.forEach((letter, letterIndex) => {
                const startX = 50 + letterIndex * 100;
                let fillStyle, strokeStyle;

                if (correctWord[letterIndex].toUpperCase() === letter) {
                    fillStyle = '#4CAF50';
                    strokeStyle = '#388E3C';
                } else if (correctWord.toUpperCase().includes(letter) && correctLetterCounts[letter] > 0) {
                    usedLetters[letter] = (usedLetters[letter] || 0) + 1;
                    if (usedLetters[letter] <= correctLetterCounts[letter]) {
                        fillStyle = '#FFC107';
                        strokeStyle = '#FFA000';
                        correctLetterCounts[letter]--;
                    } else {
                        fillStyle = '#E0E0E0';
                        strokeStyle = '#BDBDBD';
                    }
                } else {
                    fillStyle = '#E0E0E0';
                    strokeStyle = '#BDBDBD';
                }

                drawRoundedSquare(ctx, startX, startY, 90, 90, 10, fillStyle, strokeStyle);
                ctx.fillStyle = '#FFF';
                ctx.font = 'bold 34px Arial';
                const textWidth = ctx.measureText(letter).width;
                ctx.fillText(letter, startX + 45 - textWidth / 2, startY + 55);
            });
        });
    }

    if (guesses.length > 0) {
        drawLegend(ctx, canvasWidth, canvasHeight);
    } else {
        drawWrappedText(
            ctx,
            'REPLY BY FIRST GUESS',
            canvasWidth / 2,
            canvasHeight - 30,
            canvasWidth - 40,
            35,
            `bold 20px Arial`,
            '#333',
            'center'
        );
    }

    const stream = canvas.createPNGStream();
    stream["path"] = "guess_word_game_" + Date.now() + ".png";
    return {
        attachment: stream
    };
}
const gs = new Map();
module.exports = {
    config: {
        name: "guesswordgame",
        aliases: ["guessword", "gw"],
        description: "A game to guess the word based on mode with limited chances.",
        role: 0,
        author: "allou mohamed",
        countDown: 40,
        version: "beta-0-1",
        guide: "{pn} mode | end | blank | input"
    },
    onStart(run) {
        this.wordGame(run);
    },
    onReply(run) {
        this.wordGame(run);
    },
    wordGame(run) {
        const { message, args, event, commandName, Reply } = run;
        const userID = event.senderID;

        if (Reply && Reply.userID != userID) return;

        const input = args.join(' ');

        if (input.toLowerCase() === "end") {
            if (gs.has(userID)) {
                gs.delete(userID);
                return message.reply("Game has been ended.");
            }
            return message.reply("No active game to end.");
        }

        if (Reply) {
            const gameData = gs.get(userID);
            if (!gameData) return message.reply("No active game found!");

            const { mode, guesses, answer, chances } = gameData;

            if (Number(mode) !== input.length) {
                return message.reply(`Please use a word with exactly ${mode} letters.`);
            }

            if (guesses.includes(input)) {
                return message.reply("You already guessed this word! Try a different one.");
            }

            const messageID = Reply && Reply.messageID ? Reply.messageID : null;
            if (messageID) message.unsend(messageID);
            guesses.push(input);
            gameData.chances -= 1;

            const form = drawGuessTheWordGame(Number(mode), guesses, answer);

            if (input.toLowerCase() === answer.toLowerCase()) {
                form["body"] = "🎉 Congratulations! You've guessed the correct word.";
                message.send(form, () => {
                    gs.delete(userID);
                });
            } else if (gameData.chances <= 0) {
                form["body"] = `😢 You've run out of chances! The correct word was: **${answer}**.`;
                message.send(form, () => {
                    gs.delete(userID);
                });
            } else {
                form["body"] = `Wrong guess! You have ${gameData.chances} chances left.`;
                message.send(form, (err, info) => {
                    global.GoatBot.onReply.set(info.messageID, {
                        commandName,
                        userID,
                        messageID: info.messageID,
                    });
                });
            }
        } else {
            if (gs.has(userID)) return message.reply("You already have an active game. Please finish it first!");

            let defaultMode = 4;
            if (args.length !== 0 && Number(input) >= 2 && Number(input) <= 8) {
                defaultMode = Number(input);
            }

            const availableWords = modes[defaultMode.toString()];
            if (!availableWords || availableWords.length === 0) {
                return message.reply("No words available for the selected mode.");
            }

            const randomIndex = Math.floor(Math.random() * availableWords.length);
            const answer = availableWords[randomIndex];

            const chances =
                defaultMode <= 4 ? 8 :
                defaultMode <= 6 ? 10 : 
                12;

            gs.set(userID, { mode: defaultMode, guesses: [], answer, chances });

            const form = drawGuessTheWordGame(defaultMode, [], answer);
            form["body"] = `Game started! Guess a ${defaultMode}-letter word. You have ${chances} chances.`;
            message.send(form, (err, info) => {
                global.GoatBot.onReply.set(info.messageID, {
                    commandName,
                    userID,
                    messageID: info.messageID,
                });
            });
        }
    },
};
