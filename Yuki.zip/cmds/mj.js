const axios = require("axios");
const fs_ = require("fs").promises;
const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "tokens.json");

async function addTokenToDB(type, token) {
    try {
        let db = {};
        try {
            const data = await fs_.readFile(DB_PATH, "utf8");
            db = JSON.parse(data);
        } catch (e) {
            db = {};
        }
        if (!Array.isArray(db[type])) {
            db[type] = [];
        }
        if (!db[type].includes(token)) {
            db[type].push(token);
        }
        await fs_.writeFile(DB_PATH, JSON.stringify(db, null, 4), "utf8");

        return true;
    } catch (err) {
        console.error("Error adding token:", err);
        return false;
    }
}

async function GenAccToken() {
async function MakeMail() {
const options = {
  method: 'POST',
  url: 'https://api.internal.temp-mail.io/api/v3/email/new',
  headers: {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9',
    'application-name': 'web',
    'application-version': '2.4.2',
    'content-type': 'application/json;charset=UTF-8',
    'priority': 'u=1, i',
    'sec-ch-ua': '"Brave";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'sec-gpc': '1',
    'Referer': 'https://temp-mail.io/',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
  },
  data: {
    min_name_length: 10,
    max_name_length: 10
  }
};

try {
  const response = await axios.request(options);
  return response.data;
} catch (error) {
  console.error(error);
}
}
async function mekereq(em) {
let st;
try {
const response = await axios.post(
    'https://auth.zhishuyun.com/api/v1/email-code',
    {
      'template': '115309',
      'receiver': em
    },
    {
      headers: {
        'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
        'Connection': 'keep-alive',
        'Cookie': 'INVITER_ID=undefined',
        'Origin': 'https://auth.zhishuyun.com',
        'Referer': 'https://auth.zhishuyun.com/auth/register?inviter_id=undefined',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"'
      }
    }
  );
st = "s";
} catch (error ) {
st = "n"
console.log(error)
}
return st;
}
  async function GetMails(Mail) {
const options = {
  method: 'GET',
  url: `https://api.internal.temp-mail.io/api/v3/email/${Mail}/messages`,
  headers: {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9',
    'application-name': 'web',
    'application-version': '2.4.2',
    'priority': 'u=1, i',
    'sec-ch-ua': '"Brave";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'sec-gpc': '1',
    'Referer': 'https://temp-mail.io/',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
  },
  data: null
};

try {
  const response = await axios.request(options);
  return response.data;
} catch (error) {
  console.error(error);
}
  }
  function GenPas() {
  const uc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lc = 'abcdefghijklmnopqrstuvwxyz';
  const nm = '0123456789';
  const sp = '@';
  let pw = '';
  pw += uc[Math.floor(Math.random() * uc.length)];
  const ac = lc + nm + sp;
  for (let i = 0; i < 9; i++) {
    pw += ac[Math.floor(Math.random() * ac.length)];
  }
  pw += sp;
  return pw;
  }
async function mekeac(verf, em, pas) {
try {
  const response = await axios.post(
    'https://auth.zhishuyun.com/api/v1/users',
    {
      'email': em,
      'email_code': verf,
      'password': pas,
      'inviter_id': 'undefined'
    },
    {
      headers: {
        'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
        'Connection': 'keep-alive',
        'Cookie': 'INVITER_ID=undefined',
        'Origin': 'https://auth.zhishuyun.com',
        'Referer': 'https://auth.zhishuyun.com/auth/register?inviter_id=undefined',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"'
      }
    }
  );
  return response.data;
} catch (error ) {
console.log(error)
  return "err"
}

}
        async function mekeacc(em, pas) {
        try {
          const response = await axios.post(
  'https://auth.zhishuyun.com/api/v1/login/',
  {
    'email': em,
    'password': pas
  },
  {
    headers: {
      'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
      'Connection': 'keep-alive',
      'Cookie': 'INVITER_ID=undefined',
      'Origin': 'https://auth.zhishuyun.com',
      'Referer': 'https://auth.zhishuyun.com/auth/login?inviter_id=undefined',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
      'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-platform': '"Android"'
    }
  }
);
          return response.data;
        } catch (error ) {
        console.log(error)
          return "err"
        }

        }
      
        
let verf;
    let M = {};
try {
  
  M = await MakeMail();
  let ss = await mekereq(M.email);
  if(ss == "n") return "err";
  let Y = await GetMails(M.email);
  while(!Y[0]) {
  Y = await GetMails(M.email)
  }
  let text = Y[0].body_text;
   const match = text.match(/\b\d{6}\b/);
   verf = match ? match[0] : null;
} catch (e) {
  return "err";
}
  let passo = GenPas();
 await mekeac(verf,M.email, passo);
  let knokitout = await mekeacc(M.email, passo);
  let realtoken = knokitout.access_token;
  return realtoken;
};

  async function GEN(p, tok) { 
  let ni,st,id,task; 
  try { 
  const f = await axios( {
    method: 'POST',
    url: 'https://api.zhishuyun.com/midjourney/imagine/turbo?token='+tok,
    headers: {
      'accept': 'application/json',
      'content-type': 'application/json',
    },
    data: {
      action: 'generate',
      prompt: p,
    },
  });
    
    task = null; 
    ni = f.data.raw_image_url; 
    id = f.data.image_id 
    st = "s" 
  } catch (err) { 
    ni = null 
    st = "e" 
    task = err?.response?.data; 
  } 
  return { 
    id, 
    ni: ni, 
    task: task, 
    st: st 
  }; 
  } 
  async function getIMG(NUM , ID, tok) { 
  let ni,st, id; 
  try { 
  const f = await axios( {
    method: 'POST',
    url: 'https://api.zhishuyun.com/midjourney/imagine/turbo?token='+tok,
    headers: {
      'accept': 'application/json',
      'content-type': 'application/json',
    },
    data: {
      action: NUM,
      image_id: ID
    },
  });
  console.log(f.data);
    ni = f.data?.raw_image_url; 
      id = f.data?.image_id 
    st = "s" 
  } catch (err) { 
    ni = null 
    st = "e" 
  } 
  return { 
    ni: ni, 
    st: st, 
      id: id 
  }; 
  }
async function GetTokenMj() {
  async function Twogift(auth) {
  try {
  const response = await axios.post(
    'https://data.zhishuyun.com/api/v1/applications/',
    {
      'type': 'Api',
      'api_id': '62ec82bd-7de3-427f-b71a-ab3551ac7677'
    },
    {
      headers: {
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
        'Authorization': 'Bearer ' + auth,
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
        'Cookie': 'INVITER_ID=undefined',
        'Origin': 'https://data.zhishuyun.com',
        'Referer': 'https://data.zhishuyun.com/services/d87e5e99-b797-4ade-9e73-b896896b0461',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"'
      }
    }
  );


  const response1 = await axios.get('https://data.zhishuyun.com/api/v1/applications/', {
    params: {
      'limit': '10',
      'offset': '0',
      'user_id': response.data.user_id,
      'type': 'Api',
      'ordering': '-created_at'
    },
    headers: {
      'Accept': 'application/json',
      'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
      'Authorization': 'Bearer ' + auth,
      'Connection': 'keep-alive',
      'Cookie': 'INVITER_ID=undefined',
      'Referer': 'https://data.zhishuyun.com/console/applications',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
      'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Linux"'
    }
  });
  
  return response1.data.items[0].credential.token;
  } catch (e) {
  console.log(e)
  return "err";
  }
  };
  async function Threegift(auth) {
  try {
  const response = await axios.post(
    'https://data.zhishuyun.com/api/v1/applications/',
    {
      'type': 'Api',
      'api_id': '9a628863-8879-462b-bbee-5dc46505b733'
    },
    {
      headers: {
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
        'Authorization': 'Bearer ' + auth,
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
        'Cookie': 'INVITER_ID=undefined',
        'Origin': 'https://data.zhishuyun.com',
        'Referer': 'https://data.zhishuyun.com/services/d87e5e99-b797-4ade-9e73-b896896b0461',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"'
      }
    }
  );


  const response1 = await axios.get('https://data.zhishuyun.com/api/v1/applications/', {
    params: {
      'limit': '10',
      'offset': '0',
      'user_id': response.data.user_id,
      'type': 'Api',
      'ordering': '-created_at'
    },
    headers: {
      'Accept': 'application/json',
      'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
      'Authorization': 'Bearer ' + auth,
      'Connection': 'keep-alive',
      'Cookie': 'INVITER_ID=undefined',
      'Referer': 'https://data.zhishuyun.com/console/applications',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
      'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Linux"'
    }
  });
  
  return response1.data.items[0].credential.token;
  } catch (e) {
  console.log(e)
  return "err";
  }
  };
  async function Fivegift(auth) {
  try {
  const response = await axios.post(
    'https://data.zhishuyun.com/api/v1/applications/',
    {
      'type': 'Api',
      'api_id': 'c58713f3-fef7-4c18-824c-9f76b5a07a7f'
    },
    {
      headers: {
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
        'Authorization': 'Bearer ' + auth,
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
        'Cookie': 'INVITER_ID=undefined',
        'Origin': 'https://data.zhishuyun.com',
        'Referer': 'https://data.zhishuyun.com/services/d87e5e99-b797-4ade-9e73-b896896b0461',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"'
      }
    }
  );


  const response1 = await axios.get('https://data.zhishuyun.com/api/v1/applications/', {
    params: {
      'limit': '10',
      'offset': '0',
      'user_id': response.data.user_id,
      'type': 'Api',
      'ordering': '-created_at'
    },
    headers: {
      'Accept': 'application/json',
      'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
      'Authorization': 'Bearer ' + auth,
      'Connection': 'keep-alive',
      'Cookie': 'INVITER_ID=undefined',
      'Referer': 'https://data.zhishuyun.com/console/applications',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
      'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Linux"'
    }
  });
  
  return response1.data.items[0].credential.token;
  } catch (e) {
  console.log(e)
  return "err";
  }
  }
let acc = await GenAccToken();
  let twogif = await Twogift(acc);
  let threeg = await Threegift(acc);
  let fivegif = await Fivegift(acc);
  await addTokenToDB("FiveT", fivegif);
  await addTokenToDB("ThreeT", threeg);
  
  return twogif;
};



const sharp = require("sharp");
const FormData = require("form-data");

const { getStreamFromURL } = global.utils;

module.exports = {
    config: {
        name: "midjourney",
        aliases: ["dj", "mj"],
        version: "1.0",
        author: "Takt Toast 🍞",
        shortDescription: "Initiates a Midjourney process based on the provided prompt.",
        longDescription: "Midjourney.",
        role: 2,
        countDown: 90,
        category: "Image",
        guide: {
            en: "{pn} marin Kitagawa --niji 6\n\nto upscale a single image from 4 images reply with [ U1, U2, U3, U4 ]"
        }
    },

    onStart: async function ({ api, args, message, event }) {
    let prompt = args.join(" ");

    // ----- Handle reply with image -----
    if (
        event.type === "message_reply" &&
        event.messageReply.attachments &&
        event.messageReply.attachments.length > 0 &&
        ["photo", "sticker"].includes(event.messageReply.attachments[0].type)
    ) {
        const imageUrl = event.messageReply.attachments[0].url;
        const imgbbUrl = await uploadToImgbb(imageUrl);
        prompt = `${imgbbUrl.url} ${prompt}`;
    }

    if (!prompt) {
        return message.reply("Please provide a prompt.");
    }

    const processingMessage = await message.reply(
        "Initiating Midjourney process...⏳\nMight take some time.."
    );
    message.reaction("⏰", event.messageID);

    let retries = 3;
    let ge;

    try {
        const tok = await GetTokenMj();

        // ------- Retry GEN up to 3 times -------
        while (retries > 0) {
            try {
                ge = await GEN(prompt, tok);

                if (ge && ge.ni) break; // ✅ success → break
            } catch (innerErr) {
                console.log("GEN error, retrying…", innerErr);
            }

            retries--;
            console.log(`Retrying GEN… attempts left: ${retries}`);

            if (retries > 0) {
                await new Promise(res => setTimeout(res, 3000)); // small delay
            }
        }

        // ------- After retries -------
        if (!ge || !ge.ni) {
            await message.reaction("❌", event.messageID);
            message.reply("Midjourney generation failed after 3 attempts.");
            message.unsend((await processingMessage).messageID);
            return;
        }

        // ------- Successfully got image URL -------
        const imageUrl = ge.ni;
        const imageStream = await getStreamFromURL(imageUrl);

        message.reply(
            {
                body: `Midjourney process completed ✨\n\n❏ Action: U1, U2, U3, U4 or AL to send all.`,
                attachment: imageStream
            },
            (err, info) => {
                global.GoatBot.onReply.set(info.messageID, {
                    commandName: "midjourney",
                    messageID: info.messageID,
                    author: event.senderID,
                    imageUrl: imageUrl
                });
            }
        );

        message.unsend((await processingMessage).messageID);
        await message.reaction("✅", event.messageID);

    } catch (error) {
        console.error(error);
        message.reply("Error occurred during Midjourney processing.");
        await message.reaction("❌", event.messageID);
    }
},

   
onReply: async function ({ message, event, Reply, args }) {
        let { author, commandName, imageUrl } = Reply;
        if (event.senderID !== author) return;

        const options = ["U1", "U2", "U3", "U4", "AL"];

        const userSelection = args[0];
        if (!options.includes(userSelection)) {
            message.reply("Invalid option. Please select a valid action.");
            return;
        }

        try {
            const upscaleMessage = await message.reply("Upscale request added, please wait...");
            
            const imageBuffer = await axios.get(imageUrl, { responseType: 'arraybuffer' }).then(res => Buffer.from(res.data));

            
            const metadata = await sharp(imageBuffer).metadata();
            const width = metadata.width;
            const height = metadata.height;

            const halfWidth = Math.floor(width / 2);
            const halfHeight = Math.floor(height / 2);
            if (userSelection == "AL") {
            const cropRegions = [
                        { left: 0, top: 0, width: halfWidth, height: halfHeight },          // U1
                        { left: halfWidth, top: 0, width: halfWidth, height: halfHeight },  // U2
                        { left: 0, top: halfHeight, width: halfWidth, height: halfHeight }, // U3
                        { left: halfWidth, top: halfHeight, width: halfWidth, height: halfHeight } // U4
                    ];

                    const attachments = await Promise.all(cropRegions.map(async (region, index) => {
                    const croppedBuffer = await sharp(imageBuffer).extract(region).toBuffer();
                    const upscaledBuffer = await upscaleImage(croppedBuffer);
                    const tempPath = `upscaled_U${index + 1}.png`;
                    fs.writeFileSync(tempPath, upscaledBuffer);
                    return fs.createReadStream(tempPath);
                    }));

                    await message.reply({ body: "Upscaled images for all regions", attachment: attachments }, () => {
                        attachments.forEach(stream => fs.unlinkSync(stream.path));
                    });
            return;
            }
            let cropRegion;
            switch (userSelection) {
                case "U1":
                    cropRegion = { left: 0, top: 0, width: halfWidth, height: halfHeight };
                    break;
                case "U2":
                    cropRegion = { left: halfWidth, top: 0, width: halfWidth, height: halfHeight };
                    break;
                case "U3":
                    cropRegion = { left: 0, top: halfHeight, width: halfWidth, height: halfHeight };
                    break;
                case "U4":
                    cropRegion = { left: halfWidth, top: halfHeight, width: halfWidth, height: halfHeight };
                    break;
                /*case "AL":
                    if return >>>>>
                    break;*/
                default:
                    break;
            }

            
            const croppedImageBuffer = await sharp(imageBuffer).extract(cropRegion).toBuffer();

            
         
            const upscaledImageBuffer = await upscaleImage(croppedImageBuffer);

            
            const savedImagePath = `upscaled_${userSelection}.png`;
            fs.writeFileSync(savedImagePath, upscaledImageBuffer);

            message.reply({
                body: `Upscaled image for ${userSelection}`,
                attachment: fs.createReadStream(savedImagePath)
            }, () => {
                fs.unlinkSync(savedImagePath);
                message.unsend(upscaleMessage.messageID);
            });
        } catch (error) {
            console.error(error);
            message.reply("Error occurred while processing the image.");
        }
    }
};
      

async function uploadToImgbb(url) {
    try {
        const res_ = await axios({
            method: 'GET',
            url: 'https://imgbb.com',
        });

        const auth_token = res_.data.match(/auth_token="([^"]+)"/)[1];
        const timestamp = Date.now();

        const res = await axios({
            method: 'POST',
            url: 'https://imgbb.com/json',
            headers: {
                'Content-Type': 'multipart/form-data',
            },
            data: {
                source: url,
                type: 'url',
                filename:'image.png',
                action: 'upload',
                timestamp: timestamp,
                auth_token: auth_token,
            },
        });

        return {
            url: res.data.image.url,
            url_viewer: res.data.image.url_viewer,
        };
    } catch (error) {
        console.error(error);
        throw new Error('Error uploading to ImgBB');
    }
}

async function upscaleImage(imageData, scale = 4) {
  const tempPath = `./temp_${Date.now()}.jpg`;
  
  try {
    if (Buffer.isBuffer(imageData)) {
      fs.writeFileSync(tempPath, imageData);
    } else if (typeof imageData === 'string' && imageData.startsWith('data:')) {
      const base64Data = imageData.split(',')[1];
      fs.writeFileSync(tempPath, Buffer.from(base64Data, 'base64'));
    } else if (typeof imageData === 'string') {
      fs.writeFileSync(tempPath, Buffer.from(imageData, 'base64'));
    } else {
      throw new Error('Invalid image data format');
    }

    const taskId = '35mgpvmkm2r8ytqchyj0y1rxgpp74f78hAccdrc2019n4rc8d2zxs7nbh69z3pb6g97bc0007rwlbcj3hfn11gzmf83h1gjnfdj0cd738ykfAgr6r479pz09n30fzpg0tc33vkvq6zhj11fbk5mjsrqAq90kn0hxmyAmys3yf0dcz5flrqxq';
    const authorization = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE1MjMzNjQ4MjQsIm5iZiI6MTUyMzM2NDgyNCwianRpIjoicHJvamVjdF9wdWJsaWNfYzkwNWRkMWMwMWU5ZmQ3NzY5ODNjYTQwZDBhOWQyZjNfT1Vzd2EwODA0MGI4ZDJjN2NhM2NjZGE2MGQ2MTBhMmRkY2U3NyJ9.qvHSXgCJgqpC4gd6-paUlDLFmg0o2DsOvb1EUYPYx_E';
    
    const uploadData = new FormData();
    const fileName = `image_${Date.now()}.jpg`;
    
    uploadData.append('name', fileName);
    uploadData.append('chunk', '0');
    uploadData.append('chunks', '1');
    uploadData.append('task', taskId);
    uploadData.append('preview', '1');
    uploadData.append('pdfinfo', '0');
    uploadData.append('pdfforms', '0');
    uploadData.append('pdfresetforms', '0');
    uploadData.append('v', 'web.0');
    uploadData.append('file', fs.createReadStream(tempPath));

    const uploadConfig = {
      method: 'POST',
      url: 'https://api12g.iloveimg.com/v1/upload',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'sec-ch-ua-platform': '"Android"',
        'authorization': authorization,
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?1',
        'Origin': 'https://www.iloveimg.com',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://www.iloveimg.com/',
        'Accept-Language': 'en,fr;q=0.9,ar;q=0.8',
        ...uploadData.getHeaders()
      },
      data: uploadData
    };

    const uploadResponse = await axios.request(uploadConfig);
    const serverFilename = uploadResponse.data.server_filename;

    const upscaleData = new FormData();
    upscaleData.append('task', taskId);
    upscaleData.append('server_filename', serverFilename);
    upscaleData.append('scale', scale.toString());

    const upscaleConfig = {
      method: 'POST',
      url: 'https://api12g.iloveimg.com/v1/upscale',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'sec-ch-ua-platform': '"Android"',
        'Authorization': authorization,
        'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile': '?1',
        'Origin': 'https://www.iloveimg.com',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://www.iloveimg.com/',
        'Accept-Language': 'en,fr;q=0.9,ar;q=0.8',
        ...upscaleData.getHeaders()
      },
      data: upscaleData,
      responseType: 'arraybuffer'
    };

    const upscaleResponse = await axios.request(upscaleConfig);
    const imageBuffer = Buffer.from(upscaleResponse.data);
    
    fs.unlinkSync(tempPath);
    
    return imageBuffer;

  } catch (error) {
    if (fs.existsSync(tempPath)) {
      fs.unlinkSync(tempPath);
    }
    throw error;
  }
}