//2.0.0
const DIG = require("discord-image-generation");
const fs = require("fs-extra");

module.exports = {
  config: {
    name: "slap",
    aliases: ["صفع"],
    version: "1.2",
    author: "Allou",
    countDown: 5,
    role: 0,
    description: {
         en: "slap the butt of someone.",
         ar: "صفع تيز شخص."
    },
    category: "meme",
    guide: {
      en: "   {pn} @tag"
    }
  },

  langs: {
    ar: {
      noTag: "منشن حد"
    },
    en: {
      noTag: "You must tag the person you want to slap"
    }
  },

  onStart: async function ({ event, message, usersData, args, getLang }) {
    const uid1 = event.senderID;
    const uid2 = Object.keys(event.mentions)[0] || event?.messageReply?.senderID;
    if (!uid2)
      return message.reply(getLang("noTag"));
    const avatarURL1 = await usersData.getAvatarUrl(uid1);
    const avatarURL2 = await usersData.getAvatarUrl(uid2);
    const img = await new DIG.Spank().getImage(avatarURL1, avatarURL2);
    const pathSave = `${__dirname}/cache/${uid1}_${uid2}spank.png`;
    fs.writeFileSync(pathSave, Buffer.from(img));
    const content = args.join(' ').replace(Object.keys(event.mentions)[0], "");
    message.reply({
      body: `${(content || "hehe boii")}`,
      attachment: fs.createReadStream(pathSave)
    }, () => fs.unlinkSync(pathSave));
  },
  onChat: async ({ message, event, usersData }) => {
  const content = event.body?.toLowerCase();
  if (!content?.startsWith("نسبة الشذوذ")) return;

  let text;

  if (event.mentions && Object.keys(event.mentions).length > 0) {
    const uid = Object.keys(event.mentions)[0];
    const name = await usersData.getName(uid);
    text = `نسبة الشذوذ عند ${name}`;
  } else {
    text = `نسبة الشذوذ عندك`;
  }

  const percentage = Math.floor(Math.random() * 101);
  message.reply(`${text}: ${percentage}% 🏳️‍🌈`);
}
};
