const axios = require('axios');
const cheerio = require('cheerio');

async function scrapeData() {
  try {
    const response = await axios.get('https://animecountdown.com/trending', {
      headers: {
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'upgrade-insecure-requests': '1',
      },
      referrerPolicy: 'strict-origin-when-cross-origin',
    });

    const $ = cheerio.load(response.data);
    const list = [];
    $('a.countdown-content-trending-item').each((index, element) => {
      const title = $(element).find('countdown-content-trending-item-title').text();
      const episode = $(element).find('countdown-content-trending-item-desc').text();
      const countSecond = parseInt($(element).find('countdown-content-trending-item-countdown').data('time'));
      if (countSecond >= 0) {
        const days = Math.floor(countSecond / (60 * 60 * 24));
        const hours = Math.floor((countSecond % (60 * 60 * 24)) / (60 * 60));
        const minutes = Math.floor((countSecond % (60 * 60)) / 60);
        const seconds = countSecond % 60;

        const countDown = `${days} days, ${hours} hours, ${minutes} minutes, ${seconds} seconds`;
        const image = $(element).css('--poster').replace(/url\('(.+)'\)/, 'https:$1');
        const dataInfo = {
          title,
          episode,
          countDown,
          image,
        };

        list.push(dataInfo);
      }
    });

    return list;
  } catch (error) {
    throw new Error(error.message);
  }
}

module.exports = {
  config: {
    name: "cd",
    version: "1.0",
    author: "Tanvir 💀🔥",
    shortDescription: "Get a list of anime countdowns",
    category: "anime",
    guide: "{pn} animeCountdown [startIndex]",
  },
  onStart: async function ({ event, message, args, commandName }) {
    try {
      const pageNumber = args[0] ? parseInt(args[0]) : 1;
      const animeList = await scrapeData();
      const itemsPerPage = 10;

      const totalAnimeItems = animeList.length;
      const totalPages = Math.ceil(totalAnimeItems / itemsPerPage);

      const startSliceIndex = (pageNumber - 1) * itemsPerPage;
      const endSliceIndex = startSliceIndex + itemsPerPage;
      const selectedAnimeList = animeList.slice(startSliceIndex, endSliceIndex);

      if (selectedAnimeList.length === 0) {
        message.reply("No more pages available.");
        return;
      }

      const formattedList = selectedAnimeList.map((anime, index) => {
        return `${startSliceIndex + index + 1}. ${anime.title}:\n-${anime.episode}\n-Countdown: ${anime.countDown}\n- Image: (${anime.image})`;
      });

      const responseMessage = `${formattedList.join('\n\n')}\n\nPage: ${pageNumber}/${totalPages}`;
      message.reply(responseMessage);
    } catch (error) {
      message.reply(`An error occurred: ${error.message}`);
    }
  },
};
//By tanvir