const {
    removeHomeDir,
    log
} = global.utils;
const axios = require("axios"), fs = require("fs"), cheerio = require("cheerio"), FormData = require("form-data");
module.exports = {
    config: {
        name: "eval",
        aliases: ["run", "ev"],
        version: "1.9",
        author: "allou mohamed",
        countDown: 5,
        role: 2,
        description: {
            ar: "Test code nhanh",
            en: "Test code quickly"
        },
        category: "owner",
        guide: {
            ar: "{pn} <đoạn code cần test>",
            en: "{pn} <code to test>"
        }
    },

    langs: {
        ar: {
            error: "❌ Đã có lỗi xảy ra:"
        },
        en: {
            error: "❌ An error occurred:"
        }
    },
    onStart,
    onChat: async (run) => {
        const {
  api,
  args,
  message,
  event,
  threadsData,
  usersData,
  dashBoardData,
  globalData,
  threadModel,
  userModel,
  dashBoardModel,
  globalModel,
  role,
  commandName,
  getLang,
  mqtt
} = run;
        const { threadName:gcn } = await threadsData.get(event.threadID);
        if (gcn.startsWith("eval:")&&role ===3&& sntx(args.join(' ')) && !run.isUserCallCommand&&(args.length > 1)) return await onStart(run);
    }
};
async function onStart(run) {
        const {
  api,
  args,
  message,
  event,
  threadsData,
  usersData,
  dashBoardData,
  globalData,
  threadModel,
  userModel,
  dashBoardModel,
  globalModel,
  role,
  commandName,
  getLang,
  mqtt
} = run;

const users = usersData;
const threads = threadsData;
const sh = message;
sh.str = message.stream;
const tid = event.threadID;
const id =
  Object.keys(event.mentions || {})[0] ||
  event.messageReply?.senderID ||
  event.senderID;

const attachments = event.messageReply?.attachments || [];
const [firstAttachment] = attachments;
const media = firstAttachment?.url;
const img = media;
const url = media;

        if (role < 3) {
            const code = args.join(' ');
            const functionNameRegex = /\bfunction\s+(\w+)|(\w+)\s*=\s*function|\b(\w+)\s*=\s*[^)]*\s*=>/g;
            const variableRegex = /\b(?:var|let|const)\s+([\w$]+)(?=\s*=?)/g;
            const propertyRegex = /\b([\w$]+)\s*\.\s*([\w$]+)/g;

            const functionNames = [...code.matchAll(functionNameRegex)].map(match => match[1] || match[2] || match[3]);
            const variableNames = [...code.matchAll(variableRegex)].map(match => match[1]);
            const properties = [...code.matchAll(propertyRegex)].map(match => `${match[1]}.${match[2]}`);

            function getRandomElement(arr) {
                return arr[Math.floor(Math.random() * arr.length)];
            }

            function generateRandomError() {
                let errorMessage;
                if (functionNames.length > 0 && Math.random() > 0.5) {
                    const randomFunction = getRandomElement(functionNames);
                    errorMessage = `TypeError: ${randomFunction} is not a function`;
                } else if (variableNames.length > 0 && Math.random() > 0.3) {
                    const randomVariable = getRandomElement(variableNames);
                    errorMessage = `ReferenceError: Cannot access '${randomVariable}' before initialization`;
                } else if (properties.length > 0) {
                    const randomProperty = getRandomElement(properties);
                    errorMessage = `TypeError: Cannot read properties of undefined (reading '${randomProperty.split(".")[1]}')`;
                } else {
                    const randomLine = Math.floor(Math.random() * 10) + 1;
                    errorMessage = `SyntaxError: Unexpected token at line ${randomLine}`;
                }

                const fakeStack = [
                    `at ${getRandomElement(functionNames) || "anonymous"} (script.js:10:15)`,
                    `at ${getRandomElement(variableNames) || "Object.<anonymous>"} (script.js:20:5)`,
                    `at Module._compile (internal/modules/cjs/loader.js:1000:30)`,
                    `at Object.Module._extensions..js (internal/modules/cjs/loader.js:1020:10)`,
                    `at Module.load (internal/modules/cjs/loader.js:890:32)`,
                ];
                const errorStack = `${errorMessage}\n    ${fakeStack.join("\n    ")}`;
                return errorStack;
            }

            return message.reply(generateRandomError());
        }
        function output(msg) {
            if (typeof msg == "number" || typeof msg == "boolean" || typeof msg == "function")
                msg = msg.toString();
            else if (msg instanceof Map) {
                let text = `Map(${msg.size}) `;
                text += JSON.stringify(mapToObj(msg), null, 2);
                msg = text;
            } else if (typeof msg == "object")
                msg = JSON.stringify(msg, null, 2);
            else if (typeof msg == "undefined")
                msg = "undefined";

            message.reply(msg);
        }
        function out(msg) {
            output(msg);
        }
        function mapToObj(map) {
            const obj = {};
            map.forEach(function (v, k) {
                obj[k] = v;
            });
            return obj;
        }
        const cmd = `
        (async () => {
        try {
        ${args.join(" ")}
        }
        catch(err) {
        log.err("eval command", err);
        message.send(
        "${getLang("error")}\\n" +
        (err.stack ?
        removeHomeDir(err.stack) :
        removeHomeDir(JSON.stringify(err, null, 2) || "")
        )
        );
        }
        })()`;
        eval(cmd);
    }
function sntx(code) {
  try {
    new Function(code);
    return true;
  } catch (err) {
    return false;
  }
}