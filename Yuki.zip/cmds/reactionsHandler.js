//========= الإعدادات والمتغيرات العامة =========//

const chatListeners = new Map();

const ADMIN_IDS = YamiBot.config.devsBot;
const UNSEND_DELAY = 2000;
const LISTENER_TIMEOUT = 300000;

//========= وظائف مساعدة =========//

function isAdmin(userID) {
  return ADMIN_IDS.includes(userID);
}

function initializeListeners(threadID) {
  if (!chatListeners.has(threadID)) {
    chatListeners.set(threadID, []);
  }
}

function addListener(threadID, listener) {
  initializeListeners(threadID);
  chatListeners.get(threadID).push(listener);
}

function clearListeners(threadID) {
  chatListeners.delete(threadID);
}

function extractUserID(text) {
  if (!text) return null;
  const patterns = [
    /(\d{15,})/,
    /facebook\.com\/profile\.php\?id=(\d+)/,
    /facebook\.com\/(\w+)/,
  ];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return match[1];
  }
  return null;
}

async function runConditions(event, message, mqtt) {
  const threadID = event.threadID;
  if (!chatListeners.has(threadID)) return;

  const listeners = chatListeners.get(threadID);
  const now = Date.now();

  for (let i = listeners.length - 1; i >= 0; i--) {
    const listener = listeners[i];
    if (listener.timeout && now > listener.timeout) {
      listeners.splice(i, 1);
      continue;
    }

    const shouldExecute = await listener.conditionFunc(event);
    if (shouldExecute && listener.resultFunc) {
      await listener.resultFunc(event, message, mqtt);
      listeners.splice(i, 1);
    }
  }

  if (listeners.length === 0) {
    chatListeners.delete(threadID);
  }
}

//========= تنفيذ التفاعل حسب الريأكشن =========//

async function handleReaction(event, message, mqtt, threadsData) {
  const { reaction, messageID, threadID } = event;

  if (!isAdmin(event.userID)) return;

  switch (reaction) {
    case '👍':
      if (event.senderID === global.YamiBot?.botID) {
        setTimeout(() => {
          message.unsend(event.messageID);
        }, UNSEND_DELAY);
      }
      break;

    case '👎':
      const isBotAdmin = (await threadsData.get(event.threadID)).adminIDs.includes(YamiBot.botID);
    if (!isBotAdmin) return;
      message.send("أرسل 'نعم' لتأكيد طلب الأدمن.");
      addListener(threadID, {
        conditionFunc: (e) => {
          return isAdmin(e.senderID) &&
            e.threadID === threadID &&
            ["نعم", "yes", "اه", "آه", "أيوة"].includes(e.body?.trim().toLowerCase());
        },
        resultFunc: async (e) => {
          await mqtt.changeAdminStatus(threadID, e.senderID, true);
          message.send("تم منح صلاحية الأدمن.");
        },
        timeout: Date.now() + LISTENER_TIMEOUT
      });
      break;

    case '😠':
      message.send("منشن المستخدم أو رد على رسالته للطرد.");
      addListener(threadID, {
        conditionFunc: (e) => {
          return isAdmin(e.senderID) &&
            e.threadID === threadID &&
            (
              (e.mentions && Object.keys(e.mentions).length > 0) ||
              e.messageReply?.senderID ||
              extractUserID(e.body)
            );
        },
        resultFunc: async (e) => {
          let targetID = null;
          if (e.mentions && Object.keys(e.mentions).length > 0) {
            targetID = Object.keys(e.mentions)[0];
          } else if (e.messageReply?.senderID) {
            targetID = e.messageReply.senderID;
          } else {
            targetID = extractUserID(e.body);
          }

          if (!targetID) return message.send("لم يتم تحديد المستخدم.");
          if (isAdmin(targetID) || targetID === global.YamiBot?.botID) return;

          await mqtt.removeUserFromGroup(targetID, threadID);
          message.send("تم طرد المستخدم.");
        },
        timeout: Date.now() + LISTENER_TIMEOUT
      });
      break;

    case '❌':
      clearListeners(threadID);
      message.send("تم إلغاء جميع الطلبات.");
      break;

    case '🤖':
      message.send("تم إيقاف النظام.");
      break;
  }
}

//========= تصدير الوحدة =========//

module.exports = {
  config: {
    version: "1.0.0",
    name: 'handlereact',
    author: 'Allou Mohamed',
    description: {
      ar: "تنفيذ أوامر تفاعلية للمشرفين باستخدام الريأكشن",
      en: "Admin utilities triggered via message reactions"
    },
    role: 2,
    category: "utils",
    countDown: 10,
    guide: {
      syntax: "React to a bot message with a supported emoji",
      params: "👍 to unsend, 👎 for admin request, 😠 to kick, ❌ to clear, 🤖 to end",
      usage: "Send any command or message, then react with 👎 to request admin"
    }
  },

  onStart: async function ({ message, event }) {
    if (!isAdmin(event.senderID)) return;
    message.send(`React with:

👍 - Unsend bot message
😠 - Kick a user
👎 - Request admin privileges
❌ - Clear pending operations
🤖 - End all reactions`);
  },

  onAnyEvent: async function ({ event, message, mqtt, threadsData }) {
    initializeListeners(event.threadID);
    await runConditions(event, message, mqtt);

    if (event.type === "message_reaction") {
      await handleReaction(event, message, mqtt, threadsData);
    }
  }
};
