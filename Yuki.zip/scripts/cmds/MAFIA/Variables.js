const Config = require('./Config');

if (!global.MafiaGames) {
  global.MafiaGames = {
    games: {},
    activeTimers: new Map(),
    usedGroupIDs: [],
    leaderboard: [],
    mafiaRooms: {}
  };
}

function initializeGame(gameID, mainThreadID, commandName) {
  global.MafiaGames.games[gameID] = {
    id: gameID,
    main: mainThreadID,
    phase: "join",
    joinable: true,
    players: {},
    pendingPlayers: {},
    playerGroups: {},
    mafiaGroupID: null,
    day: 0,
    votes: {},
    nightActions: {},
    history: [],
    commandName: commandName,
    createdAt: Date.now(),
    voteLocked: {},
    mayorRevealed: false,
    skillUsageTracker: {},
    mafiaKillAbilityHolder: null,
    killAbilityTransferCount: 0
  };
  return global.MafiaGames.games[gameID];
}

function getGame(gameID) {
  return global.MafiaGames.games[gameID];
}

function deleteGame(gameID) {
  delete global.MafiaGames.games[gameID];
}

function getAllGames() {
  return Object.values(global.MafiaGames.games);
}

function findGameByThread(threadID) {
  return Object.values(global.MafiaGames.games).find(
    g => g.main === threadID && g.phase !== "ended"
  );
}

function clearAllTimers(gameID) {
  if (global.MafiaGames.activeTimers.has(gameID)) {
    const timers = global.MafiaGames.activeTimers.get(gameID);
    timers.forEach(timer => clearTimeout(timer));
    global.MafiaGames.activeTimers.delete(gameID);
  }
}

function addTimer(gameID, timer) {
  if (!global.MafiaGames.activeTimers.has(gameID)) {
    global.MafiaGames.activeTimers.set(gameID, []);
  }
  global.MafiaGames.activeTimers.get(gameID).push(timer);
}

function getAvailableGroupID() {
  const used = global.MafiaGames.usedGroupIDs || [];
  const available = Config.availableGroupIDs.filter(id => !used.includes(id));
  if (available.length === 0) {
    throw new Error("❌ لا توجد غرف متاحة حالياً! حاول لاحقاً");
  }
  return available[0];
}

function markGroupIDUsed(groupID) {
  if (!global.MafiaGames.usedGroupIDs.includes(groupID)) {
    global.MafiaGames.usedGroupIDs.push(groupID);
  }
}

function releaseGroupID(groupID) {
  global.MafiaGames.usedGroupIDs = global.MafiaGames.usedGroupIDs.filter(id => id !== groupID);
}

function setMafiaRoom(gameID, groupID) {
  global.MafiaGames.mafiaRooms[gameID] = groupID;
}

function getMafiaRoom(gameID) {
  return global.MafiaGames.mafiaRooms[gameID];
}

function releaseMafiaRoom(gameID) {
  const roomID = global.MafiaGames.mafiaRooms[gameID];
  if (roomID) {
    releaseGroupID(roomID);
    delete global.MafiaGames.mafiaRooms[gameID];
  }
}

function updateLeaderboard(playerStats) {
  if (!playerStats) return;
  const entries = Object.entries(playerStats).map(([id, stats]) => ({
    userID: id,
    score: calculatePlayerScore(stats),
    wins: stats.wins,
    winRate: parseFloat(stats.winRate) || 0,
    points: stats.points
  }));
  global.MafiaGames.leaderboard = entries.sort((a, b) => b.score - a.score).slice(0, 15);
}

function calculatePlayerScore(stats) {
  return (stats.wins * 15) + 
         (stats.kills * 8) + 
         (stats.correctVotes * 5) - 
         (stats.wrongVotes * 3) +
         (stats.points * 2);
}

function getLeaderboard() {
  return global.MafiaGames.leaderboard || [];
}

function initPlayer(userID, groupID, role = null) {
  return {
    userID,
    groupID,
    role,
    alive: true,
    protected: false,
    blackmailed: false,
    roleblocked: false,
    framed: false,
    convertedToVampire: false,
    abilities: {},
    joinedAt: Date.now(),
    purchasedItems: {},
    skillUsedOn: {},
    hasKillAbility: false,
    killsRemaining: 0,
    revived: false,
    revivedRole: null,
    lynched: false,
    doused: false,
    hasExtraLife: false,
    alerted: false,
    bodyguarded: null,
    trapped: null,
    crusaded: null,
    executionerTarget: null
  };
}

function alive(game) {
  return Object.values(game.players).filter(p => p.alive);
}

function aliveMafia(game) {
  return alive(game).filter(p => {
    const role = Config.ROLES[p.role];
    return role.team === "mafia";
  });
}

function aliveCitizen(game) {
  return alive(game).filter(p => {
    const role = Config.ROLES[p.role];
    return role.team === "citizen";
  });
}

function aliveNeutral(game) {
  return alive(game).filter(p => {
    const role = Config.ROLES[p.role];
    return role.team === "neutral" || role.team === "vampire";
  });
}

function aliveVampires(game) {
  return alive(game).filter(p => {
    const role = Config.ROLES[p.role];
    return role.team === "vampire" || p.convertedToVampire;
  });
}

function getPlayerByIndex(game, index) {
  const players = alive(game);
  if (index < 1 || index > players.length) return null;
  return players[index - 1];
}

function getPlayerByID(game, userID) {
  return game.players[userID];
}

function trackSkillUsage(game, actorID, targetID, skillType) {
  if (!game.skillUsageTracker[actorID]) {
    game.skillUsageTracker[actorID] = {};
  }
  if (!game.skillUsageTracker[actorID][skillType]) {
    game.skillUsageTracker[actorID][skillType] = [];
  }
  game.skillUsageTracker[actorID][skillType].push(targetID);
}

function hasUsedSkillOn(game, actorID, targetID, skillType) {
  if (!game.skillUsageTracker[actorID]) return false;
  if (!game.skillUsageTracker[actorID][skillType]) return false;
  return game.skillUsageTracker[actorID][skillType].includes(targetID);
}

function canUseSkillOn(game, actorID, targetID, skillType) {
  const actor = game.players[actorID];
  if (!actor) return false;
  
  const role = Config.ROLES[actor.role];
  const team = role.team;
  
  if (team === "mafia") {
    const teammates = aliveMafia(game).map(p => p.userID).filter(id => id !== actorID);
    const usedOnTeammates = teammates.filter(tmID => hasUsedSkillOn(game, actorID, tmID, skillType));
    
    if (usedOnTeammates.length < teammates.length) {
      if (hasUsedSkillOn(game, actorID, targetID, skillType)) {
        return false;
      }
    }
  }
  
  return true;
}

function assignMafiaKillAbility(game) {
  const mafiasWithKill = aliveMafia(game).filter(m => {
    const role = Config.ROLES[m.role];
    return role.canKill;
  });
  
  if (mafiasWithKill.length > 0) {
    const holder = mafiasWithKill[0];
    holder.hasKillAbility = true;
    holder.killsRemaining = Config.ROLES[holder.role].killsPerAbility || 2;
    game.mafiaKillAbilityHolder = holder.userID;
    return holder.userID;
  }
  
  return null;
}

function transferMafiaKillAbility(game) {
  const currentHolder = game.players[game.mafiaKillAbilityHolder];
  
  if (currentHolder && currentHolder.alive && currentHolder.killsRemaining > 0) {
    return game.mafiaKillAbilityHolder;
  }
  
  const aliveMafiaMembers = aliveMafia(game).filter(m => !m.hasKillAbility);
  
  if (aliveMafiaMembers.length === 0) {
    return null;
  }
  
  const newHolder = aliveMafiaMembers[0];
  newHolder.hasKillAbility = true;
  newHolder.killsRemaining = 2;
  game.mafiaKillAbilityHolder = newHolder.userID;
  game.killAbilityTransferCount++;
  
  return newHolder.userID;
}

function decrementMafiaKill(game) {
  const holder = game.players[game.mafiaKillAbilityHolder];
  if (holder && holder.killsRemaining > 0) {
    holder.killsRemaining--;
    
    if (holder.killsRemaining === 0) {
      holder.hasKillAbility = false;
      return transferMafiaKillAbility(game);
    }
  }
  return game.mafiaKillAbilityHolder;
}

function getMafiaKillHolder(game) {
  return game.players[game.mafiaKillAbilityHolder];
}

function cleanupOldGames() {
  const now = Date.now();
  const maxAge = Config.gameSettings.maxGameAgeMs;
  for (const [id, game] of Object.entries(global.MafiaGames.games)) {
    if (now - game.createdAt > maxAge) {
      console.log(`[MAFIA42] 🧹 Cleaning old game: ${id}`);
      clearAllTimers(id);
      releaseMafiaRoom(id);
      deleteGame(id);
    }
  }
}

function initCleanupInterval() {
  setInterval(() => {
    cleanupOldGames();
  }, Config.gameSettings.cleanupIntervalMs);
}

module.exports = {
  initializeGame,
  getGame,
  deleteGame,
  getAllGames,
  findGameByThread,
  clearAllTimers,
  addTimer,
  getAvailableGroupID,
  markGroupIDUsed,
  releaseGroupID,
  setMafiaRoom,
  getMafiaRoom,
  releaseMafiaRoom,
  updateLeaderboard,
  calculatePlayerScore,
  getLeaderboard,
  initPlayer,
  alive,
  aliveMafia,
  aliveCitizen,
  aliveNeutral,
  aliveVampires,
  getPlayerByIndex,
  getPlayerByID,
  trackSkillUsage,
  hasUsedSkillOn,
  canUseSkillOn,
  assignMafiaKillAbility,
  transferMafiaKillAbility,
  decrementMafiaKill,
  getMafiaKillHolder,
  cleanupOldGames,
  initCleanupInterval
};
