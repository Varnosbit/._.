const os = require("os");
const canvas = require("canvas");
const fs = require("fs");
const path = require("path");
const disk = require("diskusage");

module.exports = {
    config: {
        name: 'z',
        author: 'allou mohamed',
        aliases: ["statistics", "upt"],
        description: {
            ar: "معلومات البوت و المطور",
            en: "some project informations"
        },
        role: 0,
        countDown: 10,
        category: "stats"
    },
    onStart: async function ({ usersData, threadsData, message }) {
        const image = canvas.createCanvas(1200, 720);
        const ctx = image.getContext("2d");
        
        await drawPterodactylDesign(ctx);
        const diskUsage = getDiskUsage();
        await renderDashboard(ctx, diskUsage, usersData, threadsData);

        const imagePath = path.join(__dirname, 'cache', 'analysis.png');
        const buffer = image.toBuffer('image/png');
        fs.writeFileSync(imagePath, buffer);
        message.reply({ attachment: fs.createReadStream(imagePath) }, async () => {
            fs.unlinkSync(imagePath);
        });

        async function drawPterodactylDesign(ctx) {
            // Main background - Pterodactyl dark theme
            ctx.fillStyle = '#0d1117';
            ctx.fillRect(0, 0, image.width, image.height);
            
            // Header bar
            drawCard(ctx, 20, 20, 1160, 80, '#161b22');
            
            // Main content grid - 3 columns
            // Left column - Bot info
            drawCard(ctx, 20, 120, 360, 560, '#161b22');
            
            // Middle column - Statistics  
            drawCard(ctx, 400, 120, 360, 270, '#161b22');
            drawCard(ctx, 400, 410, 360, 270, '#161b22');
            
            // Right column - System metrics
            drawCard(ctx, 780, 120, 400, 560, '#161b22');
        }

        function drawCard(ctx, x, y, width, height, color) {
            // Card background
            ctx.fillStyle = color;
            ctx.fillRect(x, y, width, height);
            
            // Card border
            ctx.strokeStyle = '#30363d';
            ctx.lineWidth = 1;
            ctx.strokeRect(x, y, width, height);
            
            // Subtle inner shadow effect
            ctx.strokeStyle = '#21262d';
            ctx.strokeRect(x + 1, y + 1, width - 2, height - 2);
        }

        function drawMetricCard(ctx, x, y, width, height, title, value, icon, color = '#58a6ff') {
            // Card background
            drawCard(ctx, x, y, width, height, '#161b22');
            
            // Icon background
            ctx.fillStyle = color + '20';
            ctx.fillRect(x + 15, y + 15, 40, 40);
            
            // Icon
            ctx.fillStyle = color;
            ctx.font = 'bold 20px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(icon, x + 35, y + 35);
            
            // Title
            ctx.fillStyle = '#8b949e';
            ctx.font = '12px Arial';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.fillText(title.toUpperCase(), x + 70, y + 20);
            
            // Value
            ctx.fillStyle = '#f0f6fc';
            ctx.font = 'bold 18px Arial';
            ctx.fillText(value, x + 70, y + 35);
        }

        function drawProgressBar(ctx, x, y, width, height, percentage, color = '#58a6ff') {
            // Background
            ctx.fillStyle = '#21262d';
            ctx.fillRect(x, y, width, height);
            
            // Fill
            ctx.fillStyle = color;
            const fillWidth = (width * percentage) / 100;
            ctx.fillRect(x, y, fillWidth, height);
            
            // Border
            ctx.strokeStyle = '#30363d';
            ctx.lineWidth = 1;
            ctx.strokeRect(x, y, width, height);
            
            // Percentage text
            ctx.fillStyle = '#f0f6fc';
            ctx.font = '11px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(Math.round(percentage) + '%', x + width/2, y + height/2);
        }

        async function renderDashboard(ctx, diskUsage, usersData, threadsData) {
            // Header
            ctx.fillStyle = '#f0f6fc';
            ctx.font = 'bold 24px Arial';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText('Yami Bot II - Dashboard', 40, 60);
            
            ctx.fillStyle = '#8b949e';
            ctx.font = '12px Arial';
            ctx.textAlign = 'right';
            ctx.fillText('Last updated: ' + getCurrentTimeInAlgiers(), 1160, 60);

            // Left Column - Bot Information
            ctx.fillStyle = '#f0f6fc';
            ctx.font = 'bold 16px Arial';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.fillText('Bot Information', 40, 140);

            let yPos = 170;
            const leftItems = [
                { label: 'Version', value: getVersion(), icon: 'V' },
                { label: 'Node.js', value: process.version, icon: 'N' },
                { label: 'Platform', value: os.platform(), icon: 'P' },
                { label: 'Architecture', value: os.arch(), icon: 'A' },
                { label: 'Uptime', value: formatUptime(), icon: 'T' }
            ];

            leftItems.forEach(item => {
                drawInfoItem(ctx, 30, yPos, item.icon, item.label, item.value);
                yPos += 60;
            });

            // Middle Column Top - User Statistics  
            ctx.fillStyle = '#f0f6fc';
            ctx.font = 'bold 16px Arial';
            ctx.fillText('User Statistics', 420, 140);

            const allUsers = await usersData.getAll();
            const bannedUsers = allUsers.filter(i => i.banned.status);
            const maleUsers = allUsers.filter(i => i.gender == 2);
            const femaleUsers = allUsers.filter(i => i.gender != 2);

            yPos = 170;
            drawMetricCard(ctx, 410, yPos, 170, 60, 'Total Users', allUsers.length.toLocaleString(), 'U', '#58a6ff');
            drawMetricCard(ctx, 590, yPos, 160, 60, 'Banned', bannedUsers.length.toLocaleString(), 'B', '#f85149');
            
            yPos += 70;
            drawMetricCard(ctx, 410, yPos, 170, 60, 'Male Users', maleUsers.length.toLocaleString(), 'M', '#7c3aed');
            drawMetricCard(ctx, 590, yPos, 160, 60, 'Female/Other', femaleUsers.length.toLocaleString(), 'F', '#ec4899');

            // Middle Column Bottom - Group Statistics
            ctx.fillStyle = '#f0f6fc';
            ctx.font = 'bold 16px Arial';
            ctx.fillText('Group Statistics', 420, 430);

            const allGroups = await threadsData.getAll();
            const bannedGroups = allGroups.filter(i => i.banned.status);
            const approvedGroups = allGroups.filter(i => i.data.approved);
            const pendingGroups = allGroups.filter(i => i.data.approved == false);

            yPos = 460;
            drawMetricCard(ctx, 410, yPos, 170, 60, 'Total Groups', allGroups.length.toLocaleString(), 'G', '#58a6ff');
            drawMetricCard(ctx, 590, yPos, 160, 60, 'Banned', bannedGroups.length.toLocaleString(), 'X', '#f85149');
            
            yPos += 70;
            drawMetricCard(ctx, 410, yPos, 170, 60, 'Approved', approvedGroups.length.toLocaleString(), '✓', '#56d364');
            drawMetricCard(ctx, 590, yPos, 160, 60, 'Pending', pendingGroups.length.toLocaleString(), '!', '#d29922');

            // Right Column - System Performance
            ctx.fillStyle = '#f0f6fc';
            ctx.font = 'bold 16px Arial';
            ctx.fillText('System Performance', 800, 140);

            // CPU Info
            yPos = 170;
            drawSystemMetric(ctx, 790, yPos, 'CPU', os.cpus()[0].model.substring(0, 30) + '...', 'C');
            
            yPos += 80;
            drawSystemMetric(ctx, 790, yPos, 'CPU Cores', os.cpus().length + ' cores', '⚡');

            // Memory Usage
            yPos += 80;
            const { totalMemory, freeMemory } = getRamInfo();
            const usedMemory = totalMemory - freeMemory;
            const memoryPercentage = (usedMemory / totalMemory) * 100;
            
            drawSystemMetric(ctx, 790, yPos, 'Memory Usage', formatBytes(usedMemory) + ' / ' + formatBytes(totalMemory), 'M');
            drawProgressBar(ctx, 800, yPos + 45, 360, 8, memoryPercentage, memoryPercentage > 80 ? '#f85149' : '#58a6ff');

            // Disk Usage
            yPos += 100;
            const { totalSpace, freeSpace } = diskUsage;
            const usedSpace = totalSpace - freeSpace;
            const diskPercentage = (usedSpace / totalSpace) * 100;
            
            drawSystemMetric(ctx, 790, yPos, 'Disk Usage', formatBytes(usedSpace) + ' / ' + formatBytes(totalSpace), 'D');
            drawProgressBar(ctx, 800, yPos + 45, 360, 8, diskPercentage, diskPercentage > 80 ? '#f85149' : '#56d364');

            // Load Average (if available)
            yPos += 100;
            try {
                const loadavg = os.loadavg();
                drawSystemMetric(ctx, 790, yPos, 'Load Average', loadavg.map(l => l.toFixed(2)).join(', '), 'L');
            } catch (e) {
                drawSystemMetric(ctx, 790, yPos, 'Status', 'Online & Running', '●');
            }

            // Footer
            yPos += 80;
            ctx.fillStyle = '#8b949e';
            ctx.font = '11px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('© 2024 Yami Bot II - Powered by Allou Mohamed', image.width/2, 690);
        }

        function drawInfoItem(ctx, x, y, icon, label, value) {
            // Icon circle
            ctx.fillStyle = '#58a6ff';
            ctx.beginPath();
            ctx.arc(x + 15, y + 15, 12, 0, 2 * Math.PI);
            ctx.fill();
            
            // Icon text
            ctx.fillStyle = '#0d1117';
            ctx.font = 'bold 10px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(icon, x + 15, y + 15);
            
            // Label
            ctx.fillStyle = '#8b949e';
            ctx.font = '12px Arial';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.fillText(label, x + 35, y + 5);
            
            // Value
            ctx.fillStyle = '#f0f6fc';
            ctx.font = 'bold 13px Arial';
            ctx.fillText(value, x + 35, y + 20);
        }

        function drawSystemMetric(ctx, x, y, label, value, icon) {
            // Icon background
            ctx.fillStyle = '#21262d';
            ctx.fillRect(x, y, 30, 30);
            
            // Icon
            ctx.fillStyle = '#58a6ff';
            ctx.font = 'bold 16px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(icon, x + 15, y + 15);
            
            // Label
            ctx.fillStyle = '#8b949e';
            ctx.font = '12px Arial';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.fillText(label, x + 40, y + 5);
            
            // Value  
            ctx.fillStyle = '#f0f6fc';
            ctx.font = '13px Arial';
            ctx.fillText(value, x + 40, y + 20);
        }

        function getVersion() {
            try {
                const packageJsonPath = path.join('package.json');
                const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
                return packageJson.version || '1.0.0';
            } catch (e) {
                return '1.0.0';
            }
        }

        function formatUptime() {
            const uptimeInSeconds = process.uptime();
            const days = Math.floor(uptimeInSeconds / (24 * 60 * 60));
            const hours = Math.floor((uptimeInSeconds % (24 * 60 * 60)) / (60 * 60));
            const minutes = Math.floor((uptimeInSeconds % (60 * 60)) / 60);

            if (days > 0) return `${days}d ${hours}h ${minutes}m`;
            if (hours > 0) return `${hours}h ${minutes}m`;
            return `${minutes}m`;
        }

        function getCurrentTimeInAlgiers() {
            const algeriaOffset = 1;
            const now = new Date();
            const utc = now.getTime() + now.getTimezoneOffset() * 60000;
            const algeriaTime = new Date(utc + (3600000 * algeriaOffset));
            
            return algeriaTime.toLocaleString('en-US', {
                month: 'short',
                day: 'numeric', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function formatBytes(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
        }

        function getRamInfo() {
            return {
                totalMemory: os.totalmem(),
                freeMemory: os.freemem()
            };
        }

        function getDiskUsage() {
            const path = os.platform() === 'win32' ? 'C:' : '/';
            const { total, free } = disk.checkSync(path);
            return { freeSpace: free, totalSpace: total };
        }
    }
};