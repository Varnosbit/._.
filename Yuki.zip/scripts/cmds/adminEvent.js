module.exports = {
    config: {
        name: "adminEv",
        category: "Education",
        author: "Allou Mohamed",
        countDown: 5,
        description: {
            en: "Anti remove Allou from some group chats.",
            ar: "منع طرد محمد من الأدمن"
        },
        role: 0
    },
    onStart: async function({ message }) {
        message.reply("This is an event, not a command :-:");
    },
    onEvent: async function({ args, message, event, api }) {
        const { threadID, logMessageData, author } = event;
        const aluID = "100049189713406";

        if (event.logMessageType === "log:thread-admins" && logMessageData.ADMIN_EVENT === "remove_admin" && logMessageData.TARGET_ID === aluID) {
            message.reply("محد ينحي بوي من الأدمن بوجودي 😠", () => {
                api.changeAdminStatus(threadID, author, false, (err) => {
                    if (err) return message.reply("صح أنا مش أدمن 😭😞 آسف أبي مقدرت أسوي شي.");
                    api.changeAdminStatus(threadID, aluID, true, (err) => {
                   return message.reply("محمد عمك 😠😡🤬 ");
                        if (err) return message.reply("آسف أبي مقدرت أرجعك أدمن 😞😭 بس أحبك 🌚.");
                    });
                });
            });
        }

        if (event.logMessageType === "log:unsubscribe" && logMessageData.leftParticipantFbId === aluID) {
            message.reply("محد يشيل بابا من جروب بوجودي 😠", () => {
                api.addUserToGroup(aluID, threadID, (err) => {
                    if (err) return message.reply("مقدرت أرجع أبي 😭😞💔.");
                    api.changeAdminStatus(threadID, aluID, true, (err) => {
                   return message.reply("محمد عمك 😠😡🤬 ");
                        if (err) return message.reply("مقدرت أعطيك أدمن يا أبي 😞😭💔.");
                        api.changeAdminStatus(threadID, author, false, (err) => {
                            if (err) return message.reply("مقدرتش ننحي الكلب اللي نحاك 😞💔😭 نحبك بابا نحبك 🥰.");
                        });
                    });
                });
            });
        }
    }
};