module.exports = {
	config: {
		name: "pay",
		aliases: ["دفع", "صدقة"],
		version: "1.3",
		author: "allou Mohamed",
		countDown: 5,
		role: 0,
		description: {
			en: "Pay someone.",
			ar: "تصدق بنقود لصاحبك أو صاحبتك."
		},
		category: "economy",
		guide: {
			en: "{pn} @mention or reply to someone",
			ar: "{pn} منشن شخص أو رد على شخص"
     	}
	},
	onStart: async function({ message, event, usersData, args }) {
	    
	    const id = Object.keys(event.mentions)[0] || event?.messageReply?.senderID;
	    const id_a = event.senderID;
	    const bal = parseInt(args[0]);

	    if (!id) return message.reply("منشن أو رد على الشخص");
	    if (isNaN(bal) || bal < 10) return message.reply("تصدق بمبلغ كبير يا أيها البخيل القذر 🙂💸");

	    const userBal = await usersData.getMoney(id_a);
	    if (userBal < bal) return message.reply("ليس لديك ما يكفي من المال لتصدق بهذا المبلغ 😅.");

	    await usersData.addMoney(id, bal);
	    await usersData.subtractMoney(id_a, bal);
	    
	    message.reply(`💸 @${id_a}:\nتصدقت ب${bal} ل@${id}.\nربي يجعلها في ميزان حسناتك بربي نشاله 😹.`);
	}
};