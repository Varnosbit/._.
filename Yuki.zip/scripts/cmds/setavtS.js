const {
    YukiBB
} = global.helpers;
module.exports = {
    config: {
        name: "setavt",
        aliases: ["سيتآف"],
        role: 0,
        description: {
            en: "change status avatar",
            ar: "تغيير الآفاتار في امر status."
        },
        category: "Status",
        countDown: 10
    },
    onStart: async function({
        message, event, usersData
    }) {
        const id = event.senderID;
        const image = event?.messageReply?.attachments[0]?.url;
        if (!image) {
            await helpers.setP(usersData, id, "avatar");
            message.reply("Your profile has been successfully changed to default image.");
            return;
        }
        const z = "avatar";
        const upload = await YukiBB(image);
        const x = upload.stream;
        await helpers.setP(usersData, id, x, z);
        message.reply("Your profile has been successfully changed.");
    }
};