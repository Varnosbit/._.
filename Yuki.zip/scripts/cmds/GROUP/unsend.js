module.exports = {
  config: {
    name: "unsend",
    aliases: [],
    author: "Allou Mohamed",
    category: "utility",
    version: "1.2.1",
    role: 0,
    countDown: 5,
    guide: {
      usage: "Unsend a message sent by the bot",
      params: "none",
      syntax: "{prefix}unsend (reply to a bot message that isn't a reply-handler)"
    }
  },

  async onStart({ event, message, api }) {
    const replyMsg = event?.messageReply;

    if (!replyMsg) {
      return message.reply("# %bdMissing Reply:%\nYou must reply to a message sent by the bot.");
    }

    if (replyMsg.senderID !== api.getCurrentUserID()) {
      return message.reply("# %bdInvalid Message:%\nYou can only unsend messages sent by the bot.");
    }

    if (global.YamiBot.onReply.has(replyMsg.messageID)) {
      return message.reply("# %bdBlocked:%\nThis message is part of a reply system and cannot be unsent.");
    }

    try {
      await message.unsend(replyMsg.messageID);
    } catch {
      return message.reply("# %bdFailed:%\nUnable to unsend the message. It may have already been removed.");
    }
  }
};
