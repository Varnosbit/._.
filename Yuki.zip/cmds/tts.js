const axios = require("axios");
const FormData = require("form-data");
exports.config = {
    name: "tts",
    version: "1.0",
    author: "takt 🐦",
    category: "ai"
};
exports.onReply = async ({ message, args, usersData, event, Reply }) => {
    const { vs } = Reply;
    if (!vs || !args[0]) return;
    
    const index = parseInt(args[0]) - 1;
    if (index < 0 || index >= vs.length) {
        return message.reply("Invalid voice index. Please select a valid number from the list.");
    }
    
    const selectedVoice = vs[index];
    await usersData.set(event.senderID, selectedVoice.id, "data.ttsvid");
    
    const body = `Voice set to: ${selectedVoice.name} (${selectedVoice.gender}, ${selectedVoice.lang})`;
    const s = await utils.getStreamFromUrl(selectedVoice.voice, utils.randomString(5)+".mp3");
    message.send({body, attachment: s});
};

exports.onStart = async ({ message, args, usersData, event, commandName }) => {
    if (!args[0]) return message.reply("Please provide text to convert to speech or use 'list' to see available voices.");
    
    if (args[0] == "list") {
        const vs = await GetVoice();
        if (vs.length == 0) return message.reply("No voices available.");
        
        let list = "Available voices:\n";
        vs.forEach((voice, index) => {
            list += `${index + 1}. ${voice.name} (${voice.gender}, ${voice.lang}, ${voice.age}) - ID: ${voice.id}\n`;
        });
        
        return message.reply(list+"\n\nReply By Voice Index To Set It.", (err, info) => {
            YamiBot.onReply.set(info.messageID, {
                commandName,
                vs
            })
        });
    }
    
    try {
        const co = await GetCookie();
        const tt = args.join(" ");
        const v = await usersData.get(event.senderID, "data.ttsvid") || "NNl6r8mD7vthiJatiJt1";
        
        let s = await Elevenlabs(tt, co, v);
        
        if (s.uri) {
            message.stream(s.uri);
        } else {
            message.reply("Failed to generate audio. Please try again.");
        }
    } catch (error) {
        console.error("TTS Error:", error);
        message.reply("An error occurred while generating speech. Please try again later.");
    }
    async function tok() {
  
const API_BASE = "https://api.mail.tm"; 
const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36";

function randString(length = 8, chars = "abcdefghijklmnopqrstuvwxyz0123456789") {
  let s = "";
  for (let i = 0; i < length; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function randPassword(length = 14) {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+";
  return randString(length, chars);
}

async function fetchDomains() {
  const url = `${API_BASE}/domains`;
  const res = await axios.get(url, {
    headers: { "User-Agent": UA },
    validateStatus: null
  });
  if (res.status >= 200 && res.status < 300) return res.data;
  throw new Error(`Failed to fetch domains: ${res.status} ${res.statusText}`);
}

async function createAccount(address, password) {
  const url = `${API_BASE}/accounts`;
  const body = { address, password };
  const res = await axios.post(url, body, {
    headers: { "User-Agent": UA, "Content-Type": "application/json" },
    validateStatus: null
  });
  // API قد يرجع 201 Created أو 200
  if (res.status === 201 || (res.status >= 200 && res.status < 300)) return res.data;
  // بعض APIs ترجع 422 مع تفاصيل violations
  throw new Error(`Create account failed: ${res.status} ${JSON.stringify(res.data)}`);
}

async function getToken(address, password) {
  const url = `${API_BASE}/token`;
  const res = await axios.post(url, { address, password }, {
    headers: { "User-Agent": UA, "Content-Type": "application/json" },
    validateStatus: null
  });
  if (res.status >= 200 && res.status < 300) return res.data;
  throw new Error(`Token request failed: ${res.status} ${JSON.stringify(res.data)}`);
}
  try {
    
    const domainsRes = await fetchDomains();
    const members = (domainsRes && domainsRes["hydra:member"]) || domainsRes["hydra:member"] || domainsRes["hydra:member"] || domainsRes["hydra:member"];
    // flexible handling: sometimes API returns top-level hydra keys or plain array
    let domain;
    if (Array.isArray(domainsRes["hydra:member"]) && domainsRes["hydra:member"].length) {
      domain = domainsRes["hydra:member"][0].domain;
    } else if (Array.isArray(domainsRes) && domainsRes.length) {
      // sometimes the endpoint returns array directly
      domain = domainsRes[0].domain || domainsRes[0].domain;
    } else if (members && members.length) {
      domain = members[0].domain;
    } else if (domainsRes.domain) {
      domain = domainsRes.domain;
    }

    if (!domain) {
      throw new Error("No domain found in /domains response.");
    }

    

    // generate local part and password
    const local = `u${randString(6)}`; // يبدأ بـ u لتجنّب أرقام فقط
    const password = randPassword(14);
    const address = `${local}@${domain}`;

    
    const created = await createAccount(address, password);
   
    const tokenRes = await getToken(address, password);
    // many APIs return { token: "...", id: "..." } or { token: { access: "...", refresh: "..." } }
    

    const token = tokenRes.token ?? tokenRes.token?.access ?? tokenRes["hydra:member"] ?? tokenRes.access ?? tokenRes.tokenType ?? tokenRes["access_token"] ?? tokenRes["token"];
    

    return token;
  } catch (err) {
    console.error("ERROR:", err.message || err);
    if (err.response) console.error("response data:", err.response.data);
    process.exitCode = 1;
    throw err;
  }
}

async function Email(tok) {

let config = {
  method: 'GET',
  url: 'https://api.mail.tm/me',
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'authorization': 'Bearer '+tok,
    'sec-ch-ua-platform': '"Android"',
    'origin': 'https://mail.tm',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://mail.tm/',
    'accept-language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7'
  }
};

let r = await axios.request(config)
 
return r.data.address;
  
}

async function Msg(tok) {

let config = {
  method: 'GET',
  url: 'https://api.mail.tm/messages',
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'authorization': 'Bearer '+tok,
    'sec-ch-ua-platform': '"Android"',
    'origin': 'https://mail.tm',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://mail.tm/',
    'accept-language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
    'if-none-match': '"0a4f448ec35e5f2e298782d9de55c215"'
  }
};

let g = (await axios.request(config)).data;
  while(!g["hydra:member"]?.[0]) {
  g = await Msg(y)
 await sleep(10000)
}
let idt = g["hydra:member"]?.[0]["@id"];
  
let config2 = {
  method: 'GET',
  url: 'https://api.mail.tm'+idt,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'authorization': 'Bearer '+tok,
    'sec-ch-ua-platform': '"Android"',
    'origin': 'https://mail.tm',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://mail.tm/',
    'accept-language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7'
  }
};

  let yh = await axios.request(config2)
  return yh.data.text
}

async function GetCookie() {
let yt = await tok()
let k = await Email(yt)
let r = Math.random().toString(36).slice(2);
let ema = k;



let data = new FormData();
data.append('1_$ACTION_REF_1', '');
data.append('1_$ACTION_1:0', '{"id":"955d545e80ed98c06946689d68657c9560c37f26","bound":"$@1"}');
data.append('1_$ACTION_1:1', '[{"error":"","next":"$undefined"}]');
data.append('1_$ACTION_KEY', 'k948318504');
data.append('1_email', ema);
data.append('1_password', r+(Math.random().toString(36).slice(2)));
data.append('0', '[{"error":"","next":"$undefined"},"$K1"]');

let config = {
  method: 'POST',
  url: 'https://unitool.ai/en/entry',
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/53.36',
    'Accept': 'text/x-component',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'next-router-state-tree': '%5B%22%22%2C%7B%22children%22%3A%5B%5B%22lang%22%2C%22en%22%2C%22d%22%5D%2C%7B%22children%22%3A%5B%22entry%22%2C%7B%22children%22%3A%5B%22__PAGE__%22%2C%7B%7D%2C%22%2Fen%2Fentry%22%2C%22refresh%22%5D%7D%5D%7D%5D%7D%2Cnull%2Cnull%2Ctrue%5D',
    'sec-ch-ua-mobile': '?1',
    'next-action': '955d545e80ed98c06946689d68657c9560c37f26',
    'sec-ch-ua-platform': '"Android"',
    'origin': 'https://unitool.ai',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://unitool.ai/en/entry',
    'accept-language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
    'Cookie': 'google-state=%2F%7C%2F'
  },
  data: data
};

let res = await axios.request(config);
if(res.status != 200) console.log("hi f");
await sleep(10000)
  


const html = await Msg(yt);
  
const m = html.match(/Зарегистрироваться\s*\[(https?:\/\/[^\]\s]+)\]/);
function untrackAws(url) {

  const m = url.match(/\/L0\/([^/]+)\//);
  if (!m) return url;
  const encoded = m[1];
  try {
    return decodeURIComponent(encoded); 
  } catch {
    return url;
  }
}  
let relur = untrackAws(m[1])


const options = {
  method: 'GET',
  redirect: "manual"
};
let response = await fetch(relur, options);

let u = response.headers.get("set-cookie");


  const mas = u.match(/__Secure-unitool-ssid=([^;]+)/i)

return "google-state=%2F%7C%2F; __Secure-unitool-ssid="+mas[1]
}

async function GetVoice() {
let config = {
  method: 'GET',
  url: 'https://unitool.ai/api/elevenlabs/voices',
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://unitool.ai/en/elevenlabs',
    'accept-language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
    'Cookie': 'google-state=%2F%7C%2F; __Secure-unitool-ssid=9ef18c781d904f54f159789449e854052ad79fd83b8eaf756e2d6a876e0871a7d36405ac48cad9f6e21054feb822d7e760dd70088c55d35a76ce0630eff722081f18f11c9542bb02bd52f353c56a01b8c4c1e5321416927137924524fb0c3b98cc4a1f4285085d36efcec4420987fd186574121271e837f3f29fbd25a8ad54a1adb70e47'
  }
};

let vi = await axios.request(config);
  let kl = vi.data.voices.
    map(i => ({
    name: i.name,
    id: i.voice_id,
    voice: i.preview_url,
    gender: i.labels.gender,
    lang: i.labels.language,
    age: i.labels.age
  }))
return kl;

}
async function Elevenlabs(prompt, tok, voi="f9pGP0SX5A4RfuWxvFLN") {
  let data = JSON.stringify({
  "voice_id": voi,
  "options": {
    "text": prompt,
    "model_id": "eleven_v3",
    "voice_settings": {
      "similarity_boost": 0.75,
      "stability": 0.5,
      "style": 0,
      "use_speaker_boost": true
    }
  },
  "api_key_id": 1
});

let config = {
  method: 'POST',
  url: 'https://unitool.ai/api/text2speech',
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'Content-Type': 'application/json',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-platform': '"Android"',
    'sec-ch-ua-mobile': '?1',
    'origin': 'https://unitool.ai',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://unitool.ai/en/elevenlabs',
    'accept-language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
    'Cookie': tok
  },
  data: data
};

let y = await axios.request(config);
return y.data;
}
};

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms))
}