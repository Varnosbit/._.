//2.0.0
const {
    createCanvas,
    loadImage
} = require('canvas');
//DIMENSIONS ✨
const vsLogo = 'https://i.ibb.co/sKdfdBQ/Picsart-24-12-13-16-06-39-580.png';
const oPng = "https://i.ibb.co/NCSM0pF/Picsart-24-12-13-17-30-40-672.png";
const xPng = "https://i.ibb.co/YN6jSbM/Picsart-24-12-13-17-32-34-258.png";
const gridSize = 12;
const cellSize = 80;
const padding = 100;
const headerHeight = 300;
const boardHeight = gridSize * cellSize + padding * 1.6;
const canvasWidth = gridSize * cellSize + padding;
const canvasHeight = boardHeight + (padding / 2);

async function drawCaroBoard(player1, player2, gameData) {
    if (!gameData) gameData = [];
    let isWin = false;
    const canvas = createCanvas(canvasWidth * 2, canvasHeight * 2);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvasWidth * 2, canvasHeight * 2);

    const player1Image = await loadImage(player1.avatarPng);
    const player2Image = await loadImage(player2.avatarPng);
    const vsImage = await loadImage(vsLogo);
    
    const oImage = await loadImage(oPng);
    const xImage = await loadImage(xPng);
    const symbol1X = padding * 2 - 160;
    const symbol1Y = 60;
    ctx.drawImage(xImage, symbol1X, symbol1Y, 140, 140);

    const symbol2X = canvasWidth * 2 - 370 + 200 + 20;
    const symbol2Y = 60;
    ctx.drawImage(oImage, symbol2X, symbol2Y, 140, 140);
    
    ctx.drawImage(player1Image, padding * 2, 40, 200, 200);

    ctx.fillStyle = "#000000";
    ctx.font = "bold 40px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(player1.name, padding * 2, 280); 
    
    ctx.drawImage(player2Image, canvasWidth * 2 - 370, 40, 200, 200);
   
    ctx.fillStyle = "#000000";
    ctx.font = "bold 40px sans-serif";
    ctx.textAlign = "right";
    const nameX = canvasWidth * 2 - 370 + 200;
    const nameY = 280;
    ctx.fillText(player2.name, nameX, nameY);
    
    ctx.drawImage(vsImage, (canvasWidth * 2) / 2 - 100, 40, 200, 200);

    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 3;
    const startX = padding * 1.2;
    const startY = headerHeight * 1.2;

    for (let i = 0; i <= gridSize; i++) {
        ctx.beginPath();
        ctx.moveTo(startX, startY + i * cellSize * 2);
        ctx.lineTo(startX + gridSize * cellSize * 2, startY + i * cellSize * 2);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(startX + i * cellSize * 2, startY);
        ctx.lineTo(startX + i * cellSize * 2, startY + gridSize * cellSize * 2);
        ctx.stroke();
    }

    ctx.fillStyle = "#000000";
    ctx.font = "bold 32px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    for (let i = 0; i < gridSize; i++) {
        ctx.fillText(String.fromCharCode(65 + i), startX + i * cellSize * 2 + cellSize, startY - 40);
        ctx.fillText(i + 1, startX - 40, startY + i * cellSize * 2 + cellSize);
    }

    const board = Array.from({
        length: gridSize
    }, () => Array(gridSize).fill(null));

    for (const data of gameData) {
        const [col,
            row,
            symbol] = data.split(':');
        const colIndex = col.charCodeAt(0) - 65;
        const rowIndex = parseInt(row) - 1;
        board[rowIndex][colIndex] = symbol;

        const x = startX + colIndex * cellSize * 2;
        const y = startY + rowIndex * cellSize * 2;

        if (symbol === 'X') {
            ctx.drawImage(xImage, x + 10, y + 10, cellSize * 1.8, cellSize * 1.8);
        } else if (symbol === 'O') {
            ctx.drawImage(oImage, x + 10, y + 10, cellSize * 1.8, cellSize * 1.8);
        }
    }

    function checkWin(symbol) {
        const directions = [{
            x: 1,
            y: 0
        },
            {
                x: 0,
                y: 1
            },
            {
                x: 1,
                y: 1
            },
            {
                x: 1,
                y: -1
            } 
        ];

        for (let row = 0; row < gridSize; row++) {
            for (let col = 0; col < gridSize; col++) {
                if (board[row][col] !== symbol) continue;

                for (const {
                    x, y
                } of directions) {
                    const line = [];
                    let r = row,
                    c = col;

                    for (let i = 0; i < 5; i++) {
                        if (r < 0 || c < 0 || r >= gridSize || c >= gridSize || board[r][c] !== symbol) break;
                        line.push({
                            row: r, col: c
                        });
                        r += y;
                        c += x;
                    }

                    if (line.length === 5){ isWin = {
                        symbol
                    };return line;}
                }
            }
        }

        return null;
    }

    const winningLine = checkWin('X') || checkWin('O');
    if (winningLine) {
        ctx.strokeStyle = "#FF8D00";
        ctx.lineWidth = 14;
        ctx.globalAlpha = 0.7;
        const start = winningLine[0];
        const end = winningLine[4];

        const startXPos = startX + start.col * cellSize * 2 + cellSize;
        const startYPos = startY + start.row * cellSize * 2 + cellSize;

        const endXPos = startX + end.col * cellSize * 2 + cellSize;
        const endYPos = startY + end.row * cellSize * 2 + cellSize;

        ctx.beginPath();
        ctx.moveTo(startXPos, startYPos);
        ctx.lineTo(endXPos, endYPos);
        ctx.stroke();
    }

    const s = canvas.createPNGStream();
    s.path = "eh.png";
    return {s, isWin};
}

module.exports = {
    config: {
        name: "caro",
        aliases: ["كارو"],
        version: "1.0-Beta",
        author: "Allou Mohamed",
        countDown: 5,
        role: 0,
        description: {
          en: "caro game.",
          ar: "كارو لعبة زي اكس او"
        },
        category: "game",
        guide: {
            ar: "{pn} رد على شخص أو تاغ",
            en: "{pn} reply or tag."
        }
    },
    storGame: [],
    onStart: async function ({
        event, commandName, message, usersData, args
    }) {
        if (args[0] == "end") {
            const gameIndex = this.storGame.findIndex(prop => prop.id == event.threadID);
            if (gameIndex === -1) {
                return message.reply("No ongoing game to end.");
            }

            this.storGame.splice(gameIndex, 1);
            return message.reply("The game has been successfully ended.");
        }
        if (this.storGame.find(prop => prop.id == event.threadID)) return message.reply("Wait to current game ends.");
        const data = {
            id: event.threadID,
            player1: {
                avatarPng: await usersData.getAvatarUrl(event.senderID),
                id: event.senderID,
                name: await usersData.getName(event.senderID),
                symbol: "X"
            }
        };
        const player2 = Object.keys(event.mentions || {}).length > 0 ? Object.keys(event.mentions)[0]: event?.messageReply?.senderID || null;
        if (!player2) return message.reply("Please Mention or reply to someone.");
        const P2N = await usersData.getName(player2);
        data["player2"] = {
            avatarPng: await usersData.getAvatarUrl(player2),
            id: player2,
            name: P2N,
            symbol: "O"
        };
        message.reply("🆔 @"+player2+" React to this message to accept the challenge.\n🏆 The winner get 1000 $.", (err, info) => {
            if (err) return message.reply(err.message);
            global.GoatBot.onReaction.set(info.messageID, {
                commandName,
                allowed: player2,
                data,
                mid: info.messageID
            })
        });
    },
    
    onReaction: async function({
        event,
        message,
        Reaction,
        commandName
    }) {
        const {
            mid, allowed, data
        } = Reaction;
        if (event.userID != allowed) return;
        this.storGame.push(data);
        message.unsend(mid);
        const {s} = await drawCaroBoard(data.player1, data.player2);
        message.reply({
            body: "Reply by the cell code [X|N] example: A1, B5", attachment: s
        }, (err, info) => {
            if (err) return message.reply(err.message);
            global.GoatBot.onReply.set(info.messageID, {
                commandName,
                data,
                mid: info.messageID
            })
        });
    },
    
    onReply: async function ({
    message,
    args,
    event,
    commandName,
    usersData,
    Reply
}) {
    const input = args[0];
    const { mid, data } = Reply;
    if (!input || !/^[A-L](1[0-2]|[1-9])$/i.test(input.toUpperCase())) {
        return message.reply("Invalid input. Please provide a valid cell code (e.g., A1, B5).");
    }

    const col = input.charAt(0).toUpperCase();
    const row = parseInt(input.slice(1));
    const colIndex = col.charCodeAt(0) - 65;
    const rowIndex = row - 1;
  
    const { player1, player2, id, gameData = [] } = data;
    const lastMove = gameData[gameData.length - 1];
    const lastPlayerSymbol = lastMove ? lastMove.split(':')[2] : null;
    const currentPlayer = lastPlayerSymbol === player1.symbol ? player2 : player1;
    const symbol = currentPlayer.symbol;

    if (gameData.some(cell => {
    const [c, r] = cell.split(':');
    return c === col && parseInt(r) === row; })) {
    return message.reaction("❌", event.messageID);
    }
    if (currentPlayer.id !== event.senderID) {
        return message.reaction("❌", event.messageID);
        //return message.reply(`It's not your turn, ${await usersData.getName(event.senderID)}. Wait for your opponent.`);
    }
    gameData.push(`${col}:${row}:${symbol}`);

    const { s, isWin } = await drawCaroBoard(player1, player2, gameData);

    if (isWin) {
        await usersData.addMoney(currentPlayer.id, 1000);
        this.storGame = this.storGame.filter(game => game.id !== id);
        return message.reply({
            body: `🎉 ${currentPlayer.name} has won the game! 🏆 reward added to you 💲.`,
            attachment: s
        });
    }

    if (gameData.length === gridSize * gridSize) {
        this.storGame = this.storGame.filter(game => game.id !== id);
        return message.reply({
            body: "It's a draw! No one wins. 🤝",
            attachment: s
        });
    }

    const nextPlayer = currentPlayer.id === player1.id ? player2 : player1;
    message.reply({
        body: `${nextPlayer.name}, it's your turn!\n\n${gameData.join(",")}`,
        attachment: s
    }, (err, info) => {
        if (err) return message.reply(err.message);
        global.GoatBot.onReply.set(info.messageID, {
            commandName,
            data: {
                ...data,
                gameData
            },
            mid: info.messageID
        });
    });
  }
};
