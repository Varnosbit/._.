const axios = require('axios');
const cheerio = require('cheerio');
const { createCanvas, loadImage } = require('canvas');

async function scrapeData() {
  try {
    const response = await axios.get('https://animecountdown.com/trending', {
      headers: {
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'upgrade-insecure-requests': '1',
      },
      referrerPolicy: 'strict-origin-when-cross-origin',
    });

    const $ = cheerio.load(response.data);
    const list = [];
    $('a.countdown-content-trending-item').each((index, element) => {
      const title = $(element).find('countdown-content-trending-item-title').text();
      const episode = $(element).find('countdown-content-trending-item-desc').text();
      const countSecond = parseInt($(element).find('countdown-content-trending-item-countdown').data('time'));
      if (countSecond >= 0) {
        const days = Math.floor(countSecond / (60 * 60 * 24));
        const hours = Math.floor((countSecond % (60 * 60 * 24)) / (60 * 60));
        const minutes = Math.floor((countSecond % (60 * 60)) / 60);
        const seconds = countSecond % 60;

        const countDown = { days, hours, minutes, seconds };
        const image = $(element).css('--poster').replace(/url\('(.+)'\)/, 'https:$1');
        const dataInfo = {
          title,
          episode,
          countDown,
          image,
        };

        list.push(dataInfo);
      }
    });

    return list;
  } catch (error) {
    throw new Error(error.message);
  }
}

async function createAnimeCountdownCanvas(animeList, pageNumber = 1) {
  const canvas = createCanvas(800, 1200);
  const ctx = canvas.getContext('2d');
  
  // Background
  const gradient = ctx.createLinearGradient(0, 0, 0, 1200);
  gradient.addColorStop(0, '#1a1a2e');
  gradient.addColorStop(1, '#16213e');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 800, 1200);

  // Header
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 32px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Trending Anime Countdown', 400, 50);
  
  ctx.font = '18px sans-serif';
  ctx.fillStyle = '#cccccc';
  ctx.fillText(`Page ${pageNumber} - Found ${animeList.length} trending anime`, 400, 80);

  // Grid layout (3x3)
  const itemsPerRow = 3;
  const itemWidth = 240;
  const itemHeight = 320;
  const startX = 18;
  const startY = 120;
  const spacing = 20;

  for (let i = 0; i < Math.min(9, animeList.length); i++) {
    const anime = animeList[i];
    const row = Math.floor(i / itemsPerRow);
    const col = i % itemsPerRow;
    
    const x = startX + col * (itemWidth + spacing);
    const y = startY + row * (itemHeight + spacing);

    try {
      // Load and draw anime poster
      const image = await loadImage(anime.image).catch(() => null);
      
      if (image) {
        // Draw rounded rectangle background
        ctx.fillStyle = '#2d3748';
        roundRect(ctx, x, y, itemWidth, itemHeight, 15);
        ctx.fill();

        // Draw image with rounded corners and proper aspect ratio
        ctx.save();
        roundRect(ctx, x, y, itemWidth, itemHeight * 0.7, 15);
        ctx.clip();
        
        // Calculate aspect ratio and fit the image
        const imageAspectRatio = image.width / image.height;
        const containerAspectRatio = itemWidth / (itemHeight * 0.7);
        
        let drawWidth, drawHeight, drawX, drawY;
        
        if (imageAspectRatio > containerAspectRatio) {
          // Image is wider than container - fit by height
          drawHeight = itemHeight * 0.7;
          drawWidth = drawHeight * imageAspectRatio;
          drawX = x - (drawWidth - itemWidth) / 2;
          drawY = y;
        } else {
          // Image is taller than container - fit by width
          drawWidth = itemWidth;
          drawHeight = drawWidth / imageAspectRatio;
          drawX = x;
          drawY = y - (drawHeight - itemHeight * 0.7) / 2;
        }
        
        ctx.drawImage(image, drawX, drawY, drawWidth, drawHeight);
        ctx.restore();
      } else {
        // Fallback rectangle if image fails to load
        ctx.fillStyle = '#4a5568';
        roundRect(ctx, x, y, itemWidth, itemHeight, 15);
        ctx.fill();
      }

      // Dark overlay for text readability
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      roundRect(ctx, x, y + itemHeight * 0.55, itemWidth, itemHeight * 0.45, 0);
      ctx.fill();

      // Anime title
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'center';
      const titleY = y + itemHeight * 0.65;
      wrapText(ctx, anime.title, x + itemWidth/2, titleY, itemWidth - 20, 18);

      // Episode info
      ctx.fillStyle = '#ffd700';
      ctx.font = '14px sans-serif';
      ctx.fillText(anime.episode, x + itemWidth/2, titleY + 25);

      // Countdown display
      const countdown = anime.countDown;
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px monospace';
      ctx.textAlign = 'center';
      
      // Calculate positions for centered layout
      const countdownY = y + itemHeight - 60;
      const labelY = y + itemHeight - 45;
      const col1X = x + itemWidth * 0.125; // 1/8 of width
      const col2X = x + itemWidth * 0.375; // 3/8 of width
      const col3X = x + itemWidth * 0.625; // 5/8 of width
      const col4X = x + itemWidth * 0.875; // 7/8 of width
      
      // Days
      ctx.fillText(countdown.days.toString(), col1X, countdownY);
      ctx.font = '12px sans-serif';
      ctx.fillStyle = '#cccccc';
      ctx.fillText('DAYS', col1X, labelY);

      // Hours
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px monospace';
      ctx.fillText(countdown.hours.toString(), col2X, countdownY);
      ctx.font = '12px sans-serif';
      ctx.fillStyle = '#cccccc';
      ctx.fillText('HOURS', col2X, labelY);

      // Minutes
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px monospace';
      ctx.fillText(countdown.minutes.toString(), col3X, countdownY);
      ctx.font = '12px sans-serif';
      ctx.fillStyle = '#cccccc';
      ctx.fillText('MINS', col3X, labelY);

      // Seconds
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px monospace';
      ctx.fillText(countdown.seconds.toString(), col4X, countdownY);
      ctx.font = '12px sans-serif';
      ctx.fillStyle = '#cccccc';
      ctx.fillText('SECS', col4X, labelY);

    } catch (error) {
      console.error(`Error processing anime ${anime.title}:`, error);
      
      // Fallback display
      ctx.fillStyle = '#4a5568';
      roundRect(ctx, x, y, itemWidth, itemHeight, 15);
      ctx.fill();
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '16px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Image failed to load', x + itemWidth/2, y + itemHeight/2);
    }
  }

  // Footer
  ctx.fillStyle = '#666666';
  ctx.font = '14px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Anime Countdown helps discover what and when to watch next', 400, 1150);
  ctx.fillText('Generated by Tanvir', 400, 1180);

  return canvas;
}

function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(' ');
  let line = '';
  let testLine = '';
  const lines = [];

  for (let n = 0; n < words.length; n++) {
    testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;
    
    if (testWidth > maxWidth && n > 0) {
      lines.push(line);
      line = words[n] + ' ';
    } else {
      line = testLine;
    }
  }
  lines.push(line);

  // Only show first 2 lines to prevent overflow
  const maxLines = 2;
  for (let i = 0; i < Math.min(lines.length, maxLines); i++) {
    let lineText = lines[i];
    if (i === maxLines - 1 && lines.length > maxLines) {
      lineText = lineText.substring(0, lineText.length - 3) + '...';
    }
    ctx.fillText(lineText, x, y + (i * lineHeight));
  }
}

module.exports = {
  config: {
    name: "cd",
    version: "2.0",
    author: "Tanvir 💀🔥",
    shortDescription: "Get a visual countdown of trending anime",
    category: "anime",
    guide: "{pn} [page]",
  },
  onStart: async function ({ event, message, args, commandName }) {
    try {
      const pageNumber = args[0] ? parseInt(args[0]) : 1;
      const animeList = await scrapeData();
      const itemsPerPage = 9;

      const totalAnimeItems = animeList.length;
      const totalPages = Math.ceil(totalAnimeItems / itemsPerPage);

      if (pageNumber > totalPages || pageNumber < 1) {
        message.reply(`Invalid page number. Available pages: 1-${totalPages}`);
        return;
      }

      const startSliceIndex = (pageNumber - 1) * itemsPerPage;
      const endSliceIndex = startSliceIndex + itemsPerPage;
      const selectedAnimeList = animeList.slice(startSliceIndex, endSliceIndex);

      if (selectedAnimeList.length === 0) {
        message.reply("No anime found on this page.");
        return;
      }

      //message.reply(">> Generating anime countdown canvas...");

      const canvas = await createAnimeCountdownCanvas(selectedAnimeList, pageNumber);
      const stream = canvas.createPNGStream();
      stream.path = "anime_countdown.png";
      
      message.reply({
        //body: `>> Trending Anime Countdown - Page ${pageNumber}/${totalPages}\n\nShowing ${selectedAnimeList.length} anime out of ${totalAnimeItems} total trending anime.`,
        attachment: stream
      });

    } catch (error) {
      console.error('Error:', error);
      message.reply(`[!] An error occurred: ${error.message}`);
    }
  },
};
