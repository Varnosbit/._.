const base = "https://raw.githubusercontent.com/Aslam-Naseer/memory-card/17e507e37f1ebe0359f56d01f62419f989c12179/src/images/Aliens/";
const Aliens = [
    "AlienX",
    "Ampfibian",
    "Arctiguana",
    "Armodrillo",
    "Atomix",
    "BallWeevil",
    "Bigchill",
    "Blitzwolfer",
    "Bloxx",
    "Brainstorm",
    "Bullfrag",
    "Buzzshock",
    "Cannonbolt",
    "Chamalien",
    "Chromastone",
    "Clockwork",
    "Crashhopper",
    "Diamondhead",
    "Ditto",
    "Eatle",
    "EchoEcho",
    "EyeGuy",
    "Fasttrack",
    "Feedback",
    "FourArms",
    "Frankenstrike",
    "Ghostfreak",
    "Goop",
    "Gravattack",
    "Graymatter",
    "Heatblast",
    "Humangousaur",
    "Jetray",
    "Juryrigg",
    "KickenHawk",
    "Lodestar",
    "NRG",
    "Nanomech",
    "PeskyDust",
    "Rath",
    "Ripjaws",
    "Shocksquatch",
    "SnareOh",
    "Spidermonkey",
    "Stinkfly",
    "Swampfire",
    "Terraspin",
    "Toepick",
    "Upchuck",
    "Upgrade",
    "WaterHazard",
    "Waybig",
    "Whampire",
    "Wildmutt",
    "Wildvine",
    "XLR8"
];

exports.config = {
  name: "omnitrex",
  aliases: [
    "omnibot"
  ],
  role: 0,
  description: "Alien Collecting Game.",
  guide: {
    syntax: "> omnibot <on/off>",
    params: "Action",
    usage: "Required"
  },
  countDown: 5,
  category: "game",
  hide: false,
  author: "Allou Mohamed",
  version: "2.0.2",
  price: "Free"
};

exports.onStart = async function ({ message, threadsData, role, args, event }) {
    const action = (args[0] || "")?.trim()?.toLowerCase();

    if (!action) {
        return message.reply(
            "👻 | نظام الأومنيبوت:\n" +
            "يرسل البوت صورة لفضائي عشوائي من بن تن، ويجب أن ترد على الصورة باسم الفضائي بالإنجليزية لتحصل عليه.\n" +
            "💰 يمكنك بيع الفضائي لاحقًا مقابل نقود.\n\n" +
            "✏️ استخدم:\n- `on` أو `تشغيل` لتفعيل النظام\n- `off` أو `إيقاف` لإيقافه"
        );
    }

    switch (action) {
        case "on":
        case "تشغيل":
            await threadsData.set(event.threadID, true, "data.omnibot.run");
            await threadsData.set(event.threadID, 0, "data.omnibot.counter");
            return message.reply("👻 تم تشغيل اللعبة.");
        
        case "off":
        case "ايقاف":
        case "إيقاف":
            await threadsData.set(event.threadID, false, "data.omnibot.run");
            return message.reply("👻 تم إيقاف اللعبة.");
        
        case "reset":
        case "إعادة":
            await threadsData.set(event.threadID, [], "data.omnibot.taken");
            await threadsData.set(event.threadID, 0, "data.omnibot.counter");
            return message.reply("✅ تم إعادة تعيين قائمة الفضائيين!");
        
        default:
            return message.reply("👻 إستعمل on أو off.");
    }
};

exports.onReply = async function({ usersData, threadsData, message, args, event, Reply }) {
    const { answer, data, messageID } = Reply;
    const { tiD, taken } = data;
    const userAnswer = args.join(" ")?.trim()?.toLowerCase();

    if (userAnswer === answer.toLowerCase()) {
        message.unsend(Reply.messageID);
        message.reaction("✅", event.messageID);
        const senderID = event.senderID;
        let userAliens = await usersData.get(senderID, "data.omnitrex", []);
        
        userAliens.push(answer);
        await usersData.set(senderID, userAliens, "data.omnitrex");
        await message.reply(`%bd${answer}% added to your omnidex.`);

        const newTaken = [...taken, answer];
        await threadsData.set(tiD, newTaken, "data.omnibot.taken");
        global.YamiBot.onReply.delete(Reply.messageID);
    } else {
        await message.reply("%bdWrong% answer try again");
    }
};

exports.onChat = async function ({ message, threadsData, role, args, event, commandName }) {
    const tiD = event.threadID;
    const uiD = event.senderID;

    const isOn = await threadsData.get(tiD, "data.omnibot.run", true);
    if (!isOn) return;

    let threadCounter = await threadsData.get(tiD, "data.omnibot.counter", 0);
    threadCounter++;

    if (threadCounter >= 30) {
        threadCounter = 0;

        let taken = await threadsData.get(tiD, "data.omnibot.taken", []);
        const remainingAliens = Aliens.filter(name => !taken.includes(name));

        if (remainingAliens.length === 0) {
            await threadsData.set(tiD, false, "data.omnibot.run");
            return message.reply("👻 تم إيقاف لعبة جمع الفضائيين لأن المجموعة جمعت كل الـ " + Aliens.length + " فضائي.");
        }

        // Wait 15 seconds before sending the alien
        setTimeout(async () => {
            const randomName = remainingAliens[Math.floor(Math.random() * remainingAliens.length)];
            const imageUrl = `${base}${randomName}.png`;

            const info = await message.send({
                body: "👻 A new %bdAlien% appeared. %bdReply% by it's name to get it!",
                attachment: await utils.getStreamFromUrl(imageUrl)
            });

            if (!info?.messageID) return message.reply("👻 %bdError%: No Info messageID.");

            global.YamiBot.onReply.set(info.messageID, {
                commandName,
                answer: randomName,
                data: { tiD, taken },
                messageID: info.messageID
            });
        }, 15000); // 15 seconds
    }

    await threadsData.set(tiD, threadCounter, "data.omnibot.counter");
};