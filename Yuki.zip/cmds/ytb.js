const axios = require("axios");
class YouTubeDownloader {
  constructor() {
    this.baseURL = "https://www.clipto.com";
    this.headers = {
      accept: "application/json, text/plain, */*",
      "accept-language": "id-ID,id;q=0.9",
      "content-type": "application/json",
      origin: "https://www.clipto.com",
      referer: "https://www.clipto.com/id/media-downloader/youtube-downloader",
      "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36"
    };
    this.csrfToken = null;
  }
  async getCsrfToken() {
    try {
      const {
        data
      } = await axios.get(`${this.baseURL}/api/csrf`, {
        headers: this.headers
      });
      this.csrfToken = data.csrfToken;
      console.log("✓ CSRF token obtained");
      return this.csrfToken;
    } catch (error) {
      console.log("✗ CSRF token failed:", error.message);
      throw error;
    }
  }
  async getVideoInfo(url) {
    try {
      if (!this.csrfToken) await this.getCsrfToken();
      const {
        data
      } = await axios.post(`${this.baseURL}/api/youtube`, {
        url: url
      }, {
        headers: {
          ...this.headers,
          cookie: `XSRF-TOKEN=${this.csrfToken}`
        }
      });
      console.log("✓ Video info retrieved:", data.title);
      return data;
    } catch (error) {
      console.log("✗ Video info failed:", error.message);
      throw error;
    }
  }
  async addVideoMergeTask(youtubeURL, height = 720) {
    try {
      if (!this.csrfToken) await this.getCsrfToken();
      const {
        data
      } = await axios.post(`${this.baseURL}/clipto-api/asrtask/addVideoMerge`, {
        youtubeURL: youtubeURL,
        height: height,
        isMobile: true
      }, {
        headers: {
          ...this.headers,
          cookie: `XSRF-TOKEN=${this.csrfToken};`
        }
      });
      console.log("✓ Merge task created:", data.data.taskID);
      return data;
    } catch (error) {
      console.log("✗ Merge task failed:", error.message);
      throw error;
    }
  }
  async getVideoMergeTask(taskIDs) {
    try {
      const {
        data
      } = await axios.post(`${this.baseURL}/clipto-api/asrtask/getVideoMerge`, {
        taskIDs: taskIDs
      }, {
        headers: {
          ...this.headers,
          cookie: `XSRF-TOKEN=${this.csrfToken};`
        }
      });
      return data;
    } catch (error) {
      console.log("✗ Task check failed:", error.message);
      throw error;
    }
  }
  async pollTaskUntilComplete(taskID) {
    try {
      console.log("⏳ Polling task...");
      let attempts = 0;
      while (true) {
        const result = await this.getVideoMergeTask([taskID]);
        if (result.data?.tasks?.[0]) {
          const task = result.data.tasks[0];
          if (task.status === 2 && task.videoMergeURL) {
            if (task.videoMergeURL.startsWith("//")) {
              task.videoMergeURL = `https:${task.videoMergeURL}`;
            }
            console.log("✓ Task completed");
            return task;
          }
        }
        attempts++;
        console.log(`⏳ Attempt ${attempts}...`);
        if (attempts > 30) throw new Error("Task timeout");
        await new Promise(resolve => setTimeout(resolve, 2e3));
      }
    } catch (error) {
      console.log("✗ Polling failed:", error.message);
      throw error;
    }
  }
  _extractResolution(formatString) {
    if (!formatString) return null;
    const match = formatString.toLowerCase().match(/(\d+)(?:p)?/);
    return match ? parseInt(match[1], 10) : null;
  }
  getQualityHeight(format, medias) {
    if (!medias) return null;
    const lowerCaseFormat = format.toLowerCase();
    const targetResolution = this._extractResolution(format);
    const media = medias.find(m => {
      if (m.label?.toLowerCase() === lowerCaseFormat || m.quality?.toLowerCase() === lowerCaseFormat) {
        return true;
      }
      if (targetResolution !== null) {
        const mediaResolution = this._extractResolution(m.label || m.quality);
        if (mediaResolution !== null && mediaResolution === targetResolution) {
          return true;
        }
      }
      return false;
    });
    return media?.height || null;
  }
  async download({
    url,
    format = "720p",
    ...rest
  }) {
    try {
      console.log(`🚀 Starting download: ${format}`);
      const videoInfo = await this.getVideoInfo(url);
      const height = this.getQualityHeight(format, videoInfo.medias);
      if (height === null) {
        const availableFormats = videoInfo.medias.filter(m => m.label).map(m => m.label);
        let errorMessage = `Format "${format}" tidak ditemukan.`;
        if (availableFormats.length > 0) {
          errorMessage += ` Format yang tersedia: ${availableFormats.join(", ")}`;
        } else {
          errorMessage += ` Tidak ada format yang tersedia untuk URL ini.`;
        }
        return {
          success: false,
          error: errorMessage,
          ...rest
        };
      }
      const mergeTask = await this.addVideoMergeTask(url, height);
      if (mergeTask.head.code !== 0) throw new Error(mergeTask.head.msg);
      const downloadUrl = await this.pollTaskUntilComplete(mergeTask.data.taskID);
      console.log("✅ Download ready");
      return {
        ...videoInfo,
        ...downloadUrl,
        ...rest
      };
    } catch (error) {
      console.log("❌ Download failed:", error.message);
      return {
        success: false,
        error: error.message,
        ...rest
      };
    }
  }
}

  /*
  //res
  {
  success: true,
  url: 'https://www.youtube.com/shorts/U5_cfVguyVw',
  source: 'youtube',
  title: '',
  author: '',
  thumbnail: '',
  duration: 50,
  medias: [
    {
      formatId: 18,
      label: 'mp4 (360p)',
      type: 'video',
      ext: 'mp4',
      quality: 'mp4 (360p)',
      width: 360,
      height: 640,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=18&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5RSqzElqEjOmC0VFhUI2rnT1aCrgQN_OjFLNBGmqo1hZriOZE_fkZh-pQys61ocqsbtPwRKiQxF&spc=6b0G_IFO1r9DuBFcOswL&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=3119276&ratebypass=yes&dur=50.247&lmt=1761048097054286&mt=1761941622&fvip=3&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=6300224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cratebypass%2Cdur%2Clmt&sig=AJfQdSswRgIhAPKEuf7_sr1K9aDrnAXI0YY2o86D8GRsiZVjslftPZqEAiEAtV7SVYM_dtRbotWyLaVeYJvCoK5Qh6OaeL6xd_e80Zg%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 497760,
      fps: 30,
      audioQuality: 'AUDIO_QUALITY_LOW',
      audioSampleRate: '22050',
      mimeType: 'video/mp4; codecs="avc1.42001E, mp4a.40.2"',
      duration: 0,
      is_audio: true,
      extension: 'mp4'
    },
    {
      formatId: 299,
      label: 'mp4 (1080p60)',
      type: 'video',
      ext: 'mp4',
      quality: 'mp4 (1080p60)',
      width: 1080,
      height: 1920,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=299&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=30393352&dur=50.133&lmt=1761048097381976&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIgUCGIREXb3S2trcoLbhWRCnGnGb8oMrl3dw41s1XO2WQCIQCphL6RPeSa0Dmrj31apTMe0p_O73TUIKtlQtadR4qs6Q%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 6009608,
      fps: 60,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/mp4; codecs="avc1.64002a"',
      duration: 0,
      extension: 'mp4'
    },
    {
      formatId: 303,
      label: 'webm (1080p60)',
      type: 'video',
      ext: 'webm',
      quality: 'webm (1080p60)',
      width: 1080,
      height: 1920,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=303&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fwebm&rqh=1&gir=yes&clen=22640071&dur=50.133&lmt=1761048097226754&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIhAM2UkpUZMYRO0PmHjhPXNjLfkZStzz3F-ebnLWEVe11-AiBzPowKi_dh0NGAOxDR0BkD29tRpQe2S2eQp4i_Uke3KA%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 3926837,
      fps: 60,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/webm; codecs="vp9"',
      duration: 0,
      extension: 'webm'
    },
    {
      formatId: 298,
      label: 'mp4 (720p60)',
      type: 'video',
      ext: 'mp4',
      quality: 'mp4 (720p60)',
      width: 720,
      height: 1280,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=298&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=14708492&dur=50.133&lmt=1761048096823303&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRAIgCrkrFkd7Ho6-1DexOtBGAn5-ROJqFo_bgWDhh0HdMKgCICFe4fu63RqzRXKVuaTj6mUHlfgkVxvS8ukJd1g7uQws&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 2718629,
      fps: 60,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/mp4; codecs="avc1.640020"',
      duration: 0,
      extension: 'mp4'
    },
    {
      formatId: 302,
      label: 'webm (720p60)',
      type: 'video',
      ext: 'webm',
      quality: 'webm (720p60)',
      width: 720,
      height: 1280,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=302&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fwebm&rqh=1&gir=yes&clen=14533965&dur=50.133&lmt=1761048097000371&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIhAPbtY6TPS1dexmZvnj_Y7AV3IKTOHrFGofJgs_Qpnk49AiBEU6OltfXI9_hF9Gbl2WbMpD180ur8nOKDwVvxqmGk1A%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 2536807,
      fps: 60,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/webm; codecs="vp9"',
      duration: 0,
      extension: 'webm'
    },
    {
      formatId: 779,
      label: 'webm (480p)',
      type: 'video',
      ext: 'webm',
      quality: 'webm (480p)',
      width: 608,
      height: 1080,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=779&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fwebm&rqh=1&gir=yes&clen=3068831&dur=50.133&lmt=1761048097295178&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIhAMgkU70mwN4WLnDI8sddjvuFdGkM6DIUVrW8oZRPfOF9AiAOrSD4C0QaSmp_Dm6H8EAhUUyV3fZf9j2306Ii2rNMQw%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 530775,
      fps: 30,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/webm; codecs="vp9"',
      duration: 0,
      extension: 'webm'
    },
    {
      formatId: 135,
      label: 'mp4 (480p)',
      type: 'video',
      ext: 'mp4',
      quality: 'mp4 (480p)',
      width: 480,
      height: 854,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=135&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=5468332&dur=50.133&lmt=1761048096870505&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRAIgPH8wRTqBPz_C5rwU6Zy_cB7ClXq1uQIjd4sr1uoEBecCIHpmteOTo-ppCjjkATEevqKFawU1_20AQpnDK-sV2nAE&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 1019786,
      fps: 30,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/mp4; codecs="avc1.4d401f"',
      duration: 0,
      extension: 'mp4'
    },
    {
      formatId: 134,
      label: 'mp4 (360p)',
      type: 'video',
      ext: 'mp4',
      quality: 'mp4 (360p)',
      width: 360,
      height: 640,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=134&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=2817572&dur=50.133&lmt=1761048096778401&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIhAKvUaD0AwPajehlJMq_rTjYKW8RfC8a1q3xiiQO7BOfVAiA2MxJmpIi4mM1i9qqkD3-WL3IQCFdRHO3v6vQB8k-uiA%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 535882,
      fps: 30,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/mp4; codecs="avc1.4d401e"',
      duration: 0,
      extension: 'mp4'
    },
    {
      formatId: 243,
      label: 'webm (360p)',
      type: 'video',
      ext: 'webm',
      quality: 'webm (360p)',
      width: 360,
      height: 640,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=243&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fwebm&rqh=1&gir=yes&clen=1082345&dur=50.133&lmt=1761048096910316&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRAIgNIDSVBTARcUMFkCmesUSWh_VBaiYaS6JR8HSwnTewKMCIAewuIwr0-7gSeESKv5UjCP22AFmzKXpU3OhqiOsmUIB&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 207074,
      fps: 30,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/webm; codecs="vp9"',
      duration: 0,
      extension: 'webm'
    },
    {
      formatId: 133,
      label: 'mp4 (240p)',
      type: 'video',
      ext: 'mp4',
      quality: 'mp4 (240p)',
      width: 240,
      height: 426,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=133&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=1473662&dur=50.133&lmt=1761048096828085&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRgIhALbIPkNKX4X1R5PDlUgPFFGeQeLwB0GJB22YHLaoVp-UAiEAyUMLFYh_5VqyH_PS_6dcDiMG62J_oSEGl6h_xUtT6yw%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 265249,
      fps: 30,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/mp4; codecs="avc1.4d4015"',
      duration: 0,
      extension: 'mp4'
    },
    {
      formatId: 242,
      label: 'webm (240p)',
      type: 'video',
      ext: 'webm',
      quality: 'webm (240p)',
      width: 240,
      height: 426,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=242&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fwebm&rqh=1&gir=yes&clen=565105&dur=50.133&lmt=1761048096938601&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRAIgKpuHSFMT4KrkBfC3HcUpDLy1CcthN9qoopBn0deRqb4CICe-Um_jhjZqp0W6-fYLiDJs_TgRmlaVX2zBmwVUbk3Z&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 109557,
      fps: 30,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/webm; codecs="vp9"',
      duration: 0,
      extension: 'webm'
    },
    {
      formatId: 160,
      label: 'mp4 (144p)',
      type: 'video',
      ext: 'mp4',
      quality: 'mp4 (144p)',
      width: 144,
      height: 256,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=160&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=641340&dur=50.133&lmt=1761048096636593&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=630A224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIgGR6IXaRVzFbMkdEUoc2FpJyruao1a6UuGQh0lBGGC5MCIQCK0cfCBWkYZOl151KuJE5CaVKjfGdPMmemuoam_H_GDw%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 120734,
      fps: 30,
      audioQuality: null,
      audioSampleRate: null,
      mimeType: 'video/mp4; codecs="avc1.4d400c"',
      duration: 0,
      extension: 'mp4'
    },
    {
      formatId: 139,
      label: 'm4a (50kb/s)',
      type: 'audio',
      ext: 'm4a',
      width: null,
      height: null,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=139&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=audio%2Fmp4&rqh=1&gir=yes&clen=307732&dur=50.247&lmt=1761048082489677&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=6308224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRAIgQDr5J-FU8FWeJIkhtlYH_8Q3YB2OBrIm5wMmYnmM3HUCIBMqVyvYuOC9MuyzJxiM4ZM-PeIpT2sANR-yVAc1M5S4&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 49898,
      fps: null,
      audioQuality: 'AUDIO_QUALITY_LOW',
      audioSampleRate: '22050',
      mimeType: 'audio/mp4; codecs="mp4a.40.5"',
      duration: 0,
      quality: 'm4a (50kb/s)',
      extension: 'm4a'
    },
    {
      formatId: 140,
      label: 'm4a (131kb/s)',
      type: 'audio',
      ext: 'm4a',
      width: null,
      height: null,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=140&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=audio%2Fmp4&rqh=1&gir=yes&clen=812948&dur=50.178&lmt=1761048082776604&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=6308224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRgIhAOrXNniiaruQabhpUJ4_WIOjPC6SpsFqMOmK0QG5sfA6AiEA9nwuuvvvnfv9htFPvGpZe5p1_Cic1sfMY2zuTwjhu1Y%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 130527,
      fps: null,
      audioQuality: 'AUDIO_QUALITY_MEDIUM',
      audioSampleRate: '44100',
      mimeType: 'audio/mp4; codecs="mp4a.40.2"',
      duration: 0,
      quality: 'm4a (131kb/s)',
      extension: 'm4a'
    },
    {
      formatId: 249,
      label: 'opus (67kb/s)',
      type: 'audio',
      ext: 'opus',
      width: null,
      height: null,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=249&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=audio%2Fwebm&rqh=1&gir=yes&clen=325395&dur=50.141&lmt=1761048089252616&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=6308224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRgIhALirvlFH_FrcsdFL8z6s2lMfMcVClTVff2rrgwnDqODWAiEAnc-_dp16HK3pg0Jcfx6LeHMyniVmJXB4Ur0BIg9FKsc%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 66914,
      fps: null,
      audioQuality: 'AUDIO_QUALITY_LOW',
      audioSampleRate: '48000',
      mimeType: 'audio/webm; codecs="opus"',
      duration: 0,
      quality: 'opus (67kb/s)',
      extension: 'opus'
    },
    {
      formatId: 249,
      label: 'opus (68kb/s)',
      type: 'audio',
      ext: 'opus',
      width: null,
      height: null,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=249&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&xtags=drc%3D1&mime=audio%2Fwebm&rqh=1&gir=yes&clen=326028&dur=50.141&lmt=1761048086561109&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=6308224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cxtags%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIhAMtVnynlbTZzEfonY0Nkszwmkc2Q_yxo5lIJVT04oeNGAiAlV18NW6HVXzOuoaRmqzQQpFjUyq5LK0XvttKvbdLTCQ%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 68114,
      fps: null,
      audioQuality: 'AUDIO_QUALITY_LOW',
      audioSampleRate: '48000',
      mimeType: 'audio/webm; codecs="opus"',
      duration: 0,
      quality: 'opus (68kb/s)',
      extension: 'opus'
    },
    {
      formatId: 251,
      label: 'opus (174kb/s)',
      type: 'audio',
      ext: 'opus',
      width: null,
      height: null,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=251&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&mime=audio%2Fwebm&rqh=1&gir=yes&clen=849147&dur=50.141&lmt=1761048089237934&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=6308224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRQIgcx4jkVhz-U1G8XbTpHgYBmvvK71SLRjJOqqcaBZ0mzwCIQDgC18HJenn5n6CW6OMi1dgMWhqKT_TH2oEBTNYVgEmuA%3D%3D&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 174342,
      fps: null,
      audioQuality: 'AUDIO_QUALITY_MEDIUM',
      audioSampleRate: '48000',
      mimeType: 'audio/webm; codecs="opus"',
      duration: 0,
      quality: 'opus (174kb/s)',
      extension: 'opus'
    },
    {
      formatId: 251,
      label: 'opus (177kb/s)',
      type: 'audio',
      ext: 'opus',
      width: null,
      height: null,
      url: 'https://redirector.googlevideo.com/videoplayback?expire=1761963731&ei=cxoFaYinC6DS6dsP8eKXmAo&ip=80.187.121.7&id=o-ACUZb4qVZ1ztHj-gdrfwzWS4TNYgGoCJ4Xs3LwUyErzG&itag=251&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1761942131%2C&mh=rJ&mm=31%2C29&mn=sn-h0jeenld%2Csn-h0jelne6&ms=au%2Crdu&mv=m&mvi=5&pl=26&rms=au%2Cau&initcwndbps=2397500&bui=AdEuB5T3fqgpHH0vjjbJqyH8NVLQM88midrKDuJasiXsvnj0HC-5am6BAAGuIK3O91IZ3Bv19GiwZmIr&spc=6b0G_PlPfr9L&vprv=1&svpuc=1&xtags=drc%3D1&mime=audio%2Fwebm&rqh=1&gir=yes&clen=849739&dur=50.141&lmt=1761048086618936&mt=1761941622&fvip=3&keepalive=yes&fexp=51552689%2C51565115%2C51565681%2C51580968&c=ANDROID&txp=6308224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cxtags%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AJfQdSswRAIgekgrPgwAN5DmBERIZGn9Tbucyy3mwnZimpN_PBaPCtMCIE-kjYjmnQ2FdJDX3yI1Cr06q9D0par9rcYQ0nne2L7W&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRAIgINV-IXWqbBhJu7HGfJCHUrb8vW0eADYZCtp11FVgaSICIAt82HNz_n5VFji1lACsEvvjlBO2Jedt0Tdmghlbs_rF&pot=MuoEuiVQ0lkVuqS6GzyE6Vhau3noXxsB7PgUxOPGiAxr0sUABX0qK5R4Z3QBzsoCrIsoqPwCH6hOCqWgvkSgVOjNddN1SvVt0iDaKXENWZojN8pnLEGXyMa1fSXh8Qkp8JytMXuowZm3Y6aboDFmUvIIohfdDfSbTuPJ4WkVI_eohjnj9ZGPNb2diAbsEEx2LqJiisg3MVHXt3D4vuA3moDbwCFiGK9WfxHqJ3toDvVF63A13mwV3fUhv6bzgYH-TsTj6b4la3U8fhRvazSsupb6d611oSN5AUha8S4MKoiV3It-iQ57V6XqNkxM9jeDnGEto4oTBlnxU8lxq9KHJi9X-4p50FIyG5PhnhdQO9_n_torPR5vqIhWJx4_Osn-uCC1xzThrRhLyXSJJV4cpSXrnqooSWitZVN-WWbrMWfIbISvnQhUYwcAzvgGuk8ctSxiTiLSgnV48M0C2ZAll_naO3a01JfLBnKyF8Fub4NX1dR1Mb6RlcAI_TVp9gUsEYCcpBr9NGas6-GT9uxaqaK8fgDv-ZBNPIiafJxYZUtcGqcRvOzWmcrOF_MDtgGQejlVHUWWO2Kqdi1H08kWjvTuhSH8eelbam8ylyZiDs6_vNY42zhGqo54_Cm6JfClE_oyyfTa4DvWe7ylXdJhAiMa-PbTF3eFEnpTo5-zA6cPywSSZEUqgD7nhbSHZ0yg9DDCz28opORMtTMUYD8e2I2G8yxbDEX9D8IRqNfzSlWnQn5Dnj7I7LNNAStR0pY-3xIIDaPV-hR6q6N8YSodbKTzMMa_R1kOg0eRmwYDAqMOpOfnsgVMtQhCl4If',
      bitrate: 176857,
      fps: null,
      audioQuality: 'AUDIO_QUALITY_MEDIUM',
      audioSampleRate: '48000',
      mimeType: 'audio/webm; codecs="opus"',
      duration: 0,
      quality: 'opus (177kb/s)',
      extension: 'opus'
    }
  ],
  type: 'multiple',
  error: false,
  time_end: 273,
  taskID: '387cdad557c04960',
  thirdTaskID: '',
  videoMergeURL: 'https://clipto-mergeav.s3.us-west-2.amazonaws.com/asr/audios/merged_videos/387cdad557c04960_7dea21cdc6154381b92ca54d7e7695ee.mp4?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAXZEFILD4E7Z4USHE%2F20251031%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20251031T205817Z&X-Amz-Expires=86400&X-Amz-SignedHeaders=host&x-id=GetObject&X-Amz-Signature=0d604479e19157d869a5c346e3a30aa52013d2dc49b5eb4e531e598dc36c2d27',
  status: 2,
  videoURL: 'https://www.youtube.com/watch?v=pspmBbbOHh8&list=PL2BbzlnzyhMlGTs2w9uoxy_P5tLBiNZaI&index=2',
  height: 360,
  format: '',
  formatID: 0,
  ext: '',
  progress: 0
}
*/
const yts = require("yt-search");
async function searchYouTube(query) {
  try {
    const results = await yts(query);
    const videos = results.videos.slice(0, 6);
    
    return videos.map(video => ({
      url: video.url,
      title: video.title,
      thumbnail: video.thumbnail,
      duration: video.timestamp,
      views: video.views.toLocaleString(),
      author: video.author.name,
      ago: video.ago,
      videoId: video.videoId
    }));
  } catch (error) {
    console.error("Search error:", error.message);
    return [];
  }
}

function parseDuration(duration) {
  if (typeof duration === 'number') return duration;
  const parts = String(duration).split(':').reverse();
  let seconds = 0;
  if (parts[0]) seconds += parseInt(parts[0]);
  if (parts[1]) seconds += parseInt(parts[1]) * 60;
  if (parts[2]) seconds += parseInt(parts[2]) * 3600;
  return seconds;
}

function formatDuration(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

exports.config = {
  name: 'ytb',
  description: 'Download YouTube videos as MP3 or MP4 or get video information',
  role: 0,
  category: 'Media',
  version: '1.5.6',
  guide: `Usage: {pn} [-a|-v|info] <url or search query>
Examples:
{pn} shape of you (defaults to audio)
{pn} -a shape of you (audio format)
{pn} -v despacito (video format)
{pn} info https://youtube.com/... (get video info)
{pn} info despacito (search and get info)

Note: Videos longer than 8 minutes won't be downloaded. Audio limit is 18 minutes.
Cooldown: 3 minutes between uses.`,
  countDown: 180
};

exports.onStart = async ({ message, args, event, commandName }) => {
  try {
    if (!args.length) {
      return message.reply("❌ Please provide a YouTube URL or search query.\nExample: ytb shape of you");
    }

    // Parse arguments
    let mode = 'audio'; // default
    let query = args.join(' ');
    
    if (args[0] === '-v') {
      mode = 'video';
      query = args.slice(1).join(' ');
    } else if (args[0] === '-a') {
      mode = 'audio';
      query = args.slice(1).join(' ');
    } else if (args[0] === 'info') {
      mode = 'info';
      query = args.slice(1).join(' ');
    }

    if (!query.trim()) {
      return message.reply("❌ Please provide a search query or URL after the flag.");
    }

    // Check if it's a URL or search query
    const isUrl = query.includes('youtube.com') || query.includes('youtu.be');
    
    if (!isUrl) {
      // Search query provided - show results for user to choose
      await message.reply("🔍 Searching YouTube...");
      
      const results = await searchYouTube(query);
      
      if (!results.length) {
        return message.reply("❌ No results found for your search query.");
      }

      let replyText = `🔍 Found ${results.length} results for "${query}":\n\n`;
      results.forEach((result, index) => {
        replyText += `━━━━━━━━━━━━━━━\n`;
        replyText += `${index + 1}. ${result.title}\n`;
        replyText += `👤 ${result.author}\n`;
        replyText += `⏱️ ${result.duration}\n`;
        replyText += `👁️ ${result.views} views • ${result.ago}\n`;
      });
      replyText += `━━━━━━━━━━━━━━━\n\n`;
      replyText += `📝 Reply with number (1-${results.length}) to download\n`;
      replyText += `💡 Mode: ${mode === 'audio' ? '🎵 Audio' : mode === 'video' ? '🎬 Video' : 'ℹ️ Info'}`;

      const thumbnails = results.map(r => r.thumbnail);
      const sentMessage = await message.stream(replyText, thumbnails);
      
      global.YamiBot.onReply.set(sentMessage.messageID, {
        commandName,
        ytbUrls: results.map(r => r.url),
        ytbTitles: results.map(r => r.title),
        mode,
        author: event.senderID
      });
    } else {
      // Direct URL provided - process immediately
      await message.reply("⏳ Processing your request...");
      
      const downloader = new YouTubeDownloader();
      const videoInfo = await downloader.getVideoInfo(query);
      
      if (mode === 'info') {
        const duration = formatDuration(videoInfo.duration);
        const formats = videoInfo.medias
          .filter(m => m.type === 'video' && m.label)
          .map(m => m.label)
          .slice(0, 5)
          .join(', ');
        
        return message.reply(
          `📹 Video Information:\n\n` +
          `Title: ${videoInfo.title}\n` +
          `Author: ${videoInfo.author}\n` +
          `Duration: ${duration}\n` +
          `Available formats: ${formats}\n` +
          `URL: ${query}`
        );
      }

      const durationSeconds = parseDuration(videoInfo.duration);
      const maxDuration = mode === 'audio' ? 1180 : 580;
      
      if (durationSeconds > maxDuration) {
        return message.reply(
          `❌ Video too long! Maximum duration:\n` +
          `- Audio: 18 minutes\n` +
          `- Video: 8 minutes\n\n` +
          `This video: ${formatDuration(durationSeconds)}`
        );
      }

      if (mode === 'video') {
        const format = durationSeconds > 120 ? "360p" : "720p";
        const result = await downloader.download({ url: query, format });
        
        if (result.success === false) {
          return message.reply(`❌ Download failed: ${result.error}`);
        }
        
        return message.stream(
          `✅ Here's your video (${format}):\n${result.title}`,
          result.medias[0].url
        );
      } else {
        // Audio mode
        const audioFormats = videoInfo.medias.filter(m => m.type === 'audio');
        const bestAudio = audioFormats.reduce((best, current) => 
          (current.bitrate > best.bitrate) ? current : best
        , audioFormats[0]);
        
        if (!bestAudio) {
          return message.reply("❌ No audio format available for this video.");
        }
        
        return message.stream(
          `🎵 Here's your audio (${bestAudio.quality}):\n${videoInfo.title}`,
          bestAudio.url
        );
      }
    }
  } catch (error) {
    console.error("Error in onStart:", error);
    return message.reply(`❌ An error occurred: ${error.message}`);
  }
};

exports.onReply = async ({ message, args, Reply, event, commandName }) => {
  try {
    const { ytbUrls, mode, author } = Reply;
    
    // Check if reply is from the same user
    if (event.senderID !== author) {
      return;
    }
    
    const userChoice = parseInt(args[0]);
    
    if (isNaN(userChoice) || userChoice < 1 || userChoice > ytbUrls.length) {
      return message.reply(`❌ Invalid choice. Please reply with a number between 1 and ${ytbUrls.length}.`);
    }
    
    const urlToDl = ytbUrls[userChoice - 1];
    
    await message.reply("⏳ Processing your request...");
    
    const downloader = new YouTubeDownloader();
    const videoInfo = await downloader.getVideoInfo(urlToDl);
    
    const durationSeconds = parseDuration(videoInfo.duration);
    const maxDuration = mode === 'audio' ? 1180 : 580;
    
    if (durationSeconds > maxDuration) {
      return message.reply(
        `❌ Video too long! Maximum duration:\n` +
        `- Audio: 18 minutes\n` +
        `- Video: 8 minutes\n\n` +
        `This video: ${formatDuration(durationSeconds)}`
      );
    }

    if (mode === 'video') {
      const format = durationSeconds > 120 ? "360p" : "720p";
      const result = await downloader.download({ url: urlToDl, format });
      
      if (result.success === false) {
        return message.reply(`❌ Download failed: ${result.error}`);
      }
      
      await message.stream(
        `✅ Here's your video (${format}):\n${result.title}`,
        result.medias[0].url
      );
    } else {
      // Audio mode
      const audioFormats = videoInfo.medias.filter(m => m.type === 'audio');
      const bestAudio = audioFormats.reduce((best, current) => 
        (current.bitrate > best.bitrate) ? current : best
      , audioFormats[0]);
      
      if (!bestAudio) {
        return message.reply("❌ No audio format available for this video.");
      }
      
      await message.stream(
        `🎵 Here's your audio (${bestAudio.quality}):\n${videoInfo.title}`,
        bestAudio.url
      );
    }
    
    // Clear the reply handler
    global.YamiBot.onReply.delete(Reply.messageID);
    
  } catch (error) {
    console.error("Error in onReply:", error);
    return message.reply(`❌ An error occurred: ${error.message}`);
  }
};