"use strict";

const allowedProperties = {
	attachment: true,
	url: false,
	sticker: false,
	emoji: false,
	emojiSize: false,
	body: true,
	mentions: false,
	location: false
};

const { send } = require("process");
var utils = require("../utils");
var log = require("npmlog");

function removeSpecialChar(inputString) { // remove char banned by facebook
	if (typeof inputString !== "string")
		return inputString;
	// Convert string to Buffer
	const buffer = Buffer.from(inputString, 'utf8');

	// Filter buffer start with ef b8 8f
	let filteredBuffer = Buffer.alloc(0);
	for (let i = 0; i < buffer.length; i++) {
		if (buffer[i] === 0xEF && buffer[i + 1] === 0xB8 && buffer[i + 2] === 0x8F) {
			i += 2; // Skip 3 bytes of buffer starting with ef b8 8f
		} else {
			filteredBuffer = Buffer.concat([filteredBuffer, buffer.slice(i, i + 1)]);
		}
	}

	// Convert filtered buffer to string
	const convertedString = filteredBuffer.toString('utf8');

	return convertedString;
}

module.exports = function(defaultFuncs, api, ctx) {

  async function uploadFile(attachments) {
    try {
      const uploads = attachments.map(attachment => {
        if (!utils.isReadableStream(attachment)) {
          throw new Error(`Attachment should be a readable stream, but got ${utils.getType(attachment)}`);
        }

        const form = {
          upload_1024: attachment,
          voice_clip: "true"
        };

        return defaultFuncs
          .postFormData(
            "https://upload.facebook.com/ajax/mercury/upload.php",
            ctx.jar,
            form,
            {}
          )
          .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
          .then(resData => {
            if (resData.error) {
              throw new Error(`Error uploading file: ${JSON.stringify(resData.error)}`);
            }
            return resData.payload.metadata[0];
          });
      });

      return await Promise.all(uploads);
    } catch (error) {
      log.error('File upload failed:', error);
      throw error;
    }
  }

  return async function sendMessage(msg, threadkey, callback, messageId) {
    ctx.wsReqNumber++;
    ctx.wsTaskNumber++;
    const reqID = ctx.wsReqNumber;
    const task_id = ctx.wsTaskNumber;
	  
function generatePayload(threadkey, sendType, text, attachmentFbids, messageId) {
  const x = {
    thread_id: threadkey,
    otid: utils.generateOfflineThreadingID(),
    source: 65537,
    send_type: sendType,
    sync_group: 1,
    mark_thread_read: 1,
    text: text,
    attachment_fbids: attachmentFbids || [],
    initiating_source: 1,
    skip_url_preview_gen: 0,
    text_has_links: 0,
    multitab_env: 0
  };
  if (messageId) {
    const replyMetadata = {
      reply_source_id: messageId,
      reply_source_type: 1,
      reply_type: 0,
      reply_source_attachment_id: null
    };

    x.reply_metadata = replyMetadata;
  }

  const returnPayload = {
    app_id: '2220391788200892',
    payload: JSON.stringify({
      epoch_id: parseInt(utils.generateOfflineThreadingID(), 10),
      tasks: [{
        failure_count: null,
        label: '46',
        payload: JSON.stringify(x),
        queue_name: threadkey,
        task_id: task_id,
      }],
      version_id: '6903494529735864',
      data_trace_id: null
    }),
    request_id: reqID,
    type: 3
  };

  return returnPayload;
}
	  
		if (
			!callback &&
			(utils.getType(threadkey) === "Function" ||
				utils.getType(threadkey) === "AsyncFunction")
		) {
			return threadkey({ error: "Pass a threadkey as a second argument." });
		}
		if (
			!messageId &&
			utils.getType(callback) === "String"
		) {
			messageId = callback;
			callback = function () { };
		} 
    
let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, friendList) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(friendList);
			};
		}

		const msgType = utils.getType(msg);
		const threadkeyType = utils.getType(threadkey);
		const messageIDType = utils.getType(messageId);

if (msgType !== "String" && msgType !== "Object") {
			return callback({
				error:
					"Message should be of type string or object and not " + msgType + "."
			});
		}

		// Changing this to accomodate an array of users
		if (
			threadkeyType !== "Number" &&
			threadkeyType !== "String"
		) {
			return callback({
				error:
					"threadkey should be of type number or string and not " +
					threadkeyType +
					"."
			});
		}

		if (messageId && messageIDType !== 'String') {
			return callback({
				error:
					"MessageID should be of type string and not " +
					threadkeyType +
					"."
			});
		}

		if (msgType === "String") {
			msg = { body: msg };
		}

		if (utils.getType(msg.body) === "String") {
			msg.body = removeSpecialChar(msg.body);
		}

		const disallowedProperties = Object.keys(msg).filter(
			prop => !allowedProperties[prop]
		);
		if (disallowedProperties.length > 0) {
			return callback({
				error: "Dissallowed props: `" + disallowedProperties.join(", ") + "`"
			});
		}

await sendContent(msg.body, msg.attachment, threadkey, messageId, callback);  
 async function sendContent(text = null, attachments = [], threadkey, messageId, callback) {

      const files = await uploadFile(attachments) || [];
      const attachmentFbids = files.map(file => file.fbid);
      const payload = generatePayload(threadkey, 3, text, attachmentFbids, messageId);
      ctx.mqttClient.publish('/ls_req', JSON.stringify(payload), { qos: 1, retain: false });
      const handleRes = function(topic, message, _packet) {
        if (topic === "/ls_resp") {
          let jsonMsg = JSON.parse(message.toString());
          require('fs').writeFileSync('jsonmsg.json', JSON.stringify(jsonMsg, null, 2));//fuk isai
          jsonMsg.payload = JSON.parse(jsonMsg.payload);
          if (jsonMsg.request_id != reqID) return;
          ctx.mqttClient.removeListener('message', handleRes);
          const messageID = jsonMsg.payload.step[1][2][2][1][3];
          const timestamp = Date.now();
          return callback(null, {
            task: "sendMessage",
            messageID,
            threadkey,
            timestamp
          });
        }
      };
      ctx.mqttClient.on('message', handleRes);
    }
      return returnPromise;
  };
};
