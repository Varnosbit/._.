if (!global.resend) global.resend = new Map();
const axios = require("axios");
const FormData = require("form-data");

module.exports = {
    config: {
        name: "resend",
        author: "allou Mohamed",
        description: "resend messages with enhanced storage and attachment handling",
        category: "box chat",
        role: 0
    },

    async uploadImage(buffer) {
        try {
            const formData = new FormData();
            formData.append("file", buffer, "attachment.png");

            const { data } = await axios.post("https://i.supa.codes/api/upload", formData, {
                headers: formData.getHeaders()
            });

            if (!data?.link) throw new Error("Upload failed");
            return data.link + data.ext;
        } catch (error) {
            console.error("Error uploading attachment:", error.message);
            throw new Error("Upload failed");
        }
    },

    // Helper function to format date as day_month_year
    formatDateKey(date = new Date()) {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        return `${day}_${month}_${year}`;
    },

    // Clean up old data beyond maxDaysToStore
    async cleanupOldData(globalData) {
        const maxDaysToStore = 2;
        const currentDate = new Date();
        
        try {

            const allData = await globalData.get("resend", "data", {});
            let hasChanges = false;
            
            for (const dayKey in allData) {
                if (dayKey && dayKey.includes('_')) {
                    const [day, month, year] = dayKey.split('_').map(Number);
                    if (day && month && year) {
                        const storedDate = new Date(year, month - 1, day);
                        const daysDiff = Math.floor((currentDate - storedDate) / (1000 * 60 * 60 * 24));
                        
                        if (daysDiff > maxDaysToStore) {
                            delete allData[dayKey];
                            hasChanges = true;
                            console.log(`Cleaned up old resend data for ${dayKey}`);
                        }
                    }
                }
            }
            
            // Save updated data if changes were made
            if (hasChanges) {
                await globalData.set("resend", allData, "data");
            }
            
            // Update last cleanup timestamp
            await globalData.set("resend", Date.now(), "lastCleanup");
            
        } catch (error) {
            console.error("Error cleaning up old data:", error);
        }
    },

    // Check if cleanup is needed (called on each command)
    async checkAndCleanup(globalData) {
        try {
            const lastCleanup = await globalData.get("resend", "lastCleanup", 0);
            const currentTime = Date.now();
            const oneDayMs = 24 * 60 * 60 * 1000;
            
            // Clean up if more than 1 day has passed since last cleanup
            if (currentTime - lastCleanup > oneDayMs) {
                await this.cleanupOldData(globalData);
            }
        } catch (error) {
            console.error("Error in checkAndCleanup:", error);
        }
    },

    onLoad: async function({ globalData }) {
        await this.cleanupOldData(globalData);
    },
    
    onStart: async function({ message, args, role, event, threadsData, usersData, globalData }) {
        // Check and cleanup old data on each command usage
        await this.checkAndCleanup(globalData);
        
        if (!args || args.length === 0) {
            return message.reply("📋 Usage:\n• resend on - Enable logging\n• resend off - Disable logging\n• resend list [page] - View unsent messages\n• resend clear - Clear today's logs\n• resend stats - Show statistics\n• resend cleanup - Force cleanup old data");
        }

        const action = args[0].toLowerCase();
        const currentDateKey = this.formatDateKey();

        switch (action) {
            case 'on':
                try {
                    await threadsData.set(event.threadID, true, "data.resend_logs");
                    message.reply("✅ Resend logging enabled for this group");
                } catch (error) {
                    message.reply("❌ Failed to enable resend logging");
                }
                break;
                
            case 'off':
                try {
                    await threadsData.set(event.threadID, false, "data.resend_logs");
                    message.reply("✅ Resend logging disabled for this group");
                } catch (error) {
                    message.reply("❌ Failed to disable resend logging");
                }
                break;
                
            case 'cleanup':
                try {
                    await this.cleanupOldData(globalData);
                    message.reply("🧹 Force cleanup completed! Old data removed.");
                } catch (error) {
                    message.reply("❌ Failed to cleanup old data");
                }
                break;
                
            case 'clear':
                try {
                    const allData = await globalData.get("resend", "data", {});
                    if (allData[currentDateKey] && allData[currentDateKey][event.threadID]) {
                        delete allData[currentDateKey][event.threadID];
                        await globalData.set("resend", allData, "data");
                        message.reply("🗑️ Cleared all unsent messages for this group today");
                    } else {
                        message.reply("📝 No unsent messages found for this group today");
                    }
                } catch (error) {
                    message.reply("❌ Failed to clear logs");
                }
                break;
                
            case 'list':
                const maxOnPage = 8;
                const page = Math.max(1, parseInt(args[1]) || 1);
                
                try {
                    const allData = await globalData.get("resend", "data", {});
                    const todayData = allData[currentDateKey] || {};
                    const threadMessages = todayData[event.threadID] || [];
                    
                    if (threadMessages.length === 0) {
                        return message.reply("📝 No unsent messages found for this group today");
                    }

                    // Sort messages by timestamp (newest first)
                    threadMessages.sort((a, b) => b.timestamps - a.timestamps);
                    
                    const totalPages = Math.ceil(threadMessages.length / maxOnPage);
                    const validPage = Math.min(page, totalPages);
                    
                    const start = (validPage - 1) * maxOnPage;
                    const end = Math.min(start + maxOnPage, threadMessages.length);
                    const messagesToShow = threadMessages.slice(start, end);

                    let replyText = `📋 Unsent Messages (${threadMessages.length} total)\n`;
                    replyText += `📅 Date: ${currentDateKey.replace(/_/g, '/')}\n\n`;
                    
                    for (let i = 0; i < messagesToShow.length; i++) {
                        const msg = messagesToShow[i];
                        const msgDate = new Date(msg.timestamps);
                        const timeStr = msgDate.toLocaleTimeString('en-US', { 
                            hour12: true,
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                        
                        replyText += `${start + i + 1}. `;
                        
                        if (msg.body && msg.body.trim()) {
                            const truncatedBody = msg.body.length > 100 ? 
                                msg.body.substring(0, 100) + "..." : msg.body;
                            replyText += `💬 "${truncatedBody}"\n`;
                        } else {
                            replyText += `📎 Attachments only\n`;
                        }
                        
                        if (msg.attachments && msg.attachments.length > 0) {
                            replyText += `   📎 ${msg.attachments.length} attachment(s)\n`;
                        }
                        
                        try {
                            const senderName = await usersData.getName(msg.senderID);
                            replyText += `   👤 ${senderName || msg.senderID}\n`;
                        } catch (error) {
                            replyText += `   👤 ${msg.senderID}\n`;
                        }
                        
                        replyText += `   🕐 ${timeStr}\n\n`;
                    }

                    // Enhanced pagination info
                    if (totalPages > 1) {
                        replyText += `📄 Page ${validPage}/${totalPages}`;
                        if (validPage < totalPages) {
                            replyText += ` • Next: resend list ${validPage + 1}`;
                        }
                        if (validPage > 1) {
                            replyText += ` • Prev: resend list ${validPage - 1}`;
                        }
                    }
                    
                    message.reply(replyText);
                } catch (error) {
                    console.error("Error listing messages:", error);
                    message.reply("❌ Failed to retrieve unsent messages");
                }
                break;
                
            case 'stats':
                try {
                    const allData = await globalData.get("resend", "data", {});
                    const todayData = allData[currentDateKey] || {};
                    const threadMessages = todayData[event.threadID] || [];
                    
                    if (threadMessages.length === 0) {
                        return message.reply("📊 No unsent messages recorded for this group today");
                    }
                    
                    const totalMessages = threadMessages.length;
                    const messagesWithText = threadMessages.filter(msg => msg.body && msg.body.trim()).length;
                    const messagesWithAttachments = threadMessages.filter(msg => msg.attachments && msg.attachments.length > 0).length;
                    
                    const uniqueSenders = new Set(threadMessages.map(msg => msg.senderID)).size;
                    
                    // Get total days with data
                    const totalDaysWithData = Object.keys(allData).filter(key => key.includes('_')).length;
                    
                    let statsText = `📊 Unsent Messages Stats\n\n`;
                    statsText += `📝 Today's messages: ${totalMessages}\n`;
                    statsText += `💬 With text: ${messagesWithText}\n`;
                    statsText += `📎 With attachments: ${messagesWithAttachments}\n`;
                    statsText += `👥 Unique senders today: ${uniqueSenders}\n`;
                    statsText += `📅 Days with data: ${totalDaysWithData}\n`;
                    statsText += `🗓️ Current date: ${currentDateKey.replace(/_/g, '/')}`;
                    
                    message.reply(statsText);
                } catch (error) {
                    message.reply("❌ Failed to retrieve statistics");
                }
                break;
                
            default:
                message.reply("❌ Invalid action. Use: resend [on|off|list|clear|stats|cleanup] [page]");
                break;
        }
    },
    
    onChat: async function({ event, threadsData, globalData, api }) {
        try {
      const data = await threadsData.get(event.threadID, "data.resend_logs");
            if (!data || data !== true) return;

            if (event.type === "message") {
                global.resend.set(event.messageID, event);
                
                if (global.resend.size > 150) {
                    const firstKey = global.resend.keys().next().value;
                    global.resend.delete(firstKey);
                }
            }

            if (event.type === "message_unsend") {
                const unsentMessage = global.resend.get(event.messageID);

                if (unsentMessage) {
                    const currentDateKey = this.formatDateKey();
                    
                    const allData = await globalData.get("resend", "data", {});
                    
                    if (!allData[currentDateKey]) {
                        allData[currentDateKey] = {};
                    }
                    
                    if (!allData[currentDateKey][unsentMessage.threadID]) {
                        allData[currentDateKey][unsentMessage.threadID] = [];
                    }

                    let attachmentsArray = [];
                    if (unsentMessage.attachments && unsentMessage.attachments.length > 0) {
                        for (const attachment of unsentMessage.attachments) {
                            try {
                                if (attachment.url) {
                                
                                    const response = await axios.get(attachment.url, {
                                        responseType: 'arraybuffer',
                                        timeout: 30000,
                                        headers: {
                                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                                        }
                                    });
                                    
                                    const buffer = Buffer.from(response.data);
                                    const permanentUrl = await this.uploadImage(buffer);
                                    attachmentsArray.push(permanentUrl);
                                } else {
                                    attachmentsArray.push(attachment.toString());
                                }
                            } catch (error) {
                                console.error('Error processing attachment:', error.message);
                                attachmentsArray.push(attachment.url || attachment.toString());
                            }
                        }
                    }

                    // Add to current day's data
                    allData[currentDateKey][unsentMessage.threadID].push({
                        body: unsentMessage.body || "",
                        attachments: attachmentsArray,
                        messageID: unsentMessage.messageID,
                        senderID: unsentMessage.senderID,
                        timestamps: Date.now()
                    });

                    // Save updated data
                    await globalData.set("resend", allData, "data");

                    // Clean up memory
                    global.resend.delete(event.messageID);
                    
                    // Optional: Auto-cleanup check (every 100 unsent messages)
                    if (Math.random() < 0.01) { // 1% chance per unsent message
                        await this.checkAndCleanup(globalData);
                    }
                }
            }
        } catch (error) {
            console.error('Error in resend atChat:', error);
        }
    }
};
