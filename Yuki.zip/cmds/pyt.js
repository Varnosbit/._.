const { spawn } = require("child_process");

async function runPython(code) {
  return new Promise((resolve, reject) => {
    const p = spawn("python3", ["-c", code]);
    let out = "";
    let err = "";
    p.stdout.on("data", d => out += d.toString());
    p.stderr.on("data", d => err += d.toString());
    p.on("close", c => {
      if (c === 0) resolve(out.trim());
      else resolve((out + "\n" + err).trim());
    });
    p.on("error", reject);
  });
}

exports.config = {
  name: "python",
  aliases: ["py"],
  description: "Execute Python code",
  role: 0,
  countDown: 5
};

exports.onStart = async ({ message, args }) => {
  const code = args.join(" ");
  if (!code) return message.send("No code provided.");
  try {
    const result = await runPython(code);
    message.send(result || "No output.");
  } catch {
    message.send("Execution error.");
  }
};