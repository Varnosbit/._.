module.exports = {
	config: {
		name: "rr",
		version: "1.5",
		author: "Allou Mohamed",
		countDown: 5,
		role: 0,
		shortDescription: {
			vi: "Thử vận may với trò chơi roulette Nga",
			en: "Test your luck in Russian roulette",
			ar: "اختبر حظك في الروليت الروسي"
		},
		description: {
			vi: "Một trò chơi sinh tồn với khẩu súng lục, liệu bạn có thể sống sót?",
			en: "A survival game with a revolver, can you make it?",
			ar: "لعبة بقاء بمسدس، هل يمكنك النجاة؟"
		},
		category: "games",
		guide: {
			vi: "{p}russianroulette",
			en: "{p}russianroulette",
			ar: "{p}russianroulette"
		}
	},

	langs: {
		vi: {
			click: "Vòng %1: 🔄 Click! Buồng đạn trống.",
			bang: "Vòng %1: 💥 BANG! Viên đạn đã khai hỏa.",
			win: "🎉 CHÚC MỪNG 🎉\n- Bạn đã sống sót qua tất cả các vòng và nhận phần thưởng!",
			lose: "🎯 TRÒ CHƠI KẾT THÚC 🎯\nTrạng thái: ❌ THUA CUỘC\n- Tiền, EXP và tiền gửi của bạn đã bị đặt lại (nợ vẫn giữ nguyên)."
		},
		en: {
			click: "Round %1: 🔄 Click! Chamber empty.",
			bang: "Round %1: 💥 BANG! The bullet fires.",
			win: "🎉 WINNER 🎉\n- You survived all rounds and earned a reward!",
			lose: "🎯 GAME OVER 🎯\nStatus: ❌ LOSER\n- Account money, EXP, and deposit have been reset (debt preserved)."
		},
		ar: {
			click: "الجولة %1: 🔄 طقة! الغرفة فارغة.",
			bang: "الجولة %1: 💥 بوم! الطلقة انطلقت.",
			win: "🎉 مبروك 🎉\n- لقد نجوت من جميع الجولات وحصلت على مكافأة!",
			lose: "🎯 انتهت اللعبة 🎯\nالحالة: ❌ خاسر\n- تم إعادة ضبط المال، والخبرة، والإيداع (الدين محفوظ)."
		}
	},

	onStart: async function ({ message, getLang }) {
		let chamber = Array(6).fill(1);
		chamber[Math.floor(Math.random() * 6)] = 0;

		let results = [];
		let status = getLang("win");

		for (let i = 0; i < chamber.length; i++) {
			if (chamber[i] === 0) {
				results.push(getLang("bang", i + 1));
				status = getLang("lose");
				break;
			} else {
				results.push(getLang("click", i + 1));
			}
		}

		message.reply(`${results.join("\n")}\n\n${status}`);
	}
};