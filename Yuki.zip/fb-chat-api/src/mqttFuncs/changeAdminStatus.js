'use strict';

const { generateOfflineThreadingID } = require('../../utils');

function isCallable(fn) {
  return typeof fn === 'function';
}

function isValidThreadKey(threadKey) {
  return typeof threadKey === 'string' && threadKey.trim().length > 0;
}

function isValidContactID(contactID) {
  return typeof contactID === 'string' && contactID.trim().length > 0;
}

function isValidAdminStatus(isAdmin) {
  return typeof isAdmin === 'boolean';
}

module.exports = function (defaultFuncs, api, ctx) {
  return async function changeAdminStatus(threadKey, contactID, isAdmin, callback) {
    if (!ctx.mqttClient) {
      const err = new Error('Not connected to MQTT');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    if (!isValidThreadKey(threadKey)) {
      const err = new Error('Invalid threadKey: it should be a non-empty string');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    if (!isValidContactID(contactID)) {
      const err = new Error('Invalid contactID: it should be a non-empty string');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    if (!isValidAdminStatus(isAdmin)) {
      const err = new Error('Invalid isAdmin: it should be a boolean');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    ctx.wsReqNumber += 1;
    ctx.wsTaskNumber += 1;

    const taskPayload = {
      thread_key: threadKey,
      contact_id: contactID,
      is_admin: isAdmin,
    };

    const task = {
      failure_count: null,
      label: '25',
      payload: JSON.stringify(taskPayload),
      queue_name: 'admin_status',
      task_id: ctx.wsTaskNumber,
    };

    const content = {
      app_id: '2220391788200892',
      payload: JSON.stringify({
        tasks: [task],
        epoch_id: parseInt(generateOfflineThreadingID()),
        version_id: '9305733849522974',
      }),
      request_id: ctx.wsReqNumber,
      type: 3,
    };

    ctx.mqttClient.publish('/ls_req', JSON.stringify(content), { qos: 1, retain: false });

    const defaultCallback = (err, result) => {
      if (err) {
        return err;
      } else {
        return result;
      }
    };

    if (isCallable(callback)) {
      return callback(null, {
        status: 'sent',
        threadKey,
        contactID,
        isAdmin,
        request_id: ctx.wsReqNumber,
      });
    } else {
      return defaultCallback(null, {
        status: 'sent',
        threadKey,
        contactID,
        isAdmin,
        request_id: ctx.wsReqNumber,
      });
    }
  };
};
