"use strict";
const utils = require("../utils");
module.exports = function (defaultFuncs, api, ctx) {
	return function sendMessage(threadKey, message, attachments, callback) {
		if (!ctx.mqttClient) {
			throw new Error('Not connected to MQTT');
		}

		if (typeof threadKey !== 'string') {
			throw new Error('Invalid threadKey value');
		}

		ctx.wsReqNumber += 1;
		ctx.wsTaskNumber += 1;
        const otid = utils.generateOfflineThreadingID();
		const epoch = utils.generateOfflineThreadingID();
		const sendPayload = (messagePayload, attachmentFbids) => {
			const tasks = [];

			if (message && typeof message === 'string') {
				const messageTask = {
					failure_count: null,
					label: "46",
					payload: JSON.stringify({
						thread_id: threadKey,
						otid: otid,
						source: 65537,
						send_type: 1,
						sync_group: 1,
						mark_thread_read: 1,
						text: message,
						initiating_source: 1,
						skip_url_preview_gen: 0,
						text_has_links: 0,
						multitab_env: 0
					}),
					queue_name: threadKey,
					task_id: ctx.wsTaskNumber
				};
				tasks.push(messageTask);
			}

			if (attachmentFbids && attachmentFbids.length > 0) {
				const attachmentTask = {
					failure_count: null,
					label: "46",
					payload: JSON.stringify({
						thread_id: threadKey,
						otid: otid,
						source: 65537,
						send_type: 3,
						sync_group: 1,
						mark_thread_read: 0,
						text: null,
						attachment_fbids: attachmentFbids
					}),
					queue_name: threadKey,
					task_id: ctx.wsTaskNumber
				};
				tasks.push(attachmentTask);
			}

			const context = {
				app_id: "772021112871879",
				payload: {
					epoch_id: epoch,
					tasks: tasks,
					version_id: "8487784514598369",
					data_trace_id: null
				},
				request_id: ctx.wsReqNumber,
				type: 3
			};

			context.payload = JSON.stringify(context.payload);

			ctx.mqttClient.publish('/ls_req', JSON.stringify(context), { qos: 1, retain: false }, (err) => {
				if (err) {
					console.error('Failed to publish:', err);
					if (callback) callback(err);
				} else {
					console.log('Published successfully:', context);
					if (callback) callback(null, context);
				}
			});
		};

		if (attachments && attachments.length > 0) {
			uploadAttachment(attachments, (err, uploadedAttachments) => {
				if (err) return callback(err);

				const attachmentFbids = uploadedAttachments.map(a => a.fbid);
				sendPayload(message, attachmentFbids);
			});
		} else {
			sendPayload(message, []);
		}
	};
};

function uploadAttachment(attachments, callback) {
	const uploads = [];

	for (let i = 0; i < attachments.length; i++) {
		if (!utils.isReadableStream(attachments[i])) {
			throw {
				error: "Attachment should be a readable stream and not " + utils.getType(attachments[i]) + "."
			};
		}

		const form = {
			upload_1024: attachments[i],
			voice_clip: "true"
		};

		uploads.push(
			defaultFuncs
				.postFormData(
					"https://upload.facebook.com/ajax/mercury/upload.php",
					ctx.jar,
					form,
					{}
				)
				.then(utils.parseAndCheckLogin(ctx, defaultFuncs))
				.then(function (resData) {
					if (resData.error) {
						throw resData;
					}

					return resData.payload.metadata[0];
				})
		);
	}

	Promise
		.all(uploads)
		.then(function (resData) {
			callback(null, resData);
		})
		.catch(function (err) {
			console.error("uploadAttachment error:", err);
			callback(err);
		});
}