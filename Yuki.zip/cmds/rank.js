const { createCanvas, loadImage, registerFont } = require('canvas');
registerFont(__dirname+'/canvas/fonts/stats.ttf', { family: 'stts' });
//registerFont(__dirname+'/canvas/fonts/SArBold.ttf', { family: 'sttsAr'});
exports.config={name:"rank", version: "3.1.7", role:0, category: "canvas", description:"View rank, bal..."};
exports.onStart = async ({message, event, usersData})=>{
async function Stats(id) {
const cover = await require("../../funcs").getPinUrl("https://pin.it/4q6rP1lvH");
const gId = (await usersData.get(id, "gender")) == 2 ? "male" : "female";
//https://pin.it/1Uh10mIdj
const width = 1000;
const height = 650;
const canvas = createCanvas(width, height);
const ctx = canvas.getContext('2d');
const gradient = ctx.createLinearGradient(0, 0, 0, height);
gradient.addColorStop(0.00, '#2B2B2B');
gradient.addColorStop(0.40, '#1F1F1F');
gradient.addColorStop(0.70, '#141414');
gradient.addColorStop(1.00, '#080808');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
const adbot = YamiBot.config.adminBot;
const dvbot = YamiBot.config.devsBot;
//calc
let sttts="User", stts=null, arrclr=["#AC00AF"];
if (adbot.includes(id)) {
    stts = "ad";
    sttts = "AdminBot";
    arrclr = ["#1E90FF", "#00CED1"]; // Dodger Blue to Dark Turquoise
}

if (dvbot.includes(id)) {
    stts = "dev";
    sttts = "Developer";
    arrclr = ["#FF8C00", "#FFD700"]; // Dark Orange to Gold
}
let deltaNext = 5;
const expToLevel = (exp, deltaNextLevel = deltaNext) => Math.floor((1 + Math.sqrt(1 + 8 * exp / deltaNextLevel)) / 2);
const levelToExp = (level, deltaNextLevel = deltaNext) => Math.floor(((Math.pow(level, 2) - level) * deltaNextLevel) / 2);
let {exp, money} = await usersData.get(id);
if (money > 1000000000) money = "9999999999";
const levelUser = expToLevel(exp, deltaNext);
const lvv = `Level ${expToLevel(exp, deltaNext)}`;
const expNextLevel = levelToExp(levelUser + 1, deltaNext) - levelToExp(levelUser, deltaNext);
const currentExp = expNextLevel - (levelToExp(levelUser + 1, deltaNext) - exp);
const avatarURL = await usersData.getAvatarUrl(id);
const OG = (await usersData.getAll()).findIndex(u => u.userID==id);
const Name = validateName(await usersData.getName(id));
const profileImage = await loadImage(avatarURL); 
await drawCover(ctx, cover, 30, 30, 940, 400, 50);
await drawProfile(ctx, profileImage, 235, 440, 250);
await rGend(ctx, gId, 220, 580);
ctx.font = 'bold 35px stts';
//ctx.font = (/^[\u0600-\u06FF\s]+$/).test(Name.trim()) ? 'bold 35px sttsAr' : 'bold 35px stts';
ctx.fillStyle = 'white';
ctx.textAlign = 'left';
ctx.textBaseline = 'middle';
ctx.fillText(Name, 235 + 250 / 2 + 20, 470);
await vB(ctx, stts, 235+250/2+40+(ctx.measureText(Name).width), 465, 40);
//uid
ctx.fillStyle = '#A0A0A0';
ctx.globalAlpha = 0.75;
ctx.textAlign = 'right';
ctx.font = '30px stts';
ctx.fillText("#"+id, 945, 390);
ctx.textAlign = 'left';
ctx.fillText("@"+OG, 60, 60);
ctx.globalAlpha = 1;
//I 
drawI(ctx, sttts, 235+250/2+20, 490, arrclr);
//flag
const FM = flag();
const img = FM.img("dz");
await drawFlag(ctx, img, 235+250/2+70+(ctx.measureText(sttts).width), 490, 80);
//ords
drawI(ctx, "Num "+OG, 235+250/2+70+(ctx.measureText(sttts).width)+93, 490, ["#5800FF", "#8B00FF"]);
//rExpP
await rExpP(ctx, currentExp, expNextLevel, 235+250/2+20, 535, [/*"#0083FF", "#00B9FF"*/"#FF0024", "#FF0057"], 40, lvv);
await renderMoney(ctx, money, width - 80, 466);
//await sh.canvas(canvas);
const s = await canvas.createPNGStream();
s.path = `rank_${utils.randomString(8)}.png`;
return s;
async function drawProfile(ctx, image, x, y, size) {
    const radius = size / 2;
    const cropSize = Math.min(image.width, image.height);
    const cropX = (image.width - cropSize) / 2;
    const cropY = (image.height - cropSize) / 2;
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(image, cropX, cropY, cropSize, cropSize, x - radius, y - radius, size, size);

    ctx.lineWidth = 10;
    ctx.strokeStyle = "#2B2B2B";
    ctx.stroke();
    ctx.restore();
}
async function drawCover(ctx, inputImagePath, x, y, coverWidth, coverHeight, radius = 0) {
    const image = await loadImage(inputImagePath);
    const imageAspect = image.width / image.height;
    const targetAspect = coverWidth / coverHeight;
    let sourceX, sourceY, sourceWidth, sourceHeight;
    if (imageAspect > targetAspect) {
        sourceWidth = image.height * targetAspect;
        sourceHeight = image.height;
        sourceX = (image.width - sourceWidth) / 2;
        sourceY = 0;
    } else {
        sourceWidth = image.width;
        sourceHeight = image.width / targetAspect;
        sourceX = 0;
        sourceY = (image.height - sourceHeight) / 2;
    }
    ctx.save();
    ctx.beginPath();
    if (radius > 0) {
        const r = radius;
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + coverWidth - r, y);
        ctx.quadraticCurveTo(x + coverWidth, y, x + coverWidth, y + r);
        ctx.lineTo(x + coverWidth, y + coverHeight - r);
        ctx.quadraticCurveTo(x + coverWidth, y + coverHeight, x + coverWidth - r, y + coverHeight);
        ctx.lineTo(x + r, y + coverHeight);
        ctx.quadraticCurveTo(x, y + coverHeight, x, y + coverHeight - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
    } else {
        ctx.rect(x, y, coverWidth, coverHeight);
    }
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(image, sourceX, sourceY, sourceWidth, sourceHeight, x, y, coverWidth, coverHeight);
    const grad = ctx.createLinearGradient(0, y, 0, y + coverHeight);
    grad.addColorStop(0, 'rgba(0,0,0,0.15)');
    grad.addColorStop(1, 'rgba(0,0,0,0.75)');
    ctx.fillStyle = grad;
    ctx.fillRect(x, y, coverWidth, coverHeight);
    ctx.restore();
}
async function drawFlag(ctx, imgUrl, x, y, w = 70) {
  const height = 40;
  const radius = Math.min(20, height / 2, w / 2);
  const img = await loadImage(imgUrl);
  const imgAspect = img.width / img.height;
  const targetAspect = w / height;
  let sx, sy, sw, sh;
  if (imgAspect > targetAspect) {
    sh = img.height;
    sw = img.height * targetAspect;
    sx = (img.width - sw) / 2;
    sy = 0;
  } else {
    sw = img.width;
    sh = img.width / targetAspect;
    sx = 0;
    sy = (img.height - sh) / 2;
  }
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + height - radius);
  ctx.quadraticCurveTo(x + w, y + height, x + w - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(img, sx, sy, sw, sh, x, y, w, height);
  ctx.restore();
}
function drawI(ctx, title, x, y, colors) {
  ctx.font = "bold 22px stts";
  const textWidth = ctx.measureText(title).width;
  const paddingX = 40;
  const width = textWidth + paddingX;
  const height = 40;
  const radius = 20;
  const gradient = ctx.createLinearGradient(x, y, x, y + height);
  const step = 1 / (colors.length - 1);
  colors.forEach((c, i) => gradient.addColorStop(i * step, c));
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();
  ctx.shadowColor = "rgba(0,0,0,0.25)";
  ctx.shadowBlur = 6;
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(title, x + width / 2, y + height / 2);
  ctx.shadowBlur = 0;
}
async function vB(ctx, a, x, y, size) {
    let ic;
    if (a === "ad") ic = await loadImage("https://i.imgur.com/Rcp9ZLW.png");
    else if (a === "dev") ic = await loadImage("https://i.imgur.com/xaw9VTH.png");
    else return;

    const aspect = ic.width / ic.height;
    const w = size * aspect;
    const h = size;
    ctx.drawImage(ic, x - w / 2, y - h / 2, w, h);
}
async function rExpP(ctx, currentExp, expNextLevel, x, y, colors, r, lv = "Level 1") {
  const lIcon = await loadImage("https://img.icons8.com/ios-glyphs/30/FFFFFF/lightning-bolt--v1.png");
  const size = 60;
  const radius = 20;
  const gradient = ctx.createLinearGradient(x, y, x, y + size);
  const step = 1 / (colors.length - 1);
  colors.forEach((c, i) => gradient.addColorStop(i * step, c));

  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + size - radius, y);
  ctx.quadraticCurveTo(x + size, y, x + size, y + radius);
  ctx.lineTo(x + size, y + size - radius);
  ctx.quadraticCurveTo(x + size, y + size, x + size - radius, y + size);
  ctx.lineTo(x + radius, y + size);
  ctx.quadraticCurveTo(x, y + size, x, y + size - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.shadowColor = "rgba(0,0,0,0.25)";
  ctx.shadowBlur = 6;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.drawImage(lIcon, x + size / 2 - 15, y + size / 2 - 15, 30, 30);

  const barX = x + size + 10;
  const barY = y + size / 2 - 4;
  const width = 350;
  const height = 10;
  const MAX_WIDTH = 350;
  const scaleFactor = Math.min(MAX_WIDTH / width, 1);
  const scaledWidth = Math.min(width, MAX_WIDTH);
  const scaledExpNextLevel = expNextLevel * (scaledWidth / width);
  const scaledCurrentExp = currentExp * (scaledWidth / width);
  const percentage = Math.min((scaledCurrentExp / scaledExpNextLevel) * 100, 100);
  const barRadius = height / 2;

  // Grey base background for expNextLevel
  ctx.beginPath();
  ctx.moveTo(barX + barRadius, barY);
  ctx.lineTo(barX + scaledWidth - barRadius, barY);
  ctx.quadraticCurveTo(barX + scaledWidth, barY, barX + scaledWidth, barY + barRadius);
  ctx.lineTo(barX + scaledWidth, barY + height - barRadius);
  ctx.quadraticCurveTo(barX + scaledWidth, barY + height, barX + scaledWidth - barRadius, barY + height);
  ctx.lineTo(barX + barRadius, barY + height);
  ctx.quadraticCurveTo(barX, barY + height, barX, barY + height - barRadius);
  ctx.lineTo(barX, barY + barRadius);
  ctx.quadraticCurveTo(barX, barY, barX + barRadius, barY);
  ctx.closePath();
  ctx.fillStyle = "#949494"; // grey background for unfilled exp
  ctx.fill();

  const grad = ctx.createLinearGradient(barX, barY, barX + scaledWidth, barY);
  colors.forEach((c, i) => grad.addColorStop(i * step, c));
  const progressWidth = (scaledWidth * percentage) / 100;

  if (progressWidth > 0) {
    ctx.beginPath();
    ctx.moveTo(barX + barRadius, barY);
    ctx.lineTo(barX + progressWidth - barRadius, barY);
    ctx.quadraticCurveTo(barX + progressWidth, barY, barX + progressWidth, barY + barRadius);
    ctx.lineTo(barX + progressWidth, barY + height - barRadius);
    ctx.quadraticCurveTo(barX + progressWidth, barY + height, barX + progressWidth - barRadius, barY + height);
    ctx.lineTo(barX + barRadius, barY + height);
    ctx.quadraticCurveTo(barX, barY + height, barX, barY + height - barRadius);
    ctx.lineTo(barX, barY + barRadius);
    ctx.quadraticCurveTo(barX, barY, barX + barRadius, barY);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.shadowColor = "rgba(0,0,0,0.3)";
    ctx.shadowBlur = 5;
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  ctx.font = "bold 18px stts";
  ctx.fillStyle = "#fff";
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  //ctx.fillText(`${currentExp}/${expNextLevel}`, barX + scaledWidth / 2, barY + height / 2);
  ctx.globalAlpha = 0.7;
  const eee = Number(currentExp).toLocaleString("en-US")+"/"+expNextLevel+" Exp Point To The Level "+(Number(lv.split("Level ")[1])+1)+".";
  const eew = ctx.measureText(eee).width;
  ctx.fillText(eee, barX, barY +26);
  ctx.globalAlpha = 1;
  ctx.fillText(lv, barX, barY-14);
}
function flag() {
    const avF = ["ad","ae","af","ag","ai","al","am","ao","aq","ar","as","at","au","aw","ax","az","ba","bb","bd","be","bf","bg","bh","bi","bj","bl","bm","bn","bo","bq","br","bs","bt","bv","bw","by","bz","ca","cc","cd","cf","cg","ch","ci","ck","cl","cm","cn","co","cr","cu","cv","cw","cx","cy","cz","de","dj","dk","dm","do","dz","ec","ee","eg","eh","er","es","et","eu","fi","fj","fk","fm","fo","fr","ga","gb","gb-eng","gb-nir","gb-sct","gb-wls","gd","ge","gf","gg","gh","gi","gl","gm","gn","gp","gq","gr","gs","gt","gu","gw","gy","hk","hm","hn","hr","ht","hu","id","ie","il","im","in","io","iq","ir","is","it","je","jm","jo","jp","ke","kg","kh","ki","km","kn","kp","kr","kw","ky","kz","la","lb","lc","li","lk","lr","ls","lt","lu","lv","ly","ma","mc","md","me","mf","mg","mh","mk","ml","mm","mn","mo","mp","mq","mr","ms","mt","mu","mv","mw","mx","my","mz","na","nc","ne","nf","ng","ni","nl","no","np","nr","nu","nz","om","pa","pe","pf","pg","ph","pk","pl","pm","pn","pr","ps","pt","pw","py","qa","re","ro","rs","ru","rw","sa","sb","sc","sd","se","sg","sh","si","sj","sk","sl","sm","sn","so","sr","ss","st","sv","sx","sy","sz","tc","td","tf","tg","th","tj","tk","tl","tm","tn","to","tr","tt","tv","tw","tz","ua","ug","um","un","us","us-ak","us-al","us-ar","us-az","us-ca","us-co","us-ct","us-de","us-fl","us-ga","us-hi","us-ia","us-id","us-il","us-in","us-ks","us-ky","us-la","us-ma","us-md","us-me","us-mi","us-mn","us-mo","us-ms","us-mt","us-nc","us-nd","us-ne","us-nh","us-nj","us-nm","us-nv","us-ny","us-oh","us-ok","us-or","us-pa","us-ri","us-sc","us-sd","us-tn","us-tx","us-ut","us-va","us-vt","us-wa","us-wi","us-wv","us-wy","uy","uz","va","vc","ve","vg","vi","vn","vu","wf","ws","xk","ye","yt","za","zm","zw"];
    return {
        list: () => { return avF.join(", "); },
        img:  (x) => {
            if (!avF.includes(x)) return 404;
            return `https://flagcdn.com/h240/${x}.png`;
        }
    }
}

async function rGend(ctx, Gender, x, y) {
  const gender = (Gender || "").trim().toLowerCase();
  const icons = {
    male: "https://img.icons8.com/color/48/male.png",
    female: "https://img.icons8.com/color/48/female.png"
  };
  const iconUrl = icons[gender] || icons.male;
  const img = await loadImage(iconUrl);
  const size = 42;
  const label = gender.charAt(0).toUpperCase() + gender.slice(1);
  ctx.font = "bold 24px stts";
  ctx.fillStyle = "#FFFFFF";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const textWidth = ctx.measureText(label).width;
  const totalWidth = size + 10 + textWidth;
  const iconX = x - totalWidth / 2;
  const textX = iconX + size + 10;
  ctx.drawImage(img, iconX, y - size / 2, size, size);
  ctx.fillText(label, textX + textWidth / 2, y);
}

async function renderMoney(ctx, bal, x, y) {
  const img = await loadImage("https://i.imgur.com/3yw55wJ.png");
  const size = 30;
  const formatted = Number(bal).toLocaleString("en-US");

  ctx.font = "bold 22px stts";
  ctx.fillStyle = "#717171";
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";

  const textWidth = ctx.measureText(formatted).width;
  const totalWidth = size + 12 + textWidth;

  ctx.drawImage(img, x - totalWidth, y - size / 2, size, size);
  ctx.fillText(formatted, x, y);
}
function validateName(name) {
  if (typeof name !== "string") return "Cringe";
  name = name.trim();
  name = name.replace(/[\u{1F600}-\u{1F6FF}\u{1F300}-\u{1F5FF}\u{1F900}-\u{1F9FF}\u{2600}-\u{27BF}\u{FE00}-\u{FE0F}\u{1FA70}-\u{1FAFF}\u{200D}\u{E0020}-\u{E007F}]/gu, "");
  const validRegex = /^[\u0621-\u064A\u0660-\u0669a-zA-Z\s]+$/;
  if (!validRegex.test(name) || name === "") return "Cringe";
  if (name.length > 15) name = name.slice(0, 15);
  return name;
}
//by alu
}
const IDs = Object.keys(event.mentions);
if (IDs.length < 1) IDs.push(event.messageReply?.senderID || event.senderID);
let streams = [];
for (const id of IDs) {
    const card = await Stats(id);
    streams.push(card);
}
message.send({attachment:streams});
};