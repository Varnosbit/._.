 module.exports = {
  config: {
    name: "silent",
    aliases: ["سكوت"],
    version: "1.1",
    author: "Allou Mohamed",
    countDown: 5,
    role: 0,
    shortDescription: {
      en: "Make peoples shut up.",
      ar: "جعل الكل يسكت بالقوة."
    },
    longDescription: {
      en: "if this mode enabled bot will kick anyone send message during this mode",
      ar: "لما تشغلو رح يقوم البوت بطرد كل من يرسل رسائل."
    },
    category: "automatic",
    guide: {
      en: "{pn} empty or off",
      ar: "{pn} خليه فارغ أو إيقاف"
    }
  },
  langs: {
      en: {
          needAdminRole: "❎ Add the bot as group admin. (safe)",
          on: '⚠️ NOTICE: ⚠️\n• Turned on silent mode. everyone don\'t send message.\n ⚠️ 𝘄𝗮𝗿𝗻 ⚠️',
          off: "❎ turned off silent mode.",
          kick: "❎ %1 kicked because he send message during this mode"
      },
      ar: {
          needAdminRole: "❎ لازم البوت يكون أدمن",
          on: "⚠️ تحذير: ⚠️\n• قام الأدمن بتفعيل وضع السكوت لذا لا ترسل أي رسالة و إلى ستطرد من المجموعة\n ⚠️ 𝘄𝗮𝗿𝗻 ⚠️",
          off: "❎ تم إيقاف السكوت",
          kick: "\t\t\t=> %1:\nتم طردك عشان لسانك طويل."
      }
  },
  onStart: async function ({api,  message, event, args, threadsData, getLang }) {
    let {adminIDs} = await threadsData.get(event.threadID);
    const BOTID = api.getCurrentUserID();
    if (!adminIDs.includes(BOTID)) return message.reply(getLang("needAdminRole"));
    
    if (!args[0]) {
      await threadsData.set(event.threadID, true, "settings.shutUp");
      message.reply(getLang("on"));
    } else if (args[0] === "إيقاف") {
      await threadsData.set(event.threadID, false, "settings.shutUp");
      message.reply(getLang("off"));
    }
  },

  onChat: async function ({ event, usersData, message, threadsData, api, getLang }) {
    let {adminIDs} = await threadsData.get(event.threadID);
    const name = await usersData.getName(event.senderID);
    
    if (
      event.body &&
      (await threadsData.get(event.threadID, "settings.shutUp")) === true &&
      event.senderID !== api.getCurrentUserID() && !adminIDs.includes(event.senderID)
    ) {
      api.removeUserFromGroup(event.senderID, event.threadID).then(() => {
        message.reply(getLang("kick", name));
      });
    }
  }
};