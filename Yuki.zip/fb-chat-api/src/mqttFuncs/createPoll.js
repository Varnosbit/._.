const utils = require("../../utils.js");

module.exports = (c, t, ctx) => {
  function makePoll(threadID, question, options, callback) {
    return new Promise((resolve, reject) => {
      if (!threadID) {
        const err = new Error("Missing parameter: threadID");
        if (callback) callback(err);
        return reject(err);
      }
      if (!question) {
        const err = new Error("Missing parameter: question");
        if (callback) callback(err);
        return reject(err);
      }
      if (!options || (Array.isArray(options) && options.length === 0)) {
        const err = new Error("Missing parameter: options");
        if (callback) callback(err);
        return reject(err);
      }

      if (typeof threadID === "number") threadID = String(threadID);
      if (!Array.isArray(options)) options = [String(options)];
      else options = options.map(o => String(o));

      const reqNum = ++ctx.wsReqNumber;
      const taskNum = ++ctx.wsTaskNumber;

      const taskPayload = {
        question_text: String(question),
        thread_key: threadID,
        options,
        sync_group: 1,
      };

      const task = {
        failure_count: null,
        label: "163",
        payload: JSON.stringify(taskPayload),
        queue_name: "poll_creation",
        task_id: taskNum,
      };

      const content = {
        app_id: "2220391788200892",
        payload: JSON.stringify({
          data_trace_id: null,
          epoch_id: parseInt(utils.generateOfflineThreadingID()),
          tasks: [task],
          version_id: "7158486590867448",
        }),
        request_id: reqNum,
        type: 3,
      };

const onResponse = (topic, message) => {
  if (topic === "/ls_resp") {
    let jsonMsg;
    try {
      jsonMsg = JSON.parse(message.toString());
      jsonMsg.payload = JSON.parse(jsonMsg.payload);
    } catch (err) {
      cleanup();
      if (callback) callback(err);
      return reject(err);
    }

    if (jsonMsg.request_id === reqNum) {
      const steps = jsonMsg.payload.step || [];
      const errRegex = /(error|warn)/i;
      let errorText = null;

      for (const s of steps) {
        try {
          const str = JSON.stringify(s);
          if (errRegex.test(str)) {
            const match = str.match(/"([^"]*error[^"]*|[^"]*warn[^"]*)"/i);
            if (match) errorText = match[1];
          }
        } catch {}
      }

      if (errorText) {
        const err = { message: errorText + ", this can happen if there is an error in the threadID, the bot is not in the provided thread, or even if there is an error in other settings or a ban in the bot account." };
        cleanup();
        if (callback) callback(err);
        return reject(err);
      }
    }
  }

  if (topic !== "/t_ms") return;
  let parsed;
  try {
    parsed = JSON.parse(message.toString());
  } catch (err) {
    cleanup();
    if (callback) callback(err);
    return reject(err);
  }

  const deltas = parsed.deltas || [];
  for (const d of deltas) {
    if (d.type === "group_poll" && d.untypedData?.event_type === "question_creation") {
      let q = {};
      try {
        q = JSON.parse(d.untypedData.question_json);
      } catch (err) {
        continue;
      }
      const pollInfo = {
        question_id: d.untypedData.question_id,
        question_text: q.text,
        creator_id: q.creator_id,
        total_votes: q.total_count,
        viewer_has_voted: q.viewer_has_voted === "true",
        options: q.options.map(opt => ({
          id: opt.id,
          text: opt.text,
          total_count: opt.total_count,
          voters: opt.voters || [],
        })),
        raw: {
          message_id: d.messageMetadata?.messageId,
          thread_id: d.messageMetadata?.threadKey?.threadFbId,
          timestamp: d.messageMetadata?.timestamp,
          actorFbId: d.messageMetadata?.actorFbId,
          adminText: d.messageMetadata?.adminText,
        },
      };
      cleanup();
      if (callback) callback(null, pollInfo);
      return resolve(pollInfo);
    }
  }
};

      const cleanup = () => {
        ctx.mqttClient.removeListener("message", onResponse);
      };

      ctx.mqttClient.on("message", onResponse);
      ctx.mqttClient.publish("/ls_req", JSON.stringify(content), { qos: 1, retain: false });
    });
  }

  return makePoll;
};
