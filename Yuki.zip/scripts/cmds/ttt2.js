const { createCanvas } = require('canvas');

module.exports = {
	config: {
		name: "tictactoe2",
		aliases: ["ttt2", "xo2"],
		version: "1.0",
		author: "X7 team",
		countDown: 3,
		role: 0,
		description: {
			ar: "لعبة إكس أو مع لوحة مرسومة - العب ضد لاعب آخر أو ضد الذكاء الاصطناعي",
			en: "Tic Tac Toe game with visual board - play against another player or AI"
		},
		category: "game",
		guide: {
			ar: "{pn} @mention - للعب ضد لاعب\n{pn} ai [easy/medium/hard] - للعب ضد الذكاء الاصطناعي\n{pn} solo [easy/medium/hard] - للعب لوحدك ضد الذكاء الاصطناعي",
			en: "{pn} @mention - to play against another player\n{pn} ai [easy/medium/hard] - to play against AI\n{pn} solo [easy/medium/hard] - to play solo against AI"
		},
		envConfig: {
			winReward: 500,
			drawReward: 200
		}
	},

	langs: {
		en: {
			gameStarted: "🎮 بدأت لعبة إكس أو!\n\n🔴 اللاعب الأول: %1\n🔵 اللاعب الثاني: %2\n\n💡 اكتب رقم الخانة (1-9) للعب",
			gameStartedAI: "🎮 بدأت لعبة إكس أو ضد الذكاء الاصطناعي!\n\n🔴 أنت: X\n🤖 الذكاء الاصطناعي (%1): O\n\n💡 اكتب رقم الخانة (1-9) للعب",
			invalidMove: "❌ حركة غير صحيحة! اختر خانة فارغة من 1 إلى 9",
			notYourTurn: "⚠️ ليس دورك الآن",
			notInGame: "⚠️ أنت لست في هذه اللعبة",
			playerWin: "🎉 فاز %1!\n\n🎁 حصل على %2$",
			aiWin: "🤖 فاز الذكاء الاصطناعي!\n\n😔 حظ أفضل في المرة القادمة",
			playerTurn: "🔄 دور %1",
			draw: "🤝 تعادل!\n\n🎁 كل لاعب حصل على %1$",
			aiThinking: "🤖 الذكاء الاصطناعي يفكر...",
			needOpponent: "❌ تحتاج لذكر لاعب آخر أو استخدم 'ai' للعب ضد الذكاء الاصطناعي",
			opponentBusy: "❌ اللاعب المذكور مشغول في لعبة أخرى",
			alreadyInGame: "❌ أنت مشغول في لعبة أخرى بالفعل",
			invalidDifficulty: "❌ صعوبة غير صحيحة! استخدم: easy, medium, hard"
		}
	},

	onStart: async function ({ message, event, getLang, args, usersData, commandName }) {
		try {
			const senderID = event.senderID;
			
			// Check if player is already in a game
			if (isPlayerInGame(senderID)) {
				return message.reply(getLang("alreadyInGame"));
			}

			// AI Game Mode
			if (args[0] === 'ai' || args[0] === 'solo') {
				const difficulty = args[1] || 'medium';
				if (!['easy', 'medium', 'hard'].includes(difficulty)) {
					return message.reply(getLang("invalidDifficulty"));
				}

				const gameData = {
					type: 'ai',
					player1: senderID,
					player2: 'ai',
					board: Array(9).fill(null),
					currentPlayer: senderID,
					difficulty: difficulty,
					gameActive: true
				};

				// Store game data
				global.tictactoeGames = global.tictactoeGames || new Map();
				global.tictactoeGames.set(senderID, gameData);

				const canvas = drawBoard(gameData.board, gameData);
				const readableStream = canvas.createPNGStream();
				readableStream.path = "tictactoe.png";

				message.reply({
					body: getLang("gameStartedAI", difficulty.toUpperCase()),
					attachment: readableStream
				}, (err, info) => {
					if (!err) {
						global.GoatBot.onReply.set(info.messageID, {
							commandName,
							messageID: info.messageID,
							gameID: senderID,
							type: 'ai'
						});
					}
				});
				return;
			}

			// Player vs Player Mode
			const mentions = Object.keys(event.mentions);
			if (mentions.length === 0) {
				return message.reply(getLang("needOpponent"));
			}

			const opponentID = mentions[0];
			if (opponentID === senderID) {
				return message.reply(getLang("needOpponent"));
			}

			if (isPlayerInGame(opponentID)) {
				return message.reply(getLang("opponentBusy"));
			}

			const gameData = {
				type: 'pvp',
				player1: senderID,
				player2: opponentID,
				board: Array(9).fill(null),
				currentPlayer: senderID,
				gameActive: true
			};

			const gameID = `${senderID}_${opponentID}`;
			global.tictactoeGames = global.tictactoeGames || new Map();
			global.tictactoeGames.set(gameID, gameData);

			const player1Name = await getUserName(senderID, usersData);
			const player2Name = await getUserName(opponentID, usersData);

			const canvas = drawBoard(gameData.board, gameData);
			const readableStream = canvas.createPNGStream();
			readableStream.path = "tictactoe.png";

			message.reply({
				body: getLang("gameStarted", player1Name, player2Name),
				attachment: readableStream
			}, (err, info) => {
				if (!err) {
					global.GoatBot.onReply.set(info.messageID, {
						commandName,
						messageID: info.messageID,
						gameID: gameID,
						type: 'pvp'
					});
				}
			});

		} catch (error) {
			console.error("TicTacToe onStart error:", error);
			message.reply("❌ حدث خطأ في بدء اللعبة");
		}
	},

	onReply: async function ({ message, Reply, event, getLang, usersData, envCommands, commandName }) {
		try {
			const { gameID, type } = Reply;
			const senderID = event.senderID;
			const move = parseInt(event.body.trim());

			global.tictactoeGames = global.tictactoeGames || new Map();
			const gameData = global.tictactoeGames.get(gameID);

			if (!gameData || !gameData.gameActive) {
				return message.reply("❌ اللعبة غير موجودة أو انتهت");
			}

			// Validate move
			if (isNaN(move) || move < 1 || move > 9) {
				return message.reply(getLang("invalidMove"));
			}

			const boardIndex = move - 1;
			if (gameData.board[boardIndex] !== null) {
				return message.reply(getLang("invalidMove"));
			}

			// Check if it's player's turn
			if (type === 'pvp') {
				if (senderID !== gameData.currentPlayer) {
					return message.reply(getLang("notYourTurn"));
				}
				if (senderID !== gameData.player1 && senderID !== gameData.player2) {
					return message.reply(getLang("notInGame"));
				}
			} else if (type === 'ai') {
				if (senderID !== gameData.player1) {
					return message.reply(getLang("notInGame"));
				}
			}

			// Make player move
			gameData.board[boardIndex] = senderID === gameData.player1 ? 'X' : 'O';

			// Check for win or draw
			const result = checkGameEnd(gameData.board);
			
			if (result.gameOver) {
				gameData.gameActive = false;
				global.GoatBot.onReply.delete(Reply.messageID);
				
				const canvas = drawBoard(gameData.board, gameData, result.winningLine);
				const readableStream = canvas.createPNGStream();
				readableStream.path = "tictactoe.png";

				if (result.winner) {
					if (type === 'pvp') {
						const winnerID = result.winner === 'X' ? gameData.player1 : gameData.player2;
						const winnerName = await getUserName(winnerID, usersData);
						const reward = envCommands.tictactoe?.winReward || 500;
						
						await usersData.addMoney(winnerID, reward);
						
						message.reply({
							body: getLang("playerWin", winnerName, reward),
							attachment: readableStream
						});
					} else {
						if (result.winner === 'X') {
							const reward = envCommands.tictactoe?.winReward || 500;
							await usersData.addMoney(gameData.player1, reward);
							message.reply({
								body: getLang("playerWin", "أنت", reward),
								attachment: readableStream
							});
						} else {
							message.reply({
								body: getLang("aiWin"),
								attachment: readableStream
							});
						}
					}
				} else {
					// Draw
					const drawReward = envCommands.tictactoe?.drawReward || 200;
					if (type === 'pvp') {
						await usersData.addMoney(gameData.player1, drawReward);
						await usersData.addMoney(gameData.player2, drawReward);
					} else {
						await usersData.addMoney(gameData.player1, drawReward);
					}
					
					message.reply({
						body: getLang("draw", drawReward),
						attachment: readableStream
					});
				}
				
				global.tictactoeGames.delete(gameID);
				return;
			}

			// AI Turn
			if (type === 'ai') {
				message.reply(getLang("aiThinking"));
				
				setTimeout(async () => {
					const aiMove = getAIMove(gameData.board, gameData.difficulty);
					gameData.board[aiMove] = 'O';

					const aiResult = checkGameEnd(gameData.board);
					
					if (aiResult.gameOver) {
						gameData.gameActive = false;
						global.GoatBot.onReply.delete(Reply.messageID);
						
						const canvas = drawBoard(gameData.board, gameData, aiResult.winningLine);
						const readableStream = canvas.createPNGStream();
						readableStream.path = "tictactoe.png";

						if (aiResult.winner) {
							if (aiResult.winner === 'X') {
								const reward = envCommands.tictactoe?.winReward || 500;
								await usersData.addMoney(gameData.player1, reward);
								message.reply({
									body: getLang("playerWin", "أنت", reward),
									attachment: readableStream
								});
							} else {
								message.reply({
									body: getLang("aiWin"),
									attachment: readableStream
								});
							}
						} else {
							const drawReward = envCommands.tictactoe?.drawReward || 200;
							await usersData.addMoney(gameData.player1, drawReward);
							message.reply({
								body: getLang("draw", drawReward),
								attachment: readableStream
							});
						}
						
						global.tictactoeGames.delete(gameID);
						return;
					}

					// Continue game
					const canvas = drawBoard(gameData.board, gameData);
					const readableStream = canvas.createPNGStream();
					readableStream.path = "tictactoe.png";

					message.reply({
						body: "🔄 دورك الآن",
						attachment: readableStream
					}, (err, info) => {
						if (!err) {
							global.GoatBot.onReply.set(info.messageID, {
								commandName,
								messageID: info.messageID,
								gameID: gameID,
								type: 'ai'
							});
						}
					});
				}, 1500);
				
			} else {
				// PvP - Switch turns
				gameData.currentPlayer = gameData.currentPlayer === gameData.player1 ? gameData.player2 : gameData.player1;
				const nextPlayerName = await getUserName(gameData.currentPlayer, usersData);
				
				const canvas = drawBoard(gameData.board, gameData);
				const readableStream = canvas.createPNGStream();
				readableStream.path = "tictactoe.png";

				message.reply({
					body: getLang("playerTurn", nextPlayerName),
					attachment: readableStream
				}, (err, info) => {
					if (!err) {
						global.GoatBot.onReply.set(info.messageID, {
							commandName,
							messageID: info.messageID,
							gameID: gameID,
							type: 'pvp'
						});
					}
				});
			}

		} catch (error) {
			console.error("TicTacToe onReply error:", error);
			message.reply("❌ حدث خطأ في معالجة الحركة");
		}
	}
};

// Helper Functions
function drawBoard(board, gameData, winningLine = null) {
	const canvas = createCanvas(600, 700);
	const ctx = canvas.getContext('2d');

	// Background gradient
	const gradient = ctx.createLinearGradient(0, 0, 600, 700);
	gradient.addColorStop(0, '#667eea');
	gradient.addColorStop(1, '#764ba2');
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, 600, 700);

	// Title
	ctx.fillStyle = '#ffffff';
	ctx.font = 'bold 36px Arial';
	ctx.textAlign = 'center';
	ctx.fillText('🎮 إكس أو', 300, 50);

	// Game info
	ctx.font = '20px Arial';
	if (gameData.type === 'ai') {
		ctx.fillText(`🔴 أنت vs 🤖 AI (${gameData.difficulty})`, 300, 80);
	} else {
		ctx.fillText('🔴 X vs 🔵 O', 300, 80);
	}

	// Board background
	ctx.fillStyle = '#ffffff';
	ctx.fillRect(50, 120, 500, 500);
	
	// Grid shadow
	ctx.shadowColor = 'rgba(0,0,0,0.3)';
	ctx.shadowBlur = 10;
	ctx.shadowOffsetX = 5;
	ctx.shadowOffsetY = 5;

	// Draw grid lines
	ctx.strokeStyle = '#333333';
	ctx.lineWidth = 4;
	ctx.lineCap = 'round';

	// Vertical lines
	for (let i = 1; i < 3; i++) {
		ctx.beginPath();
		ctx.moveTo(50 + i * 166.67, 120);
		ctx.lineTo(50 + i * 166.67, 620);
		ctx.stroke();
	}

	// Horizontal lines
	for (let i = 1; i < 3; i++) {
		ctx.beginPath();
		ctx.moveTo(50, 120 + i * 166.67);
		ctx.lineTo(550, 120 + i * 166.67);
		ctx.stroke();
	}

	// Reset shadow
	ctx.shadowColor = 'transparent';

	// Draw cell numbers and X/O
	for (let i = 0; i < 9; i++) {
		const row = Math.floor(i / 3);
		const col = i % 3;
		const x = 50 + col * 166.67 + 83.33;
		const y = 120 + row * 166.67 + 83.33;

		if (board[i] === null) {
			// Draw cell number
			ctx.fillStyle = '#cccccc';
			ctx.font = '24px Arial';
			ctx.textAlign = 'center';
			ctx.fillText((i + 1).toString(), x, y + 8);
		} else if (board[i] === 'X') {
			// Draw X
			ctx.strokeStyle = '#e74c3c';
			ctx.lineWidth = 8;
			ctx.lineCap = 'round';
			
			ctx.beginPath();
			ctx.moveTo(x - 40, y - 40);
			ctx.lineTo(x + 40, y + 40);
			ctx.stroke();
			
			ctx.beginPath();
			ctx.moveTo(x + 40, y - 40);
			ctx.lineTo(x - 40, y + 40);
			ctx.stroke();
		} else if (board[i] === 'O') {
			// Draw O
			ctx.strokeStyle = '#3498db';
			ctx.lineWidth = 8;
			ctx.beginPath();
			ctx.arc(x, y, 40, 0, 2 * Math.PI);
			ctx.stroke();
		}
	}

	// Draw winning line
	if (winningLine) {
		ctx.strokeStyle = '#f1c40f';
		ctx.lineWidth = 12;
		ctx.lineCap = 'round';
		ctx.shadowColor = 'rgba(241, 196, 15, 0.5)';
		ctx.shadowBlur = 20;

		const [start, end] = winningLine;
		const startRow = Math.floor(start / 3);
		const startCol = start % 3;
		const endRow = Math.floor(end / 3);
		const endCol = end % 3;

		const startX = 50 + startCol * 166.67 + 83.33;
		const startY = 120 + startRow * 166.67 + 83.33;
		const endX = 50 + endCol * 166.67 + 83.33;
		const endY = 120 + endRow * 166.67 + 83.33;

		ctx.beginPath();
		ctx.moveTo(startX, startY);
		ctx.lineTo(endX, endY);
		ctx.stroke();
	}

	// Instructions
	ctx.shadowColor = 'transparent';
	ctx.fillStyle = '#ffffff';
	ctx.font = '18px Arial';
	ctx.textAlign = 'center';
	ctx.fillText('💡 اكتب رقم الخانة (1-9) للعب', 300, 660);

	return canvas;
}

function checkGameEnd(board) {
	const winPatterns = [
		[0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
		[0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns  
		[0, 4, 8], [2, 4, 6] // Diagonals
	];

	for (const pattern of winPatterns) {
		const [a, b, c] = pattern;
		if (board[a] && board[a] === board[b] && board[a] === board[c]) {
			return { gameOver: true, winner: board[a], winningLine: [a, c] };
		}
	}

	if (board.every(cell => cell !== null)) {
		return { gameOver: true, winner: null };
	}

	return { gameOver: false };
}

function getAIMove(board, difficulty) {
	const availableMoves = board.map((cell, index) => cell === null ? index : null).filter(val => val !== null);
	
	if (difficulty === 'easy') {
		// Random move 80% of the time
		if (Math.random() < 0.8) {
			return availableMoves[Math.floor(Math.random() * availableMoves.length)];
		}
	}

	if (difficulty === 'easy' || difficulty === 'medium') {
		// Check for winning move
		for (const move of availableMoves) {
			const testBoard = [...board];
			testBoard[move] = 'O';
			if (checkGameEnd(testBoard).winner === 'O') {
				return move;
			}
		}

		// Check for blocking move
		for (const move of availableMoves) {
			const testBoard = [...board];
			testBoard[move] = 'X';
			if (checkGameEnd(testBoard).winner === 'X') {
				return move;
			}
		}

		if (difficulty === 'medium') {
			// Medium: 50% random after checking win/block
			if (Math.random() < 0.5) {
				return availableMoves[Math.floor(Math.random() * availableMoves.length)];
			}
		}
	}

	// Hard difficulty: Use minimax
	return minimax(board, 0, true).index;
}

function minimax(board, depth, isMaximizing) {
	const result = checkGameEnd(board);
	
	if (result.gameOver) {
		if (result.winner === 'O') return { score: 10 - depth };
		if (result.winner === 'X') return { score: depth - 10 };
		return { score: 0 };
	}

	const availableMoves = board.map((cell, index) => cell === null ? index : null).filter(val => val !== null);

	if (isMaximizing) {
		let bestScore = -Infinity;
		let bestMove = availableMoves[0];

		for (const move of availableMoves) {
			const newBoard = [...board];
			newBoard[move] = 'O';
			const score = minimax(newBoard, depth + 1, false).score;
			
			if (score > bestScore) {
				bestScore = score;
				bestMove = move;
			}
		}

		return { score: bestScore, index: bestMove };
	} else {
		let bestScore = Infinity;
		let bestMove = availableMoves[0];

		for (const move of availableMoves) {
			const newBoard = [...board];
			newBoard[move] = 'X';
			const score = minimax(newBoard, depth + 1, true).score;
			
			if (score < bestScore) {
				bestScore = score;
				bestMove = move;
			}
		}

		return { score: bestScore, index: bestMove };
	}
}

function isPlayerInGame(playerID) {
	global.tictactoeGames = global.tictactoeGames || new Map();
	
	for (const [gameID, gameData] of global.tictactoeGames.entries()) {
		if (gameData.gameActive && (gameData.player1 === playerID || gameData.player2 === playerID)) {
			return true;
		}
	}
	return false;
}

async function getUserName(userID, usersData) {
	try {
		const userData = await usersData.get(userID);
		return userData.name || "مجهول";
	} catch {
		return "مجهول";
	}
}
