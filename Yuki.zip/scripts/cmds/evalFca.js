"use strict";

const {
    removeHomeDir,
    log
} = global.utils;

module.exports = {
    config: {
        name: "evalfca",
        version: "1.6",
        author: "allou mohamed",
        countDown: 5,
        role: 2,
        description: {
            ar: "Test code nhanh",
            en: "Test code quickly"
        },
        category: "owner",
        guide: {
            ar: "{pn} <đoạn code cần test>",
            en: "{pn} <code to test>"
        }
    },

    onStart: async function (run) {
        const {
            args,
            message,
            role,
            api
        } = run;

        if (role < 3) return;
        try {
            await api.eval(args, message);
        } catch (err) {
            log.err("eval command", err);
            message.send(
                "🦆 Error:\n" +
                (err.stack ? removeHomeDir(err.stack) : removeHomeDir(JSON.stringify(err, null, 2) || ""))
            );
        }
    }
};
