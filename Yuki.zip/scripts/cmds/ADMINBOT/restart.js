const fs = require("fs-extra");
const path = require("path");
const langs = {
		ar: {
			restarting: "🔄 | يتم إعادة تشغيل البوت...",
			restarted: "✅ | تم إعادة تشغيل يامي بنجاح 🤡\n⏰ | استغرق {time} ثانية"
		},
		en: {
			restarting: "🔄 | Restarting bot...",
			restarted: "✅ | Yami restarted successfully 🤡\n⏰ | Time: {time}s"
		}
	};
const restartFile = path.join(
	process.cwd(),
	"scripts",
	"cmds",
	"tmp",
	"restart.txt"
);

module.exports = {
	config: {
		name: "restart",
		version: "1.4",
		author: "Alu | Modified",
		countDown: 5,
		role: 2,
		description: {
			ar: "إعادة تشغيل البوت",
			en: "Restart bot"
		},
		category: "Owner",
		guide: {
			ar: "{pn}: إعادة تشغيل البوت",
			en: "{pn}: Restart bot"
		}
	},

	

	onLoad: function ({ api }) {
		if (!fs.existsSync(restartFile)) return;

		const [tid, lang, time] = fs.readFileSync(restartFile, "utf-8").split("|");
		const elapsed = Math.floor((Date.now() - Number(time)) / 1000);

		const msg = langs[lang]?.restarted.replace("{time}", elapsed)
			|| langs.en.restarted.replace("{time}", elapsed);

		api.sendMessage(msg, tid);
		fs.unlinkSync(restartFile);
	},
 
	onStart: async function ({ message, event, usersData, args }) {
		const lang = await usersData.get(event.senderID, "data.lang") || "en";

		if (args.length > 0) {
			sendFakeRestart(message, lang);
			return;
		}

		fs.ensureDirSync(path.dirname(restartFile));
		fs.writeFileSync(
			restartFile,
			`${event.threadID}|${lang}|${Date.now()}`
		);

		await message.reply(langs[lang].restarting);
		process.exit(2);
	}
};

function sendFakeRestart(message, lang) {
	const texts = {
		ar: {
			restarting: "🔄 | يتم إعادة تشغيل البوت...",
			restarted: "✅ | تم إعادة تشغيل يامي بنجاح 🤡\n⏰ | استغرق {time} ثانية"
		},
		en: {
			restarting: "🔄 | Restarting bot...",
			restarted: "✅ | Yami restarted successfully 🤡\n⏰ | Time: {time}s"
		}
	};

	message.reply(texts[lang]?.restarting || texts.en.restarting);

	const randomTime = Math.floor(Math.random() * 10 + 3);

	setTimeout(() => {
		message.send(
			(texts[lang]?.restarted || texts.en.restarted)
				.replace("{time}", randomTime)
		);
	}, randomTime * 1000);
}