const axios = require("axios");

const sharp = require("sharp");
const FormData = require("form-data");
const fs = require("fs");
const { getStreamFromURL } = global.utils;


async function createMidjourneyTask(prompt) {
    try {
        const response = await axios.post('https://simo-mj.onrender.com/generatex', { prompt, key:"siamxmjcdi" });
        return response.data;
    } catch (error) {
        console.error(error);
        throw new Error('Error creating Midjourney task');
    }
}


async function checkMidjourneyStatus(body) {
    try {
        const response = await axios.post('https://simo-mj.onrender.com/task', body);
        return response.data;
    } catch (error) {
        console.error(error);
        throw new Error('Error checking Midjourney status');
    }
}

module.exports = {
    config: {
        name: "midjourney",
        aliases: ["dj", "mj"],
        version: "1.0",
        author: "SiAM",
        shortDescription: "Initiates a Midjourney process based on the provided prompt.",
        longDescription: "Midjourney.",
        role: 2,
        countDown: 90,
        category: "Image",
        guide: {
            en: "{pn} marin Kitagawa --niji 6\n\nto upscale a single image from 4 images reply with [ U1, U2, U3, U4 ]"
        }
    },

    onStart: async function ({ api, args, message, event }) {
      

        let prompt = args.join(" ");

       
        if (event.type === "message_reply" && event.messageReply.attachments && event.messageReply.attachments.length > 0 && ["photo", "sticker"].includes(event.messageReply.attachments[0].type)) {
            const imageUrl = event.messageReply.attachments[0].url;
            const imgbbUrl = await uploadToImgbb(imageUrl); 
            prompt = `${imgbbUrl.url} ${prompt}`;
        }

        if (!prompt) {
            message.reply("Please provide a prompt.");
            return;
        }

        let jobId, authToken;

       
        try {
            const taskInfo = await createMidjourneyTask(prompt);

            if (taskInfo.task_id) {
                jobId = taskInfo.task_id;
                authToken = taskInfo.token;
            } else {
                const errorMessage = `Failed to add job ⚠️\n❏ Reason: ${taskInfo.message || 'Unknown error'}`;
                message.reply(errorMessage);
                return;
            }
        } catch (error) {
            console.error(error);
            if (error.response) {
                const { data } = error.response;
                message.reply(`❏ ${data.message}`);
            } else {
                message.reply("Failed to add job: Unknown error occurred.");
            }
            return;
        }

        const processingMessage = await message.reply("Initiating Midjourney process...⏳\nMight take some time..");
        message.reaction("⏰", event.messageID);
        let retries = 20;

       
        const checkStatus = async () => {
            try {
                const jobStatus = await checkMidjourneyStatus({ task_id: jobId, token: authToken });

                
                if (!jobStatus.response) {
                    console.log("Task still in progress..."); 
                    if (retries > 0) {
                        retries--;
                        setTimeout(checkStatus, 30000); 
                    } else {
                        message.reply("Taking too long. Job cancelled.");
                        await message.reaction("❌", event.messageID);
                    }
                    return;
                }

                
                if (jobStatus.response.success) {
                    const imageUrl = jobStatus.response.raw_image_url;
                   // const actions = jobStatus.response.actions;
                    const imageStream = await getStreamFromURL(imageUrl);

                    message.reply(
                        {
                            body: `Midjourney process completed ✨\n\n❏ Action: U1, U2, U3, U4 or AL fo send all.`,
                            attachment: imageStream
                        },
                        (err, info) => {
                            global.GoatBot.onReply.set(info.messageID, {
                                commandName: "midjourney",
                                messageID: info.messageID,
                                author: event.senderID,
                                imageUrl: imageUrl
                            });
                        }
                    );

                    message.unsend((await processingMessage).messageID);
                    await message.reaction("✅", event.messageID);
                } else if (jobStatus.response.error) {
                    message.reply(`Prompt rejected by Midjourney ⚠️ \n❏ Reason: ${jobStatus.response.error.message}`);
                    message.unsend((await processingMessage).messageID);
                    await message.reaction("❌", event.messageID);
                }
            } catch (error) {
                console.error(error);
                message.reply("Error occurred while checking job status.");
                await message.reaction("❌", event.messageID);
            }
        };

        checkStatus();
    },

   
onReply: async function ({ message, event, Reply, args }) {
        let { author, commandName, imageUrl } = Reply;
        if (event.senderID !== author) return;

        const options = ["U1", "U2", "U3", "U4", "AL"];

        const userSelection = args[0];
        if (!options.includes(userSelection)) {
            message.reply("Invalid option. Please select a valid action.");
            return;
        }

        try {
            const upscaleMessage = await message.reply("Upscale request added, please wait...");
            
            const imageBuffer = await axios.get(imageUrl, { responseType: 'arraybuffer' }).then(res => Buffer.from(res.data));

            
            const metadata = await sharp(imageBuffer).metadata();
            const width = metadata.width;
            const height = metadata.height;

            const halfWidth = Math.floor(width / 2);
            const halfHeight = Math.floor(height / 2);
            if (userSelection == "AL") {
            const cropRegions = [
                        { left: 0, top: 0, width: halfWidth, height: halfHeight },          // U1
                        { left: halfWidth, top: 0, width: halfWidth, height: halfHeight },  // U2
                        { left: 0, top: halfHeight, width: halfWidth, height: halfHeight }, // U3
                        { left: halfWidth, top: halfHeight, width: halfWidth, height: halfHeight } // U4
                    ];

                    const attachments = await Promise.all(cropRegions.map(async (region, index) => {
                    const croppedBuffer = await sharp(imageBuffer).extract(region).toBuffer();
                    const upscaledBuffer = await upscaleImage(croppedBuffer);
                    const tempPath = `upscaled_U${index + 1}.png`;
                    fs.writeFileSync(tempPath, upscaledBuffer);
                    return fs.createReadStream(tempPath);
                    }));

                    await message.reply({ body: "Upscaled images for all regions", attachment: attachments }, () => {
                        attachments.forEach(stream => fs.unlinkSync(stream.path));
                    });
            return;
            }
            let cropRegion;
            switch (userSelection) {
                case "U1":
                    cropRegion = { left: 0, top: 0, width: halfWidth, height: halfHeight };
                    break;
                case "U2":
                    cropRegion = { left: halfWidth, top: 0, width: halfWidth, height: halfHeight };
                    break;
                case "U3":
                    cropRegion = { left: 0, top: halfHeight, width: halfWidth, height: halfHeight };
                    break;
                case "U4":
                    cropRegion = { left: halfWidth, top: halfHeight, width: halfWidth, height: halfHeight };
                    break;
                /*case "AL":
                    if return >>>>>
                    break;*/
                default:
                    break;
            }

            
            const croppedImageBuffer = await sharp(imageBuffer).extract(cropRegion).toBuffer();

            
         
            const upscaledImageBuffer = await upscaleImage(croppedImageBuffer);

            
            const savedImagePath = `upscaled_${userSelection}.png`;
            fs.writeFileSync(savedImagePath, upscaledImageBuffer);

            message.reply({
                body: `Upscaled image for ${userSelection}`,
                attachment: fs.createReadStream(savedImagePath)
            }, () => {
                fs.unlinkSync(savedImagePath);
                message.unsend(upscaleMessage.messageID);
            });
        } catch (error) {
            console.error(error);
            message.reply("Error occurred while processing the image.");
        }
    }
};
      

async function uploadToImgbb(url) {
    try {
        const res_ = await axios({
            method: 'GET',
            url: 'https://imgbb.com',
        });

        const auth_token = res_.data.match(/auth_token="([^"]+)"/)[1];
        const timestamp = Date.now();

        const res = await axios({
            method: 'POST',
            url: 'https://imgbb.com/json',
            headers: {
                'Content-Type': 'multipart/form-data',
            },
            data: {
                source: url,
                type: 'url',
                filename:'image.png',
                action: 'upload',
                timestamp: timestamp,
                auth_token: auth_token,
            },
        });

        return {
            url: res.data.image.url,
            url_viewer: res.data.image.url_viewer,
        };
    } catch (error) {
        console.error(error);
        throw new Error('Error uploading to ImgBB');
    }
}


async function upscaleImage(imageData) {
    try {
        const accessToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE1MjMzNjQ4MjQsIm5iZiI6MTUyMzM2NDgyNCwianRpIjoicHJvamVjdF9wdWJsaWNfYzkwNWRkMWMwMWU5ZmQ3NzY5ODNjYTQwZDBhOWQyZjNfT1Vzd2EwODA0MGI4ZDJjN2NhM2NjZGE2MGQ2MTBhMmRkY2U3NyJ9.qvHSXgCJgqpC4gd6-paUlDLFmg0o2DsOvb1EUYPYx_E';
        const uploadUrl = 'https://api2g.iloveimg.com/v1/upload';
        const upscaleUrl = 'https://api2g.iloveimg.com/v1/upscale';
        const scale = 4;
        const TaskId = 'xxpn9rwj817czh6447rgA9hdxhxwk6Asr57fhdg2dfbsts2k6yl5tngxvgnbyA4z78mw8Avjz1m0nwvAdmg43h86A7ytrd860nc4gz9ljwvk37gzf6350mydtc55vss55rzkypxs5gd1j6w8hzfz89zgtpqy26td0qf8mA3j3kpmw61j6swq';

        const formData = new FormData();
        formData.append('task', TaskId);
        formData.append('file', imageData, { filename: 'image.jpg' });

        const uploadResponse = await axios.post(uploadUrl, formData, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                ...formData.getHeaders(),
            },
        });

        const serverFilename = uploadResponse.data.server_filename;

        const upscaleFormData = new FormData();
        upscaleFormData.append('task', TaskId);
        upscaleFormData.append('server_filename', serverFilename);
        upscaleFormData.append('scale', scale);

        const upscaleResponse = await axios.post(upscaleUrl, upscaleFormData, {
            responseType: 'arraybuffer',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                ...upscaleFormData.getHeaders(),
            },
        });

        return upscaleResponse.data;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}
