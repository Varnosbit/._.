'use strict';

const { generateOfflineThreadingID, parseAndCheckLogin, getType, isReadableStream } = require('../../utils');
const log = require('npmlog');

function isCallable(fn) {
  return typeof fn === 'function';
}

module.exports = function (defaultFuncs, api, ctx) {
  return async function changeGroupImage(image, threadKey, callback) {

    async function uploadFile(attachments) {
      try {
        if (getType(attachments) !== "Array") {
          attachments = [attachments];
        }

        const uploads = attachments.map(attachment => {
          if (!isReadableStream(attachment)) {
            throw new Error(`Attachment should be a readable stream, but got ${getType(attachment)}`);
          }

          const form = {
            upload_1024: attachment,
            voice_clip: "true"
          };

          return defaultFuncs
            .postFormData(
              "https://upload.facebook.com/ajax/mercury/upload.php",
              ctx.jar,
              form,
              {}
            )
            .then(parseAndCheckLogin(ctx, defaultFuncs))
            .then(resData => {
              if (resData.error) {
                throw new Error(`Error uploading file: ${JSON.stringify(resData.error)}`);
              }
              return resData.payload.metadata[0];
            });
        });

        return await Promise.all(uploads);
      } catch (error) {
        log.error('File upload failed:', error);
        throw error;
      }
    }

    if (!ctx.mqttClient) {
      const err = new Error("Not connected to MQTT");
      log.error("changeGroupImage", err.message);
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    if (typeof threadKey !== 'string' || threadKey.trim().length === 0) {
      const err = new Error("Invalid threadKey: it should be a non-empty string");
      log.error("changeGroupImage", err.message);
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    try {
      const [Image] = await uploadFile(image); 

      ctx.wsReqNumber += 1;
      ctx.wsTaskNumber += 1;

      const task = {
        failure_count: null,
        label: "37",
        payload: JSON.stringify({
          thread_key: threadKey,
          image_id: Image.image_id,
          sync_group: 1,
        }),
        queue_name: "thread_image",
        task_id: ctx.wsTaskNumber,
      };

      const content = {
        app_id: "2220391788200892",
        payload: JSON.stringify({
          tasks: [task],
          epoch_id: parseInt(generateOfflineThreadingID()),
          version_id: "9305733849522974",
        }),
        request_id: ctx.wsReqNumber,
        type: 3,
      };

      ctx.mqttClient.publish("/ls_req", JSON.stringify(content), {
        qos: 1,
        retain: false,
      });

      log.info("changeGroupImage", `Group image change request sent for thread ${threadKey} with image ID ${Image.image_id}`);

      const result = {
        status: 'sent',
        threadKey,
        imageId: Image.image_id,
        request_id: ctx.wsReqNumber,
      };

      return isCallable(callback) ? callback(null, result) : result;
    } catch (err) {
      const errorMessage = `Failed to change group image for thread ${threadKey}: ${err.message}`;
      log.error("changeGroupImage", errorMessage);
      if (isCallable(callback)) {
        return callback(new Error(errorMessage));
      }
      throw new Error(errorMessage);
    }
  };
};
