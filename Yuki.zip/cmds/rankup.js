const deltaNext = 5;
const expToLevel = exp => Math.floor((1 + Math.sqrt(1 + 8 * exp / deltaNext)) / 2);

module.exports = {
	config: {
		name: "rankup",
		version: "1.0.2",
		author: "Allou Mohamed",
		countDown: 5,
		role: 0,
		description: "Manage Rank Up Message.",
		category: "ranking",
		guide: {
			syntax: "/rankup [on|off|custom <message>]",
			params: "on: Enable rank up message\noff: Disable rank up message\ncustom <message>: Set a custom rank up message",
			usage: "/rankup on\n/rankup off\n/rankup custom Congrats {name}, you are now level {level}!"
		}
	},

	onStart: async function ({ message, event, threadsData, args }) {
		if (!["on", "off", "custom"].includes(args[0]))
			return message.reply("Syntax error, use:\n/rankup on\n/rankup off\n/rankup custom <message>");

		if (args[0] === "custom") {
			const customMsg = args.slice(1).join(" ");
			if (!customMsg) return message.reply("Please provide a message.\nExample: /rankup custom Congrats {name}, you reached level {currentRank}!");
			await threadsData.set(event.threadID, customMsg, "data.rankup.message");
			return message.reply("Custom rank up message has been saved!");
		}

		await threadsData.set(event.threadID, args[0] === "on", "settings.sendRankupMessage");
		return message.reply(args[0] === "on"
			? "Turned %bdon% level up noti."
			: "Turned %bdoff% level up noti.");
	},

	onChat: async function ({ threadsData, usersData, event, message }) {
		const sendRankupMessage = await threadsData.get(event.threadID, "settings.sendRankupMessage", true);
		if (!sendRankupMessage) return;

		const Name = await usersData.getName(event.senderID);
		const { exp } = await usersData.get(event.senderID);
		const currentLevel = expToLevel(exp);

		if (currentLevel > expToLevel(exp - 1)) {
			let customMessage = await threadsData.get(event.threadID, "data.rankup.message");
			const formMessage = {};

			if (customMessage) {
				customMessage = customMessage
					.replace(/{oldRank}/g, currentLevel - 1)
					.replace(/{currentRank}/g, currentLevel)
					.replace(/{userName}/g, Name)
					.replace(/{name}/g, Name);
				formMessage.body = customMessage;
			} else {
				formMessage.body = `Congratulations %bd${Name}%! You've leveled up to Level %bd${currentLevel}%!`;
			}

			message.reply(formMessage);
		}
	}
};
