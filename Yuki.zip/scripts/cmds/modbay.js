const axios = require('axios');
const cheerio = require('cheerio');
const baseUrl = 'https://modbay.org/mods';
const totalPages = 125;

module.exports = {
    config: {
        name: "modby",
        aliases: "مودات",
        author: "allou Mohamed",
        description: {
            ar: "الحصول على مودات ماين كرافت من موقع modby",
            en: "get modbay Minecraft addons"
        },
        category: "Minecraft",
        guide: {
            en: "{pn} query",
            ar: "{pn} بحث"
        }
    },
    all: null,
    onStart: async ({ message, args }) => {
        const searchTerm = args.join(" ");
        const mods = await searchMods(searchTerm);
        
        if (mods.length > 0) {
            let body = ``;
            let imageStream = [];
            for (let i = 0; i < mods.length && i < 6; i++) {
                const mod = mods[i];
                const { name, description, image, url } = mod;
                body += `${i + 1}. ${name}\n${description}\n- Url: ${url}\n\n`;
                imageStream.push(await utils.getStreamFromURL("https://modbay.org" + image));
            }
            await message.reply({ body: body, attachment: imageStream });
        } else {
            await message.reply("لم يعثر على أي مود له علاقة بالبحث");
        }

        async function fetchModsDataFromPage(url) {
            try {
                const { data } = await axios.get(url);
                const $ = cheerio.load(data);

                const mods = [];

                $('.post-card').each((index, element) => {
                    const mod = {};
                    mod.url = $(element).find('.post-card__link-img').attr('href');
                    mod.image = $(element).find('.post-card__link-img img').data('srcset').split(' ')[0];
                    mod.name = $(element).find('.post-card__title a').text().trim();
                    mod.description = $(element).find('.post-card__descr').text().trim();
                    mods.push(mod);
                });

                return mods;
            } catch (error) {
                console.error(`Error fetching the data from ${url}: ${error.message}`);
                return [];
            }
        }

        async function fetchAllModsData() {
            message.reply("🔄 please wait..");
            
            const allMods = [];
            for (let i = 1; i <= totalPages; i++) {
                const pageUrl = `${baseUrl}/page/${i}/`;
                const mods = await fetchModsDataFromPage(pageUrl);
                allMods.push(...mods);
            }
            return allMods;
        }

        async function searchMods(searchTerm) {
            if (!module.exports.all) {
                module.exports.all = await fetchAllModsData();
            }

            const allMods = module.exports.all;

            const filteredMods = allMods.filter(mod => 
                mod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                mod.description.toLowerCase().includes(searchTerm.toLowerCase())
            );

            return filteredMods;
        }
    }
};