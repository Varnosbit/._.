/**
 * @by Allou Mohamed
 * do not remove the author name to get more updates
 */

"use strict";

const utils = require("../utils");
const log = require("npmlog");

function formatData(resData) {
  const theme = resData.messenger_thread_theme;
  return theme;
}

module.exports = function (defaultFuncs, api, ctx) {
  return function getThreadThemes(ID, callback) {
    let resolveFunc = function () { };
    let rejectFunc = function () { };
    const returnPromise = new Promise(function (resolve, reject) {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err, data) {
        if (err) {
          return rejectFunc(err);
        }
        resolveFunc(data);
      };
    }

    const form = {
      av: ctx.i_userID || ctx.userID,
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "MWPThreadThemeProviderQuery",
      doc_id: "9734829906576883",
      variables: JSON.stringify({
        id: ID,
      }),
      fb_dtsg: ctx.fb_dtsg
    };

    defaultFuncs
      .post("https://web.facebook.com/api/graphql/", ctx.jar, form)
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then(function (resData) {
        if (resData.errors) {
          throw resData;
        }
        return callback(null, formatData(resData.data));
      })
      .catch(function (err) {
        log.error("getThreadThemes", err);
        return callback(err);
      });

    return returnPromise;
  };
};
