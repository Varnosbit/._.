'use strict';

const { generateOfflineThreadingID } = require('../../utils');

function isCallable(fn) {
  return typeof fn === 'function';
}

function isValidContactIDs(contactIDs) {
  return Array.isArray(contactIDs) && contactIDs.every(id => typeof id === 'string' && id.trim().length > 0);
}

function isValidThreadKey(threadKey) {
  return typeof threadKey === 'string' && threadKey.trim().length > 0;
}

module.exports = function (defaultFuncs, api, ctx) {
  return async function addUserToGroup(contactIDs, threadKey, callback) {
    if (!ctx.mqttClient) {
      const err = new Error('Not connected to MQTT');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    if (!isValidThreadKey(threadKey)) {
      const err = new Error('Invalid threadKey: it should be a non-empty string');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    let IDs;
    if (Array.isArray(contactIDs)) {
      IDs = contactIDs;
    } else {
      IDs = Array.of(contactIDs);
    }

    if (!isValidContactIDs(IDs)) {
      const err = new Error('Invalid contactIDs: all contact IDs should be non-empty strings');
      if (isCallable(callback)) {
        return callback(err);
      }
      throw err;
    }

    ctx.wsReqNumber += 1;
    ctx.wsTaskNumber += 1;

    const label = "23";

    const taskPayload = {
      thread_key: threadKey,
      contact_ids: IDs,
      sync_group: 1,
    };

    const payload = JSON.stringify(taskPayload);
    const version = "9305733849522974";
    const epoch = parseInt(generateOfflineThreadingID());

    const task = {
      failure_count: null,
      label: label,
      payload: payload,
      queue_name: String(threadKey),
      task_id: ctx.wsTaskNumber,
    };

    const content = {
      app_id: "2220391788200892",
      payload: JSON.stringify({
        tasks: [task],
        epoch_id: epoch,
        version_id: version,
      }),
      request_id: ctx.wsReqNumber,
      type: 3,
    };

    ctx.mqttClient.publish("/ls_req", JSON.stringify(content), { qos: 1, retain: false });

    const defaultCallback = (err, result) => {
      if (err) {
        return err;
      } else {
        return result;
      }
    };

    if (isCallable(callback)) {
      return callback(null, {
        status: 'sent',
        contactIDs: IDs,
        threadKey,
        request_id: ctx.wsReqNumber,
      });
    } else {
      return defaultCallback(null, {
        status: 'sent',
        contactIDs: IDs,
        threadKey,
        request_id: ctx.wsReqNumber,
      });
    }
  };
};
