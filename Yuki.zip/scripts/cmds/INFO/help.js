//1.0.9
const path = require("path");
const fs = require("fs");
const axios = require("axios");

async function translateText(text, targetLang = "ar") {
	try {
		const res = await axios.get(
			"https://translate.googleapis.com/translate_a/single",
			{
				params: {
					client: "gtx",
					sl: "auto",
					tl: targetLang,
					dt: "t",
					q: text
				}
			}
		);
		return res.data?.[0]?.map(t => t[0]).join("") || text;
	} catch {
		return text;
	}
}

function isUpperCaseFolder(folderName) {
	return /^[A-Z]/.test(folderName);
}

function getCmdDesc(cmd, lang = "ar") {
	const possibleObjNames = ["description", "desc", "shortDescription", "longDescription"];

	for (const name of possibleObjNames) {
		const descObj = cmd.config[name];

		if (typeof descObj === 'string') return descObj;

		if (typeof descObj === 'object' && descObj !== null) {
			// Try to get the requested language first
			if (descObj[lang]) return descObj[lang];
			// Fallback to English
			if (lang !== "en" && descObj["en"]) return descObj["en"];
			// Fallback to any available value
			const values = Object.values(descObj);
			if (values.length > 0) return values[0];
		}
	}

	return lang === "ar" ? "لا يوجد وصف متاح" : "No description available.";
}

function getGuideInfo(cmd, lang = "ar") {
	const guide = cmd.config.guide;
	let usage = lang === "ar" ? "اختياري" : "Optional";
	let params = lang === "ar" ? "لا يوجد" : "none";
	
	if (typeof guide === 'string') {
		const matches = guide.match(/<([^>]+)>/g);
		if (matches) {
			usage = lang === "ar" ? "مطلوب" : "Required";
			params = matches.map(match => match.replace(/[<>]/g, '')).join(', ');
		}
	} else if (typeof guide === 'object' && guide !== null) {
		const guideObj = guide[lang] || guide["en"] || guide;
		
		if (guideObj.usage) {
			usage = guideObj.usage;
		} else if (guideObj.params) {
			usage = lang === "ar" ? "مطلوب" : "Required";
		}
		
		if (guideObj.params) {
			if (typeof guideObj.params === 'string') {
				params = guideObj.params;
			} else if (Array.isArray(guideObj.params)) {
				params = guideObj.params.join(', ');
			}
		} else if (guideObj.syntax) {
			const matches = guideObj.syntax.match(/<([^>]+)>/g);
			if (matches) {
				usage = lang === "ar" ? "مطلوب" : "Required";
				params = matches.map(match => match.replace(/[<>]/g, '')).join(', ');
			}
		}
	}
	
	if (!params || params === "none" || params === "لا يوجد" || params === "") {
		params = "-";
	}
	if (!usage || usage === "") {
		usage = "-";
	}
	
	return { usage, params };
}

function getSyntax(cmd, lang = "ar", prefix = ".") {
	const name = cmd.config.name;
	const guide = cmd.config.guide;
	
	if (typeof guide === 'string') {
		let syntax = guide.replace(/{pn}/g, `${prefix}${name}`);
		return syntax.startsWith(name) ? syntax.replace(name, `${prefix}${name}`) : syntax;
	} else if (typeof guide === 'object' && guide !== null) {
		const guideObj = guide[lang] || guide["en"] || guide;
		
		if (guideObj.syntax) {
			let syntax = guideObj.syntax.replace(/{pn}/g, `${prefix}${name}`);
			return syntax.startsWith(name) ? 
				syntax.replace(name, `${prefix}${name}`) : 
				syntax;
		} else if (typeof guideObj === 'string') {
			let syntax = guideObj.replace(/{pn}/g, `${prefix}${name}`);
			return syntax.startsWith(name) ? 
				syntax.replace(name, `${prefix}${name}`) : 
				syntax;
		}
	}
	
	return `${prefix}${name}`;
}

exports.config = {
	name: "help",
	author: "Allou Mohamed",
	version: "4.2.3",
	countDown: 3,
	role: 0,
	description: {
		ar: "قائمة أوامر البوت بشكل تفاعلي",
		en: "Interactive bot commands menu"
	},
	guide: {
		ar: "اكتب help ثم قم بالرد على الفئة أو الأمر بالرقم أو الاسم",
		en: "Type help then reply with a category or command number/name"
	},
	aliases: ["أوامر", "مساعدة", "مينيوو", "menu", "الاوامر"]
};

exports.langs = {
	ar: {
		header: "__________ أوامري __________",
		choose: "↭ رد برقم الفئة التي ترغب بها ↭",
		commands: "📜 أوامر فئة %1:\n%2\n\n↩️ قم بالرد برقم أو اسم الأمر",
		guide: "📖 دليل الأمر %1:\n\n%2",
		detailedGuide: "____________________________\n↭ %1: %2\n↭ يستخدم هكذا:\n%3\n\n____________________________",
		info: "____________________________\n\t\t\t\t\t\t\t\t\t✦ ʸᵃᵐᶦ ᵛ¹.⁰ ✦\n\t\t\t\t\t\t\t↭ %1 أمر ↭",
		notFound: "❌ غير موجود",
		noCommands: "لا توجد أوامر متاحة لدورك الحالي."
	},
	en: {
		header: "🤡 | YamiBot Commands Menu",
		choose: "📂 Choose a category by replying with its number or name:",
		commands: "📜 Commands in %1:\n%2\n\n↩️ Reply with command number or name",
		guide: "📖 Command guide %1:\n\n%2",
		detailedGuide: "━━━━━━━━━━━━━━\n📖 Command: %1\n📝 Description: %2\n⚙️ Syntax: %3\n📋 Parameters: %4\n✅ Usage: %5\n━━━━━━━━━━━━━━",
		info: "━━━━━━━━━━━━━━\n🤖 Bot name: YamiBot v4\n⚙️ Version: v4.2\n👑 Developer: Allou Mohamed\n📦 Available commands: %1",
		notFound: "❌ Not found",
		noCommands: "No commands available for your role."
	}
};

function getValidCategories(basePath) {
	return fs.readdirSync(basePath).filter(f => {
		const fullPath = path.join(basePath, f);
		return fs.statSync(fullPath).isDirectory() && isUpperCaseFolder(f);
	});
}

function getCommandsInCategory(categoryPath, minRole) {
	const files = fs.readdirSync(categoryPath).filter(f => f.endsWith(".js"));
	const commands = [];
	
	for (const file of files) {
		try {
			const cmd = require(path.join(categoryPath, file));
			if (minRole >= cmd.config.role) {
				commands.push(cmd);
			}
		} catch (err) {
			console.error(`Error loading command ${file}:`, err);
		}
	}
	
	return commands;
}

exports.onStart = async function ({
	message,
	usersData,
	event,
	getLang,
	role
}) {
	const lang = await usersData.get(event.senderID, "data.lang") || "en";
	const basePath = path.join(process.cwd(), "scripts/cmds");

	const folders = getValidCategories(basePath);
	const categories = [];
	let totalCommands = 0;

	for (let i = 0; i < folders.length; i++) {
		const folder = folders[i];
		const folderPath = path.join(basePath, folder);
		const commands = getCommandsInCategory(folderPath, role);

		if (commands.length === 0) continue;

		totalCommands += commands.length;

		const displayName = lang === "ar" 
			? await translateText(folder, "ar") 
			: folder;

		categories.push(`↭ ${i + 1} <-> ${displayName}`);
	}

	if (categories.length === 0) {
		return message.reply(getLang("noCommands"));
	}

	const menuText =
		`${getLang("header")}\n\n` +
		`${getLang("choose")}\n\n` +
		categories.join("\n") +
		`\n\n` +
		getLang("info", totalCommands);

	const { messageID } = await message.send(menuText);

	YamiBot.onReply.set(messageID, {
		commandName: "help",
		action: "category",
		lang,
		role,
		folders
	});
};

exports.onReply = async function ({
	Reply,
	message,
	args,
	getLang,
	role
}) {
	const { action, lang, folders } = Reply;
	const basePath = path.join(process.cwd(), "scripts/cmds");

	if (action === "category") {
		const input = args.join(" ").toLowerCase();
		const validFolders = folders || getValidCategories(basePath);

		let category;
		const numInput = parseInt(input);

		// Check if input is a number
		if (!isNaN(numInput) && numInput > 0 && numInput <= validFolders.length) {
			category = validFolders[numInput - 1];
		} else {
			// Search by name
			for (const f of validFolders) {
				const displayName = lang === "ar" 
					? await translateText(f, "ar") 
					: f;
				
				if (displayName.toLowerCase() === input || f.toLowerCase() === input) {
					category = f;
					break;
				}
			}
		}

		if (!category) return message.reply(getLang("notFound"));

		const folderPath = path.join(basePath, category);
		const cmds = getCommandsInCategory(folderPath, role);

		if (cmds.length === 0) {
			return message.reply(getLang("notFound"));
		}

		const commandList = [];
		for (let i = 0; i < cmds.length; i++) {
			const cmd = cmds[i];
			
			// Get command name based on language
			let name;
			if (lang === "ar") {
				name = cmd.config.aliases?.[0] || cmd.config.name;
			} else {
				name = cmd.config.name;
			}

			// Get description based on language
			const desc = getCmdDesc(cmd, lang);

			commandList.push(`${i + 1}. ${name} — ${desc}`);
		}

		const categoryName = lang === "ar"
			? await translateText(category, "ar")
			: category;

		const { messageID } = await message.send(
			getLang("commands", categoryName, commandList.join("\n"))
		);

		YamiBot.onReply.set(messageID, {
			commandName: "help",
			action: "command",
			lang,
			category,
			role,
			cmds
		});
	}

	if (action === "command") {
		const input = args.join(" ").toLowerCase();
		const cmds = Reply.cmds || getCommandsInCategory(
			path.join(basePath, Reply.category), 
			role
		);

		let targetCmd;
		const numInput = parseInt(input);

		// Check if input is a number
		if (!isNaN(numInput) && numInput > 0 && numInput <= cmds.length) {
			targetCmd = cmds[numInput - 1];
		} else {
			// Search by name or alias
			for (const cmd of cmds) {
				const names = [
					cmd.config.name,
					...(cmd.config.aliases || [])
				].map(n => n.toLowerCase());

				if (names.includes(input)) {
					targetCmd = cmd;
					break;
				}
			}
		}

		if (!targetCmd) {
			return message.reply(getLang("notFound"));
		}

		// Get command name based on language
		let title;
		if (lang === "ar") {
			title = targetCmd.config.aliases?.[0] || targetCmd.config.name;
		} else {
			title = targetCmd.config.name;
		}

		const desc = getCmdDesc(targetCmd, lang);
		const syntax = getSyntax(targetCmd, lang);
		const { usage, params } = getGuideInfo(targetCmd, lang);

		const guideText = getLang(
			"detailedGuide",
			title,
			desc,
			syntax,
			params,
			usage
		);

		return message.send(guideText);
	}
};