//3.0.0
const fetch = require("node-fetch");
const { URLSearchParams } = require("url");
const axios = require("axios");

async function fetchPinterestImages(query, bookmark = null) {
  const sourceUrl = `/search/pins/?q=${encodeURIComponent(query)}&rs=rs`;

  const payload = {
    options: {
      query,
      scope: "pins",
      page_size: 50,
      bookmarks: bookmark ? [bookmark] : [],
      source_url: sourceUrl,
      rs: "rs"
    },
    context: {}
  };

  const body = new URLSearchParams();
  body.append("source_url", sourceUrl);
  body.append("data", JSON.stringify(payload));

  const res = await fetch(
    "https://www.pinterest.com/resource/BaseSearchResource/get/",
    {
      method: "POST",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Requested-With": "XMLHttpRequest",
        "X-Pinterest-AppState": "active",
        "X-Pinterest-PWS-Handler": "www/search/[scope].js",
        "X-Pinterest-Source-URL": sourceUrl,
        "X-App-Version": "c512162",
        "X-CSRFToken": "c4fb762090cb55a097900d87c3084b9d",
        "Referer": "https://www.pinterest.com/",
        "Origin": "https://www.pinterest.com",
        "Cookie": "csrftoken=c4fb762090cb55a097900d87c3084b9d"
      },
      body
    }
  );

  if (!res.ok) throw new Error(`Pinterest HTTP ${res.status}`);

  const json = await res.json();
  const resource = json.resource_response;

  const results = [];
  const nextBookmark = resource.bookmark || null;

  for (const item of resource.data.results || []) {
    if (!item.images) continue;
    results.push({
      id: item.id,
      image:
        item.images["736x"]?.url ||
        item.images["564x"]?.url ||
        ""
    });
  }

  return { results, bookmark: nextBookmark };
}

/* stream handler */
let getStream = global.utils?.getStreamFromUrl;
if (!getStream) {
  getStream = async (url) => {
    const res = await axios.get(url, { responseType: "stream" });
    return res.data;
  };
}

exports.config = {
  name: "pinv2",
  aliases: ["بينترست", "pinterest", "pin"],
  description: {
    en: "Get images from Pinterest.",
    ar: "جلب الصور من بينترست."
  },
  role: 0,
  author: "Allou Mohamed",
  countDown: 10,
  version: "1.0.2"
};

exports.langs = {
  en: {
    noQuery: "❌ Provide a search query.",
    noRange: "❌ No results in this range.",
    result: "🔎 Pinterest: %1\n📸 Images %2 → %3"
  },

  ar: {
    noQuery: "❌ يرجى إدخال عبارة للبحث.",
    noRange: "❌ لا توجد نتائج في هذا النطاق.",
    result: "🔎 بينترست: %1\n📸 الصور من %2 إلى %3"
  }
};

exports.onStart = async ({ message, args, getLang }) => {
  const raw = args.join(" ");
  if (!raw) return message.send(getLang("noQuery"));

  const cnMatch = raw.match(/--cn\s*(\d+)/i);
  const bmMatch = raw.match(/--bm\s*(\d+)/i);
  const stMatch = raw.match(/--st\s*(\d+)/i);
  const endMatch = raw.match(/--end\s*(\d+)/i);

  let st = stMatch ? Number(stMatch[1]) : 1;
  let end = endMatch ? Number(endMatch[1]) : null;

  const cn =
    cnMatch ? Number(cnMatch[1]) :
    end !== null ? end - st + 1 :
    5;

  const loops = bmMatch ? Number(bmMatch[1]) : cnToBookMark(end || cn);

  const query = raw
    .replace(/--cn\s*\d+/gi, "")
    .replace(/--bm\s*\d+/gi, "")
    .replace(/--st\s*\d+/gi, "")
    .replace(/--end\s*\d+/gi, "")
    .trim();

  let bookmark = null;
  let collected = [];

  for (let i = 0; i < loops; i++) {
    const res = await fetchPinterestImages(query, bookmark);
    collected.push(...res.results);
    bookmark = res.bookmark;
    if (!bookmark) break;
  }

  st = Math.max(1, st);
  const startIndex = st - 1;
  const endIndex = end ? end : startIndex + cn;

  const sliced = collected.slice(startIndex, endIndex);
  if (!sliced.length) return message.send(getLang("noRange"));

  const attachments = [];
  for (const img of sliced) {
    try {
      attachments.push(await getStream(img.image));
    } catch {}
  }

  return message.send({
    body: getLang(
      "result",
      query,
      st,
      startIndex + sliced.length
    ),
    attachment: attachments
  });
};

function cnToBookMark(cn) { const p = Math.ceil(cn / 46); return p < 1 ? 1 : p; }
