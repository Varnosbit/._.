const axios = require("axios");
const fs = require("fs");
const { getStreamFromURL } = global.utils;

module.exports = {
  config: {
    name: "nijiv4",
    version: "1.0",
    author: "SiAM",
    countDown: 10,
    role: 0,
    shortDescription: { en: "Generate anime image" },
    longDescription: { en: "Generate anime-style image using Niji v4" },
    category: "ai",
    guide: { en: "/nijiv4 <prompt> --ar <aspect ratio>\nExample: /nijiv4 1girl, cat ears --ar 9:16" }
  },

  onStart: async function ({ api, message, event, args, commandName }) {
    let prompt = args.join(" ");
    let aspectRatio = "1:1";

    const aspectIndex = args.indexOf("--ar");
    if (aspectIndex !== -1 && args.length > aspectIndex + 1) {
      aspectRatio = args[aspectIndex + 1];
      args.splice(aspectIndex, 2);
      prompt = args.join(" ");
    }

    if (!prompt) {
      return message.reply("Please provide a prompt to generate the image.");
    }

    const processingMessage = await message.reply("Initiating Niji process...⏳\nMight take some time..");
    message.reaction("⏰", event.messageID);

    try {
      const res = await axios.post(
        "https://simoai-niji.onrender.com/anim/generate",
        { prompt, aspectRatio },
        { headers: { "Content-Type": "application/json" } }
      );

      const { merged_image, individual_images } = res.data;

      const imgStream = await getStreamFromURL(merged_image);

      const actionText = `ACTION: [ ${individual_images.map((_, i) => `U${i + 1}`).join(" , ")} ]`;

      const sent = await message.reply({
        body: `${actionText}`,
        attachment: imgStream
      });

      global.GoatBot.onReply.set(sent.messageID, {
        commandName,
        author: event.senderID,
        images: individual_images
      });

      message.unsend(processingMessage.messageID);
      message.reaction("✅", event.messageID);
    } catch (err) {
      console.error(err);
      message.reply("Image generation failed.");
      message.reaction("❌", event.messageID);
    }
  },

  onReply: async function ({ message, event, Reply }) {
    const { author, images } = Reply;
    if (event.senderID !== author) return;

    const userSelection = event.body.trim().toUpperCase();
    if (!/^U[1-4]$/.test(userSelection)) return message.reply("Please use U1 to U4 for upscale.");

    const index = parseInt(userSelection.substring(1)) - 1;
    if (!images[index]) return message.reply("Invalid image number.");

    const imageUrl = images[index];

    const processingMessage = await message.reply("Upscaling image...⏳");
    message.reaction("⏰", event.messageID);

    try {
      const response = await axios.get(`https://simoai-niji.onrender.com/upscale?imageurl=${encodeURIComponent(imageUrl)}`, {
        responseType: 'stream'
      });

      const path = `temp_upscaled_${Date.now()}.png`;
      const writer = fs.createWriteStream(path);

      await new Promise((resolve, reject) => {
        response.data.pipe(writer);
        writer.on("finish", resolve);
        writer.on("error", reject);
      });

      await message.reply({
        body: `Upscaled image for ${userSelection}`,
        attachment: fs.createReadStream(path)
      });

      fs.unlinkSync(path);
      message.unsend(processingMessage.messageID);
      message.reaction("✅", event.messageID);
    } catch (err) {
      console.error(err);
      message.reply("Error occurred while processing the image.");
      message.reaction("❌", event.messageID);
    }
  }
};
