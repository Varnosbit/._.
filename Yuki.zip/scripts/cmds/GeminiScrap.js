const fetch = require('node-fetch');
const fs = require('fs');
const axios = require('axios');

const Cookie = "__Secure-1PSID=g.a000rAgFs7iw4oFrJm-88KVlRxlDpsxBuivzDi6_uTc18LfhLTwi9msVvzFCQt-wconW_hphRQACgYKAWASARYSFQHGX2Mivfztt9om6_AI2gceAcF5_xoVAUF8yKrTiYEt7hI3r1HWCfVXQHPS0076";

const conversations = new Map();
class Gemini {
    constructor() {
        (this.params = {
            bl: "",
            _reqid: "",
            rt: "c",
        }),
        (this.data = {
            "f.req": "",
            at: "",
        }),
        (this.post_url =
            "https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate"),
        (this.headers = this.setupHeaders());
    }
    setupHeaders() {
        return {
            Host: "gemini.google.com",
            "X-Same-Domain": "1",
            "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
            Origin: "https://gemini.google.com",
            Referer: "https://gemini.google.com/",
            Cookie
        };
    }
    extractImageUrls(data) {
        const urls = [];
        function findUrls(node) {
            if (Array.isArray(node)) {
                node.forEach(findUrls);
            } else if (typeof node === 'object' && node !== null) {
                Object.values(node).forEach(findUrls);
            } else if (typeof node === 'string' && node.startsWith('http') && /\.(jpg|png|jpeg|gif)$/.test(node)) {
                urls.push(node);
            }
        }
        findUrls(data);
        return urls;
    }

    async getImageBuffer(url) {
        if (fs.existsSync(url) && fs.lstatSync(url).isFile()) {
        return fs.readFileSync(url);
        }
      try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });

        return Buffer.from(response.data);
      } catch (error) {
        console.error('Error fetching the image:', error);
      }
    }
    
    async uploadImage(name, buffer) {
        const size = buffer.byteLength;

        try {
            const initResponse = await fetch("https://push.clients6.google.com/upload/", {
                method: "POST",
                headers: {
                    "X-Goog-Upload-Command": "start",
                    "X-Goog-Upload-Protocol": "resumable",
                    "X-Goog-Upload-Header-Content-Length": size,
                    "X-Tenant-Id": "bard-storage",
                    "Push-Id": "feeds/mcudyrk2a4khkz",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: `File name=${encodeURIComponent(name)}`,
            });

            if (!initResponse.ok) {
                throw new Error(`Failed to initialize upload: ${initResponse.statusText}`);
            }

            const uploadUrl = initResponse.headers.get("X-Goog-Upload-URL");
            if (!uploadUrl) {
                throw new Error("No upload URL received from the server.");
            }

            const uploadResponse = await fetch(uploadUrl, {
                method: "POST",
                headers: {
                    "X-Goog-Upload-Command": "upload, finalize",
                    "X-Goog-Upload-Offset": "0",
                    "X-Tenant-Id": "bard-storage",
                },
                body: buffer,
            });

            if (!uploadResponse.ok) {
                throw new Error(`Failed to upload image: ${uploadResponse.statusText}`);
            }

            return await uploadResponse.text();
        } catch (e) {
            throw new Error(
                "Could not fetch Google Bard. You may be disconnected from the internet: " + e.message
            );
        }
    }

    async question(ID, query, url) {
        const {
            choice_id = "",
            conversation_id = "",
            response_id = ""
        } = conversations.get(ID) || {};
        try {
            const response = await fetch("https://gemini.google.com/", {
                method: "GET",
                headers: this.headers,
            }),
            geminiText = await response.text(),
            snlM0e = geminiText.match(/"SNlM0e":"(.*?)"/)?.[1] || "",
            blValue = geminiText.match(/"cfb2h":"(.*?)"/)?.[1] || "";
            if (!snlM0e)
                return(
                {
                    content:
                    "Authentication Error! Ensure correct __Secure-1PSID or __Secure-3PSID value.",
                }
            );
            if (!blValue)
                return (
                {
                    content: "Value Error! Handle this case accordingly.",
                }
            );
            (this.data.at = snlM0e),
            (this.params.bl = blValue);
            let req_id = parseInt(Math.random().toString().slice(2, 6));
            const requestArray = [
                [
                    query,
                    0,
                    null,
                    url ? [[[url,
                        1],
                        "gemini-ai_upload"]]: [],
                    null,
                    null,
                    0,
                ],
                ["en"],
                [
                    conversation_id,
                    response_id,
                    choice_id,
                    null,
                    null,
                    [],
                ],
                null,
                null,
                null,
                [1],
                0,
                [],
                [],
                1,
                0,
            ];
            (this.params._reqid = String(req_id)),
            (this.data["f.req"] = JSON.stringify([
                null,
                JSON.stringify(requestArray),
            ]));
            const postData = `f.req=${encodeURIComponent(this.data["f.req"])}&at=${this.data.at}`,
            urlWithParams = `${this.post_url}?${new URLSearchParams(this.params)}`,
            responsePost = await fetch(urlWithParams, {
                method: "POST",
                headers: this.headers,
                body: postData,
            });
            if (!responsePost.ok)
                return (
                {
                    content: `Response Status: ${responsePost.status}`,
                }
            );

            const resp_dict = JSON.parse(
                (await responsePost.text()).split("\n")[3],
            )[0][2];
            if (null === resp_dict)
                return (
                {
                    content: `Response Error: ${responsePost.text}.`,
                }
            );
            const parsed_answer = JSON.parse(resp_dict);
            const images = this.extractImageUrls(parsed_answer);
            const bard_answer = {
                content: parsed_answer[4][0][1][0],
                conversation_id: parsed_answer[1][0],
                response_id: parsed_answer[1][1],
                factualityQueries: parsed_answer[3],
                textQuery: parsed_answer[2] ? parsed_answer[2][0]: "",
                choices: parsed_answer[4].map((i) => ({
                    id: i[0],
                    content: i[1],
                })),
                images
            };
            return conversations.set(ID, {
                conversation_id: bard_answer.conversation_id,
                response_id: bard_answer.response_id,
                choice_id: bard_answer.choices[0]?.id,
            }),
            (req_id += 1e5),
            bard_answer;
        } catch (error) {
            return (
                console.error(error),
                {
                    content: `Error: ${error.message}`,
                }
            );
        }
    }
}
const gemini = new Gemini();
module.exports = {
    config: {
        name: "gemini",
        aliases: ["jimmy"],
        author: "allou Mohamed",
        description: {
            ar: "تكلم مع ذكاء إصطناعي.",
            en: "chat with Gemini"
        },
        category: "ai",
        guide: {
            en: "{pn} query",
            ar: "{pn} سؤال"
        }
    },
    onStart: async function({ event, message, commandName, args, usersData }) {
        await HandleGemini(event, message, commandName, args, null, usersData);
    },
    onReply: async function({ event, message, commandName, args, Reply, usersData }) {
        await HandleGemini(event, message, commandName, args, Reply, usersData);
    }
};

async function HandleGemini(event, message, commandName, args, Reply, usersData) {
    let img = null;
    const ID = event.senderID;
    if (Reply && Reply.Alu != ID) return;
    if (args[0] == "clear") {
        conversations.delete(ID);
        return message.reply("You're chat with Gemini cleared.");
    }
    const prompt = args.length > 0 
  ? args.join(" ") 
  : (event?.messageReply?.attachments?.[0]?.url 
    ? "Identify exactly what is in this picture." 
    : "Hi, my name is " + await usersData.getName(event.senderID) + " remember it");
    if (event?.messageReply?.attachments?.[0]?.url) {
        const buffer = await gemini.getImageBuffer(event?.messageReply?.attachments?.[0]?.url);
        img = await gemini.uploadImage('gemini-ai_upload', buffer);
    }
    try {
        const res = await gemini.question(ID, prompt, img);
        if (res.content) {
            const streams = [];
            if (res.images.length > 0) {
                for (let i = 0; i < res.images.length; i++) {
                    try {
                    streams.push(await utils.getStreamFromUrl(res.images[i]));
                    } catch(e){}
                }
            }
            message.reply({body: res.content, attachment: streams}, (err, info) => {
                if (err) return message.reply("🤓 server issues, go do something else or ask owner to maintain it.");
                global.GoatBot.onReply.set(info.messageID, {
                    commandName,
                    Alu: event.senderID
                });
            });
        }
    } catch (error) {
        return message.reply("🤓 server issues, go do something else or ask owner to maintain it.");
    }
}
