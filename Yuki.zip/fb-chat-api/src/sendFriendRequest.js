"use strict";

const log = require("npmlog");

function formatRequestData(friendId, ctx) {
  return {
    av: ctx.userID,
    fb_api_caller_class: "RelayModern",
    fb_api_req_friendly_name: "FriendingCometFriendRequestSendMutation",
    doc_id: "9012643805460802",
    variables: JSON.stringify({
      input: {
        friend_requestee_ids: [friendId],
        friending_channel: "PROFILE_BUTTON",
        actor_id: ctx.userID,
        client_mutation_id: Math.round(Math.random() * 1024).toString()
      },
      scale: 3
    })
  };
}

module.exports = function (defaultFuncs, api, ctx) {
  return function sendFriendRequest(friendId, callback) {
    let resolveFunc = function () { };
    let rejectFunc = function () { };
    const returnPromise = new Promise(function (resolve, reject) {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err, data) {
        if (err) {
          return rejectFunc(err);
        }
        resolveFunc(data);
      };
    }

    const form = formatRequestData(friendId, ctx);

    defaultFuncs
      .post("https://web.facebook.com/api/graphql/", ctx.jar, form)
      .then(function (resData) {
        if (resData.errors) {
          throw resData;
        }
        return callback(null, resData);
      })
      .catch(function (err) {
        log.error("sendFriendRequest", err);
        return callback(err);
      });

    return returnPromise;
  };
};