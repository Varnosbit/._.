const axios = require("axios");

exports.onStart = async function ({ message, args, event }) {
  let userMessage = event.messageReply?.body || args.join(" ").trim();

  if (!userMessage) {
    return message.reply("Please provide a prompt to generate the image.");
  }

  let aspectRatio = "16:9", cn = 4;
  const aspectRatioMatch = userMessage.match(/--ar\s*(\d+:\d+)/);
  const cnMatch = userMessage.match(/--cn\s*(\d+)/);

  if (aspectRatioMatch) {
    aspectRatio = aspectRatioMatch[1];
    userMessage = userMessage.replace(/--ar\s*\d+:\d+/, "").trim();
  }

  if (cnMatch) {
    cn = parseInt(cnMatch[1]);
    userMessage = userMessage.replace(/--cn\s*\d+/, "").trim();
  }

  try {
    const imageLinks = [];
    if (cn > 4) message.reaction("⏳", event.messageID);

    for (let i = 0; i < cn; i++) {
      const response = await axios.get(
        `https://www.ai4chat.co/api/image/generate?prompt=${encodeURIComponent(userMessage)}&aspect_ratio=${encodeURIComponent(aspectRatio)}`
      );

      if (response.data.image_link) {
        imageLinks.push(response.data.image_link);
      } else {
        console.error(`Failed to generate image on attempt ${i + 1}`);
      }
    }

    if (imageLinks.length > 0) {
      if (cn > 4) message.reaction("✅", event.messageID);
      message.stream(imageLinks);
    } else {
      message.reply("Failed to generate images. Please try again.");
    }
  } catch (error) {
    console.error("Image generation error:", error.message);
    message.reply("An error occurred while generating the images.");
  }
};

exports.config = {
  name: "fastgen",
  aliases: ["fg"],
  role: 0,
  category: "Ai",
  countDown: 15,
  author: "Allou Mohamed",
  desc: "Fast gen imgs",
  version: "2.2"
};