const { createCanvas } = require("canvas");
module.exports = {
    config: {
        name: "analytics",
        version: "1.0.2",
        category: "info",
        role: 2,
        description: "for owner if bot ._.",
        countDown: 10,
        guid: "{pn}"
    },
    onStart: async({message, globalData}) => {
const analytics = await globalData.get("analytics");
const analyticsData = analytics.data;
const data = formatTopCommandsWithPercentage(analyticsData);
drawChart(data, message);
}
}

function formatTopCommandsWithPercentage(data) {
  const colors = [
    "#00D4FF", "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD", "#98D8C8",
    "#FF9F43", "#10AC84", "#EE5A24", "#0984E3", "#A29BFE", "#FD79A8", "#FDCB6E", "#6C5CE7",
    "#74B9FF", "#00B894", "#E17055", "#81ECEC"
  ];
  
  const total = Object.values(data).reduce((sum, value) => sum + value, 0);
  const sortedCommands = Object.entries(data)
    .sort(([, valueA], [, valueB]) => valueB - valueA)
    .slice(0, 20);
  
  const formattedData = sortedCommands.map(([label, value], index) => ({
    label,
    value,
    percentage: Math.floor((value / total) * 100),
    color: colors[index] || "#80FF00"
  }));
  
  return formattedData;
}

function drawChart(data, message) {
  const width = 1920;
  const height = 1120;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, '#0f0f23');
  gradient.addColorStop(1, '#1a1a2e');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
  ctx.lineWidth = 1;
  for (let i = 0; i < width; i += 100) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, height);
    ctx.stroke();
  }
  for (let i = 0; i < height; i += 100) {
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(width, i);
    ctx.stroke();
  }

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 48px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'left';
  ctx.shadowColor = 'rgba(0, 212, 255, 0.6)';
  ctx.shadowBlur = 20;
  ctx.fillText('Bot Command Analytics Dashboard', 80, 120);
  
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#a0a0a0';
  ctx.font = '24px "Segoe UI", Arial, sans-serif';
  ctx.fillText('Real-time user engagement metrics', 80, 160);

  const chartX = 80;
  const chartY = 240;
  const chartWidth = 1200;
  const chartHeight = 600;
  const barWidth = chartWidth / data.length;
  const maxValue = Math.max(...data.map(item => item.value));

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.lineWidth = 2;
  ctx.strokeRect(chartX, chartY, chartWidth, chartHeight);

  for (let i = 0; i <= 10; i++) {
    const y = chartY + (chartHeight / 10) * i;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(chartX, y);
    ctx.lineTo(chartX + chartWidth, y);
    ctx.stroke();
    
    ctx.fillStyle = '#666';
    ctx.font = '18px "Segoe UI", Arial, sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    const value = Math.round((maxValue / 10) * (10 - i));
    ctx.fillText(value.toString(), chartX - 20, y);
  }

  data.forEach((item, index) => {
    const barHeight = (item.value / maxValue) * chartHeight;
    const x = chartX + index * barWidth;
    const y = chartY + chartHeight - barHeight;
    
    const barGradient = ctx.createLinearGradient(x, y, x, y + barHeight);
    barGradient.addColorStop(0, item.color);
    barGradient.addColorStop(1, adjustBrightness(item.color, -30));
    
    ctx.fillStyle = barGradient;
    ctx.fillRect(x + barWidth * 0.1, y, barWidth * 0.8, barHeight);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + barWidth * 0.1, y, barWidth * 0.8, barHeight);
    
    if (barHeight > 50) {
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px "Segoe UI", Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`${item.percentage}%`, x + barWidth * 0.5, y + barHeight * 0.5);
    }
    
    ctx.save();
    ctx.translate(x + barWidth * 0.5, chartY + chartHeight + 20);
    ctx.rotate(-Math.PI / 4);
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px "Segoe UI", Arial, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    const commandName = item.label.split("-")[0];
    if (commandName.length > 12) {
      ctx.fillText(commandName.substring(0, 12) + '...', 0, 0);
    } else {
      ctx.fillText(commandName, 0, 0);
    }
    ctx.restore();
  });

  const legendX = 1360;
  const legendStartY = 240;
  const cardWidth = 480;
  const cardHeight = 38;
  let legendY = legendStartY;

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 32px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Command Breakdown', legendX, legendStartY - 40);

  const legendContainer = Math.min(data.length, 15);
  
  data.slice(0, legendContainer).forEach((item, index) => {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(legendX, legendY, cardWidth, cardHeight);
    
    ctx.strokeStyle = item.color;
    ctx.lineWidth = 3;
    ctx.strokeRect(legendX, legendY, cardWidth, cardHeight);

    ctx.fillStyle = item.color;
    ctx.fillRect(legendX + 15, legendY + 12, 24, 14);

    ctx.fillStyle = '#ffffff';
    ctx.font = '20px "Segoe UI", Arial, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    const commandName = item.label.split("-")[0];
    const displayName = commandName.length > 18 ? commandName.substring(0, 18) + '...' : commandName;
    ctx.fillText(displayName, legendX + 50, legendY + cardHeight / 2);

    ctx.fillStyle = '#a0a0a0';
    ctx.font = '18px "Segoe UI", Arial, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(`${item.value.toLocaleString()} uses`, legendX + cardWidth - 120, legendY + cardHeight / 2);

    ctx.fillStyle = item.color;
    ctx.font = 'bold 20px "Segoe UI", Arial, sans-serif';
    ctx.fillText(`${item.percentage}%`, legendX + cardWidth - 20, legendY + cardHeight / 2);

    legendY += cardHeight + 12;
  });

  if (data.length > 15) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.fillRect(legendX, legendY, cardWidth, 40);
    
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px "Segoe UI", Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`+${data.length - 15} more commands`, legendX + cardWidth / 2, legendY + 20);
    legendY += 52;
  }

  const totalUses = data.reduce((sum, item) => sum + item.value, 0);
  ctx.fillStyle = 'rgba(0, 212, 255, 0.1)';
  ctx.fillRect(legendX, legendY, cardWidth, 50);
  ctx.strokeStyle = '#00D4FF';
  ctx.lineWidth = 2;
  ctx.strokeRect(legendX, legendY, cardWidth, 50);
  
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 24px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText('Total Commands:', legendX + 20, legendY + 25);
  
  ctx.textAlign = 'right';
  ctx.fillStyle = '#00D4FF';
  ctx.font = 'bold 28px "Segoe UI", Arial, sans-serif';
  ctx.fillText(totalUses.toLocaleString(), legendX + cardWidth - 20, legendY + 25);

  const buffer = canvas.createPNGStream();
  buffer.path = "analytics_chart.png";
  message.send({ attachment: buffer });
}

function adjustBrightness(color, percent) {
  const num = parseInt(color.replace("#", ""), 16);
  const amt = Math.round(2.55 * percent);
  const R = (num >> 16) + amt;
  const G = (num >> 8 & 0x00FF) + amt;
  const B = (num & 0x0000FF) + amt;
  return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
    (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
    (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
}