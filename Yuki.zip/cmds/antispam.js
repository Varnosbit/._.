const WINDOW_MS = 5000;
const LIMIT = 5;
const MAX_WARN = 3;

module.exports.config = {
    name: "antispam",
    version: "2.6",
    author: "Allou",
    countDown: 0,
    role: 0,
    shortDescription: "Anti spam system",
    longDescription: "Warns users, stores spam data, and performs delayed kick when bot becomes admin",
    category: "system"
};

module.exports.onStart = async function () {};

module.exports.onChat = async function ({ event, message, mqtt, usersData, threadsData }) {
    const { threadID, senderID, timestamp, type } = event;
    if (type !== "message" && type !== "message_reply") return;

    const now = timestamp || Date.now();

    let spamData = await threadsData.get(threadID, "data.spam") || {};
    if (!spamData[senderID]) {
        spamData[senderID] = {
            count: 0,
            lastReset: now,
            warns: 0,
            locked: false,
            pendingKick: false,
            lastWarnTime: 0
        };
    }

    const data = spamData[senderID];

    if (data.locked) {
        await threadsData.set(threadID, spamData, "data.spam");
        return;
    }

    const threadInfo = await threadsData.get(threadID);
    const adminIDs = threadInfo.adminIDs || [];
    const botIsAdmin = adminIDs.includes(global.GoatBot.botID);

    if (data.pendingKick && botIsAdmin) {
        try {
            await mqtt.removeUserFromGroup(senderID, threadID);
            data.pendingKick = false;
            data.locked = true;
            await threadsData.set(threadID, spamData, "data.spam");
        } catch (error) {
            await message.reply(`❌ فشل تنفيذ الطرد.`);
        }
        return;
    }

    if (now - data.lastReset >= WINDOW_MS) {
        data.count = 0;
        data.lastReset = now;
    }

    data.count++;
    await threadsData.set(threadID, spamData, "data.spam");

    if (data.count > LIMIT) {
        const timeSinceLastWarn = now - data.lastWarnTime;
        
        if (timeSinceLastWarn >= 2000) {
            data.warns++;
            data.lastWarnTime = now;
            await threadsData.set(threadID, spamData, "data.spam");

            const name = await usersData.getName(senderID);
            
            if (data.warns >= MAX_WARN) {
                if (botIsAdmin) {
                    try {
                        await message.reply(
                            `⛔ ${name}\nتحذير رقم ${data.warns}/${MAX_WARN}. تم طردك بعد ${MAX_WARN} تحذيرات للإزعاج.`
                        );
                        await mqtt.removeUserFromGroup(senderID, threadID);
                        data.locked = true;
                        await threadsData.set(threadID, spamData, "data.spam");
                    } catch (error) {
                        await message.reply(`❌ فشل تنفيذ الطرد.`);
                    }
                } else {
                    data.pendingKick = true;
                    await threadsData.set(threadID, spamData, "data.spam");
                    await message.reply(
                        `⚠️ ${name}\nتحذير رقم ${data.warns}/${MAX_WARN}. وصلت للحد الأقصى. سيتم طردك عندما أصبح مشرفاً.`
                    );
                }
            } else {
                await message.reply(
                    `⚠️ ${name}\nتحذير رقم ${data.warns}/${MAX_WARN}. أرسلت ${data.count} رسالة خلال ${WINDOW_MS / 1000} ثوانٍ.`
                );
            }
        }
    }
};