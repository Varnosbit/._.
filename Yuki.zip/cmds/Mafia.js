const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const DB_PATH = path.join(__dirname, "mafiagame", "database.json");

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const availableGroupIDs = [
  "10094252270604707", "29355635377353562", "9227752777260681", "9301459426611190",
  "28703348225980440", "9075587479230439", "28739924468985551", "9250352948406018",
  "9161676927293097", "29257925920465305", "9827690807250166", "9499591600061217",
  "9541738132550024", "9667704829927404", "9643655792353007", "9347203865375607",
  "29140870055503895", "9208772235908400", "9763741193660755", "9432637010133127"
];

const ROLES = {
  mafia: {
    team: "mafia",
    name: "مافيا",
    desc: "يقتل لاعباً كل ليلة في الظلام 🌙",
    night: true,
    canKill: true,
    priority: 5,
    emoji: "🔪"
  },
  godfather: {
    team: "mafia",
    name: "عراب المافيا",
    desc: "زعيم المافيا القوي، يظهر كمواطن للشرطي 🎭",
    night: true,
    canKill: true,
    disguised: true,
    priority: 5,
    emoji: "👔"
  },
  consigliere: {
    team: "mafia",
    name: "المستشار",
    desc: "يكتشف دور أي لاعب بدقة تامة كل ليلة 🎯",
    night: true,
    ability: "precise_check",
    priority: 8,
    emoji: "🎯"
  },
  framer: {
    team: "mafia",
    name: "المزور",
    desc: "يزور لاعباً ويجعله يظهر كمافيا للشرطي 🖼️",
    night: true,
    ability: "frame",
    priority: 7,
    emoji: "🖼️"
  },
  janitor: {
    team: "mafia",
    name: "عامل النظافة",
    desc: "يخفي دور الضحية بعد موتها 🧹",
    night: true,
    ability: "clean",
    uses: 2,
    priority: 4,
    emoji: "🧹"
  },
  blackmailer: {
    team: "mafia",
    name: "المبتز",
    desc: "يبتز لاعباً ويمنعه من الكلام والتصويت نهاراً 🤫",
    night: true,
    ability: "blackmail",
    priority: 3,
    emoji: "🤫"
  },
  cop: {
    team: "citizen",
    name: "شرطي",
    desc: "يفحص لاعباً كل ليلة ليعرف إذا كان مافيا أم لا 👮",
    night: true,
    ability: "investigate",
    priority: 8,
    emoji: "👮"
  },
  sheriff: {
    team: "citizen",
    name: "عمدة",
    desc: "يفحص لاعباً ويقتله فوراً إذا كان من المافيا ⭐",
    night: true,
    ability: "sheriff_check",
    priority: 6,
    emoji: "⭐"
  },
  doctor: {
    team: "citizen",
    name: "طبيب",
    desc: "يحمي لاعباً من محاولات القتل الليلية 💊",
    night: true,
    ability: "heal",
    priority: 6,
    emoji: "💊"
  },
  bodyguard: {
    team: "citizen",
    name: "حارس شخصي",
    desc: "يحمي لاعباً ويموت بدلاً منه إذا تعرض للقتل 🛡️",
    night: true,
    ability: "bodyguard",
    priority: 6,
    emoji: "🛡️"
  },
  vigilante: {
    team: "citizen",
    name: "حارس",
    desc: "يقتل لاعباً مشبوهاً ليلاً (استخدامات محدودة) 🔫",
    night: true,
    ability: "vigi_kill",
    uses: 2,
    priority: 5,
    emoji: "🔫"
  },
  veteran: {
    team: "citizen",
    name: "محارب قديم",
    desc: "يتحصن في منزله ويقتل كل من يزوره ⚔️",
    night: true,
    ability: "alert",
    uses: 3,
    priority: 10,
    emoji: "⚔️"
  },
  lookout: {
    team: "citizen",
    name: "مراقب",
    desc: "يراقب منزل لاعب ويرى كل من يزوره ليلاً 👁️",
    night: true,
    ability: "lookout",
    priority: 9,
    emoji: "👁️"
  },
  tracker: {
    team: "citizen",
    name: "متعقب",
    desc: "يتعقب لاعباً ليرى من زار في تلك الليلة 🔎",
    night: true,
    ability: "track",
    priority: 9,
    emoji: "🔎"
  },
  escort: {
    team: "citizen",
    name: "مرافق",
    desc: "يشغل لاعباً طوال الليل ويمنعه من استخدام قدرته 💃",
    night: true,
    ability: "roleblock",
    priority: 2,
    emoji: "💃"
  },
  transporter: {
    team: "citizen",
    name: "ناقل",
    desc: "يبدل مكان لاعبين، كل من يزور أحدهما يزور الآخر 🚗",
    night: true,
    ability: "transport",
    priority: 1,
    emoji: "🚗"
  },
  mayor: {
    team: "citizen",
    name: "رئيس البلدية",
    desc: "يكشف عن نفسه نهاراً وصوته يساوي 3 أصوات 🎖️",
    night: false,
    ability: "reveal",
    uses: 1,
    priority: 0,
    emoji: "🎖️"
  },
  spy: {
    team: "citizen",
    name: "جاسوس",
    desc: "يراقب المافيا ويرى من يفحصونه أو يستهدفونه 🕵️",
    night: true,
    ability: "spy",
    priority: 9,
    emoji: "🕵️"
  },
  crusader: {
    team: "citizen",
    name: "صليبي",
    desc: "يحرس لاعباً ويهاجم أي شخص يحاول إيذاءه ⚔️🛡️",
    night: true,
    ability: "crusade",
    priority: 7,
    emoji: "⚔️🛡️"
  },
  retributionist: {
    team: "citizen",
    name: "منتقم",
    desc: "يحيي لاعباً ميتاً ليستخدم قدرته مرة واحدة فقط 💀➡️",
    night: true,
    ability: "revive",
    uses: 1,
    priority: 8,
    emoji: "💀➡️"
  },
  trapper: {
    team: "citizen",
    name: "صياد",
    desc: "ينصب فخاً مميتاً على منزل لاعب 🪤",
    night: true,
    ability: "trap",
    priority: 8,
    emoji: "🪤"
  },
  psychic: {
    team: "citizen",
    name: "عراف",
    desc: "يرى رؤيا عن لاعبين، أحدهما شرير بالتأكيد 🔮",
    night: true,
    ability: "psychic_vision",
    priority: 9,
    emoji: "🔮"
  },
  medium: {
    team: "citizen",
    name: "وسيط روحي",
    desc: "يتحدث مع روح ميت عشوائي كل ليلة 👻",
    night: true,
    ability: "seance",
    priority: 0,
    emoji: "👻"
  },
  citizen: {
    team: "citizen",
    name: "مواطن",
    desc: "مواطن عادي يصوت ويحلل ويحاول كشف المافيا 👤",
    night: false,
    priority: 0,
    emoji: "👤"
  },
  jester: {
    team: "neutral",
    name: "مهرج",
    desc: "يفوز إذا تم إقصاؤه بالتصويت! الفوز بالخسارة 🤡",
    night: false,
    win_condition: "lynched",
    priority: 0,
    emoji: "🤡"
  },
  executioner: {
    team: "neutral",
    name: "جلاد",
    desc: "لديه هدف محدد، يفوز إذا تم إقصاء هدفه 🪓",
    night: false,
    win_condition: "target_lynched",
    priority: 0,
    emoji: "🪓"
  },
  witch: {
    team: "neutral",
    name: "ساحرة",
    desc: "تسيطر على لاعب وتجبره على استهدف شخص آخر 🧙",
    night: true,
    ability: "control",
    priority: 3,
    emoji: "🧙"
  },
  survivor: {
    team: "neutral",
    name: "ناجٍ",
    desc: "يفوز إذا بقي حياً حتى النهاية، لديه دروع واقية 🦺",
    night: true,
    ability: "vest",
    uses: 4,
    win_condition: "survive",
    priority: 6,
    emoji: "🦺"
  },
  arsonist: {
    team: "neutral",
    name: "حارق",
    desc: "يشعل اللاعبين واحداً تلو الآخر ثم يحرقهم جميعاً 🔥",
    night: true,
    ability: "douse",
    win_condition: "burn_all",
    priority: 5,
    emoji: "🔥"
  },
  serial_killer: {
    team: "neutral",
    name: "قاتل متسلسل",
    desc: "يقتل كل ليلة ولا يمكن إيقافه أبداً 🔪💀",
    night: true,
    ability: "sk_kill",
    win_condition: "last_alive",
    priority: 5,
    emoji: "🔪💀"
  },
  werewolf: {
    team: "neutral",
    name: "مستذئب",
    desc: "يهاجم في الليالي الفردية ويقتل الضحية وكل زواره 🐺",
    night: true,
    ability: "maul",
    win_condition: "last_alive",
    priority: 5,
    emoji: "🐺"
  },
  amnesiac: {
    team: "neutral",
    name: "فاقد الذاكرة",
    desc: "يتذكر دور لاعب ميت ويصبح مثله تماماً ❓",
    night: true,
    ability: "remember",
    uses: 1,
    priority: 0,
    emoji: "❓"
  },
  vampire: {
    team: "vampire",
    name: "مصاص دماء",
    desc: "يحول لاعباً إلى مصاص دماء كل ليلتين 🧛",
    night: true,
    ability: "convert_vamp",
    win_condition: "vampire_majority",
    priority: 4,
    emoji: "🧛"
  },
  vampire_hunter: {
    team: "citizen",
    name: "صائد مصاصي الدماء",
    desc: "يفحص ويقتل مصاصي الدماء فوراً 🧄",
    night: true,
    ability: "vh_check",
    priority: 6,
    emoji: "🧄"
  }
};

const SHOP_ITEMS = {
  extra_life: {
    name: "حياة إضافية",
    desc: "تحميك من الموت مرة واحدة فقط! استخدام تلقائي 💝",
    price: 5000,
    emoji: "❤️",
    type: "passive"
  },
  investigation: {
    name: "تحقيق خاص",
    desc: "اكتشف دور لاعب بدقة 100% في الليل 🔍",
    price: 3000,
    emoji: "🔍",
    type: "night"
  },
  protection: {
    name: "حماية شخصية",
    desc: "احمي نفسك من القتل ليلة واحدة 🛡️",
    price: 2500,
    emoji: "🛡️",
    type: "night"
  },
  vote_power: {
    name: "قوة تصويت",
    desc: "صوتك يساوي صوتين في التصويت القادم ⚡",
    price: 4000,
    emoji: "⚡",
    type: "day"
  },
  reveal_team: {
    name: "كشف الفريق",
    desc: "اعرف فريق لاعب (مافيا/مواطن/محايد) 👥",
    price: 3500,
    emoji: "👥",
    type: "night"
  }
};

function secureRandom(min, max) {
  const range = max - min;
  const randomBytes = crypto.randomBytes(4);
  const randomValue = randomBytes.readUInt32BE(0);
  return min + (randomValue % (range + 1));
}

function secureShuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = secureRandom(0, i);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function getRandomElement(array) {
  return array[secureRandom(0, array.length - 1)];
}

function getRoleDistribution(playerCount) {
  const roles = [];
  const mafiaCount = Math.max(1, Math.floor(playerCount / 3.5));
  
  if (mafiaCount === 1) {
    roles.push(secureRandom(0, 1) === 0 ? "mafia" : "godfather");
  } else {
    roles.push("godfather");
    for (let i = 1; i < mafiaCount; i++) {
      roles.push("mafia");
    }
    if (playerCount >= 8) {
      const helpers = ["consigliere", "framer", "janitor", "blackmailer"];
      const helper = getRandomElement(helpers);
      roles[roles.length - 1] = helper;
    }
  }
  
  const guaranteedRoles = [];
  guaranteedRoles.push(secureRandom(0, 1) === 0 ? "cop" : "sheriff");
  guaranteedRoles.push("doctor");
  if (playerCount >= 7) {
    guaranteedRoles.push("vigilante");
  }
  roles.push(...guaranteedRoles);
  
  const specialRoles = [
    "bodyguard", "veteran", "lookout", "tracker", "escort", "transporter",
    "mayor", "spy", "crusader", "retributionist", "trapper", "psychic",
    "medium", "vampire_hunter"
  ];
  
  const neutralRoles = [
    "jester", "executioner", "witch", "survivor", "arsonist",
    "serial_killer", "werewolf", "amnesiac"
  ];
  
  if (playerCount >= 9) {
    roles.push("vampire");
  }
  
  const availableSpecials = secureShuffle(specialRoles);
  const availableNeutrals = secureShuffle(neutralRoles);
  
  while (roles.length < playerCount) {
    const rand = secureRandom(0, 100);
    if (rand < 20 && availableNeutrals.length > 0) {
      roles.push(availableNeutrals.pop());
    } else if (availableSpecials.length > 0) {
      roles.push(availableSpecials.pop());
    } else {
      roles.push("citizen");
    }
  }
  return secureShuffle(roles);
}

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initialDB = {
      playerStats: {},
      shopPurchases: {},
      playerRooms: {},
      playerInRoom: {},
      exchangeRate: 1.4
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialDB, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

let DB = loadDB();

if (!global.MafiaGames) {
  global.MafiaGames = {
    games: {},
    activeTimers: new Map(),
    usedGroupIDs: [],
    leaderboard: []
  };
}

function alive(g) {
  return Object.values(g.players).filter(p => p.alive);
}

function aliveMafia(g) {
  return alive(g).filter(p => {
    const role = ROLES[p.role];
    return role.team === "mafia";
  });
}

function aliveCitizen(g) {
  return alive(g).filter(p => {
    const role = ROLES[p.role];
    return role.team === "citizen";
  });
}

function aliveNeutral(g) {
  return alive(g).filter(p => {
    const role = ROLES[p.role];
    return role.team === "neutral" || role.team === "vampire";
  });
}

function aliveVampires(g) {
  return alive(g).filter(p => {
    const role = ROLES[p.role];
    return role.team === "vampire" || p.convertedToVampire;
  });
}

function getPlayerByIndex(g, index) {
  const players = alive(g);
  if (index < 1 || index > players.length) return null;
  return players[index - 1];
}

function getAvailableGroupID() {
  const used = global.MafiaGames.usedGroupIDs || [];
  const available = availableGroupIDs.filter(id => !used.includes(id));
  if (available.length === 0) {
    throw new Error("❌ لا توجد غرف متاحة حالياً! حاول لاحقاً");
  }
  return available[0];
}

function markGroupIDUsed(groupID) {
  if (!global.MafiaGames.usedGroupIDs.includes(groupID)) {
    global.MafiaGames.usedGroupIDs.push(groupID);
  }
}

function releaseGroupID(groupID) {
  global.MafiaGames.usedGroupIDs = global.MafiaGames.usedGroupIDs.filter(id => id !== groupID);
}

function clearAllTimers(gameID) {
  if (global.MafiaGames.activeTimers.has(gameID)) {
    const timers = global.MafiaGames.activeTimers.get(gameID);
    timers.forEach(timer => clearTimeout(timer));
    global.MafiaGames.activeTimers.delete(gameID);
  }
}

function addTimer(gameID, timer) {
  if (!global.MafiaGames.activeTimers.has(gameID)) {
    global.MafiaGames.activeTimers.set(gameID, []);
  }
  global.MafiaGames.activeTimers.get(gameID).push(timer);
}

function getPlayerRoom(userID) {
  if (!DB.playerRooms) DB.playerRooms = {};
  return DB.playerRooms[userID] || null;
}

function savePlayerRoom(userID, groupID) {
  if (!DB.playerRooms) DB.playerRooms = {};
  DB.playerRooms[userID] = groupID;
  if (!DB.playerInRoom) DB.playerInRoom = {};
  DB.playerInRoom[userID] = groupID;
  saveDB(DB);
}

function removePlayerFromRoom(userID) {
  if (!DB.playerInRoom) DB.playerInRoom = {};
  delete DB.playerInRoom[userID];
  saveDB(DB);
}

function initPlayerStats(userID) {
  if (!DB.playerStats) DB.playerStats = {};
  if (!DB.playerStats[userID]) {
    DB.playerStats[userID] = {
      gamesPlayed: 0,
      wins: 0,
      losses: 0,
      kills: 0,
      deaths: 0,
      correctVotes: 0,
      wrongVotes: 0,
      survivalRate: 0,
      winRate: 0,
      money: 0,
      points: 0
    };
  }
  return DB.playerStats[userID];
}

function updatePlayerStats(userID, updates) {
  const stats = initPlayerStats(userID);
  Object.assign(stats, updates);
  if (stats.gamesPlayed > 0) {
    stats.winRate = ((stats.wins / stats.gamesPlayed) * 100).toFixed(1);
    stats.survivalRate = (((stats.gamesPlayed - stats.deaths) / stats.gamesPlayed) * 100).toFixed(1);
  }
  saveDB(DB);
  return stats;
}

function awardPlayer(userID, money, points, reason, usersData) {
  const stats = initPlayerStats(userID);
  stats.money += money;
  stats.points += points;
  if (money > 0) {
    usersData.addMoney(userID, money);
  }
  saveDB(DB);
  return { money, points, reason };
}

function updateLeaderboard() {
  if (!DB.playerStats) return;
  const entries = Object.entries(DB.playerStats).map(([id, stats]) => ({
    userID: id,
    score: calculatePlayerScore(stats),
    wins: stats.wins,
    winRate: parseFloat(stats.winRate) || 0,
    points: stats.points
  }));
  global.MafiaGames.leaderboard = entries.sort((a, b) => b.score - a.score).slice(0, 15);
}

function calculatePlayerScore(stats) {
  return (stats.wins * 15) + 
         (stats.kills * 8) + 
         (stats.correctVotes * 5) - 
         (stats.wrongVotes * 3) +
         (stats.points * 2);
}

async function showLeaderboard(mqtt, threadID, usersData) {
  if (!global.MafiaGames.leaderboard || global.MafiaGames.leaderboard.length === 0) {
    return mqtt.sendMessage("📊 لا توجد إحصائيات بعد! كن أول من يلعب 🎮", threadID);
  }
  let msg = `🏆 لوحة الشرف - أفضل اللاعبين 🏆
━━━━━━━━━━━━━━━━━━

`;
  const medals = ["🥇", "🥈", "🥉"];
  for (let i = 0; i < Math.min(global.MafiaGames.leaderboard.length, 10); i++) {
    const entry = global.MafiaGames.leaderboard[i];
    const name = await usersData.getName(entry.userID);
    const medal = medals[i] || `${i + 1}️⃣`;
    msg += `${medal} ${name}\n`;
    msg += `   💫 نقاط: ${entry.score} | 🏅 فوز: ${entry.wins} | 📈 ${entry.winRate}%\n\n`;
  }
  msg += `━━━━━━━━━━━━━━━━━━
💡 نصيحة: اربح المزيد من الألعاب لتتصدر القائمة!`;
  await mqtt.sendMessage(msg, threadID);
}

async function showPlayerStats(mqtt, userID, threadID, usersData) {
  const stats = initPlayerStats(userID);
  const name = await usersData.getName(userID);
  let msg = `📊 إحصائيات ${name} 📊
━━━━━━━━━━━━━━━━━━

🎮 الألعاب: ${stats.gamesPlayed}
🏆 انتصارات: ${stats.wins} 🔥
💔 هزائم: ${stats.losses}
📈 نسبة فوز: ${stats.winRate}% ${stats.winRate >= 50 ? "🌟" : ""}
💪 نسبة نجاة: ${stats.survivalRate}% ${stats.survivalRate >= 60 ? "🛡️" : ""}
🔪 قتلى: ${stats.kills}
✅ تصويت صحيح: ${stats.correctVotes}
❌ تصويت خاطئ: ${stats.wrongVotes}
💰 المال: ${stats.money.toLocaleString()}
⭐ النقاط: ${stats.points.toLocaleString()}
`;
  const rank = global.MafiaGames.leaderboard.findIndex(e => e.userID === userID) + 1;
  if (rank > 0) {
    msg += `\n🏅 ترتيبك: #${rank}`;
    if (rank <= 3) {
      msg += ` ${rank === 1 ? "👑" : rank === 2 ? "🥈" : "🥉"}`;
    }
  } else {
    msg += `\n📍 ترتيبك: غير مصنف بعد`;
  }
  msg += `\n\n━━━━━━━━━━━━━━━━━━
💡 استمر في اللعب لتحسين إحصائياتك!`;
  await mqtt.sendMessage(msg, threadID);
}

function getPlayerPurchases(userID) {
  if (!DB.shopPurchases) DB.shopPurchases = {};
  if (!DB.shopPurchases[userID]) {
    DB.shopPurchases[userID] = {};
  }
  return DB.shopPurchases[userID];
}

function addPurchaseToInventory(userID, itemKey) {
  const purchases = getPlayerPurchases(userID);
  if (!purchases[itemKey]) {
    purchases[itemKey] = { count: 0 };
  }
  purchases[itemKey].count++;
  saveDB(DB);
}

function removePurchaseFromInventory(userID, itemKey) {
  const purchases = getPlayerPurchases(userID);
  if (purchases[itemKey] && purchases[itemKey].count > 0) {
    purchases[itemKey].count--;
    if (purchases[itemKey].count === 0) {
      delete purchases[itemKey];
    }
    saveDB(DB);
    return true;
  }
  return false;
}

function hasPurchase(userID, itemKey) {
  const purchases = getPlayerPurchases(userID);
  return purchases[itemKey] && purchases[itemKey].count > 0;
}

async function showShop(mqtt, userID, threadID, usersData, commandName) {
  const stats = initPlayerStats(userID);
  const purchases = getPlayerPurchases(userID);
  let msg = `🛒 المتجر - قدرات خاصة 🛒
━━━━━━━━━━━━━━━━━━

💰 رصيدك: ${stats.money.toLocaleString()} 
⭐ نقاطك: ${stats.points.toLocaleString()}

🎁 المنتجات المتاحة:
━━━━━━━━━━━━━━━━━━

`;
  let index = 1;
  for (const [key, item] of Object.entries(SHOP_ITEMS)) {
    msg += `${index}. ${item.emoji} ${item.name}\n`;
    msg += `   📝 ${item.desc}\n`;
    msg += `   💵 السعر: ${item.price.toLocaleString()} 💰\n`;
    if (purchases[key] && purchases[key].count > 0) {
      msg += `   ✅ لديك: ${purchases[key].count}\n`;
    }
    msg += `\n`;
    index++;
  }
  msg += `━━━━━━━━━━━━━━━━━━

💱 سعر الصرف: ${DB.exchangeRate} نقطة = 1 💰

📌 للشراء: رد برقم المنتج
📦 للمخزون: اكتب "جرد"
💸 للصرف: اكتب "صرف + عدد النقاط"

مثال: صرف 1000`;
  const { messageID } = await mqtt.sendMessage(msg, threadID);
  global.YamiBot.onReply.set(messageID, {
    commandName: commandName,
    type: "shop_menu",
    userID: userID
  });
}

async function handleShopPurchase(Reply, event, mqtt, usersData) {
  const userID = Reply.userID;
  const input = event.body.trim();
  if (input === "جرد" || input === "المخزون") {
    return showInventory(mqtt, userID, event.threadID, usersData, Reply.commandName);
  }
  if (input.startsWith("بيع ")) {
    const itemNum = parseInt(input.split(" ")[1]);
    return handleSell(mqtt, userID, event.threadID, itemNum, usersData);
  }
  if (input.startsWith("صرف ")) {
    const points = parseInt(input.split(" ")[1]);
    return handleExchange(mqtt, userID, event.threadID, points, usersData);
  }
  const itemIndex = parseInt(input) - 1;
  const items = Object.keys(SHOP_ITEMS);
  if (itemIndex < 0 || itemIndex >= items.length) {
    return mqtt.sendMessage("❌ رقم خاطئ! استخدم الأرقام من القائمة 🔢", event.threadID);
  }
  const itemKey = items[itemIndex];
  const item = SHOP_ITEMS[itemKey];
  const stats = initPlayerStats(userID);
  if (stats.money < item.price) {
    return mqtt.sendMessage(
      `💸 رصيدك غير كافٍ!\n\n💵 السعر: ${item.price.toLocaleString()} 💰\n💰 رصيدك: ${stats.money.toLocaleString()} 💰\n\n💡 اربح المزيد من الألعاب أو اصرف نقاطك!`, 
      event.threadID
    );
  }
  stats.money -= item.price;
  addPurchaseToInventory(userID, itemKey);
  updatePlayerStats(userID, stats);
  await mqtt.sendMessage(
    `✅ تم الشراء بنجاح! 🎉\n\n${item.emoji} ${item.name}\n\n💸 دفعت: ${item.price.toLocaleString()} 💰\n💰 الرصيد المتبقي: ${stats.money.toLocaleString()} 💰\n\n📦 تحقق من مخزونك: اكتب "جرد"`, 
    event.threadID
  );
}

async function showInventory(mqtt, userID, threadID, usersData, commandName) {
  const purchases = getPlayerPurchases(userID);
  const stats = initPlayerStats(userID);
  let msg = `📦 مخزونك 📦
━━━━━━━━━━━━━━━━━━

💰 رصيدك: ${stats.money.toLocaleString()}
⭐ نقاطك: ${stats.points.toLocaleString()}

🎁 المشتريات:
━━━━━━━━━━━━━━━━━━

`;
  const items = Object.entries(purchases).filter(([key, data]) => data.count > 0);
  if (items.length === 0) {
    msg += `❌ لا توجد مشتريات بعد!\n\n💡 زر المتجر لشراء قدرات خاصة 🛒`;
  } else {
    let index = 1;
    for (const [key, data] of items) {
      const item = SHOP_ITEMS[key];
      msg += `${index}. ${item.emoji} ${item.name}\n`;
      msg += `   📊 العدد: ${data.count}\n`;
      msg += `   💵 قيمة البيع: ${Math.floor(item.price * 0.7).toLocaleString()} 💰\n\n`;
      index++;
    }
    msg += `━━━━━━━━━━━━━━━━━━\n\n📌 للبيع: بيع + رقم\n   مثال: بيع 1`;
  }
  msg += `\n\n💱 للصرف: صرف + عدد النقاط\n   مثال: صرف 1000\n\n💡 سعر الصرف: ${DB.exchangeRate} نقطة = 1 💰`;
  const { messageID } = await mqtt.sendMessage(msg, threadID);
  global.YamiBot.onReply.set(messageID, {
    commandName: commandName,
    type: "shop_menu",
    userID: userID
  });
}

async function handleSell(mqtt, userID, threadID, itemNum, usersData) {
  const purchases = getPlayerPurchases(userID);
  const items = Object.entries(purchases).filter(([key, data]) => data.count > 0);
  if (itemNum < 1 || itemNum > items.length) {
    return mqtt.sendMessage("❌ رقم خاطئ! حاول مرة أخرى 🔢", threadID);
  }
  const [itemKey, data] = items[itemNum - 1];
  const item = SHOP_ITEMS[itemKey];
  const sellPrice = Math.floor(item.price * 0.7);
  if (!removePurchaseFromInventory(userID, itemKey)) {
    return mqtt.sendMessage("❌ فشل البيع! حاول مرة أخرى", threadID);
  }
  const stats = initPlayerStats(userID);
  stats.money += sellPrice;
  updatePlayerStats(userID, stats);
  await mqtt.sendMessage(
    `✅ تم البيع بنجاح! 💸\n\n${item.emoji} ${item.name}\n\n💰 حصلت على: ${sellPrice.toLocaleString()} 💰\n💵 الرصيد الحالي: ${stats.money.toLocaleString()} 💰`,
    threadID
  );
}

async function handleExchange(mqtt, userID, threadID, points, usersData) {
  if (isNaN(points) || points < 1) {
    return mqtt.sendMessage("❌ عدد نقاط غير صحيح! أدخل رقماً صحيحاً 🔢", threadID);
  }
  const stats = initPlayerStats(userID);
  if (stats.points < points) {
    return mqtt.sendMessage(
      `❌ ليس لديك نقاط كافية!\n\n⭐ نقاطك: ${stats.points.toLocaleString()}\n💡 احتجت: ${points.toLocaleString()}`, 
      threadID
    );
  }
  const money = Math.floor(points / DB.exchangeRate);
  if (money < 1) {
    return mqtt.sendMessage(
      `❌ تحتاج ${DB.exchangeRate} نقطة على الأقل للصرف!\n\n⭐ نقاطك: ${stats.points.toLocaleString()}`, 
      threadID
    );
  }
  const actualPoints = money * DB.exchangeRate;
  stats.points -= actualPoints;
  stats.money += money;
  updatePlayerStats(userID, stats);
  await mqtt.sendMessage(
    `✅ تم الصرف بنجاح! 💱\n\n⭐ صرفت: ${actualPoints.toLocaleString()} نقطة\n💰 حصلت على: ${money.toLocaleString()} 💰\n\n━━━━━━━━━━━━━━━━━━\n⭐ النقاط المتبقية: ${stats.points.toLocaleString()}\n💵 الرصيد الحالي: ${stats.money.toLocaleString()} 💰`,
    threadID
  );
}

async function listPlayers(g, usersData, showStatus = true) {
  const players = alive(g);
  const list = [];
  for (let i = 0; i < players.length; i++) {
    const p = players[i];
    const name = await usersData.getName(p.userID);
    let line = `${i + 1}. ${name}`;
    if (showStatus) {
      const statuses = [];
      if (p.blackmailed) statuses.push("🤫");
      if (p.roleblocked) statuses.push("💤");
      if (p.protected) statuses.push("🛡️");
      if (statuses.length > 0) {
        line += ` ${statuses.join(" ")}`;
      }
    }
    list.push(line);
  }
  return list.join("\n");
}

async function listPlayersWithRoles(g, usersData) {
  const list = [];
  const players = Object.values(g.players);
  for (let i = 0; i < players.length; i++) {
    const p = players[i];
    const name = await usersData.getName(p.userID);
    const status = p.alive ? "✅" : "☠️";
    const roleData = ROLES[p.role];
    let displayRole = `${roleData.emoji} ${roleData.name}`;
    if (p.convertedToVampire) {
      displayRole += " 🧛 (مصاص دماء)";
    }
    list.push(`${i + 1}. ${name} ${status} - ${displayRole}`);
  }
  return list.join("\n");
}

function formatGameStatus(g) {
  const alive_count = alive(g).length;
  const mafia_count = aliveMafia(g).length;
  const citizen_count = aliveCitizen(g).length;
  const neutral_count = aliveNeutral(g).length;
  let status = `📊 حالة اللعبة
━━━━━━━━━━━━━━━━━━

👥 أحياء: ${alive_count}
🔴 مافيا: ${mafia_count}
🔵 مواطنون: ${citizen_count}`;
  if (neutral_count > 0) {
    status += `\n⚪ محايدون: ${neutral_count}`;
  }
  status += `\n📅 اليوم: ${g.day}`;
  return status;
}

function formatPhaseMessage(phase, day) {
  const phases = {
    night: `🌙 الليلة ${day} 🌙
━━━━━━━━━━━━━━━━━━
🌑 المافيا تتحرك في الظلام...
🔪 احذر من حولك!`,
    day: `☀️ النهار ${day} ☀️
━━━━━━━━━━━━━━━━━━
💬 وقت النقاش والتحليل
🕵️ ابحث عن المشبوهين!`,
    voting: `🗳️ التصويت - اليوم ${day} 🗳️
━━━━━━━━━━━━━━━━━━
⚖️ من المشبوه؟
🎯 اختر بحكمة!`
  };
  return phases[phase] || "";
}

async function createGameReport(g, winner, usersData) {
  let report = `🎭 انتهت اللعبة! 🎭
━━━━━━━━━━━━━━━━━━

`;
  if (winner === "mafia") {
    report += `🔴 فريق المافيا انتصر! 🔪\n🌑 سيطروا على المدينة بالخوف\n\n`;
  } else if (winner === "citizen") {
    report += `🔵 فريق المواطنين انتصر! 👮\n☀️ عاد الأمان للمدينة\n\n`;
  } else if (winner === "neutral") {
    report += `⚪ فوز محايد مثير! 🎯\n🎭 حقق هدفه الخاص\n\n`;
  } else if (winner === "vampire") {
    report += `🟣 مصاصو الدماء انتصروا! 🧛\n🌙 سيطروا على المدينة بالظلام\n\n`;
  } else if (winner === "cancelled") {
    report += `❌ تم إلغاء اللعبة\n\n`;
  }
  report += `📜 الأدوار الكاملة:
━━━━━━━━━━━━━━━━━━

`;
  report += await listPlayersWithRoles(g, usersData);
  report += `\n\n━━━━━━━━━━━━━━━━━━`;
  report += `\n📅 إجمالي الأيام: ${g.day}`;
  report += `\n⏱️ المدة: ${Math.floor((Date.now() - g.createdAt) / 60000)} دقيقة`;
  return report;
}


function checkGameEnd(g) {
  const alivePlayers = alive(g);
  const mafia = aliveMafia(g);
  const citizen = aliveCitizen(g);
  const neutral = aliveNeutral(g);
  const vampires = aliveVampires(g);
  if (alivePlayers.length === 0) {
    return { ended: true, winner: "draw" };
  }
  if (vampires.length >= alivePlayers.length / 2 && vampires.length > 0) {
    return { ended: true, winner: "vampire" };
  }
  if (mafia.length >= citizen.length + neutral.length - vampires.length && mafia.length > 0) {
    return { ended: true, winner: "mafia" };
  }
  if (mafia.length === 0 && vampires.length === 0) {
    const sk = alivePlayers.find(p => p.role === "serial_killer");
    const ww = alivePlayers.find(p => p.role === "werewolf");
    const arson = alivePlayers.find(p => p.role === "arsonist");
    if (alivePlayers.length === 1 && (sk || ww || arson)) {
      return { ended: true, winner: "neutral", specialPlayer: sk || ww || arson };
    }
    return { ended: true, winner: "citizen" };
  }
  return { ended: false };
}

async function cleanup(mqtt, g) {
  g.phase = "ended";
  clearAllTimers(g.id);
  for (const [userID, groupID] of Object.entries(g.playerGroups)) {
    try {
      releaseGroupID(groupID);
      await mqtt.removeUserFromGroup(userID, groupID);
      removePlayerFromRoom(userID);
    } catch (err) {
      console.error(`[MAFIA42] Failed to remove ${userID}:`, err);
    }
    await sleep(1500);
  }
  delete global.MafiaGames.games[g.id];
  if (global.YamiBot.onReply) {
    for (const [msgID, data] of global.YamiBot.onReply.entries()) {
      if (data.gameID === g.id) {
        global.YamiBot.onReply.delete(msgID);
      }
    }
  }
}

async function onLoad({ api }) {
  DB = loadDB();
  console.log("[MAFIA42] 🎮 Database loaded");
  console.log(`[MAFIA42] 🎯 Active games: ${Object.keys(global.MafiaGames.games).length}`);
  if (DB.playerInRoom) {
    for (const [userID, groupID] of Object.entries(DB.playerInRoom)) {
      try {
        await api.removeUserFromGroup(userID, groupID);
        console.log(`[MAFIA42] 🧹 Removed ${userID} from room ${groupID}`);
      } catch (err) {
        console.error(`[MAFIA42] Failed to remove ${userID}:`, err);
      }
      await sleep(1000);
    }
    DB.playerInRoom = {};
    saveDB(DB);
  }
}

async function onStart({ mqtt, event, usersData, commandName, args, role }) {
  if (args && args.length > 0) {
    const command = args[0].toLowerCase();
    if (command === "end" && role > 1) {
      return handleGameEnd_Command(mqtt, event.threadID, usersData);
    }
    if (command === "لوحة_الشرف" || command === "leaderboard") {
      return showLeaderboard(mqtt, event.threadID, usersData);
    }
    if (command === "احصائياتي" || command === "stats") {
      return showPlayerStats(mqtt, event.senderID, event.threadID, usersData);
    }
    if (command === "متجر" || command === "shop") {
      return showShop(mqtt, event.senderID, event.threadID, usersData, commandName);
    }
    if (command === "مخزوني" || command === "inventory") {
      return showInventory(mqtt, event.senderID, event.threadID, usersData, commandName);
    }
    if (command === "مساعدة" || command === "help") {
      return sendGameHelp(mqtt, event.threadID);
    }
    if (command === "قواعد" || command === "rules") {
      return sendGameRules(mqtt, event.threadID);
    }
  }
  if (role < 1) return;
  const existingGame = Object.values(global.MafiaGames.games).find(
    g => g.main === event.threadID && g.phase !== "ended"
  );
  if (existingGame) {
    return mqtt.sendMessage("⚠️ يوجد لعبة نشطة بالفعل في هذه المجموعة! 🎮\nانتظر حتى تنتهي أو استخدم مجموعة أخرى 🔄", event.threadID);
  }
  const id = Date.now().toString() + secureRandom(1000, 9999);
  global.MafiaGames.games[id] = {
    id,
    main: event.threadID,
    phase: "join",
    joinable: true,
    players: {},
    pendingPlayers: {},
    playerGroups: {},
    day: 0,
    votes: {},
    nightActions: {},
    history: [],
    commandName: commandName,
    createdAt: Date.now(),
    voteLocked: {},
    mayorRevealed: false
  };
  const text = `🎭 Mafia42 - لعبة الخداع الاجتماعية 🎭
━━━━━━━━━━━━━━━━━━

🎮 لعبة استراتيجية مثيرة وممتعة!

━━━━━━━━━━━━━━━━━━

⚔️ الفرق:
🔴 فريق المافيا (1 لكل 3.5 لاعب)
🔵 فريق المواطنين (الأغلبية)
⚪ محايدون (أهداف خاصة ومثيرة)
🟣 مصاصو دماء (من 9+ لاعبين)

━━━━━━━━━━━━━━━━━━

⏱️ الوقت: 3 دقائق للانضمام
👥 اللاعبون: 6-12 لاعب
🎭 الأدوار: 30+ دور متنوع ومختلف!

━━━━━━━━━━━━━━━━━━

✨ الميزات الخاصة:
🛒 متجر قدرات خاصة
💱 نظام نقاط محسّن (100 نقطة = 1 💰)
💸 بيع وشراء القدرات
🎯 أدوار جديدة ومثيرة
📱 رسائل محسنة وملونة
🎁 مكافآت سخية

━━━━━━━━━━━━━━━━━━

📌 خطوات الانضمام:
1️⃣ أرسل طلب صداقة للبوت ✅
2️⃣ أرسل رسالة خاصة للبوت 💬
3️⃣ ضع ريأكشن هنا للانضمام 👍
4️⃣ انتظر حتى ينتهي الوقت ⏳

━━━━━━━━━━━━━━━━━━

⏰ ابدأ الآن! الوقت يمضي... 🚀`;
  const { messageID } = await mqtt.sendMessage(text, event.threadID);
  global.YamiBot.onReaction.set(messageID, {
    commandName,
    gameID: id,
    type: "join"
  });
  joinTimer(mqtt, id, usersData);
}

async function handleGameEnd_Command(mqtt, threadID, usersData) {
  const g = Object.values(global.MafiaGames.games).find(
    game => game.main === threadID && game.phase !== "ended"
  );
  if (!g) {
    return mqtt.sendMessage("❌ لا توجد لعبة نشطة في هذه المجموعة!", threadID);
  }
  await mqtt.sendMessage("⚠️ تم إنهاء اللعبة بواسطة المشرف!", g.main);
  const report = await createGameReport(g, "cancelled", usersData);
  await mqtt.sendMessage(report, g.main);
  await cleanup(mqtt, g);
}

function joinTimer(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const timer1 = setTimeout(async () => {
    if (g.joinable) {
      const count = Object.keys(g.pendingPlayers).length;
      await mqtt.sendMessage(
        `⏰ تبقى 90 ثانية للانضمام! ⏰\n━━━━━━━━━━━━━━━━━━\n👥 المنتظرون حالياً: ${count} لاعب\n\n💡 ضع ريأكشن للانضمام الآن! 🚀`, 
        g.main
      );
    }
  }, 90000);
  const timer2 = setTimeout(async () => {
    if (g.joinable) {
      const count = Object.keys(g.pendingPlayers).length;
      await mqtt.sendMessage(
        `⚠️ تبقى 30 ثانية فقط! آخر فرصة! ⚠️\n━━━━━━━━━━━━━━━━━━\n👥 المنتظرون حالياً: ${count} لاعب\n\n🔥 انضم الآن قبل فوات الأوان! ⏳`, 
        g.main
      );
    }
  }, 150000);
  const timer3 = setTimeout(() => {
    g.joinable = false;
    processPendingPlayers(mqtt, gameID, usersData);
  }, 180000);
  addTimer(gameID, timer1);
  addTimer(gameID, timer2);
  addTimer(gameID, timer3);
}

async function joinGame(mqtt, event, gameID, usersData, api) {
  const g = global.MafiaGames.games[gameID];
  if (!g || !g.joinable) {
    return;
  }
  const userID = event.userID;
  if (g.pendingPlayers[userID] || g.players[userID]) {
    return;
  }
  if (Object.keys(g.pendingPlayers).length >= 12) {
    return mqtt.sendMessage("❌ اللعبة ممتلئة! (12 لاعب) 😔\nحاول في اللعبة القادمة 🔄", event.threadID);
  }
  g.pendingPlayers[userID] = {
    userID,
    joinedAt: Date.now()
  };
}

async function processPendingPlayers(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const pendingIDs = Object.keys(g.pendingPlayers);
  const playerCount = pendingIDs.length;
  if (playerCount < 6) {
    await mqtt.sendMessage(
      `❌ عدد اللاعبين غير كافٍ ❌
━━━━━━━━━━━━━━━━━━

👥 اللاعبون المنتظرون: ${playerCount}
📊 الحد الأدنى المطلوب: 6 لاعبين

😔 تم إلغاء اللعبة للأسف
💡 حاول مرة أخرى مع المزيد من الأصدقاء!`, 
      g.main
    );
    delete global.MafiaGames.games[gameID];
    return;
  }
  await mqtt.sendMessage(
    `⚙️ جاري الإعداد... ⚙️
━━━━━━━━━━━━━━━━━━

👥 عدد اللاعبين: ${playerCount}
🔄 جاري إدخال اللاعبين للغرف الخاصة...
⏳ انتظر قليلاً...`,
    g.main
  );
  const successful = [];
  const failed = [];
  for (const userID of pendingIDs) {
    try {
      let groupID = getPlayerRoom(userID);
      if (!groupID || global.MafiaGames.usedGroupIDs.includes(groupID)) {
        groupID = getAvailableGroupID();
      }
      markGroupIDUsed(groupID);
      await global.YamiBot.fcaApi.addUserToGroup(userID, groupID);
      g.players[userID] = {
        userID,
        groupID,
        role: null,
        alive: true,
        protected: false,
        blackmailed: false,
        roleblocked: false,
        framed: false,
        convertedToVampire: false,
        abilities: {},
        joinedAt: Date.now(),
        purchasedItems: {}
      };
      g.playerGroups[userID] = groupID;
      savePlayerRoom(userID, groupID);
      successful.push(userID);
      await sleep(1500);
    } catch (err) {
      console.error(`[MAFIA42] Failed to add ${userID}:`, err);
      failed.push(userID);
      const groupID = g.playerGroups[userID];
      if (groupID) {
        releaseGroupID(groupID);
      }
    }
  }
  g.pendingPlayers = {};
  let resultMsg = `✅ نتائج الانضمام ✅
━━━━━━━━━━━━━━━━━━

`;
  if (successful.length > 0) {
    resultMsg += `✅ تم إدخال ${successful.length} لاعب بنجاح! 🎉\n\n`;
    for (let i = 0; i < Math.min(successful.length, 10); i++) {
      const name = await usersData.getName(successful[i]);
      resultMsg += `${i + 1}. ${name} ✅\n`;
    }
    if (successful.length > 10) {
      resultMsg += `... و ${successful.length - 10} آخرين ✅\n`;
    }
    resultMsg += `\n`;
  }
  if (failed.length > 0) {
    resultMsg += `❌ فشل إدخال ${failed.length} لاعب 😔\n\n`;
    for (let i = 0; i < Math.min(failed.length, 5); i++) {
      const name = await usersData.getName(failed[i]);
      resultMsg += `${i + 1}. ${name} ❌\n`;
    }
    if (failed.length > 5) {
      resultMsg += `... و ${failed.length - 5} آخرين ❌\n`;
    }
    resultMsg += `\n⚠️ السبب المحتمل:\n`;
    resultMsg += `• لم يرسلوا طلب صداقة للبوت\n`;
    resultMsg += `• لم يرسلوا رسالة خاصة للبوت\n`;
    resultMsg += `• حظروا البوت من المراسلة\n\n`;
    resultMsg += `💡 تأكدوا من إرسال طلب صداقة ورسالة!`;
  }
  await mqtt.sendMessage(resultMsg, g.main);
  const finalCount = Object.keys(g.players).length;
  if (finalCount < 6) {
    await mqtt.sendMessage(
      `❌ العدد غير كافٍ بعد الفشل ❌
━━━━━━━━━━━━━━━━━━

👥 اللاعبون الناجحون: ${finalCount}
📊 الحد الأدنى المطلوب: 6 لاعبين

😔 تم إلغاء اللعبة للأسف
💡 حاول مرة أخرى واتبع التعليمات!`, 
      g.main
    );
    await cleanup(mqtt, g);
    return;
  }
  await sleep(2000);
  startGame(mqtt, gameID, usersData);
}

async function startGame(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const playerCount = Object.keys(g.players).length;
  assignRoles(g, playerCount);
  for (const userID of Object.keys(g.players)) {
    initPlayerStats(userID);
  }
  await sendRoles(mqtt, g, usersData);
  const mafiaCount = aliveMafia(g).length;
  await mqtt.sendMessage(
    `🎉 بدأت اللعبة! استعدوا! 🎉
━━━━━━━━━━━━━━━━━━

👥 عدد اللاعبين: ${playerCount}
🔴 عدد المافيا: ${mafiaCount}
🎲 تم توزيع الأدوار عشوائياً!

━━━━━━━━━━━━━━━━━━

${formatGameStatus(g)}

━━━━━━━━━━━━━━━━━━

🌙 الليلة الأولى ستبدأ بعد 10 ثواني...
🤫 استعدوا للخداع والمكر! 😈`, 
    g.main
  );
  setTimeout(() => {
    startNightPhase(mqtt, gameID, usersData);
  }, 10000);
}

function assignRoles(g, playerCount) {
  const playerIDs = secureShuffle(Object.keys(g.players));
  const roles = getRoleDistribution(playerCount);
  playerIDs.forEach((id, i) => {
    const role = roles[i];
    g.players[id].role = role;
    const roleData = ROLES[role];
    if (roleData.uses) {
      g.players[id].abilities[roleData.ability] = roleData.uses;
    }
    if (role === "executioner") {
      const others = playerIDs.filter(pid => pid !== id);
      const target = getRandomElement(others);
      g.players[id].executionerTarget = target;
    }
  });
}

async function sendRoles(mqtt, g, usersData) {
  const mafiaMembers = [];
  for (const p of Object.values(g.players)) {
    if (ROLES[p.role].team === "mafia") {
      const name = await usersData.getName(p.userID);
      mafiaMembers.push(`🔴 ${name}`);
    }
  }
  const mafiaList = mafiaMembers.join("\n");
  for (const p of Object.values(g.players)) {
    const roleData = ROLES[p.role];
    let msg = `${roleData.emoji} دورك في اللعبة ${roleData.emoji}
━━━━━━━━━━━━━━━━━━

🎭 ${roleData.name} 🎭

📝 ${roleData.desc}

━━━━━━━━━━━━━━━━━━

`;
    if (roleData.team === "mafia") {
      msg += `🔴 فريق المافيا 🔴
━━━━━━━━━━━━━━━━━━

أعضاء فريقك:
${mafiaList}

💬 يمكنكم التحدث معاً ليلاً
🤝 تنسقوا مع بعض!
🔪 اقتلوا بحذر وذكاء

━━━━━━━━━━━━━━━━━━

`;
    } else if (roleData.team === "citizen") {
      msg += `🔵 فريق المواطنين 🔵
━━━━━━━━━━━━━━━━━━

🎯 الهدف: القضاء على المافيا كلها!
🕵️ استخدم قدراتك بذكاء
🤝 تعاون مع الفريق
⚖️ صوّت بحكمة

━━━━━━━━━━━━━━━━━━

`;
    } else if (roleData.team === "neutral") {
      msg += `⚪ محايد - هدف خاص ⚪
━━━━━━━━━━━━━━━━━━

🎯 لديك هدفك الخاص!
🎭 اخف نواياك
🧠 استغل الفريقين
🏆 حقق هدفك للفوز!

━━━━━━━━━━━━━━━━━━

`;
    } else if (roleData.team === "vampire") {
      msg += `🟣 مصاص دماء 🟣
━━━━━━━━━━━━━━━━━━

🧛 حول الجميع لمصاصي دماء!
🌙 اصبر واحذر
🎯 السيطرة على نصف المدينة

━━━━━━━━━━━━━━━━━━

`;
    }
    if (roleData.uses && roleData.uses < 10) {
      msg += `⚡ عدد الاستخدامات المحدودة: ${roleData.uses} مرة\n\n━━━━━━━━━━━━━━━━━━\n\n`;
    }
    if (p.role === "executioner" && p.executionerTarget) {
      const targetName = await usersData.getName(p.executionerTarget);
      msg += `🎯 هدفك الخاص: ${targetName}\n🪓 يجب أن يُقصى بالتصويت للفوز!\n\n━━━━━━━━━━━━━━━━━━\n\n`;
    }
    msg += `🔒 رسائلك سرية تماماً\n🎮 استمتع باللعبة\n🍀 حظاً موفقاً!`;
    await mqtt.sendMessage(msg, p.groupID);
    await sleep(1000);
  }
}

async function startNightPhase(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  g.phase = "night";
  g.day++;
  g.nightActions = {};
  for (const p of Object.values(g.players)) {
    if (p.alive) {
      p.protected = false;
      p.blackmailed = false;
      p.roleblocked = false;
      p.framed = false;
      delete p.alerted;
      delete p.bodyguarded;
      delete p.trapped;
      delete p.crusaded;
    }
  }
  await mqtt.sendMessage(
    `${formatPhaseMessage("night", g.day)}

━━━━━━━━━━━━━━━━━━

${formatGameStatus(g)}

━━━━━━━━━━━━━━━━━━

⏱️ المرحلة الليلية: 40 ثانية
🤫 صمت تام في المجموعة!
✨ استخدموا قدراتكم بحكمة`,
    g.main
  );
  for (const p of alive(g)) {
    const roleData = ROLES[p.role];
    if (!roleData.night && !roleData.canKill) continue;
    if (p.roleblocked) continue;
    const canAct = roleData.canKill || roleData.ability;
    if (!canAct) continue;
    let msg = `${formatPhaseMessage("night", g.day)}\n\n${roleData.emoji} | ${roleData.name}: ${roleData.desc}\n━━━━━━━━━━━━━━━━━━\n`;
    if (p.role === "retributionist") {
      const deadPlayers = Object.values(g.players).filter(pl => !pl.alive);
      if (deadPlayers.length === 0 || !p.abilities.revive || p.abilities.revive <= 0) {
        await mqtt.sendMessage(`❌ لا توجد موتى لإحيائهم! 😔`, p.groupID);
        continue;
      }
      msg += `💀➡️ اختر رقم الميت لإحيائه:\n━━━━━━━━━━━━━━━━━━\n\n`;
      for (let i = 0; i < deadPlayers.length; i++) {
        const deadName = await usersData.getName(deadPlayers[i].userID);
        msg += `${i + 1}. ${deadName} ☠️\n`;
      }
      msg += `\n━━━━━━━━━━━━━━━━━━\n✨ سيعود للحياة ليلة واحدة!\n⚡ متبقي: ${p.abilities.revive} مرة`;
    } else if (p.role === "amnesiac") {
      const deadPlayers = Object.values(g.players).filter(pl => !pl.alive);
      if (deadPlayers.length === 0 || !p.abilities.remember || p.abilities.remember <= 0) {
        await mqtt.sendMessage(`❌ لا توجد موتى لتذكر دورهم! 😔`, p.groupID);
        continue;
      }
      msg += `❓ اختر رقم الميت لتذكر دوره:\n━━━━━━━━━━━━━━━━━━\n\n`;
      for (let i = 0; i < deadPlayers.length; i++) {
        const deadName = await usersData.getName(deadPlayers[i].userID);
        msg += `${i + 1}. ${deadName} ☠️\n`;
      }
      msg += `\n━━━━━━━━━━━━━━━━━━\n✨ ستصبح مثله تماماً!\n⚡ متبقي: ${p.abilities.remember} مرة`;
    } else if (p.role === "psychic") {
      const alivePlayers = alive(g);
      if (alivePlayers.length < 3) {
        await mqtt.sendMessage(`❌ لا يوجد لاعبون كافيون للرؤيا! 😔`, p.groupID);
        continue;
      }
      const shuffled = secureShuffle(alivePlayers.filter(pl => pl.userID !== p.userID));
      const evilRoles = ["mafia", "godfather", "consigliere", "framer", "janitor", "blackmailer", 
        "serial_killer", "werewolf", "arsonist", "witch"];
      const evilPlayer = shuffled.find(pl => evilRoles.includes(pl.role));
      if (!evilPlayer) {
        await mqtt.sendMessage(`❌ لا يوجد أشرار في الرؤيا! 😔`, p.groupID);
        continue;
      }
      const goodPlayer = shuffled.find(pl => pl.userID !== evilPlayer.userID && !evilRoles.includes(pl.role));
      if (!goodPlayer) {
        await mqtt.sendMessage(`❌ لا يوجد أخيار في الرؤيا! 😔`, p.groupID);
        continue;
      }
      const pair = secureRandom(0, 1) === 0 ? [evilPlayer, goodPlayer] : [goodPlayer, evilPlayer];
      const name1 = await usersData.getName(pair[0].userID);
      const name2 = await usersData.getName(pair[1].userID);
      await mqtt.sendMessage(
        `🔮 رؤياك الليلة 🔮\n━━━━━━━━━━━━━━━━━━\n\n👤 ${name1}\n👤 ${name2}\n\n━━━━━━━━━━━━━━━━━━\n⚠️ أحدهما شرير بالتأكيد!\n✨ استخدم هذه المعلومة بحكمة`,
        p.groupID
      );
      continue;
    } else if (p.role === "medium") {
      const deadPlayers = Object.values(g.players).filter(pl => !pl.alive);
      if (deadPlayers.length === 0) {
        await mqtt.sendMessage(`❌ لا توجد أرواح للحديث معها! 😔`, p.groupID);
        continue;
      }
      const randomDead = getRandomElement(deadPlayers);
      const deadName = await usersData.getName(randomDead.userID);
      const roleData = ROLES[randomDead.role];
      await mqtt.sendMessage(
        `👻 تواصلت مع روح ${deadName}!\n━━━━━━━━━━━━━━━━━━\n\n🎭 دوره: ${roleData.emoji} ${roleData.name}\n\n━━━━━━━━━━━━━━━━━━\n💬 الأموات يخبرون الحقيقة!`,
        p.groupID
      );
      continue;
    } else if (p.role === "spy") {
      const mafiaActions = Object.entries(g.nightActions).filter(([actorID, action]) => {
        const actor = g.players[actorID];
        return actor && ROLES[actor.role].team === "mafia";
      });
      if (mafiaActions.length > 0) {
        let spyMsg = `🕵️ تقرير المافيا الليلة 🕵️\n━━━━━━━━━━━━━━━━━━\n\n`;
        for (const [actorID, action] of mafiaActions) {
          const actorName = await usersData.getName(actorID);
          if (action.target) {
            const targetName = await usersData.getName(action.target);
            spyMsg += `🔴 ${actorName} استهدف ${targetName}\n`;
          }
        }
        spyMsg += `\n━━━━━━━━━━━━━━━━━━\n👁️ معلومات حساسة!`;
        await mqtt.sendMessage(spyMsg, p.groupID);
      }
      continue;
    } else if (p.role === "veteran") {
      msg += `⚔️ رد بـ: نعم للتحصن\n💀 ستقتل كل من يزورك!\n`;
      if (p.abilities.alert) {
        msg += `⚡ متبقي: ${p.abilities.alert} مرة`;
      }
    } else if (p.role === "survivor") {
      msg += `🦺 رد بـ: نعم لاستخدام الدرع\n🛡️ ستحمي نفسك من القتل!\n`;
      if (p.abilities.vest) {
        msg += `⚡ متبقي: ${p.abilities.vest} مرة`;
      }
    } else if (p.role === "transporter") {
      const playersList = await listPlayers(g, usersData, false);
      msg += `رد برقم اللاعبين:\n${playersList}\n━━━━━━━━━━━━━━━━━━\n`;
      msg += `🚗 اختر رقمين للتبديل\n📝 مثال: 1 2\n🔄 ستبدل مكانهما وكل من يزورهما!`;
    } else if (p.role === "witch") {
      const playersList = await listPlayers(g, usersData, false);
      msg += `رد برقم اللاعبين:\n${playersList}\n━━━━━━━━━━━━━━━━━━\n`;
      msg += `🧙 اختر رقمين للسيطرة\n📝 مثال: 1 2\n🎯 الأول: من ستسيطرين عليه\n🎯 الثاني: هدفه الجديد`;
    } else if (p.role === "arsonist") {
      const playersList = await listPlayers(g, usersData, false);
      msg += `رد برقم اللاعب:\n${playersList}\n━━━━━━━━━━━━━━━━━━\n`;
      msg += `🔥 اختر رقماً لإشعاله\n💥 أو اكتب: حرق - لحرق الجميع!`;
    } else {
      const needsPlayerList = ["mafia", "godfather", "consigliere", "framer", "janitor", 
        "blackmailer", "cop", "sheriff", "doctor", "bodyguard", "vigilante", "lookout", 
        "tracker", "escort", "crusader", "trapper", "serial_killer", "werewolf", "vampire", "vampire_hunter"];
      if (needsPlayerList.includes(p.role)) {
        const playersList = await listPlayers(g, usersData, false);
        msg += `رد برقم اللاعب:\n${playersList}\n━━━━━━━━━━━━━━━━━━\n`;
      }
      if (p.role === "mafia" || p.role === "godfather") {
        msg += `🔪 اختر رقم اللاعب الذي تريد قتله\n💀 اختر بحكمة!`;
      } else if (p.role === "consigliere") {
        msg += `🎯 اختر رقماً للكشف الدقيق عن دوره`;
      } else if (p.role === "framer") {
        msg += `🖼️ اختر رقماً لتزويره وجعله يظهر كمافيا`;
      } else if (p.role === "janitor") {
        msg += `🧹 اختر رقماً لإخفاء دوره بعد موته`;
        if (p.abilities.clean) {
          msg += `\n⚡ متبقي: ${p.abilities.clean} مرة`;
        }
      } else if (p.role === "blackmailer") {
        msg += `🤫 اختر رقماً لابتزازه ومنعه من التصويت`;
      } else if (p.role === "cop") {
        msg += `👮 اختر رقماً للتحقيق منه`;
      } else if (p.role === "sheriff") {
        msg += `⭐ اختر رقماً لفحصه وقتله إن كان مافيا`;
      } else if (p.role === "doctor") {
        msg += `💊 اختر رقماً لحمايته من القتل`;
      } else if (p.role === "bodyguard") {
        msg += `🛡️ اختر رقماً لحراسته والموت بدلاً منه`;
      } else if (p.role === "vigilante") {
        msg += `🔫 اختر رقماً لقتله`;
        if (p.abilities.vigi_kill) {
          msg += `\n⚡ متبقي: ${p.abilities.vigi_kill} مرة`;
        }
      } else if (p.role === "lookout") {
        msg += `👁️ اختر رقماً لمراقبة منزله`;
      } else if (p.role === "tracker") {
        msg += `🔎 اختر رقماً لتعقبه ومعرفة من زار`;
      } else if (p.role === "escort") {
        msg += `💃 اختر رقماً لإشغاله ومنعه من التصرف`;
      } else if (p.role === "crusader") {
        msg += `⚔️🛡️ اختر رقماً لحراسته وقتل من يهاجمه`;
      } else if (p.role === "trapper") {
        msg += `🪤 اختر رقماً لنصب فخ على منزله`;
      } else if (p.role === "serial_killer") {
        msg += `🔪💀 اختر رقماً لقتله بدم بارد`;
      } else if (p.role === "werewolf") {
        if (g.day % 2 === 1) {
          msg += `🐺 اختر رقماً لمهاجمته وقتل كل زواره`;
        } else {
          await mqtt.sendMessage(`🐺 ليلة هادئة! لا يمكنك المهاجمة الليلة 🌕`, p.groupID);
          continue;
        }
      } else if (p.role === "vampire") {
        msg += `🧛 اختر رقماً لتحويله لمصاص دماء`;
      } else if (p.role === "vampire_hunter") {
        msg += `🧄 اختر رقماً لفحصه وقتله إن كان مصاص دماء`;
      }
    }
    msg += `\n━━━━━━━━━━━━━━━━━━\n⚠️ إقرأ جيداً! اختر بحكمة 🧠`;
    if (!p.groupID) continue;
    try {
      const { messageID } = await mqtt.sendMessage(msg, p.groupID);
      global.YamiBot.onReply.set(messageID, {
        commandName: g.commandName,
        gameID: g.id,
        playerID: p.userID,
        type: "night"
      });
    } catch (error) {
      console.error(`[MAFIA42] Failed to send night message to ${p.userID}:`, error);
    }
  }
  nightPhaseTimer(mqtt, gameID, usersData);
}

function nightPhaseTimer(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const timer1 = setTimeout(async () => {
    if (g.phase === "night") {
      await mqtt.sendMessage("⏰ تبقى 10 ثواني على نهاية الليل! 🌙", g.main);
    }
  }, 30000);
  const timer2 = setTimeout(() => {
    if (g.phase === "night") {
      resolveNightActions(mqtt, gameID, usersData);
    }
  }, 40000);
  addTimer(gameID, timer1);
  addTimer(gameID, timer2);
}

async function handleNightAction(Reply, event, mqtt, usersData) {
  const g = global.MafiaGames.games[Reply.gameID];
  if (!g || g.phase !== "night") return;
  const player = g.players[Reply.playerID];
  if (!player || !player.alive) return;
  if (player.roleblocked) {
    return mqtt.sendMessage("💤 تم إشغالك! لا يمكنك التصرف الليلة 😴", player.groupID);
  }
  const input = event.body.trim();
  if (input.toLowerCase().startsWith("استخدام ") || input.toLowerCase().startsWith("use ")) {
    return handlePurchasedItemUse(player, input, mqtt, g, usersData);
  }
  const yesActions = ["veteran", "survivor"];
  if (yesActions.includes(player.role) && (input === "نعم" || input.toLowerCase() === "yes")) {
    if (player.role === "veteran") {
      if (!player.abilities.alert || player.abilities.alert <= 0) {
        return mqtt.sendMessage("❌ لا توجد استخدامات متبقية! 😔", player.groupID);
      }
      g.nightActions[player.userID] = { type: "alert" };
      player.abilities.alert--;
      player.alerted = true;
      return mqtt.sendMessage(`⚔️ متحصن! ستقتل كل من يزورك الليلة! 💀\n━━━━━━━━━━━━━━━━━━\n⚡ متبقي: ${player.abilities.alert} مرة`, player.groupID);
    } else if (player.role === "survivor") {
      if (!player.abilities.vest || player.abilities.vest <= 0) {
        return mqtt.sendMessage("❌ لا توجد دروع متبقية! 😔", player.groupID);
      }
      g.nightActions[player.userID] = { type: "vest" };
      player.abilities.vest--;
      player.protected = true;
      return mqtt.sendMessage(`🦺 استخدمت الدرع! أنت محمي الليلة! 🛡️\n━━━━━━━━━━━━━━━━━━\n⚡ متبقي: ${player.abilities.vest} مرة`, player.groupID);
    }
  }
  if (input === "حرق" && player.role === "arsonist") {
    g.nightActions[player.userID] = { type: "ignite" };
    return mqtt.sendMessage(`🔥 سيحترق كل من أشعلتهم! 💥\n━━━━━━━━━━━━━━━━━━\n😈 نار الانتقام قادمة!`, player.groupID);
  }
  if (player.role === "transporter" || player.role === "witch") {
    const parts = input.split(" ");
    if (parts.length !== 2) {
      return mqtt.sendMessage("❌ اكتب رقمين فقط!\n━━━━━━━━━━━━━━━━━━\n📝 مثال: 1 2", player.groupID);
    }
    const target1Index = parseInt(parts[0]);
    const target2Index = parseInt(parts[1]);
    if (isNaN(target1Index) || isNaN(target2Index)) {
      return mqtt.sendMessage("❌ أدخل رقمين صحيحين! 🔢", player.groupID);
    }
    const target1 = getPlayerByIndex(g, target1Index);
    const target2 = getPlayerByIndex(g, target2Index);
    if (!target1 || !target2) {
      return mqtt.sendMessage("❌ أرقام خاطئة! تحقق من القائمة 📋", player.groupID);
    }
    if (player.role === "transporter") {
      g.nightActions[player.userID] = { 
        type: "transport", 
        target1: target1.userID, 
        target2: target2.userID 
      };
      const name1 = await usersData.getName(target1.userID);
      const name2 = await usersData.getName(target2.userID);
      return mqtt.sendMessage(`🚗 سيتم تبديل ${name1} و ${name2}!\n━━━━━━━━━━━━━━━━━━\n🔄 كل من يزور أحدهما سيزور الآخر!`, player.groupID);
    } else {
      g.nightActions[player.userID] = { 
        type: "control", 
        target: target1.userID, 
        newTarget: target2.userID 
      };
      const name1 = await usersData.getName(target1.userID);
      const name2 = await usersData.getName(target2.userID);
      return mqtt.sendMessage(`🧙 ستسيطرين على ${name1}!\n━━━━━━━━━━━━━━━━━━\n🎯 هدفه الجديد: ${name2}\n✨ السحر يعمل!`, player.groupID);
    }
  }
  const targetIndex = parseInt(input);
  if (isNaN(targetIndex)) {
    return mqtt.sendMessage("❌ رد برقم صحيح من القائمة! 🔢", player.groupID);
  }
  let target;
  if (player.role === "retributionist") {
    const dead = Object.values(g.players).filter(p => !p.alive);
    if (targetIndex < 1 || targetIndex > dead.length) {
      return mqtt.sendMessage("❌ رقم خاطئ! اختر من الموتى 💀", player.groupID);
    }
    target = dead[targetIndex - 1];
    if (!player.abilities.revive || player.abilities.revive <= 0) {
      return mqtt.sendMessage("❌ لا توجد استخدامات متبقية! 😔", player.groupID);
    }
    g.nightActions[player.userID] = { type: "revive", target: target.userID };
    player.abilities.revive--;
    const targetName = await usersData.getName(target.userID);
    return mqtt.sendMessage(`✅ تم التأكيد!\n━━━━━━━━━━━━━━━━━━\n💀➡️ سيتم إحياء ${targetName}!\n━━━━━━━━━━━━━━━━━━\n⏳ انتظر النتائج...`, player.groupID);
  } else if (player.role === "amnesiac") {
    const dead = Object.values(g.players).filter(p => !p.alive);
    if (targetIndex < 1 || targetIndex > dead.length) {
      return mqtt.sendMessage("❌ رقم خاطئ! اختر من الموتى 💀", player.groupID);
    }
    target = dead[targetIndex - 1];
    if (!player.abilities.remember || player.abilities.remember <= 0) {
      return mqtt.sendMessage("❌ لا توجد استخدامات متبقية! 😔", player.groupID);
    }
    g.nightActions[player.userID] = { type: "remember", target: target.userID };
    player.abilities.remember--;
    const targetName = await usersData.getName(target.userID);
    return mqtt.sendMessage(`✅ تم التأكيد!\n━━━━━━━━━━━━━━━━━━\n❓ ستتذكر دور ${targetName}!\n━━━━━━━━━━━━━━━━━━\n⏳ انتظر النتائج...`, player.groupID);
  } else {
    target = getPlayerByIndex(g, targetIndex);
    if (!target) {
      return mqtt.sendMessage("❌ رقم خاطئ! تحقق من القائمة 📋", player.groupID);
    }
  }
  const targetName = await usersData.getName(target.userID);
  const simpleActions = {
    "mafia": "kill",
    "godfather": "kill",
    "consigliere": "precise_check",
    "framer": "frame",
    "janitor": "clean",
    "blackmailer": "blackmail",
    "cop": "investigate",
    "sheriff": "sheriff_check",
    "doctor": "heal",
    "bodyguard": "bodyguard",
    "vigilante": "vigi_kill",
    "lookout": "lookout",
    "tracker": "track",
    "escort": "roleblock",
    "crusader": "crusade",
    "trapper": "trap",
    "arsonist": "douse",
    "serial_killer": "sk_kill",
    "werewolf": "maul",
    "vampire": "convert_vamp",
    "vampire_hunter": "vh_check"
  };
  const actionType = simpleActions[player.role];
  if (actionType) {
    if (player.role === "vigilante" && (!player.abilities.vigi_kill || player.abilities.vigi_kill <= 0)) {
      return mqtt.sendMessage("❌ لا توجد استخدامات متبقية! 😔", player.groupID);
    }
    if (player.role === "janitor" && (!player.abilities.clean || player.abilities.clean <= 0)) {
      return mqtt.sendMessage("❌ لا توجد استخدامات متبقية! 😔", player.groupID);
    }
    g.nightActions[player.userID] = { type: actionType, target: target.userID };
    if (player.role === "vigilante") player.abilities.vigi_kill--;
    if (player.role === "janitor") player.abilities.clean--;
    const confirmations = {
      "kill": `🔪 سيتم قتل ${targetName} الليلة!`,
      "precise_check": `🎯 سيتم الكشف الدقيق عن ${targetName}!`,
      "frame": `🖼️ سيتم تزوير ${targetName}!`,
      "clean": `🧹 سيتم تنظيف دور ${targetName}!`,
      "blackmail": `🤫 سيتم ابتزاز ${targetName}!`,
      "investigate": `👮 سيتم التحقيق من ${targetName}!`,
      "sheriff_check": `⭐ سيتم فحص ${targetName}!`,
      "heal": `💊 سيتم حماية ${targetName}!`,
      "bodyguard": `🛡️ ستحرس ${targetName}!`,
      "vigi_kill": `🔫 سيتم قتل ${targetName}!`,
      "lookout": `👁️ ستراقب ${targetName}!`,
      "track": `🔎 ستتعقب ${targetName}!`,
      "roleblock": `💃 سيتم إشغال ${targetName}!`,
      "crusade": `⚔️🛡️ ستحرس ${targetName}!`,
      "trap": `🪤 سيتم نصب فخ على ${targetName}!`,
      "douse": `🔥 سيتم إشعال ${targetName}!`,
      "sk_kill": `🔪💀 سيتم قتل ${targetName}!`,
      "maul": `🐺 سيتم مهاجمة ${targetName}!`,
      "convert_vamp": `🧛 سيتم تحويل ${targetName}!`,
      "vh_check": `🧄 سيتم فحص ${targetName}!`
    };
    return mqtt.sendMessage(`✅ تم التأكيد!\n━━━━━━━━━━━━━━━━━━\n${confirmations[actionType] || `تم: ${targetName}`}\n━━━━━━━━━━━━━━━━━━\n⏳ انتظر النتائج...`, player.groupID);
  }
}

async function handlePurchasedItemUse(player, input, mqtt, g, usersData) {
  const parts = input.toLowerCase().split(" ");
  if (parts.length < 2) {
    return mqtt.sendMessage("❌ استخدم: استخدام + نوع القدرة\n━━━━━━━━━━━━━━━━━━\n🛡️ حماية\n🔍 تحقيق\n👥 كشف", player.groupID);
  }
  const itemType = parts[1];
  if (itemType === "حماية" || itemType === "protection") {
    if (!hasPurchase(player.userID, "protection")) {
      return mqtt.sendMessage("❌ ليس لديك هذه القدرة! 😔\n━━━━━━━━━━━━━━━━━━\n💡 اشترها من المتجر أولاً 🛒", player.groupID);
    }
    if (g.nightActions[player.userID] && g.nightActions[player.userID].type === "self_protect") {
      return mqtt.sendMessage("⚠️ استخدمت الحماية بالفعل الليلة! 🛡️", player.groupID);
    }
    removePurchaseFromInventory(player.userID, "protection");
    g.nightActions[player.userID] = { type: "self_protect" };
    player.protected = true;
    return mqtt.sendMessage(`✅ تم استخدام الحماية! 🛡️\n━━━━━━━━━━━━━━━━━━\n💪 أنت محمي من القتل الليلة!\n✨ حماية مضمونة 100%`, player.groupID);
  } else if (itemType === "تحقيق" || itemType === "investigation") {
    if (!hasPurchase(player.userID, "investigation")) {
      return mqtt.sendMessage("❌ ليس لديك هذه القدرة! 😔\n━━━━━━━━━━━━━━━━━━\n💡 اشترها من المتجر أولاً 🛒", player.groupID);
    }
    const playersList = await listPlayers(g, usersData, false);
    const msg = `🔍 اختر رقم اللاعب للتحقيق منه:\n━━━━━━━━━━━━━━━━━━\n${playersList}\n━━━━━━━━━━━━━━━━━━\n💡 سيتم الكشف عن دوره بدقة!`;
    const { messageID } = await mqtt.sendMessage(msg, player.groupID);
    global.YamiBot.onReply.set(messageID, {
      commandName: g.commandName,
      gameID: g.id,
      playerID: player.userID,
      type: "shop_investigation"
    });
  } else if (itemType === "كشف" || itemType === "reveal") {
    if (!hasPurchase(player.userID, "reveal_team")) {
      return mqtt.sendMessage("❌ ليس لديك هذه القدرة! 😔\n━━━━━━━━━━━━━━━━━━\n💡 اشترها من المتجر أولاً 🛒", player.groupID);
    }
    const playersList = await listPlayers(g, usersData, false);
    const msg = `👥 اختر رقم اللاعب لكشف فريقه:\n━━━━━━━━━━━━━━━━━━\n${playersList}\n━━━━━━━━━━━━━━━━━━\n💡 سيتم كشف فريقه فقط!`;
    const { messageID } = await mqtt.sendMessage(msg, player.groupID);
    global.YamiBot.onReply.set(messageID, {
      commandName: g.commandName,
      gameID: g.id,
      playerID: player.userID,
      type: "shop_reveal_team"
    });
  } else {
    return mqtt.sendMessage("❌ نوع قدرة غير معروف!\n━━━━━━━━━━━━━━━━━━\n🛡️ حماية\n🔍 تحقيق\n👥 كشف", player.groupID);
  }
}

async function handleShopInvestigation(Reply, event, mqtt, usersData) {
  const g = global.MafiaGames.games[Reply.gameID];
  if (!g) return;
  const player = g.players[Reply.playerID];
  if (!player || !player.alive) return;
  if (!hasPurchase(player.userID, "investigation")) {
    return mqtt.sendMessage("❌ ليس لديك هذه القدرة! 😔", player.groupID);
  }
  const targetIndex = parseInt(event.body.trim());
  if (isNaN(targetIndex)) {
    return mqtt.sendMessage("❌ رد برقم صحيح! 🔢", player.groupID);
  }
  const target = getPlayerByIndex(g, targetIndex);
  if (!target) {
    return mqtt.sendMessage("❌ رقم خاطئ! 📋", player.groupID);
  }
  removePurchaseFromInventory(player.userID, "investigation");
  const targetName = await usersData.getName(target.userID);
  const roleData = ROLES[target.role];
  await mqtt.sendMessage(
    `🔍 نتيجة التحقيق الخاص! 🔍\n━━━━━━━━━━━━━━━━━━\n\n👤 ${targetName}\n🎭 الدور: ${roleData.emoji} ${roleData.name}\n\n━━━━━━━━━━━━━━━━━━\n✅ تحقيق دقيق 100%!`,
    player.groupID
  );
}

async function handleShopRevealTeam(Reply, event, mqtt, usersData) {
  const g = global.MafiaGames.games[Reply.gameID];
  if (!g) return;
  const player = g.players[Reply.playerID];
  if (!player || !player.alive) return;
  if (!hasPurchase(player.userID, "reveal_team")) {
    return mqtt.sendMessage("❌ ليس لديك هذه القدرة! 😔", player.groupID);
  }
  const targetIndex = parseInt(event.body.trim());
  if (isNaN(targetIndex)) {
    return mqtt.sendMessage("❌ رد برقم صحيح! 🔢", player.groupID);
  }
  const target = getPlayerByIndex(g, targetIndex);
  if (!target) {
    return mqtt.sendMessage("❌ رقم خاطئ! 📋", player.groupID);
  }
  removePurchaseFromInventory(player.userID, "reveal_team");
  const targetName = await usersData.getName(target.userID);
  const roleData = ROLES[target.role];
  const teamNames = {
    "mafia": "🔴 المافيا",
    "citizen": "🔵 المواطنين",
    "neutral": "⚪ المحايدين",
    "vampire": "🟣 مصاصي الدماء"
  };
  await mqtt.sendMessage(
    `👥 نتيجة كشف الفريق! 👥\n━━━━━━━━━━━━━━━━━━\n\n👤 ${targetName}\n🎯 الفريق: ${teamNames[roleData.team]}\n\n━━━━━━━━━━━━━━━━━━\n✅ معلومة مؤكدة!`,
    player.groupID
  );
}

async function resolveNightActions(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const actions = g.nightActions;
  const results = [];
  const deaths = [];
  for (const p of Object.values(g.players)) {
    if (p.alive && hasPurchase(p.userID, "extra_life")) {
      p.hasExtraLife = true;
    }
  }
  const swaps = {};
  for (const [actorID, action] of Object.entries(actions)) {
    if (action.type === "transport") {
      swaps[action.target1] = action.target2;
      swaps[action.target2] = action.target1;
    }
  }
  const applySwap = (targetID) => swaps[targetID] || targetID;
  const sortedActions = Object.entries(actions).sort((a, b) => {
    const roleA = ROLES[g.players[a[0]].role];
    const roleB = ROLES[g.players[b[0]].role];
    return (roleB.priority || 0) - (roleA.priority || 0);
  });
  for (const [actorID, action] of sortedActions) {
    const actor = g.players[actorID];
    if (!actor || !actor.alive) continue;
    if (action.type === "roleblock") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        target.roleblocked = true;
        results.push(`💤 تم إشغال شخص ما!`);
      }
    } else if (action.type === "heal") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        target.protected = true;
        results.push(`💊 الطبيب حمى شخصاً ما!`);
      }
    } else if (action.type === "bodyguard") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        target.bodyguarded = actorID;
      }
    } else if (action.type === "vest" || action.type === "self_protect") {
      actor.protected = true;
    } else if (action.type === "alert") {
      actor.alerted = true;
    } else if (action.type === "trap") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        target.trapped = actorID;
      }
    } else if (action.type === "crusade") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        target.crusaded = actorID;
      }
    } else if (action.type === "frame") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        target.framed = true;
      }
    } else if (action.type === "blackmail") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        target.blackmailed = true;
        results.push(`🤫 شخص ما تم ابتزازه!`);
      }
    }
  }
  for (const [actorID, action] of sortedActions) {
    const actor = g.players[actorID];
    if (!actor || !actor.alive || actor.roleblocked) continue;
    const killActions = ["kill", "vigi_kill", "sk_kill", "maul", "sheriff_check", "vh_check"];
    if (killActions.includes(action.type)) {
      let targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (!target || !target.alive) continue;
      if (target.alerted) {
        actor.alive = false;
        const funnyMessages = [
          "😂 هههههه! هاجم المحارب القديم وانجلد! 🤡",
          "🤣 غبي! راح للمحارب القديم بنفسه! 💀",
          "😆 المحارب القديم كان مستني حد أبله! 🎯"
        ];
        const funnyMsg = getRandomElement(funnyMessages);
        deaths.push({ userID: actor.userID, reason: `⚔️ ${funnyMsg}` });
        results.push(`⚔️ المحارب القديم قتل مهاجماً غبياً! 💀😂`);
        await mqtt.sendMessage(`☠️ قُتلت!\n━━━━━━━━━━━━━━━━━━\n${funnyMsg}\n💀 المحارب القديم لا يُهزم!`, actor.groupID);
        const stats = initPlayerStats(actor.userID);
        stats.deaths++;
        updatePlayerStats(actor.userID, stats);
        continue;
      }
      if (target.trapped) {
        const trapper = g.players[target.trapped];
        actor.alive = false;
        deaths.push({ userID: actor.userID, reason: "🪤 وقع في فخ الصياد المحترف! 😏" });
        results.push(`🪤 الصياد اصطاد شخصاً غبياً! 💀🎣`);
        await mqtt.sendMessage(`☠️ قُتلت!\n━━━━━━━━━━━━━━━━━━\n🪤 وقعت في فخ محكم!\n😏 كان ينتظرك الصياد!`, actor.groupID);
        const stats = initPlayerStats(actor.userID);
        stats.deaths++;
        updatePlayerStats(actor.userID, stats);
        continue;
      }
      if (target.crusaded) {
        const crusader = g.players[target.crusaded];
        actor.alive = false;
        deaths.push({ userID: actor.userID, reason: "⚔️🛡️ قتله الصليبي الشجاع! 🗡️" });
        results.push(`⚔️🛡️ الصليبي دافع وقتل مهاجماً! 💀⚔️`);
        await mqtt.sendMessage(`☠️ قُتلت!\n━━━━━━━━━━━━━━━━━━\n⚔️🛡️ الصليبي كان يحرس!\n🗡️ دفاع قوي!`, actor.groupID);
        const stats = initPlayerStats(actor.userID);
        stats.deaths++;
        updatePlayerStats(actor.userID, stats);
        continue;
      }
      if (target.protected) {
        results.push(`🛡️ تم منع محاولة قتل! الحماية نجحت! ✅`);
        await mqtt.sendMessage(`✅ تم إنقاذك!\n🛡️ الحماية نجحت!\n💪 أنت بخير!`, target.groupID);
        continue;
      }
      if (target.bodyguarded) {
        const bg = g.players[target.bodyguarded];
        if (bg && bg.alive) {
          bg.alive = false;
          deaths.push({ userID: bg.userID, reason: "🛡️ ضحى كحارس شخصي بطل! 💪" });
          results.push(`🛡️ الحارس الشخصي ضحى بنفسه! 💔😢`);
          const targetName = await usersData.getName(target.userID);
          await mqtt.sendMessage(`☠️ ضحيت بنفسك!\n━━━━━━━━━━━━━━━━━━\n🛡️ حميت ${targetName}!\n💪 موت بطولي!`, bg.groupID);
          await mqtt.sendMessage(`✅ تم إنقاذك!\n🛡️ الحارس ضحى بنفسه!\n💔 ديون لا تُنسى!`, target.groupID);
          const stats = initPlayerStats(bg.userID);
          stats.deaths++;
          updatePlayerStats(bg.userID, stats);
          continue;
        }
      }
      if (target.hasExtraLife && hasPurchase(target.userID, "extra_life")) {
        removePurchaseFromInventory(target.userID, "extra_life");
        target.hasExtraLife = false;
        results.push(`❤️ الحياة الإضافية أنقذت شخصاً! ✨`);
        await mqtt.sendMessage(`❤️ نجوت بأعجوبة!\n━━━━━━━━━━━━━━━━━━\n✨ الحياة الإضافية أنقذتك!\n🎁 فرصة ثانية!`, target.groupID);
        continue;
      }
      if (action.type === "sheriff_check" || action.type === "vh_check") {
        const roleData = ROLES[target.role];
        const isTarget = (action.type === "sheriff_check" && roleData.team === "mafia") ||
                        (action.type === "vh_check" && (roleData.team === "vampire" || target.convertedToVampire));
        if (isTarget) {
          target.alive = false;
          deaths.push({ userID: target.userID, reason: action.type === "sheriff_check" ? "⭐ قتله العمدة العادل! ⚖️" : "🧄 قتله صائد مصاصي الدماء! 🧛" });
          const targetStats = initPlayerStats(target.userID);
          targetStats.deaths++;
          updatePlayerStats(target.userID, targetStats);
          const killerStats = initPlayerStats(actorID);
          killerStats.kills++;
          updatePlayerStats(actorID, killerStats);
          await mqtt.sendMessage(`✅ كان ${action.type === "sheriff_check" ? "مافيا 🔴" : "مصاص دماء 🧛"} وقتلته!\n🎯 إصابة دقيقة!`, actor.groupID);
        } else {
          await mqtt.sendMessage(`✅ ليس ${action.type === "sheriff_check" ? "مافيا 🔵" : "مصاص دماء 👤"}\n😌 مواطن بريء`, actor.groupID);
        }
        continue;
      }
      target.alive = false;
      let deathMsg = "☠️ قُتل";
      if (action.type === "vigi_kill") deathMsg = "🔫 قتله الحارس الشجاع! 🎯";
      else if (action.type === "sk_kill") deathMsg = "🔪💀 قتله القاتل المتسلسل! 😱";
      else if (action.type === "maul") deathMsg = "🐺 مزقه المستذئب بوحشية! 🩸";
      deaths.push({ userID: target.userID, reason: deathMsg });
      const targetStats = initPlayerStats(target.userID);
      targetStats.deaths++;
      updatePlayerStats(target.userID, targetStats);
      const killerStats = initPlayerStats(actorID);
      killerStats.kills++;
      updatePlayerStats(actorID, killerStats);
      if (action.type === "maul") {
        for (const [visitorID, visitorAction] of Object.entries(actions)) {
          if (visitorAction.target === target.userID && visitorID !== actorID) {
            const visitor = g.players[visitorID];
            if (visitor && visitor.alive) {
              visitor.alive = false;
              deaths.push({ userID: visitor.userID, reason: "🐺 مزقه المستذئب أيضاً! 🩸😱" });
              await mqtt.sendMessage(`☠️ قُتلت!\n━━━━━━━━━━━━━━━━━━\n🐺 المستذئب مزقك!\n😱 كنت في المكان الخطأ!`, visitor.groupID);
              const vStats = initPlayerStats(visitorID);
              vStats.deaths++;
              updatePlayerStats(visitorID, vStats);
            }
          }
        }
      }
    } else if (action.type === "ignite") {
      const dousedPlayers = Object.values(g.players).filter(p => p.doused && p.alive);
      for (const target of dousedPlayers) {
        if (!target.protected && !(target.hasExtraLife && hasPurchase(target.userID, "extra_life"))) {
          target.alive = false;
          deaths.push({ userID: target.userID, reason: "🔥 احترق في نار الحارق! 🔥💀" });
          const stats = initPlayerStats(target.userID);
          stats.deaths++;
          updatePlayerStats(target.userID, stats);
        } else if (target.hasExtraLife && hasPurchase(target.userID, "extra_life")) {
          removePurchaseFromInventory(target.userID, "extra_life");
          target.hasExtraLife = false;
          await mqtt.sendMessage(`❤️ الحياة الإضافية أنقذتك من الحريق! 🔥`, target.groupID);
        }
      }
      if (dousedPlayers.length > 0) {
        results.push(`🔥 حريق هائل اجتاح المدينة! 💥😱`);
        const arsonStats = initPlayerStats(actorID);
        arsonStats.kills += dousedPlayers.filter(p => !p.alive).length;
        updatePlayerStats(actorID, arsonStats);
      }
    }
  }
  await handleInformationActions(mqtt, g, actions, applySwap, usersData, results);
  await announceNightResults(mqtt, g, deaths, results, usersData);
}

async function handleInformationActions(mqtt, g, actions, applySwap, usersData, results) {
  const sortedActions = Object.entries(actions).sort((a, b) => {
    const roleA = ROLES[g.players[a[0]].role];
    const roleB = ROLES[g.players[b[0]].role];
    return (roleB.priority || 0) - (roleA.priority || 0);
  });
  for (const [actorID, action] of sortedActions) {
    const actor = g.players[actorID];
    if (!actor || !actor.alive) continue;
    if (action.type === "investigate") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        const roleData = ROLES[target.role];
        let result = target.framed ? "🔴 مافيا" : roleData.disguised ? "🔵 مواطن" : roleData.team === "mafia" ? "🔴 مافيا" : "🔵 مواطن";
        const targetName = await usersData.getName(target.userID);
        await mqtt.sendMessage(`👮 نتيجة التحقيق:\n━━━━━━━━━━━━━━━━━━\n${targetName}\n🔍 ${result}\n\n${result === "🔴 مافيا" ? "⚠️ مشبوه!" : "✅ يبدو بريئاً"}`, actor.groupID);
      }
    } else if (action.type === "precise_check") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        const roleData = ROLES[target.role];
        const targetName = await usersData.getName(target.userID);
        await mqtt.sendMessage(`🎯 كشف دقيق!\n━━━━━━━━━━━━━━━━━━\n${targetName}\n🎭 ${roleData.emoji} ${roleData.name}\n\n✅ معلومة مؤكدة 100%!`, actor.groupID);
      }
    } else if (action.type === "lookout") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        const visitors = [];
        for (const [vID, vAction] of Object.entries(actions)) {
          if (vAction.target === targetID && vID !== actorID) {
            visitors.push(vID);
          }
        }
        const targetName = await usersData.getName(target.userID);
        if (visitors.length > 0) {
          let msg = `👁️ تقرير المراقبة\n━━━━━━━━━━━━━━━━━━\n\n🏠 منزل ${targetName}\n\n👥 الزوار:\n`;
          for (const vID of visitors) {
            const vName = await usersData.getName(vID);
            msg += `• ${vName}\n`;
          }
          msg += `\n✅ معلومات دقيقة!`;
          await mqtt.sendMessage(msg, actor.groupID);
        } else {
          await mqtt.sendMessage(`👁️ تقرير المراقبة\n━━━━━━━━━━━━━━━━━━\n\n🏠 منزل ${targetName}\n\n❌ لا زوار الليلة\n😴 ليلة هادئة`, actor.groupID);
        }
      }
    } else if (action.type === "track") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive) {
        const targetAction = actions[targetID];
        const targetName = await usersData.getName(target.userID);
        if (targetAction && targetAction.target) {
          const visitedName = await usersData.getName(targetAction.target);
          await mqtt.sendMessage(`🔎 تقرير التعقب\n━━━━━━━━━━━━━━━━━━\n\n🎯 ${targetName}\n\n📍 زار: ${visitedName}\n\n✅ تعقب ناجح!`, actor.groupID);
        } else {
          await mqtt.sendMessage(`🔎 تقرير التعقب\n━━━━━━━━━━━━━━━━━━\n\n🎯 ${targetName}\n\n❌ لم يزر أحداً\n🏠 بقي في منزله`, actor.groupID);
        }
      }
    } else if (action.type === "douse") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive && target.userID !== actorID) {
        target.doused = true;
        const targetName = await usersData.getName(target.userID);
        await mqtt.sendMessage(`🔥 تم إشعال ${targetName}!\n━━━━━━━━━━━━━━━━━━\n✅ جاهز للحرق!\n💥 اكتب "حرق" لإشعال الجميع`, actor.groupID);
      }
    } else if (action.type === "convert_vamp") {
      const targetID = applySwap(action.target);
      const target = g.players[targetID];
      if (target && target.alive && target.userID !== actorID) {
        const roleData = ROLES[target.role];
        if (roleData.team === "citizen" || roleData.team === "neutral") {
          target.convertedToVampire = true;
          const targetName = await usersData.getName(target.userID);
          await mqtt.sendMessage(`🧛 تم تحويل ${targetName}!\n━━━━━━━━━━━━━━━━━━\n✅ أصبح مصاص دماء!\n🌙 توسع الإمبراطورية`, actor.groupID);
          await mqtt.sendMessage(`🧛 تم تحويلك!\n━━━━━━━━━━━━━━━━━━\n🌙 أصبحت مصاص دماء!\n🎯 هدفك: السيطرة على المدينة`, target.groupID);
        } else {
          await mqtt.sendMessage(`❌ فشل التحويل!\n━━━━━━━━━━━━━━━━━━\n⚠️ لا يمكن تحويله`, actor.groupID);
        }
      }
    } else if (action.type === "remember") {
      const target = g.players[action.target];
      if (target && !target.alive) {
        const newRole = target.role;
        const oldRole = actor.role;
        actor.role = newRole;
        actor.abilities = {};
        const roleData = ROLES[newRole];
        if (roleData.uses) {
          actor.abilities[roleData.ability] = roleData.uses;
        }
        const targetName = await usersData.getName(target.userID);
        await mqtt.sendMessage(`❓ تذكرت الماضي!\n━━━━━━━━━━━━━━━━━━\n\n👤 ${targetName}\n🎭 ${roleData.emoji} ${roleData.name}\n\n✅ أصبحت مثله!\n📝 ${roleData.desc}`, actor.groupID);
      }
    } else if (action.type === "revive") {
      const target = g.players[action.target];
      if (target && !target.alive) {
        target.revived = true;
        target.revivedRole = target.role;
        const targetName = await usersData.getName(target.userID);
        await mqtt.sendMessage(`💀➡️ تم إحياء ${targetName}!\n━━━━━━━━━━━━━━━━━━\n✅ عاد للحياة ليلة واحدة!\n⚡ يمكنه استخدام قدرته`, actor.groupID);
        await mqtt.sendMessage(`💀➡️ عدت للحياة!\n━━━━━━━━━━━━━━━━━━\n✨ المنتقم أحياك!\n⏰ ليلة واحدة فقط\n🎯 استخدم قدرتك بحكمة`, target.groupID);
        const roleData = ROLES[target.role];
        if (roleData.night && roleData.ability) {
          const playersList = await listPlayers(g, usersData, false);
          let msg = `${roleData.emoji} ${roleData.name}\n━━━━━━━━━━━━━━━━━━\n\nاستخدم قدرتك الآن!\n\n${playersList}\n\n━━━━━━━━━━━━━━━━━━\n⏰ فرصة أخيرة!`;
          const { messageID } = await mqtt.sendMessage(msg, target.groupID);
          global.YamiBot.onReply.set(messageID, {
            commandName: g.commandName,
            gameID: g.id,
            playerID: target.userID,
            type: "revived_action"
          });
        }
      }
    }
  }
}

async function announceNightResults(mqtt, g, deaths, results, usersData) {
  let announcement = `${formatPhaseMessage("day", g.day)}\n\n`;
  if (deaths.length > 0) {
    announcement += `☠️ الموتى الليلة:\n━━━━━━━━━━━━━━━━━━\n\n`;
    for (const death of deaths) {
      const victim = g.players[death.userID];
      const victimName = await usersData.getName(victim.userID);
      announcement += `💀 ${victimName}\n   ${death.reason}\n\n`;
      await mqtt.sendMessage(`☠️ قُتلت!\n━━━━━━━━━━━━━━━━━━\n${death.reason}`, victim.groupID);
    }
  } else {
    announcement += `✅ لا موتى الليلة! 🎉\n━━━━━━━━━━━━━━━━━━\n💪 الجميع نجا!\n\n`;
  }
  if (results.length > 0) {
    announcement += `📰 أحداث الليلة:\n━━━━━━━━━━━━━━━━━━\n`;
    results.forEach(r => { announcement += `• ${r}\n`; });
    announcement += `\n`;
  }
  announcement += `━━━━━━━━━━━━━━━━━━\n\n${formatGameStatus(g)}`;
  await mqtt.sendMessage(announcement, g.main);
  const endResult = checkGameEnd(g);
  if (endResult.ended) {
    return handleGameEnd(mqtt, g, endResult, usersData);
  }
  setTimeout(() => {
    startDayPhase(mqtt, g.id, usersData);
  }, 3000);
}

async function startDayPhase(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  g.phase = "day";
  g.votes = {};
  g.voteLocked = {};
  const playersList = await listPlayers(g, usersData);
  const msg = `${formatPhaseMessage("day", g.day)}\n\n━━━━━━━━━━━━━━━━━━\n\n👥 الأحياء:\n━━━━━━━━━━━━━━━━━━\n\n${playersList}\n\n━━━━━━━━━━━━━━━━━━\n\n💬 ناقشوا وحللوا المعلومات!\n🕵️ من المشبوه في نظركم?\n\n━━━━━━━━━━━━━━━━━━\n\n${formatGameStatus(g)}\n\n━━━━━━━━━━━━━━━━━━\n\n⏱️ دقيقة واحدة للنقاش!`;
  await mqtt.sendMessage(msg, g.main);
  dayPhaseTimer(mqtt, gameID, usersData);
}

function dayPhaseTimer(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const timer1 = setTimeout(async () => {
    if (g.phase === "day") {
      await mqtt.sendMessage("⏰ تبقى 30 ثانية للنقاش! 💬", g.main);
    }
  }, 30000);
  const timer2 = setTimeout(() => {
    if (g.phase === "day") {
      startVoting(mqtt, gameID, usersData);
    }
  }, 60000);
  addTimer(gameID, timer1);
  addTimer(gameID, timer2);
}

async function startVoting(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  g.phase = "voting";
  g.votes = {};
  g.voteLocked = {};
  await mqtt.sendMessage(`${formatPhaseMessage("voting", g.day)}\n\n━━━━━━━━━━━━━━━━━━\n\n⚖️ حان وقت العدالة!\n🎯 اختاروا بحكمة!\n\n⏱️ دقيقة واحدة للتصويت!`, g.main);
  for (const p of alive(g)) {
    if (p.blackmailed) {
      await mqtt.sendMessage(`🤫 تم ابتزازك!\n━━━━━━━━━━━━━━━━━━\n🚫 لا يمكنك التصويت اليوم!\n😔 الصمت إجباري`, p.groupID);
      continue;
    }
    const playersList = await listPlayers(g, usersData, false);
    let msg = `🗳️ التصويت - اليوم ${g.day}\n━━━━━━━━━━━━━━━━━━\n\n⚖️ اختر رقم اللاعب:\n${playersList}\n━━━━━━━━━━━━━━━━━━\n\n💡 أو اكتب: تخطي`;
    if (hasPurchase(p.userID, "vote_power")) {
      msg += `\n⚡ لديك قوة تصويت! (+1 صوت)`;
    }
    msg += `\n\n⚠️ فكر جيداً! 🧠`;
    if (!p.groupID) continue;
    try {
      const { messageID } = await mqtt.sendMessage(msg, p.groupID);
      global.YamiBot.onReply.set(messageID, {
        commandName: g.commandName,
        gameID: g.id,
        playerID: p.userID,
        type: "voting"
      });
    } catch (error) {
      console.error(`[MAFIA42] Failed to send vote message to ${p.userID}:`, error);
    }
  }
  votingTimer(mqtt, gameID, usersData);
}

function votingTimer(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const timer1 = setTimeout(async () => {
    if (g.phase === "voting") {
      await mqtt.sendMessage("⏰ تبقى 30 ثانية للتصويت! 🗳️", g.main);
    }
  }, 30000);
  const timer2 = setTimeout(() => {
    if (g.phase === "voting") {
      resolveVotes(mqtt, gameID, usersData);
    }
  }, 60000);
  addTimer(gameID, timer1);
  addTimer(gameID, timer2);
}

async function handleVote(Reply, event, mqtt, usersData) {
  const g = global.MafiaGames.games[Reply.gameID];
  if (!g || g.phase !== "voting") return;
  const voter = g.players[Reply.playerID];
  if (!voter || !voter.alive || voter.blackmailed) return;
  if (g.voteLocked[voter.userID]) {
    return mqtt.sendMessage("🔒 لقد صوّتت بالفعل!\n━━━━━━━━━━━━━━━━━━\n⚠️ لا يمكن التغيير", voter.groupID);
  }
  const input = event.body.trim();
  if (input === "تخطي") {
    g.votes[voter.userID] = "skip";
    g.voteLocked[voter.userID] = true;
    const voterName = await usersData.getName(voter.userID);
    await mqtt.sendMessage(`⏭️ ${voterName} صوّت للتخطي`, g.main);
    return mqtt.sendMessage("✅ اخترت التخطي\n━━━━━━━━━━━━━━━━━━\n⏭️ لا إقصاء اليوم", voter.groupID);
  }
  const targetIndex = parseInt(input);
  if (isNaN(targetIndex)) {
    return mqtt.sendMessage("❌ رد برقم صحيح أو: تخطي 🔢", voter.groupID);
  }
  const target = getPlayerByIndex(g, targetIndex);
  if (!target) {
    return mqtt.sendMessage("❌ رقم خاطئ! تحقق من القائمة 📋", voter.groupID);
  }
  if (target.userID === voter.userID) {
    return mqtt.sendMessage("⚠️ لا يمكنك التصويت لنفسك! 🚫\n━━━━━━━━━━━━━━━━━━\n😅 اختر شخصاً آخر", voter.groupID);
  }
  g.votes[voter.userID] = target.userID;
  g.voteLocked[voter.userID] = true;
  const targetName = await usersData.getName(target.userID);
  const voterName = await usersData.getName(voter.userID);
  await mqtt.sendMessage(`🗳️ تم التصويت لإقصاء ${targetName}`, g.main);
  return mqtt.sendMessage(`✅ صوّتت لإقصاء ${targetName}\n━━━━━━━━━━━━━━━━━━\n🔒 تم تسجيل صوتك!`, voter.groupID);
}

async function resolveVotes(mqtt, gameID, usersData) {
  const g = global.MafiaGames.games[gameID];
  if (!g) return;
  const voteCounts = {};
  for (const [voterID, targetID] of Object.entries(g.votes)) {
    if (targetID === "skip") continue;
    const voter = g.players[voterID];
    if (!voter || !voter.alive) continue;
    let voteWeight = 1;
    if (voter.role === "mayor" && g.mayorRevealed) {
      voteWeight = 3;
    }
    if (hasPurchase(voterID, "vote_power")) {
      voteWeight += 1;
      removePurchaseFromInventory(voterID, "vote_power");
    }
    voteCounts[targetID] = (voteCounts[targetID] || 0) + voteWeight;
  }
  let maxVotes = 0;
  let candidates = [];
  for (const [targetID, count] of Object.entries(voteCounts)) {
    if (count > maxVotes) {
      maxVotes = count;
      candidates = [targetID];
    } else if (count === maxVotes) {
      candidates.push(targetID);
    }
  }
  let msg = `📊 نتائج التصويت 📊\n━━━━━━━━━━━━━━━━━━\n\n`;
  const sortedVotes = Object.entries(voteCounts).sort((a, b) => b[1] - a[1]);
  for (const [targetID, count] of sortedVotes) {
    const target = g.players[targetID];
    const targetName = await usersData.getName(target.userID);
    msg += `🎯 ${targetName}: ${count} ${count === 1 ? 'صوت' : 'أصوات'}\n`;
  }
  msg += `\n━━━━━━━━━━━━━━━━━━\n\n`;
  let executed = null;
  if (candidates.length === 0 || maxVotes === 0) {
    msg += `⏭️ لا إقصاء اليوم!\n😌 الجميع نجا`;
  } else if (candidates.length === 1) {
    executed = g.players[candidates[0]];
    const roleData = ROLES[executed.role];
    const executedName = await usersData.getName(executed.userID);
    if (executed.role === "jester") {
      executed.alive = false;
      msg += `🎭 تم إقصاء: ${executedName}\n\n🤡 كان مهرجاً!\n🎉 فاز بتحقيق هدفه!\n😂 ضحك على الجميع!`;
      await mqtt.sendMessage(`🎉 فزت! 🤡\n━━━━━━━━━━━━━━━━━━\n✅ تم التصويت عليك!\n😂 هدفك تحقق!\n🎭 الفوز بالخسارة!`, executed.groupID);
      await mqtt.sendMessage(msg, g.main);
      return handleGameEnd(mqtt, g, { ended: true, winner: "neutral", specialPlayer: executed }, usersData);
    }
    executed.alive = false;
    executed.lynched = true;
    msg += `☠️ تم إقصاء: ${executedName}`;
    const execStats = initPlayerStats(executed.userID);
    execStats.deaths++;
    updatePlayerStats(executed.userID, execStats);
    const executioner = Object.values(g.players).find(p => 
      p.role === "executioner" && 
      p.executionerTarget === executed.userID &&
      p.alive
    );
    if (executioner) {
      msg += `\n\n🪓 كان هدف الجلاد!\n🎉 فاز الجلاد!\n🎯 خطة محكمة!`;
      await mqtt.sendMessage(`🎉 فزت! 🪓\n━━━━━━━━━━━━━━━━━━\n✅ تم إقصاء هدفك!\n🎯 خطة نجحت!\n🏆 انتصار محكم!`, executioner.groupID);
      await mqtt.sendMessage(msg, g.main);
      return handleGameEnd(mqtt, g, { ended: true, winner: "neutral", specialPlayer: executioner }, usersData);
    }
  } else {
    const tiedNames = [];
    for (const id of candidates) {
      const name = await usersData.getName(g.players[id].userID);
      tiedNames.push(name);
    }
    msg += `⚖️ تعادل!\n${tiedNames.join(" و ")}\n\n⏭️ لا إقصاء!\n🤔 قرار صعب`;
  }
  await mqtt.sendMessage(msg, g.main);
  if (executed) {
    const roleData = ROLES[executed.role];
    await mqtt.sendMessage(`☠️ تم إقصاؤك!\n━━━━━━━━━━━━━━━━━━\n${roleData.emoji} ${roleData.name}\n📝 ${roleData.desc}`, executed.groupID);
  }
  const endResult = checkGameEnd(g);
  if (endResult.ended) {
    return handleGameEnd(mqtt, g, endResult, usersData);
  }
  setTimeout(() => {
    startNightPhase(mqtt, gameID, usersData);
  }, 3000);
}

async function handleGameEnd(mqtt, g, endResult, usersData) {
  const { winner, specialPlayer } = endResult;
  let winnerPlayers = [];
  if (winner === "mafia") {
    winnerPlayers = Object.values(g.players).filter(p => ROLES[p.role].team === "mafia");
  } else if (winner === "citizen") {
    winnerPlayers = Object.values(g.players).filter(p => ROLES[p.role].team === "citizen");
  } else if (winner === "neutral" && specialPlayer) {
    winnerPlayers = [specialPlayer];
  } else if (winner === "vampire") {
    winnerPlayers = Object.values(g.players).filter(p => ROLES[p.role].team === "vampire" || p.convertedToVampire);
  }
  const report = await createGameReport(g, winner, usersData);
  let announcement = report + `\n\n🎁 الجوائز:\n━━━━━━━━━━━━━━━━━━\n\n`;
  const rewards = [];
  for (const player of winnerPlayers) {
    awardPlayer(player.userID, 2000, 200, "فوز", usersData);
    const name = await usersData.getName(player.userID);
    rewards.push(`🏆 ${name}: +2,000 💰 +200 ⭐`);
    const stats = initPlayerStats(player.userID);
    stats.wins++;
    stats.gamesPlayed++;
    updatePlayerStats(player.userID, stats);
  }
  const losers = Object.values(g.players).filter(p => 
    !winnerPlayers.some(w => w.userID === p.userID)
  );
  for (const player of losers) {
    const stats = initPlayerStats(player.userID);
    stats.losses++;
    stats.gamesPlayed++;
    if (player.alive) {
      awardPlayer(player.userID, 500, 50, "ناجٍ", usersData);
      const name = await usersData.getName(player.userID);
      rewards.push(`💪 ${name}: +500 💰 +50 ⭐ (ناجٍ)`);
    }
    updatePlayerStats(player.userID, stats);
  }
  if (rewards.length > 0) {
    announcement += rewards.slice(0, 12).join("\n");
    if (rewards.length > 12) {
      announcement += `\n... و ${rewards.length - 12} آخرين`;
    }
  }
  announcement += `\n\n━━━━━━━━━━━━━━━━━━\n💡 100 نقطة = 1 💰\n🛒 زر المتجر!`;
  updateLeaderboard();
  await mqtt.sendMessage(announcement, g.main);
  await cleanup(mqtt, g);
}

async function onReaction({ Reaction, event, api, mqtt, usersData }) {
  if (Reaction.type === "join") {
    return joinGame(mqtt, event, Reaction.gameID, usersData, api);
  }
}

async function onReply({ Reply, event, api, mqtt, usersData }) {
  try {
    if (Reply.type === "night") {
      return handleNightAction(Reply, event, mqtt, usersData);
    }
    if (Reply.type === "voting") {
      return handleVote(Reply, event, mqtt, usersData);
    }
    if (Reply.type === "shop_menu") {
      if (Reply.userID !== event.senderID) return;
      return handleShopPurchase(Reply, event, mqtt, usersData);
    }
    if (Reply.type === "shop_investigation") {
      if (Reply.playerID !== event.senderID) return;
      return handleShopInvestigation(Reply, event, mqtt, usersData);
    }
    if (Reply.type === "shop_reveal_team") {
      if (Reply.playerID !== event.senderID) return;
      return handleShopRevealTeam(Reply, event, mqtt, usersData);
    }
    if (Reply.type === "revived_action") {
      return handleRevivedAction(Reply, event, mqtt, usersData);
    }
  } catch (error) {
    console.error("[MAFIA42] ❌ Error:", error);
    await mqtt.sendMessage("❌ حدث خطأ! حاول مرة أخرى 🔄", event.threadID);
  }
}

async function handleRevivedAction(Reply, event, mqtt, usersData) {
  const g = global.MafiaGames.games[Reply.gameID];
  if (!g || g.phase !== "night") return;
  const player = g.players[Reply.playerID];
  if (!player || player.alive || !player.revived) return;
  const input = event.body.trim();
  const targetIndex = parseInt(input);
  if (isNaN(targetIndex)) {
    return mqtt.sendMessage("❌ رد برقم صحيح من القائمة! 🔢", player.groupID);
  }
  const target = getPlayerByIndex(g, targetIndex);
  if (!target) {
    return mqtt.sendMessage("❌ رقم خاطئ! تحقق من القائمة 📋", player.groupID);
  }
  const targetName = await usersData.getName(target.userID);
  const roleData = ROLES[player.revivedRole];
  const simpleActions = {
    "cop": "investigate",
    "sheriff": "sheriff_check",
    "doctor": "heal",
    "bodyguard": "bodyguard",
    "vigilante": "vigi_kill",
    "lookout": "lookout",
    "tracker": "track",
    "escort": "roleblock",
    "crusader": "crusade",
    "trapper": "trap",
    "vampire_hunter": "vh_check"
  };
  const actionType = simpleActions[player.revivedRole];
  if (actionType) {
    g.nightActions[player.userID] = { type: actionType, target: target.userID };
    const confirmations = {
      "investigate": `👮 سيتم التحقيق من ${targetName}!`,
      "sheriff_check": `⭐ سيتم فحص ${targetName}!`,
      "heal": `💊 سيتم حماية ${targetName}!`,
      "bodyguard": `🛡️ ستحرس ${targetName}!`,
      "vigi_kill": `🔫 سيتم قتل ${targetName}!`,
      "lookout": `👁️ ستراقب ${targetName}!`,
      "track": `🔎 ستتعقب ${targetName}!`,
      "roleblock": `💃 سيتم إشغال ${targetName}!`,
      "crusade": `⚔️🛡️ ستحرس ${targetName}!`,
      "trap": `🪤 سيتم نصب فخ على ${targetName}!`,
      "vh_check": `🧄 سيتم فحص ${targetName}!`
    };
    return mqtt.sendMessage(`✅ تم التأكيد!\n━━━━━━━━━━━━━━━━━━\n${confirmations[actionType]}\n━━━━━━━━━━━━━━━━━━\n💀 آخر عمل لك!`, player.groupID);
  }
}

async function sendGameHelp(mqtt, threadID) {
  const msg = `🎮 Mafia42 - المساعدة 🎮
━━━━━━━━━━━━━━━━━━

📌 الأوامر:
• مافيا - بدء لعبة 🎭
• مافيا لوحة_الشرف 🏆
• مافيا احصائياتي 📊
• مافيا متجر 🛒
• مافيا جرد 📦
• مافيا مساعدة 💡
• مافيا قواعد 📜

━━━━━━━━━━━━━━━━━━

🎭 30+ دور مختلف!
🛒 قدرات خاصة للشراء
💱 100 نقطة = 1 💰
🏆 نظام نقاط وجوائز
📊 إحصائيات شاملة

━━━━━━━━━━━━━━━━━━

⚔️ الفرق:
🔴 المافيا - القتلة الأشرار
🔵 المواطنون - الأبطال
⚪ المحايدون - أهداف خاصة
🟣 مصاصو الدماء - التحويل

━━━━━━━━━━━━━━━━━━

💡 نصائح:
• استمع للأدلة بتركيز
• حلل تصرفات اللاعبين
• لا تثق بأحد بسهولة
• استخدم قدراتك بذكاء
• تعاون مع فريقك

━━━━━━━━━━━━━━━━━━

🎯 هدفك: اكشف الأعداء وانتصر!`;
  await mqtt.sendMessage(msg, threadID);
}

async function sendGameRules(mqtt, threadID) {
  const msg = `📜 Mafia42 - القواعد 📜
━━━━━━━━━━━━━━━━━━

👥 عدد اللاعبين: 6-12

━━━━━━━━━━━━━━━━━━

⏱️ المدة الزمنية:
• الانضمام: 3 دقائق
• الليل: 40 ثانية
• النهار: 60 ثانية
• التصويت: 60 ثانية

━━━━━━━━━━━━━━━━━━

🎲 توزيع الأدوار:
• عشوائي تماماً
• 1 مافيا لكل 3.5 لاعب
• أدوار خاصة للمافيا
• أدوار قوية للمواطنين
• محايدون بأهداف فريدة

━━━━━━━━━━━━━━━━━━

🏆 شروط الفوز:

🔴 المافيا:
• عددهم ≥ الباقين

🔵 المواطنون:
• موت كل المافيا والأشرار

⚪ المحايدون:
• تحقيق أهدافهم الخاصة

🟣 مصاصو الدماء:
• نصف المدينة مصاصي دماء

━━━━━━━━━━━━━━━━━━

💰 نظام المكافآت:
• فوز: 2000 💰 + 200 ⭐
• نجاة: 500 💰 + 50 ⭐
• قتل: نقاط إضافية
• تصويت صحيح: +5 نقاط

━━━━━━━━━━━━━━━━━━

🛒 المتجر:
• حياة إضافية: 5000 💰
• تحقيق خاص: 3000 💰
• حماية شخصية: 2500 💰
• قوة تصويت: 4000 💰
• كشف فريق: 3500 💰

━━━━━━━━━━━━━━━━━━

💱 سعر الصرف:
100 نقطة = 1 💰

━━━━━━━━━━━━━━━━━━

⚠️ قواعد مهمة:
• لا كشف للأدوار إلا بالتصويت
• ممنوع التحدث أثناء الليل
• استخدم قدراتك بحكمة
• التعاون مع الفريق ضروري

━━━━━━━━━━━━━━━━━━

🎮 استمتع باللعبة!`;
  await mqtt.sendMessage(msg, threadID);
}

function cleanupOldGames() {
  const now = Date.now();
  const maxAge = 24 * 60 * 60 * 1000;
  for (const [id, game] of Object.entries(global.MafiaGames.games)) {
    if (now - game.createdAt > maxAge) {
      console.log(`[MAFIA42] 🧹 Cleaning old game: ${id}`);
      clearAllTimers(id);
      delete global.MafiaGames.games[id];
    }
  }
}

setInterval(() => {
  cleanupOldGames();
}, 60 * 60 * 1000);

module.exports = {
  config: {
    name: "مافيا",
    aliases: ["mafiav2", "mafia42"],
    description: "🎭 Mafia42 - لعبة الخداع الاجتماعي المحسّنة! 🎮",
    usage: "مافيا للبدء",
    cooldown: 5,
    role: 0,
    author: "Mafia42 v2.5",
    version: "2.5.4"
  },
  onLoad,
  onStart,
  onReply,
  onReaction
};
