const axios = require("axios");

module.exports = {
  config: {
    name: "translate",
    aliases: ["tr"],
    version: "1.2",
    author: "Allou Mohamed",
    countDown: 5,
    role: 0,
    description: "Translate text using Google Translate API.",
    category: "tools",
    guide: {
      syntax: "{pn} <target_lang> <text>",
      params: {
        target_lang: "The language code to translate to (e.g., en, id, fr)",
        text: "The text you want to translate"
      },
      usage: "{pn} en saya suka kamu"
    }
  },

  onStart: async function ({ message, args, event, commandName, prefix }) {
    const targetLang = args[0];
    const replyText = event.messageReply?.body;
    const textToTranslate = args.slice(1).join(" ") || replyText;

    if (!targetLang || !textToTranslate) {
      return message.reply(`#%bdUsage%:\n\n${prefix}${commandName}%bd <target_lang> <text or reply to text>%`);
    }

    try {
      const res = await axios.get("https://translate.googleapis.com/translate_a/single", {
        params: {
          client: "gtx",
          sl: "auto",
          tl: targetLang,
          dt: "t",
          q: textToTranslate
        }
      });

      const translated = res.data[0].map(part => part[0]).join("");

      return message.reply(`#%bdTranslation%:\n\n${translated}`);
    } catch (err) {
      console.error(err);
      return message.reply("#%bdError%:\n\nFailed to translate. Check the %bdlanguage% code or try again later.");
    }
  }
};