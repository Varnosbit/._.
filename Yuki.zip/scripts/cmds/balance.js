module.exports = {
	config: {
		name: "balance",
		aliases: ["رصيدي", "رصيد", "bal", "فلوسي"],
		version: "1.3",
		author: "AllouMohamed",
		countDown: 5,
		role: 0,
		description: {
			vi: "xem số tiền hiện có của bạn hoặc người được tag",
			en: "view your money or the money of the tagged person",
			ar: "عرض الرصيد"
		},
		category: "economy",
		guide: {
			vi: "   {pn}: xem số tiền của bạn"
				+ "\n   {pn} <@tag>: xem số tiền của người được tag",
			en: "   {pn}: view your money"
				+ "\n   {pn} <@tag>: view the money of the tagged person",
			ar: "{pn} لعرض رصيدك الشخصي\n{pn} <@tag> لعرض رصيد شخص آخر\n{pn} الأغنى أو {pn} top لعرض أغنى 5 أشخاص"
		},
		ar: true
	},

	langs: {
		vi: {
			money: "Bạn đang có %1$",
			moneyOf: "%1 đang có %2$"
		},
		en: {
			money: "You have %1$",
			moneyOf: "%1 has %2$",
			topList: "🏆 Top richest:\n%1"
		},
		ar: {
		    money: "بحوزتك %1 دينار.",
		    moneyOf: "%1 لديه %2 دينار.",
		    topList: "🏆 قائمة أغنى 5 أشخاص:\n%1"
		}
	},

	/** دالة لتنسيق الأعداد الكبيرة بجميع الأحرف الممكنة حتى ∞ */
	formatMoney: function (num) {
	    if (num >= Number.MAX_SAFE_INTEGER) return "∞"; // المال اللانهائي
	    const units = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"];
	    let unitIndex = 0;
	    while (num >= 1000 && unitIndex < units.length - 1) {
	        num /= 1000;
	        unitIndex++;
	    }
	    return num.toFixed(2) + units[unitIndex];
	},

	onStart: async function ({ message, usersData, event, getLang, args }) {
	    if (args[0] === "الأغنى" || args[0] === "top") {
	        const users = await usersData.getAll();
	        const top5Users = users
	            .sort((a, b) => (parseInt(b.money) || 0) - (parseInt(a.money) || 0))
	            .slice(0, 5);

	        const decoratedList = top5Users.map((user, index) => {
	            let medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '⭐';
	            return `${medal} ${user.name} - ${this.formatMoney(user.money)} دينار`;
	        }).join('\n');

	        return message.reply(getLang("topList", decoratedList));
	    }

	    if (Object.keys(event.mentions).length > 0) {
	        let msg = "";
	        for (const uid of Object.keys(event.mentions)) {
	            const userMoney = await usersData.get(uid, "money") || 0;
	            msg += getLang("moneyOf", event.mentions[uid].replace("@", ""), this.formatMoney(userMoney)) + '\n';
	        }
	        return message.reply(msg);
	    }

	    const userData = await usersData.get(event.senderID) || { money: 0 };
	    message.reply(getLang("money", this.formatMoney(userData.money)));
	}
};
